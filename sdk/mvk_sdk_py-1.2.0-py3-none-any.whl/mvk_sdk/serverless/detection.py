"""Centralized serverless environment detection and configuration for MVK SDK.

This module provides a single source of truth for serverless environment detection
and configuration, eliminating the scattered logic across multiple files.
"""

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger("mvk.serverless_detection")


# Centralized serverless environment detection
def detect_serverless_environment() -> Optional[str]:
    """Single source of truth for serverless environment detection.

    Supports detection of:
    - AWS Lambda (including Lambda@Edge)
    - Google Cloud Functions (1st and 2nd gen)
    - Azure Functions (all runtime versions)
    - Oracle Functions
    - Vercel (Edge Runtime and Serverless Functions)
    - Cloudflare Workers
    - Netlify Functions
    - Railway Functions
    - Render Functions

    Returns:
        Serverless environment type or None if not in serverless environment
    """
    # Check for forced serverless mode (highest priority)
    if os.environ.get("MVK_SERVERLESS", "").lower() == "true":
        return "forced"

    # AWS Lambda (including Lambda@Edge)
    if "AWS_LAMBDA_FUNCTION_NAME" in os.environ:
        return "lambda"

    # Google Cloud Functions (1st and 2nd gen)
    # FUNCTION_TARGET is the primary indicator in newer runtimes (2nd gen)
    # K_SERVICE and FUNCTION_NAME are fallbacks for older runtimes
    if (
        "FUNCTION_TARGET" in os.environ
        or "K_SERVICE" in os.environ
        or "FUNCTION_NAME" in os.environ
    ):
        return "gcp"

    # Azure Functions (all runtime versions) - FIXED: check for non-empty values
    if os.environ.get("FUNCTIONS_WORKER_RUNTIME"):
        return "azure"

    # Oracle Functions - ADDED: missing support
    if "OCI_FUNCTION_ID" in os.environ or "OCI_FUNCTION_APPLICATION_ID" in os.environ:
        return "oracle"

    # Vercel (Edge Runtime and Serverless Functions)
    if "VERCEL" in os.environ:
        return "vercel"

    # Cloudflare Workers
    if "CLOUDFLARE_WORKERS" in os.environ:
        return "cloudflare_workers"

    # Netlify Functions
    if "NETLIFY" in os.environ:
        return "netlify"

    # Railway Functions
    if "RAILWAY_ENVIRONMENT" in os.environ:
        return "railway"

    # Render Functions
    if "RENDER" in os.environ:
        return "render"

    return None


def is_serverless_environment() -> bool:
    """Check if running in a serverless environment.

    Returns:
        True if in serverless environment, False otherwise
    """
    return detect_serverless_environment() is not None


# Centralized serverless configurations with provider-specific optimizations
SERVERLESS_CONFIGURATIONS: Dict[str, Dict[str, Any]] = {
    # Generic serverless (fallback)
    "default": {
        "batching": {"max_items": 1, "max_interval_ms": 100},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 3, "max_retries": 1},
    },
    # AWS Lambda optimizations
    "lambda": {
        "batching": {"max_items": 1, "max_interval_ms": 50},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 5, "max_retries": 2},
    },
    # Google Cloud Functions optimizations
    # Note: GCP Cloud Functions 2nd gen is Knative-based with different shutdown behavior
    # Timeout of 5s is reasonable for span export (typical export <1s)
    # Max 100ms batch interval ensures frequent exports for reliability
    "gcp": {
        "batching": {"max_items": 1, "max_interval_ms": 100},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 5, "max_retries": 2},
    },
    # Azure Functions optimizations
    "azure": {
        "batching": {"max_items": 1, "max_interval_ms": 50},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 2, "max_retries": 1},
    },
    # Oracle Functions optimizations - NEW
    "oracle": {
        "batching": {"max_items": 1, "max_interval_ms": 50},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 3, "max_retries": 1},
    },
    # Vercel optimizations
    "vercel": {
        "batching": {"max_items": 1, "max_interval_ms": 10},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 1, "max_retries": 0},
    },
    # Cloudflare Workers optimizations
    "cloudflare_workers": {
        "batching": {"max_items": 1, "max_interval_ms": 5},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 1, "max_retries": 0},
    },
    # Netlify Functions optimizations
    "netlify": {
        "batching": {"max_items": 1, "max_interval_ms": 50},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 2, "max_retries": 1},
    },
    # Railway Functions optimizations
    "railway": {
        "batching": {"max_items": 1, "max_interval_ms": 100},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 5, "max_retries": 2},
    },
    # Render Functions optimizations
    "render": {
        "batching": {"max_items": 1, "max_interval_ms": 100},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 5, "max_retries": 2},
    },
    # Forced serverless mode
    "forced": {
        "batching": {"max_items": 1, "max_interval_ms": 100},
        "failed_batch_disk": {"enabled": False},
        "exporter": {"timeout": 3, "max_retries": 1},
    },
}


def get_serverless_config(provider: Optional[str] = None) -> Dict[str, Any]:
    """Get serverless configuration for specific provider.

    Args:
        provider: Serverless provider type (auto-detected if None)

    Returns:
        Configuration optimized for the serverless provider
    """
    if provider is None:
        provider = detect_serverless_environment()

    # Handle case where provider is None (not in serverless environment)
    if provider is None:
        provider = "default"

    config = SERVERLESS_CONFIGURATIONS.get(provider, SERVERLESS_CONFIGURATIONS["default"])
    logger.debug(f"Using serverless config for {provider}: {config}")

    # Return a deep copy to avoid modifying the original configuration
    import copy

    return copy.deepcopy(config)


def apply_serverless_optimizations(config: Dict[str, Any]) -> Dict[str, Any]:
    """Apply serverless optimizations to configuration.

    Args:
        config: Base configuration dictionary

    Returns:
        Configuration with serverless optimizations applied
    """
    result = config.copy()

    # Detect serverless environment
    serverless_type = detect_serverless_environment()
    if serverless_type is None:
        logger.debug("No serverless environment detected, returning original config")
        return result

    logger.info(f"🔧 Applying serverless optimizations for {serverless_type}...")

    # Get provider-specific configuration
    serverless_config = get_serverless_config(serverless_type)

    # Apply optimizations with deep merge
    for key, value in serverless_config.items():
        if isinstance(value, dict) and key in result and isinstance(result[key], dict):
            # Deep merge dictionaries
            result[key] = {**result[key], **value}
            logger.debug(f"   Merged {key}: {value}")
        else:
            # Replace with serverless value
            result[key] = value
            logger.debug(f"   Set {key}: {value}")

    # Add serverless metadata
    result["serverless"] = {
        "enabled": True,
        "type": serverless_type,
    }

    logger.info(f"✅ Serverless optimizations applied successfully for {serverless_type}")
    return result


def get_serverless_aware_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Get configuration with serverless awareness.

    This function combines serverless detection and optimization in one call.

    Args:
        config: Base configuration dictionary

    Returns:
        Configuration adjusted for serverless if detected, otherwise original config
    """
    if is_serverless_environment():
        return apply_serverless_optimizations(config)
    return config


# Backward compatibility aliases
def detect_environment() -> Optional[str]:
    """Backward compatibility alias for detect_serverless_environment()."""
    return detect_serverless_environment()


def detect_serverless() -> Optional[str]:
    """Backward compatibility alias for detect_serverless_environment()."""
    return detect_serverless_environment()


def is_serverless() -> bool:
    """Backward compatibility alias for is_serverless_environment()."""
    return is_serverless_environment()


# Legacy configuration for backward compatibility
SERVERLESS_CONFIG = SERVERLESS_CONFIGURATIONS["default"]
