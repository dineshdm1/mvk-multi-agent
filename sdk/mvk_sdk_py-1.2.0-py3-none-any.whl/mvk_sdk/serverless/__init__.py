"""MVK SDK v1.1 Serverless Support.

This module provides serverless environment detection and optimization
for AWS Lambda, Google Cloud Functions, Azure Functions, and Vercel.
"""

import asyncio
import functools
import logging
import os
import time
from typing import Any, Awaitable, Callable, Dict, Optional, TypeVar, overload

from ..error_handling import safe_wrapper

logger = logging.getLogger("mvk.serverless")

T = TypeVar("T")

# Serverless configuration optimizations - now centralized in detection.py
# Import for backward compatibility
from .detection import SERVERLESS_CONFIG


def detect_environment() -> Optional[str]:
    """Detect the serverless environment.

    Returns:
        Type of serverless environment or None
    """
    # Use centralized detection logic
    from .detection import detect_serverless_environment

    return detect_serverless_environment()


def is_serverless() -> bool:
    """Check if running in a serverless environment.

    Returns:
        True if in serverless environment
    """
    # Use centralized detection logic
    from .detection import is_serverless_environment

    return is_serverless_environment()


def get_serverless_config(provider: Optional[str] = None) -> Dict[str, Any]:
    """Get serverless-optimized configuration.

    Args:
        provider: Serverless provider type (auto-detected if None)

    Returns:
        Serverless configuration dictionary
    """
    # Use centralized configuration logic
    from .detection import get_serverless_config as _get_serverless_config

    return _get_serverless_config(provider)


def apply_serverless_optimizations(config: Dict[str, Any]) -> Dict[str, Any]:
    """Apply serverless optimizations to configuration.

    Args:
        config: Base configuration

    Returns:
        Configuration with serverless optimizations
    """
    # Use centralized optimization logic
    from .detection import apply_serverless_optimizations as _apply_serverless_optimizations

    return _apply_serverless_optimizations(config)


def initialize_serverless_support() -> Dict[str, Any]:
    """Initialize serverless support with comprehensive logging.

    Returns:
        Dictionary with initialization details
    """
    logger.info("🔧 Initializing MVK SDK Serverless Support...")

    # Detect environment
    env = detect_environment()
    is_serverless_env = is_serverless()

    logger.info(f"   Environment detection: {env}")
    logger.info(f"   Is serverless: {is_serverless_env}")

    # Get serverless config
    serverless_config = get_serverless_config()
    logger.info(f"   Serverless config: {serverless_config}")

    # Check for environment variables
    env_vars = {
        "MVK_SERVERLESS": os.environ.get("MVK_SERVERLESS"),
        "MVK_MODE": os.environ.get("MVK_MODE"),
        "AWS_LAMBDA_FUNCTION_NAME": os.environ.get("AWS_LAMBDA_FUNCTION_NAME"),
        "K_SERVICE": os.environ.get("K_SERVICE"),
        "FUNCTION_NAME": os.environ.get("FUNCTION_NAME"),
        "FUNCTIONS_WORKER_RUNTIME": os.environ.get("FUNCTIONS_WORKER_RUNTIME"),
        "VERCEL": os.environ.get("VERCEL"),
    }

    logger.info("   Environment variables:")
    for key, value in env_vars.items():
        if value is not None:
            logger.info(f"     {key}={value}")

    # Test tracer provider
    try:
        provider = get_tracer_provider()
        logger.info(f"   Tracer provider: {type(provider).__name__}")
    except Exception as e:
        logger.warning(f"   Tracer provider error: {e}")

    logger.info("✅ MVK SDK Serverless Support initialized")

    return {
        "environment": env,
        "is_serverless": is_serverless_env,
        "config": serverless_config,
        "env_vars": env_vars,
    }


def get_serverless_aware_config(base_config: Dict[str, Any]) -> Dict[str, Any]:
    """Get configuration with serverless detection and optimization.

    Args:
        base_config: Base configuration

    Returns:
        Configuration with serverless optimizations if applicable
    """
    # Use centralized serverless-aware configuration logic
    from .detection import get_serverless_aware_config as _get_serverless_aware_config

    # Start with the base config
    config = base_config.copy()

    logger.info("🔍 Checking for serverless environment...")

    # Check for mode from environment
    if "MVK_MODE" in os.environ:
        config["mode"] = os.environ["MVK_MODE"]
        logger.info(f"   Mode from environment: {os.environ['MVK_MODE']}")

    # Apply centralized serverless optimizations
    return _get_serverless_aware_config(config)


def _get_opentelemetry_processor(provider):
    """Get OpenTelemetry span processor with comprehensive access patterns.

    This function implements multiple access patterns to reliably retrieve
    the active span processor from OpenTelemetry's ProxyTracerProvider.

    Args:
        provider: OpenTelemetry tracer provider

    Returns:
        Span processor instance or None if not found
    """
    # Pattern 1: Direct processor access
    try:
        if hasattr(provider, "_active_span_processor"):
            processor = provider._active_span_processor
            if processor is not None:
                logger.debug("Found processor via _active_span_processor")
                return processor
    except Exception:
        pass

    # Pattern 2: Via tracer provider
    try:
        if hasattr(provider, "_tracer_provider"):
            tracer_provider = provider._tracer_provider
            if hasattr(tracer_provider, "_active_span_processor"):
                processor = tracer_provider._active_span_processor
                if processor is not None:
                    logger.debug("Found processor via tracer_provider._active_span_processor")
                    return processor
    except Exception:
        pass

    # Pattern 3: Via span processor registry
    try:
        if hasattr(provider, "_span_processors"):
            processors = provider._span_processors
            if processors:
                logger.debug("Found processor via _span_processors")
                return processors[0]  # Return first processor
    except Exception:
        pass

    # Pattern 4: Method-based access
    try:
        if hasattr(provider, "get_active_span_processor"):
            processor = provider.get_active_span_processor()
            if processor is not None:
                logger.debug("Found processor via get_active_span_processor()")
                return processor
    except Exception:
        pass

    # Pattern 5: Legacy fallback patterns
    try:
        processor = getattr(provider, "get_active_span_processor", lambda: None)()
        if processor is not None:
            logger.debug("Found processor via legacy get_active_span_processor")
            return processor
    except Exception:
        pass

    try:
        processor = getattr(provider, "_active_span_processor", None)
        if processor is not None:
            logger.debug("Found processor via legacy _active_span_processor")
            return processor
    except Exception:
        pass

    logger.debug("No OpenTelemetry processor found with any access pattern")
    return None


def get_tracer_provider():
    """Get the current tracer provider.

    Returns:
        Tracer provider instance
    """
    # Import here to avoid circular dependency
    try:
        from opentelemetry import trace  # type: ignore

        return trace.get_tracer_provider()
    except (ImportError, ModuleNotFoundError) as e:
        # Fall back to MVK tracer when OpenTelemetry is not available
        logger.debug("OpenTelemetry not available, falling back to MVK tracer: %s", e)
        from ..mvk_tracer import get_tracer

        return get_tracer()
    except Exception as e:
        # Handle any other unexpected errors
        logger.debug("Unexpected error getting tracer provider, falling back to MVK tracer: %s", e)
        from ..mvk_tracer import get_tracer

        return get_tracer()


def force_flush(timeout_ms: int = 1000) -> bool:
    """Force flush all pending spans.

    Args:
        timeout_ms: Timeout in milliseconds

    Returns:
        True if flush succeeded, False otherwise
    """
    try:
        # Prefer provider path first (integration asserts this path)
        try:
            provider = get_tracer_provider()
        except Exception as e:
            logger.debug("Failed to get tracer provider: %s", e)
            provider = None

        if provider:
            try:
                # Check if provider has direct force_flush method (MVK tracer case)
                if hasattr(provider, "force_flush"):
                    start_time = time.time()
                    result = provider.force_flush(timeout_ms)
                    elapsed = (time.time() - start_time) * 1000
                    if elapsed > timeout_ms:
                        logger.warning(f"Force flush timed out after {elapsed:.0f}ms")
                        return False
                    logger.debug(f"Force flush completed in {elapsed:.0f}ms")
                    return bool(result)

                # Try OpenTelemetry provider path with comprehensive access patterns
                processor = _get_opentelemetry_processor(provider)

                if processor:
                    start_time = time.time()
                    if hasattr(processor, "force_flush"):
                        result = processor.force_flush(timeout_millis=timeout_ms)
                    elif hasattr(processor, "shutdown"):
                        # Fallback to shutdown if force_flush not available
                        result = processor.shutdown(timeout_millis=timeout_ms)
                    else:
                        logger.warning("Span processor does not support flush")
                        result = False

                    elapsed = (time.time() - start_time) * 1000
                    if elapsed > timeout_ms:
                        logger.warning(f"Force flush timed out after {elapsed:.0f}ms")
                        return False

                    logger.debug(f"Force flush completed in {elapsed:.0f}ms")
                    return bool(result)
            except Exception as e:
                # If provider path errors, fall through to MVK tracer path
                logger.debug(
                    f"Provider force flush failed, falling back to MVK tracer: {e}",
                    exc_info=True,
                )
                pass

        # Fallback to MVK tracer, and log via mvk_tracer logger on error
        try:
            from ..mvk_tracer import get_tracer
            from ..mvk_tracer import logger as tracer_logger

            tracer = get_tracer()
            processor = getattr(tracer, "_processor", None)
            if processor and hasattr(processor, "force_flush"):
                try:
                    return bool(processor.force_flush(timeout_millis=timeout_ms))
                except Exception as e:  # pylint: disable=broad-except
                    try:
                        tracer_logger.exception("Error during processor force flush: %s", e)
                    except Exception as log_err:
                        # Logging itself failed, but we must not break - this is extremely rare
                        import sys

                        print(
                            f"ERROR: Failed to log processor force flush error: {log_err}",
                            file=sys.stderr,
                        )
                        pass
                    return False
        except ImportError as e:
            logger.debug(f"Failed to import MVK tracer for force flush: {e}", exc_info=True)
            pass

        logger.warning("No tracer provider or MVK tracer available for flush")
        return False

    except Exception:  # pylint: disable=broad-except
        logger.exception("Error during force flush")
        return False


def lambda_handler(flush_timeout_ms: int = 1000) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator for AWS Lambda handlers with automatic flush.

    Args:
        flush_timeout_ms: Timeout for flush in milliseconds

    Returns:
        Decorator function
    """

    def decorator(handler_func: Callable[..., T]) -> Callable[..., T]:
        # Check if handler is async
        if asyncio.iscoroutinefunction(handler_func):

            @functools.wraps(handler_func)
            async def async_wrapper(*args, **kwargs) -> T:
                try:
                    result_typed: T = await handler_func(*args, **kwargs)  # type: ignore[misc]
                    return result_typed
                finally:
                    # Call module-level force_flush that tests patch
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return async_wrapper  # type: ignore[return-value]
        else:

            @functools.wraps(handler_func)
            def sync_wrapper(*args, **kwargs) -> T:
                try:
                    result: T = handler_func(*args, **kwargs)
                    return result
                finally:
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return sync_wrapper

    return decorator


def gcp_http_handler(
    flush_timeout_ms: int = 1000,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator for GCP Cloud Functions HTTP handlers with automatic flush.

    Works with both sync and async HTTP handler functions.

    Args:
        flush_timeout_ms: Timeout for flush in milliseconds

    Returns:
        Decorator function

    Example:
        @gcp_http_handler(flush_timeout_ms=1000)
        def my_function(request):
            # Use SDK here
            return "OK"
    """

    def decorator(handler_func: Callable[..., T]) -> Callable[..., T]:
        # Check if handler is async
        if asyncio.iscoroutinefunction(handler_func):

            @functools.wraps(handler_func)
            async def async_wrapper(*args, **kwargs) -> T:
                try:
                    result_typed: T = await handler_func(*args, **kwargs)  # type: ignore[misc]
                    return result_typed
                finally:
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return async_wrapper  # type: ignore[return-value]
        else:

            @functools.wraps(handler_func)
            def sync_wrapper(*args, **kwargs) -> T:
                try:
                    result: T = handler_func(*args, **kwargs)
                    return result
                finally:
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return sync_wrapper

    return decorator


def gcp_event_handler(
    flush_timeout_ms: int = 1000,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator for GCP Cloud Functions event-driven handlers with automatic flush.

    Works with both sync and async event handler functions.

    Args:
        flush_timeout_ms: Timeout for flush in milliseconds

    Returns:
        Decorator function

    Example:
        @gcp_event_handler(flush_timeout_ms=1000)
        def my_function(event, context):
            # Use SDK here
            pass
    """

    def decorator(handler_func: Callable[..., T]) -> Callable[..., T]:
        # Check if handler is async
        if asyncio.iscoroutinefunction(handler_func):

            @functools.wraps(handler_func)
            async def async_wrapper(*args, **kwargs) -> T:
                try:
                    result_typed: T = await handler_func(*args, **kwargs)  # type: ignore[misc]
                    return result_typed
                finally:
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return async_wrapper  # type: ignore[return-value]
        else:

            @functools.wraps(handler_func)
            def sync_wrapper(*args, **kwargs) -> T:
                try:
                    result: T = handler_func(*args, **kwargs)
                    return result
                finally:
                    from mvk_sdk.serverless import force_flush as _ff

                    _ff(timeout_ms=flush_timeout_ms)

            return sync_wrapper

    return decorator


class ServerlessSpanProcessor:
    """Span processor optimized for serverless environments.

    This processor exports spans immediately (batch size = 1)
    to avoid data loss in ephemeral environments.
    """

    def __init__(self, exporter):
        """Initialize the processor.

        Args:
            exporter: The span exporter to use
        """
        self.exporter = exporter
        self.spans = []

    def on_start(self, span, parent_context=None):
        """Called when a span is started.

        Args:
            span: The span that was started
            parent_context: Parent context
        """
        pass  # No action needed on start

    def on_end(self, span):
        """Called when a span is ended.

        Args:
            span: The span that was ended
        """
        # Export immediately in serverless
        try:
            self.exporter.export([span])
            logger.debug(f"Exported span immediately: {span}")
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to export span in serverless mode")

    def shutdown(self, timeout_millis=30000):
        """Shutdown the processor.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            True if shutdown succeeded
        """
        try:
            if hasattr(self.exporter, "shutdown"):
                return self.exporter.shutdown(timeout_millis)
            return True
        except Exception:  # pylint: disable=broad-except
            logger.exception("Error during processor shutdown")
            return False

    def force_flush(self, timeout_millis=30000):
        """Force flush any pending spans.

        Args:
            timeout_millis: Timeout in milliseconds

        Returns:
            True if flush succeeded
        """
        # In serverless mode, spans are exported immediately
        # so there's nothing to flush
        return True


def optimize_for_cold_start():
    """Apply optimizations for serverless cold starts."""
    # This is called during module import to minimize cold start time
    preload_dependencies()
    minimize_memory_footprint()


def preload_dependencies():
    """Preload critical dependencies to avoid lazy loading during execution."""
    # Preload commonly used modules
    try:
        import gzip
        import json
        import ssl
        import urllib.request

        logger.debug("Preloaded dependencies for cold start optimization")
    except ImportError:
        pass  # Some dependencies might not be available


def minimize_memory_footprint():
    """Minimize memory footprint for serverless environments."""
    # Disable unnecessary features
    import gc

    # Aggressive garbage collection
    gc.collect()

    # Reduce internal buffer sizes if possible
    logger.debug("Minimized memory footprint for serverless")


# Auto-detect and log serverless environment on module import
_serverless_env = detect_environment()
if _serverless_env:
    logger.info(f"MVK SDK running in serverless environment: {_serverless_env}")

    # Apply cold start optimizations for Lambda and GCP
    if _serverless_env in ("lambda", "gcp"):
        optimize_for_cold_start()
