"""W3C TraceContext propagation for MVK SDK v1.1.

This module handles extraction and injection of traceparent headers
for distributed tracing across services.
"""

import re
import secrets
from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class TraceContext:
    """Represents trace context extracted from or to be injected into headers."""

    trace_id: str
    parent_span_id: str
    trace_flags: int = 0x01  # Sampled by default

    @property
    def is_sampled(self) -> bool:
        """Check if trace is sampled."""
        return bool(self.trace_flags & 0x01)


class TraceContextPropagator:
    """W3C TraceContext propagator for distributed tracing.

    Handles extraction from incoming traceparent headers and
    injection into outgoing HTTP requests.
    """

    # W3C traceparent format: version-trace_id-parent_span_id-trace_flags
    TRACEPARENT_PATTERN = re.compile(r"^([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})$")

    @staticmethod
    def generate_trace_id() -> str:
        """Generate a new 32-character hex trace ID."""
        return secrets.token_hex(16)

    @staticmethod
    def generate_span_id() -> str:
        """Generate a new 16-character hex span ID."""
        return secrets.token_hex(8)

    def extract(self, headers: Dict[str, str]) -> Optional[TraceContext]:
        """Extract trace context from incoming HTTP headers.

        Args:
            headers: HTTP headers dict (case-insensitive keys preferred)

        Returns:
            TraceContext if valid traceparent found, None otherwise
        """
        # Try different case variations for header name
        traceparent = None
        for key in ["traceparent", "Traceparent", "TRACEPARENT"]:
            if key in headers:
                traceparent = headers[key]
                break

        # Also check lowercase version of all keys
        if not traceparent:
            for key, value in headers.items():
                if key.lower() == "traceparent":
                    traceparent = value
                    break

        if not traceparent:
            return None

        # Parse traceparent header
        match = self.TRACEPARENT_PATTERN.match(traceparent.strip())
        if not match:
            return None

        version, trace_id, parent_span_id, trace_flags = match.groups()

        # We only support version 00 for now
        if version != "00":
            return None

        return TraceContext(
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            trace_flags=int(trace_flags, 16),
        )

    def inject(
        self,
        trace_id: str,
        span_id: str,
        headers: Dict[str, str],
        trace_flags: int = 0x01,
    ) -> None:
        """Inject trace context into outgoing HTTP headers.

        Args:
            trace_id: 32-character hex trace ID
            span_id: 16-character hex span ID (becomes parent for downstream)
            headers: Mutable headers dict to inject into
            trace_flags: Trace flags (default: sampled)
        """
        # Format: version-trace_id-span_id-trace_flags
        traceparent = f"00-{trace_id}-{span_id}-{trace_flags:02x}"
        headers["traceparent"] = traceparent

    def create_child_context(self, parent_context: Optional[TraceContext]) -> Tuple[str, str, str]:
        """Create child span context from parent.

        Args:
            parent_context: Parent trace context (None for root span)

        Returns:
            Tuple of (trace_id, parent_span_id, new_span_id)
        """
        if parent_context:
            # Continue existing trace
            trace_id = parent_context.trace_id
            parent_span_id = parent_context.parent_span_id
        else:
            # Start new trace
            trace_id = self.generate_trace_id()
            parent_span_id = "0" * 16  # All zeros for root span

        # Always generate new span ID
        span_id = self.generate_span_id()

        return trace_id, parent_span_id, span_id


# Global propagator instance
propagator = TraceContextPropagator()
