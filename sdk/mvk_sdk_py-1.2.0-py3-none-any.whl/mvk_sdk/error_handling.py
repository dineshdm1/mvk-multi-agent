"""OTEL-compliant error handling for MVK SDK v1.1.

This module provides error handling patterns that guarantee:
1. SDK never breaks client code
2. Vendor exceptions propagate normally
3. SDK exceptions are logged but suppressed
4. SystemExit and KeyboardInterrupt are not caught
"""

import asyncio
import functools
import logging
import random
import time
from contextlib import contextmanager
from typing import Any, Awaitable, Callable, List, Optional, TypeVar, Union, overload

logger = logging.getLogger("mvk.core.error_handling")

T = TypeVar("T")

# Known vendor exception modules (expanded for v1.1)
VENDOR_MODULES = {
    # AI/ML Providers
    "openai",
    "anthropic",
    "google.generativeai",
    "boto3",  # AWS services
    "azure",
    "vertexai",
    "cohere",
    "huggingface",
    "replicate",
    "together",
    # Vector Databases
    "pinecone",
    "weaviate",
    "chromadb",
    "qdrant",
    "milvus",
    "faiss",
    "elasticsearch",
    # HTTP Libraries
    "requests",
    "httpx",
    "aiohttp",
    "urllib3",
    # Database Libraries
    "psycopg2",
    "pymongo",
    "redis",
    "sqlalchemy",
    # Other Common Libraries
    "pandas",
    "numpy",
    "pydantic",
    "fastapi",
    "flask",
    "django",
}


def is_vendor_exception(exc: Exception) -> bool:
    """Determine if an exception is from a vendor library.

    Args:
        exc: The exception to check

    Returns:
        True if exception is from a vendor library, False otherwise
    """
    exc_module = type(exc).__module__
    if exc_module:
        # Check if exception module starts with any vendor module
        for vendor in VENDOR_MODULES:
            if exc_module.startswith(vendor):
                return True
    return False


def safe_wrapper(operation_name: str) -> Callable[[Callable[..., T]], Callable[..., Optional[T]]]:
    """OTEL-compliant wrapper that never breaks client code.

    Args:
        operation_name: Name of the operation for logging

    Returns:
        Decorator function
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except Exception as e:  # pylint: disable=broad-except
                # Check if it's a vendor exception
                if is_vendor_exception(e):
                    # Vendor exceptions propagate
                    raise

                # SDK exceptions are logged but suppressed
                logger.exception(
                    f"SDK operation failed: {operation_name}",
                    extra={"operation": operation_name, "error": str(e)},
                )
                return None

        return wrapper

    return decorator


def safe_async_wrapper(
    operation_name: str,
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[Optional[T]]]]:
    """Decorator for safe async operations.

    Args:
        operation_name: Name of the operation for logging

    Returns:
        Decorator function for async operations
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[Optional[T]]]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return await func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                # Never suppress system exit or keyboard interrupt
                raise
            except Exception as e:  # pylint: disable=broad-except
                # Check if it's a vendor exception
                if is_vendor_exception(e):
                    # Vendor exceptions propagate
                    raise

                # SDK exceptions are logged but suppressed
                logger.exception(
                    f"SDK async operation failed: {operation_name}",
                    extra={"operation": operation_name, "error": str(e)},
                )
                return None

        return wrapper

    return decorator


@contextmanager
def safe_operation(operation_name: str, cleanup_func: Optional[Callable] = None):
    """Context manager for safe operations with cleanup.

    Args:
        operation_name: Name of the operation for logging
        cleanup_func: Optional cleanup function to call in finally
    """
    try:
        yield
    except Exception as e:  # pylint: disable=broad-except
        if is_vendor_exception(e):
            raise
        logger.exception(
            f"SDK operation failed: {operation_name}",
            extra={"operation": operation_name, "error": str(e)},
        )
    finally:
        if cleanup_func:
            try:
                cleanup_func()
            except Exception:  # pylint: disable=broad-except
                logger.exception(
                    f"Cleanup failed for operation: {operation_name}",
                    extra={"operation": operation_name},
                )


def exporter_boundary(func: Callable[..., T]) -> Callable[..., Optional[T]]:
    """Error boundary for exporter functions.

    Exporters should never crash the application.

    Args:
        func: The exporter function to wrap

    Returns:
        Wrapped function
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Optional[T]:
        try:
            return func(*args, **kwargs)
        except Exception:  # pylint: disable=broad-except
            logger.exception(f"Exporter failed: {func.__name__}", extra={"exporter": func.__name__})
            return None

    return wrapper


def wrapper_boundary(provider: str) -> Callable:
    """Error boundary for provider wrappers.

    Args:
        provider: Name of the provider being wrapped

    Returns:
        Decorator function
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(original_func: Callable, *args, **kwargs):
            try:
                return func(original_func, *args, **kwargs)
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                logger.exception(
                    f"Wrapper failed for {provider}, calling original",
                    extra={"provider": provider, "error": str(e)},
                )
                # Fall back to original function
                return original_func(*args, **kwargs)

        return wrapper

    return decorator


def processor_boundary(func: Callable[..., T]) -> Callable[..., Optional[T]]:
    """Error boundary for processor functions.

    Args:
        func: The processor function to wrap

    Returns:
        Wrapped function
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Optional[T]:
        try:
            return func(*args, **kwargs)
        except Exception:  # pylint: disable=broad-except
            logger.exception(
                f"Processor failed: {func.__name__}", extra={"processor": func.__name__}
            )
            return None

    return wrapper


def with_fallback(
    fallback_func: Callable[..., T],
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to provide fallback behavior on failure.

    Args:
        fallback_func: Function to call if primary fails

    Returns:
        Decorator function
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            try:
                return func(*args, **kwargs)
            except Exception as e:  # pylint: disable=broad-except
                logger.warning(
                    f"Primary function failed, using fallback: {func.__name__}",
                    extra={"function": func.__name__, "error": str(e)},
                )
                return fallback_func(*args, **kwargs)

        return wrapper

    return decorator


def get_memory_usage() -> float:
    """Get current memory usage as a percentage.

    Returns:
        Memory usage percentage (0.0 to 1.0)
    """
    try:
        import psutil  # type: ignore

        percent = float(psutil.virtual_memory().percent)
        return percent / 100.0
    except (ImportError, Exception):  # pylint: disable=broad-except
        # If we can't get memory usage (psutil not installed), assume it's fine
        return 0.0


def handle_memory_pressure(queue: List[Any], threshold: float = 0.9) -> List[Any]:
    """Handle memory pressure by dropping oldest items.

    Args:
        queue: The queue to potentially trim
        threshold: Memory usage threshold (0.0 to 1.0)

    Returns:
        Potentially trimmed queue
    """
    memory_usage = get_memory_usage()

    if memory_usage > threshold:
        # Drop 20% of oldest items
        drop_count = max(1, len(queue) // 5)
        logger.warning(
            f"Memory pressure detected ({memory_usage:.1%}), dropping {drop_count} oldest spans",
            extra={"memory_usage": memory_usage, "dropped": drop_count},
        )
        return queue[drop_count:]

    return queue


def retry_with_backoff(
    max_attempts: int = 3,
    initial_delay: float = 1.0,
    max_delay: float = 60.0,
    exponential_base: float = 2.0,
    jitter: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., Optional[T]]]:
    """Decorator for retry with exponential backoff.

    Args:
        max_attempts: Maximum number of attempts
        initial_delay: Initial delay in seconds
        max_delay: Maximum delay in seconds
        exponential_base: Base for exponential backoff
        jitter: Whether to add jitter to delays

    Returns:
        Decorator function
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            last_exception: Optional[Exception] = None

            for attempt in range(max_attempts):
                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:  # pylint: disable=broad-except
                    last_exception = e

                    if attempt < max_attempts - 1:
                        # Calculate delay with exponential backoff
                        delay = float(min(initial_delay * (exponential_base**attempt), max_delay))

                        if jitter:
                            # Add jitter (0.5 to 1.5 times the delay)
                            delay = delay * (0.5 + random.random())

                        logger.debug(
                            f"Attempt {attempt + 1}/{max_attempts} failed, retrying in {delay:.1f}s",
                            extra={
                                "function": func.__name__,
                                "attempt": attempt + 1,
                                "delay": delay,
                                "error": str(e),
                            },
                        )
                        time.sleep(delay)

            # All attempts failed
            logger.error(
                f"All {max_attempts} attempts failed for {func.__name__}",
                extra={
                    "function": func.__name__,
                    "attempts": max_attempts,
                    "last_error": str(last_exception),
                },
            )
            return None

        return wrapper

    return decorator


def ensure_cleanup(*cleanup_funcs: Callable) -> Callable:
    """Decorator to ensure cleanup functions are called.

    Args:
        *cleanup_funcs: Cleanup functions to call

    Returns:
        Decorator function
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            try:
                return func(*args, **kwargs)
            finally:
                for cleanup_func in cleanup_funcs:
                    try:
                        cleanup_func()
                    except Exception:  # pylint: disable=broad-except
                        logger.exception(
                            f"Cleanup failed in {func.__name__}", extra={"function": func.__name__}
                        )

        return wrapper

    return decorator


# Component-specific error boundaries
def create_error_boundary(component: str) -> Callable:
    """Create a component-specific error boundary.

    Args:
        component: Name of the component

    Returns:
        Error boundary decorator
    """

    def boundary(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                logger.exception(
                    f"{component} operation failed: {func.__name__}",
                    extra={"component": component, "operation": func.__name__},
                )
                return None

        return wrapper

    return boundary


# Pre-created boundaries for common components
tracer_boundary = create_error_boundary("tracer")
metric_boundary = create_error_boundary("metrics")
context_boundary = create_error_boundary("context")


def never_break_client_code(
    operation_name: str, fallback_value: Optional[T] = None
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Universal decorator that guarantees SDK never breaks client code.

    This is the core non-breaking guarantee implementation for v1.1:
    - Vendor exceptions always propagate (never caught)
    - SDK exceptions are logged but suppressed
    - SystemExit and KeyboardInterrupt never caught
    - Returns fallback value on SDK errors
    - Comprehensive logging for debugging

    Args:
        operation_name: Name of the operation for logging
        fallback_value: Value to return if SDK operation fails

    Returns:
        Decorator function
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                # Never suppress system exit or keyboard interrupt
                raise
            except Exception as e:  # pylint: disable=broad-except
                # Check if it's a vendor exception
                if is_vendor_exception(e):
                    # Vendor exceptions always propagate - this is critical
                    logger.debug(
                        f"Propagating vendor exception from {operation_name}: {type(e).__name__}"
                    )
                    raise

                # SDK exceptions are logged but suppressed
                logger.exception(
                    f"SDK operation failed (suppressed): {operation_name}",
                    extra={
                        "operation": operation_name,
                        "function": func.__name__,
                        "error_type": type(e).__name__,
                        "error": str(e),
                    },
                )

                # Return fallback value to prevent client code from breaking
                # mypy: fallback_value is Optional[T]; if None, this will still type as T at call sites
                return fallback_value  # type: ignore[return-value]

        return wrapper

    return decorator


def never_break_client_code_async(
    operation_name: str, fallback_value: Optional[T] = None
) -> Callable[[Callable[..., Awaitable[T]]], Callable[..., Awaitable[T]]]:
    """Async version of never_break_client_code decorator.

    Args:
        operation_name: Name of the operation for logging
        fallback_value: Value to return if SDK operation fails

    Returns:
        Decorator function for async operations
    """

    def decorator(func: Callable[..., Awaitable[T]]) -> Callable[..., Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs) -> T:
            try:
                return await func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                # Never suppress system exit or keyboard interrupt
                raise
            except Exception as e:  # pylint: disable=broad-except
                # Check if it's a vendor exception
                if is_vendor_exception(e):
                    # Vendor exceptions always propagate - this is critical
                    logger.debug(
                        f"Propagating vendor exception from async {operation_name}: {type(e).__name__}"
                    )
                    raise

                # SDK exceptions are logged but suppressed
                logger.exception(
                    f"SDK async operation failed (suppressed): {operation_name}",
                    extra={
                        "operation": operation_name,
                        "function": func.__name__,
                        "error_type": type(e).__name__,
                        "error": str(e),
                    },
                )

                # Return fallback value to prevent client code from breaking
                return fallback_value  # type: ignore[return-value]

        return wrapper

    return decorator


def safe_span_operation(span_name: str):
    """Decorator for span operations that must never break client code.

    Specifically designed for span creation, modification, and export operations.

    Args:
        span_name: Name of the span operation for logging

    Returns:
        Decorator function
    """
    return never_break_client_code(f"span_operation:{span_name}", None)


def safe_metric_operation(metric_name: str):
    """Decorator for metric operations that must never break client code.

    Args:
        metric_name: Name of the metric operation for logging

    Returns:
        Decorator function
    """
    return never_break_client_code(f"metric_operation:{metric_name}", None)


def safe_context_operation(operation_name: str):
    """Decorator for context operations that must never break client code.

    Args:
        operation_name: Name of the context operation for logging

    Returns:
        Decorator function
    """
    return never_break_client_code(f"context_operation:{operation_name}", None)


def safe_export_operation(exporter_name: str):
    """Decorator for export operations that must never break client code.

    Args:
        exporter_name: Name of the exporter for logging

    Returns:
        Decorator function
    """
    return never_break_client_code(f"export_operation:{exporter_name}", False)


# Global error suppression for critical SDK operations
def suppress_sdk_errors(operation_name: str):
    """Context manager for suppressing SDK errors while preserving vendor exceptions.

    Use this for operations that must never interrupt client code flow.

    Args:
        operation_name: Name of the operation for logging
    """
    return safe_operation(operation_name)


def create_error_isolation_boundary(component_name: str, isolation_level: str = "strict"):
    """Create error isolation boundary for a specific component.

    Provides different levels of error isolation:
    - strict: All SDK errors suppressed, vendor errors propagated
    - moderate: Some SDK errors may propagate (for debugging)
    - lenient: Most errors propagated (for development)

    Args:
        component_name: Name of the component
        isolation_level: Level of isolation (strict, moderate, lenient)

    Returns:
        Error boundary decorator
    """

    def boundary(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                # Never suppress system exit or keyboard interrupt
                raise
            except Exception as e:  # pylint: disable=broad-except
                # Check if it's a vendor exception
                if is_vendor_exception(e):
                    # Vendor exceptions always propagate
                    logger.debug(
                        f"Propagating vendor exception from {component_name}: {type(e).__name__}"
                    )
                    raise

                # Handle SDK exceptions based on isolation level
                if isolation_level == "strict":
                    # Suppress all SDK errors
                    logger.exception(
                        f"SDK error suppressed in {component_name}: {type(e).__name__}: {str(e)}",
                        extra={"component": component_name, "isolation_level": isolation_level},
                    )
                    return None
                elif isolation_level == "moderate":
                    # Suppress most SDK errors but log more details
                    logger.error(
                        f"SDK error in {component_name}: {type(e).__name__}: {str(e)}",
                        extra={"component": component_name, "isolation_level": isolation_level},
                    )
                    return None
                else:  # lenient
                    # Propagate SDK errors for development/debugging
                    logger.warning(
                        f"SDK error propagating from {component_name}: {type(e).__name__}: {str(e)}",
                        extra={"component": component_name, "isolation_level": isolation_level},
                    )
                    raise

        return wrapper

    return boundary


def isolate_component_errors(component_name: str):
    """Create strict error isolation for a component.

    This is the recommended isolation level for production components.

    Args:
        component_name: Name of the component

    Returns:
        Strict error isolation decorator
    """
    return create_error_isolation_boundary(component_name, "strict")


def isolate_export_errors(exporter_name: str):
    """Create error isolation specifically for export operations.

    Export operations must never break the application.

    Args:
        exporter_name: Name of the exporter

    Returns:
        Export error isolation decorator
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                raise
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                # Export errors are always suppressed
                logger.exception(
                    f"Export error suppressed in {exporter_name}: {type(e).__name__}: {str(e)}",
                    extra={"exporter": exporter_name, "error_type": "export_error"},
                )
                return None

        return wrapper

    return decorator


def isolate_wrapper_errors(provider_name: str) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Create error isolation specifically for provider wrappers.

    Wrapper errors must never break the wrapped application.

    Args:
        provider_name: Name of the provider

    Returns:
        Wrapper error isolation decorator
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(original_func: Callable[..., T], *args, **kwargs) -> T:
            try:
                return func(original_func, *args, **kwargs)
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    # Vendor exceptions propagate (this is the actual API error)
                    raise

                # Wrapper errors are suppressed and fall back to original function
                logger.exception(
                    f"Wrapper error suppressed for {provider_name}, falling back to original: {type(e).__name__}: {str(e)}",
                    extra={"provider": provider_name, "error_type": "wrapper_error"},
                )
                return original_func(*args, **kwargs)

        return wrapper

    return decorator


def isolate_span_errors(span_operation: str):
    """Create error isolation specifically for span operations.

    Span operations must never break the application.

    Args:
        span_operation: Name of the span operation

    Returns:
        Span error isolation decorator
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                raise
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                # Span errors are always suppressed
                logger.exception(
                    f"Span error suppressed in {span_operation}: {type(e).__name__}: {str(e)}",
                    extra={"span_operation": span_operation, "error_type": "span_error"},
                )
                return None

        return wrapper

    return decorator


def isolate_context_errors(context_operation: str):
    """Create error isolation specifically for context operations.

    Context operations must never break the application.

    Args:
        context_operation: Name of the context operation

    Returns:
        Context error isolation decorator
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                raise
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                # Context errors are always suppressed
                logger.exception(
                    f"Context error suppressed in {context_operation}: {type(e).__name__}: {str(e)}",
                    extra={"context_operation": context_operation, "error_type": "context_error"},
                )
                return None

        return wrapper

    return decorator


def isolate_metric_errors(metric_operation: str):
    """Create error isolation specifically for metric operations.

    Metric operations must never break the application.

    Args:
        metric_operation: Name of the metric operation

    Returns:
        Metric error isolation decorator
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Optional[T]:
            try:
                return func(*args, **kwargs)
            except (SystemExit, KeyboardInterrupt):
                raise
            except Exception as e:  # pylint: disable=broad-except
                if is_vendor_exception(e):
                    raise

                # Metric errors are always suppressed
                logger.exception(
                    f"Metric error suppressed in {metric_operation}: {type(e).__name__}: {str(e)}",
                    extra={"metric_operation": metric_operation, "error_type": "metric_error"},
                )
                return None

        return wrapper

    return decorator


# Pre-created isolation boundaries for common components
export_isolation = isolate_export_errors
wrapper_isolation = isolate_wrapper_errors
span_isolation = isolate_span_errors
context_isolation = isolate_context_errors
metric_isolation = isolate_metric_errors
