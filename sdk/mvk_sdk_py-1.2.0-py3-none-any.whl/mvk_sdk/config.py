"""MVK SDK Configuration Utilities - Simplified.

This module provides utility functions for the MVK SDK configuration system.
Most configuration logic has been moved to config_schema.py for better maintainability.
"""

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger("mvk.core.config")


def detect_serverless() -> Optional[str]:
    """Detect if running in a serverless environment.

    Enhanced v1.1 detection with comprehensive platform support:
    - AWS Lambda (including Lambda@Edge)
    - Google Cloud Functions (1st and 2nd gen)
    - Azure Functions (all runtime versions)
    - Vercel (Edge Runtime and Serverless Functions)
    - Cloudflare Workers
    - Netlify Functions
    - Railway Functions
    - Render Functions
    - Oracle Functions

    Returns:
        Type of serverless environment or None
    """
    # Use centralized detection logic
    from .serverless.detection import detect_serverless_environment

    return detect_serverless_environment()


def parse_headers(headers_str: str) -> Dict[str, str]:
    """Parse comma-separated headers string.

    Args:
        headers_str: String like "Key1=Value1,Key2=Value2"

    Returns:
        Dictionary of headers
    """
    headers = {}
    if headers_str:
        for pair in headers_str.split(","):
            if "=" in pair:
                key, value = pair.split("=", 1)
                headers[key.strip()] = value.strip()
    return headers


def merge_configs(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Merge two configuration dictionaries recursively.

    Args:
        base: Base configuration
        override: Override configuration (takes priority)

    Returns:
        Merged configuration
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_configs(result[key], value)
        else:
            result[key] = value

    return result


def apply_serverless_optimizations(
    config: Dict[str, Any], serverless_type: Optional[str] = None
) -> Dict[str, Any]:
    """Apply serverless-specific optimizations to config.

    Args:
        config: Base configuration
        serverless_type: Type of serverless environment (auto-detected if None)

    Returns:
        Configuration with serverless optimizations
    """
    # Use centralized optimization logic
    from .serverless.detection import (
        apply_serverless_optimizations as _apply_serverless_optimizations,
    )

    return _apply_serverless_optimizations(config)
