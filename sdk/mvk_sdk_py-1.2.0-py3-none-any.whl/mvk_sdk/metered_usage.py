"""Metered usage helper module for MVK SDK v1.1.

This module provides standardized metered usage tracking across all AI provider
and vector database wrappers to ensure uniform telemetry collection.
"""

import json
import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


class MetricKind(str, Enum):
    """Canonical metric kinds for metered usage."""

    # LLM/Embeddings
    TOKEN_PROMPT = "token.prompt"
    TOKEN_COMPLETION = "token.completion"
    TOKEN_TOTAL = "token.total"
    TOKEN_REASONING = "token.reasoning"
    TOKEN_CACHED_READ = "token.cached.read"
    TOKEN_CACHED_WRITE = "token.cached.write"
    TOKEN_AUDIO_INPUT_SECONDS = "token.audio.input_seconds"
    TOKEN_AUDIO_OUTPUT_SECONDS = "token.audio.output_seconds"
    TOKEN_VIDEO_INPUT_SECONDS = "token.video.input_seconds"
    TOKEN_VIDEO_OUTPUT_SECONDS = "token.video.output_seconds"
    TOKEN_IMAGE_INPUT_COUNT = "token.image.input_count"
    TOKEN_IMAGE_INPUT_PIXELS = "token.image.input_pixels"
    EMBEDDING_VECTORS = "embedding.vectors"
    EMBEDDING_DIMENSIONS = "embedding.dimensions"
    EMBEDDING_TOKENS = "embedding.tokens"

    # Vector DB
    VECTOR_PROCESSED = "vector.processed"
    VECTOR_RETRIEVED = "vector.retrieved"
    VECTORDB_READ_UNITS = "vectordb.read_units"
    VECTORDB_WRITE_UNITS = "vectordb.write_units"
    VECTORDB_STORAGE_BYTES = "vectordb.storage_bytes"

    # Pinecone Serverless API specific
    PINECONE_READ_UNITS = "pinecone.read_units"
    PINECONE_WRITE_UNITS = "pinecone.write_units"
    PINECONE_TOKENS = "pinecone.tokens"
    PINECONE_REQUESTS = "pinecone.requests"


class UnitOfMeasure(str, Enum):
    """Unit of measure enum for metered usage."""

    TOKEN = "token"
    VECTOR = "vector"
    UNIT = "unit"
    BYTE = "byte"
    SECOND = "second"
    PIXEL = "pixel"
    COUNT = "count"
    DIMENSION = "dimension"


class MeteredUsageBuilder:
    """Builder for constructing metered usage arrays."""

    def __init__(self) -> None:
        """Initialize the builder with an empty metrics list."""
        self.metrics: List[Dict[str, Any]] = []

    def add_metric(
        self,
        metric_kind: Union[MetricKind, str],
        quantity: Union[int, float],
        uom: Union[UnitOfMeasure, str],
        estimated_cost: Optional[float] = None,
        currency: str = "USD",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "MeteredUsageBuilder":
        """Add a metric to the builder.

        Args:
            metric_kind: The type of metric (from MetricKind enum or string)
            quantity: The quantity of the metric
            uom: Unit of measure (from UnitOfMeasure enum or string)
            estimated_cost: Optional estimated cost
            currency: Currency for cost (default USD)
            metadata: Optional metadata dict

        Returns:
            Self for chaining
        """
        # Validate metric_kind
        if isinstance(metric_kind, str):
            # Allow string for flexibility but log if not in enum
            if metric_kind not in [k.value for k in MetricKind]:
                logger.debug(f"Non-standard metric_kind: {metric_kind}")
        else:
            metric_kind = metric_kind.value

        # Validate uom
        if isinstance(uom, str):
            if uom not in [u.value for u in UnitOfMeasure]:
                logger.debug(f"Non-standard uom: {uom}")
        else:
            uom = uom.value

        # Build metric dict
        metric: Dict[str, Any] = {
            "metric_kind": metric_kind,
            "quantity": quantity,
            "uom": uom,
        }

        if estimated_cost is not None:
            metric["estimated_cost"] = estimated_cost
            metric["currency"] = currency

        if metadata:
            metric["metadata"] = metadata

        self.metrics.append(metric)
        return self

    def add_token_metrics(
        self,
        prompt: Optional[int] = None,
        completion: Optional[int] = None,
        total: Optional[int] = None,
        reasoning: Optional[int] = None,
        cached_read: Optional[int] = None,
        cached_write: Optional[int] = None,
        audio_input_seconds: Optional[float] = None,
        audio_output_seconds: Optional[float] = None,
        video_input_seconds: Optional[float] = None,
        video_output_seconds: Optional[float] = None,
        image_input_count: Optional[int] = None,
        image_input_pixels: Optional[int] = None,
    ) -> "MeteredUsageBuilder":
        """Helper for adding common token metrics.

        Args:
            prompt: Number of prompt tokens
            completion: Number of completion tokens
            total: Total number of tokens
            reasoning: Number of reasoning tokens (o-series models)
            cached_read: Number of cached tokens read
            cached_write: Number of cached tokens written
            audio_input_seconds: Audio input duration in seconds
            audio_output_seconds: Audio output duration in seconds
            video_input_seconds: Video input duration in seconds
            video_output_seconds: Video output duration in seconds
            image_input_count: Number of input images
            image_input_pixels: Total pixels in input images

        Returns:
            Self for chaining
        """
        if prompt is not None and prompt > 0:
            self.add_metric(MetricKind.TOKEN_PROMPT, prompt, UnitOfMeasure.TOKEN)
        if completion is not None and completion > 0:
            self.add_metric(MetricKind.TOKEN_COMPLETION, completion, UnitOfMeasure.TOKEN)
        if total is not None and total > 0:
            self.add_metric(MetricKind.TOKEN_TOTAL, total, UnitOfMeasure.TOKEN)
        if reasoning is not None and reasoning > 0:
            self.add_metric(MetricKind.TOKEN_REASONING, reasoning, UnitOfMeasure.TOKEN)
        if cached_read is not None and cached_read > 0:
            self.add_metric(MetricKind.TOKEN_CACHED_READ, cached_read, UnitOfMeasure.TOKEN)
        if cached_write is not None and cached_write > 0:
            self.add_metric(MetricKind.TOKEN_CACHED_WRITE, cached_write, UnitOfMeasure.TOKEN)
        if audio_input_seconds is not None and audio_input_seconds > 0:
            self.add_metric(
                MetricKind.TOKEN_AUDIO_INPUT_SECONDS,
                audio_input_seconds,
                UnitOfMeasure.SECOND,
            )
        if audio_output_seconds is not None and audio_output_seconds > 0:
            self.add_metric(
                MetricKind.TOKEN_AUDIO_OUTPUT_SECONDS,
                audio_output_seconds,
                UnitOfMeasure.SECOND,
            )
        if video_input_seconds is not None and video_input_seconds > 0:
            self.add_metric(
                MetricKind.TOKEN_VIDEO_INPUT_SECONDS,
                video_input_seconds,
                UnitOfMeasure.SECOND,
            )
        if video_output_seconds is not None and video_output_seconds > 0:
            self.add_metric(
                MetricKind.TOKEN_VIDEO_OUTPUT_SECONDS,
                video_output_seconds,
                UnitOfMeasure.SECOND,
            )
        if image_input_count is not None and image_input_count > 0:
            self.add_metric(
                MetricKind.TOKEN_IMAGE_INPUT_COUNT,
                image_input_count,
                UnitOfMeasure.COUNT,
            )
        if image_input_pixels is not None and image_input_pixels > 0:
            self.add_metric(
                MetricKind.TOKEN_IMAGE_INPUT_PIXELS,
                image_input_pixels,
                UnitOfMeasure.PIXEL,
            )

        return self

    def add_embedding_metrics(
        self,
        prompt_tokens: Optional[int] = None,
        vectors: Optional[int] = None,
        dimensions: Optional[int] = None,
        batch_size: Optional[int] = None,
    ) -> "MeteredUsageBuilder":
        """Helper for adding embedding metrics.

        Args:
            prompt_tokens: Number of tokens in embedding input
            vectors: Number of vectors generated
            dimensions: Dimensionality of vectors
            batch_size: Batch size for embedding operation

        Returns:
            Self for chaining
        """
        if prompt_tokens is not None and prompt_tokens > 0:
            self.add_metric(MetricKind.EMBEDDING_TOKENS, prompt_tokens, UnitOfMeasure.TOKEN)
        if vectors is not None and vectors > 0:
            metadata = {}
            if dimensions:
                metadata["dimensions"] = dimensions
            if batch_size:
                metadata["batch_size"] = batch_size
            self.add_metric(
                MetricKind.EMBEDDING_VECTORS,
                vectors,
                UnitOfMeasure.VECTOR,
                metadata=metadata if metadata else None,
            )
        if dimensions is not None and dimensions > 0:
            self.add_metric(MetricKind.EMBEDDING_DIMENSIONS, dimensions, UnitOfMeasure.DIMENSION)

        return self

    def add_vector_db_metrics(
        self,
        vectors_processed: Optional[int] = None,
        vectors_retrieved: Optional[int] = None,
        read_units: Optional[int] = None,
        write_units: Optional[int] = None,
        storage_bytes: Optional[int] = None,
        dim: Optional[int] = None,
        op: Optional[str] = None,
        namespace: Optional[str] = None,
        top_k: Optional[int] = None,
    ) -> "MeteredUsageBuilder":
        """Helper for adding vector database metrics.

        Args:
            vectors_processed: Number of vectors processed
            vectors_retrieved: Number of vectors retrieved
            read_units: Read units consumed
            write_units: Write units consumed
            storage_bytes: Storage used in bytes
            dim: Vector dimensionality
            op: Operation type
            namespace: Namespace/collection
            top_k: Number of results requested

        Returns:
            Self for chaining
        """
        metadata: Dict[str, Union[str, int]] = {}
        if dim:
            metadata["dim"] = dim
        if op:
            metadata["op"] = op
        if namespace:
            metadata["namespace"] = namespace
        if top_k:
            metadata["top_k"] = top_k

        if vectors_processed is not None and vectors_processed > 0:
            self.add_metric(
                MetricKind.VECTOR_PROCESSED,
                vectors_processed,
                UnitOfMeasure.VECTOR,
                metadata=metadata if metadata else None,
            )
        if vectors_retrieved is not None and vectors_retrieved > 0:
            self.add_metric(
                MetricKind.VECTOR_RETRIEVED,
                vectors_retrieved,
                UnitOfMeasure.VECTOR,
                metadata=metadata if metadata else None,
            )
        if read_units is not None and read_units > 0:
            self.add_metric(MetricKind.VECTORDB_READ_UNITS, read_units, UnitOfMeasure.UNIT)
        if write_units is not None and write_units > 0:
            self.add_metric(MetricKind.VECTORDB_WRITE_UNITS, write_units, UnitOfMeasure.UNIT)
        if storage_bytes is not None and storage_bytes > 0:
            self.add_metric(MetricKind.VECTORDB_STORAGE_BYTES, storage_bytes, UnitOfMeasure.BYTE)

        return self

    def add_pinecone_metrics(
        self,
        read_units: Optional[float] = None,
        write_units: Optional[float] = None,
        tokens: Optional[int] = None,
        requests: Optional[int] = None,
        index_name: Optional[str] = None,
        namespace: Optional[str] = None,
        record_count: Optional[int] = None,
        payload_bytes: Optional[int] = None,
        operation: Optional[str] = None,
    ) -> "MeteredUsageBuilder":
        """Helper for adding Pinecone Serverless API metrics.

        Args:
            read_units: Read Units consumed (RUs)
            write_units: Write Units consumed (WUs)
            tokens: Tokens processed (for embeddings)
            requests: Number of requests (for rerank)
            index_name: Pinecone index name
            namespace: Pinecone namespace
            record_count: Number of records processed
            payload_bytes: Payload size in bytes
            operation: Operation type (query, upsert, etc.)

        Returns:
            Self for chaining
        """
        metadata: Dict[str, Union[str, int]] = {}
        if index_name:
            metadata["index_name"] = index_name
        if namespace:
            metadata["namespace"] = namespace
        if record_count is not None:
            metadata["record_count"] = record_count
        if payload_bytes is not None:
            metadata["payload_bytes"] = payload_bytes
        if operation:
            metadata["operation"] = operation

        if read_units is not None and read_units > 0:
            self.add_metric(
                MetricKind.PINECONE_READ_UNITS,
                read_units,
                UnitOfMeasure.UNIT,
                metadata=metadata if metadata else None,
            )
        if write_units is not None and write_units > 0:
            self.add_metric(
                MetricKind.PINECONE_WRITE_UNITS,
                write_units,
                UnitOfMeasure.UNIT,
                metadata=metadata if metadata else None,
            )
        if tokens is not None and tokens > 0:
            self.add_metric(
                MetricKind.PINECONE_TOKENS,
                tokens,
                UnitOfMeasure.TOKEN,
                metadata=metadata if metadata else None,
            )
        if requests is not None and requests > 0:
            self.add_metric(
                MetricKind.PINECONE_REQUESTS,
                requests,
                UnitOfMeasure.COUNT,
                metadata=metadata if metadata else None,
            )

        return self

    def build(self) -> Optional[List[Dict[str, Any]]]:
        """Build and return the metrics array.

        Returns:
            List of metric dicts if any metrics were added, None otherwise
        """
        return self.metrics if self.metrics else None


def _infer_provider_from_model_name(model_name: str) -> Optional[str]:
    """Infer provider from a model name string using simple heuristics.

    Best-effort inference used when mvk.model_provider is not set.
    """
    name = model_name.lower()
    # OpenAI
    if name.startswith(("gpt-", "gpt4", "gpt_", "text-embedding-", "text-embedding-3", "o3", "o1")):
        return "openai"
    # Anthropic
    if name.startswith(("claude",)):
        return "anthropic"
    # Google Gemini
    if "gemini" in name:
        return "google"
    # AWS Bedrock and common embedded providers (heuristic)
    if any(prefix in name for prefix in ("bedrock", "amazon.titan", "cohere", "ai21")):
        return "bedrock"
    return None


def _enrich_metrics_with_provider(span: Any, metrics: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Attach metadata.model_provider to each metric where missing.

    Source precedence:
      1) span.attributes["mvk.model_provider"]
      2) span.attributes["mvk.model_provider_code"]
      3) infer from span.attributes["mvk.model_name"]
      4) infer from metric["metadata"]["model_name"]

    Notes:
      - Guard against non-dict or Mock-like span.attributes to avoid inserting
        non-serializable objects into metadata, which would break JSON encoding.
    """
    if not span:
        return metrics

    # Safely get attributes and ensure they are a dict
    attrs = getattr(span, "attributes", None)
    if not isinstance(attrs, dict):
        return metrics

    # Resolve provider from span attributes, validating types as strings
    provider: Optional[str] = None
    candidate_provider = attrs.get("mvk.model_provider") or attrs.get("mvk.model_provider_code")
    if isinstance(candidate_provider, str) and candidate_provider:
        provider = candidate_provider
    else:
        span_model_name = attrs.get("mvk.model_name")
        if isinstance(span_model_name, str) and span_model_name:
            provider = _infer_provider_from_model_name(span_model_name)

    enriched: List[Dict[str, Any]] = []
    for m in metrics:
        m_copy = dict(m)
        meta: Dict[str, Any] = {}
        if isinstance(m_copy.get("metadata"), dict):
            meta = dict(m_copy["metadata"])  # shallow copy

        # If still no provider, try per-metric model_name
        local_provider: Optional[str] = provider
        metric_model_name = meta.get("model_name")
        if local_provider is None and isinstance(metric_model_name, str) and metric_model_name:
            local_provider = _infer_provider_from_model_name(metric_model_name)

        # Only attach provider if it is a non-empty string
        if isinstance(local_provider, str) and local_provider and "model_provider" not in meta:
            meta["model_provider"] = local_provider

        if meta:
            m_copy["metadata"] = meta
        enriched.append(m_copy)
    return enriched


def safe_populate_metered_usage(span: Any, builder: MeteredUsageBuilder) -> None:
    """Safely populate metered_usage attribute on a span.

    Args:
        span: The span to populate
        builder: MeteredUsageBuilder with metrics
    """
    try:
        metered_usage = builder.build()
        if metered_usage:
            # Ensure provider metadata is present where possible
            metered_usage = _enrich_metrics_with_provider(span, metered_usage)
            # Encode as JSON string to ensure proper OTLP compliance
            metered_usage_json = json.dumps(metered_usage)
            span.set_attribute("mvk.metered_usage", metered_usage_json)
    except Exception as e:
        # Log but don't fail - backend ETL will handle from vendor_attributes
        logger.debug(f"Failed to populate metered_usage: {e}")


def safe_extract_field(response: Any, *field_path: str, default: Any = None) -> Any:
    """Safely extract nested field from response object.

    Args:
        response: Response object to extract from
        *field_path: Path of fields to traverse
        default: Default value if extraction fails

    Returns:
        Extracted value or default
    """
    try:
        current = response
        for field in field_path:
            if hasattr(current, field):
                attr = getattr(current, field)
                # Only check for Mock if we're at a leaf value that should have a real value
                # Don't reject Mock objects that are intermediate traversal points
                current = attr
            elif isinstance(current, dict):
                current = current.get(field)
                if current is None:
                    return default
            else:
                return default

        # Final check - only reject Mock objects if they're supposed to be actual values
        # Check if it's a Mock by looking for Mock-specific methods, but allow real values
        if hasattr(current, "_mock_name") and hasattr(current, "_spec_signature"):
            # This is likely an uninitialized Mock - return default
            return default

        return current if current is not None else default
    except Exception:
        return default
