"""JSON utilities for MVK SDK with proper enum serialization.

This module provides custom JSON serialization that handles enums properly,
similar to how Jackson handles enums in Java by serializing them as their values
rather than their string representations.
"""

import json
from enum import Enum
from typing import Any


class MVKJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that properly handles enum serialization.

    Similar to Jackson's enum handling in Java, this encoder serializes
    enum objects as their values rather than their string representations.

    Example:
        MVKStepType.LLM -> "LLM" (not "MVKStepType.LLM")
    """

    def default(self, obj: Any) -> Any:
        """Convert objects to JSON-serializable format.

        Args:
            obj: Object to serialize

        Returns:
            JSON-serializable representation
        """
        if isinstance(obj, Enum):
            return obj.value
        return super().default(obj)


def dumps(obj: Any, **kwargs) -> str:
    """Serialize object to JSON string with proper enum handling.

    Args:
        obj: Object to serialize
        **kwargs: Additional arguments for json.dumps

    Returns:
        JSON string with enums serialized as their values
    """
    # Use our custom encoder if no custom encoder is specified
    if "cls" not in kwargs:
        kwargs["cls"] = MVKJSONEncoder

    return json.dumps(obj, **kwargs)


def loads(s: str, **kwargs) -> Any:
    """Deserialize JSON string to object.

    Args:
        s: JSON string to deserialize
        **kwargs: Additional arguments for json.loads

    Returns:
        Deserialized object
    """
    return json.loads(s, **kwargs)
