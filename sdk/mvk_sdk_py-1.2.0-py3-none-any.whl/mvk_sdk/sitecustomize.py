"""Site customization for MVK SDK auto-instrumentation.

This file enables automatic instrumentation when placed in site-packages
or when PYTHONPATH includes the directory containing this file.

Much simpler now - just calls instrument() which handles everything!
"""

import logging
import os

# Only proceed if auto-instrumentation is explicitly enabled
if os.environ.get("MVK_AUTO_INSTRUMENT") == "1":
    try:
        # Import MVK SDK and enable instrumentation
        import mvk_sdk as mvk

        # Get configuration from environment variables
        agent_id = os.environ.get("MVK_AGENT_ID")
        api_key = os.environ.get("MVK_API_KEY")

        # Parse wrappers from environment
        wrappers = None
        if "MVK_WRAPPERS" in os.environ:
            wrappers_str = os.environ["MVK_WRAPPERS"]
            wrapper_list = [w.strip() for w in wrappers_str.split(",") if w.strip()]
            wrappers = {"include": wrapper_list}

        # Enable instrumentation - handles both immediate and lazy automatically!
        mvk.instrument(
            agent_id=agent_id,
            api_key=api_key,
            wrappers=wrappers,  # None means use defaults: {"include": ["genai", "vectordb"]}
        )

        # Log success
        logger = logging.getLogger("mvk.sitecustomize")
        logger.info(
            f"MVK SDK auto-instrumentation enabled via sitecustomize.py. "
            f"Wrappers: {wrappers or {'include': ['genai', 'vectordb']}} (default)"
        )

    except ImportError as e:
        # MVK SDK not installed or not available
        logger = logging.getLogger("mvk.sitecustomize")
        logger.debug(f"MVK SDK not available for auto-instrumentation: {e}")
    except Exception as e:
        # Other errors - log but don't break Python startup
        logger = logging.getLogger("mvk.sitecustomize")
        logger.warning(f"Failed to enable MVK auto-instrumentation: {e}")
