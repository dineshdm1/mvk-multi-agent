"""LangChain callback handler for capturing model metadata from framework-level calls.

This module provides a callback handler that intercepts LangChain model calls
to capture model metadata (specifically model_name) that is available at the
framework level but not propagated through to the low-level instrumentation.

This is particularly useful for frameworks like LangChain that use Vertex AI,
where the model name is stored in the ChatVertexAI instance but not passed
through the protobuf request object to the low-level GAPIC API.

Usage:
    The callback handler is registered automatically when the SDK detects
    LangChain and Vertex AI are being used together.
"""

import contextvars
from typing import Any, Dict, Optional
from uuid import UUID

from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "langchain")

# Context variable shared with vertexai_instrumentor to pass model name
_langchain_model_context: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "langchain_model_name", default=None
)


class MVKLangChainCallbackHandler:
    """Callback handler for capturing LangChain model metadata.

    This handler intercepts LangChain chat model calls to extract the model_name
    from the serialized configuration (which contains the ChatVertexAI kwargs).
    The captured model_name is stored in a context variable that can be accessed
    by the low-level Vertex AI instrumentation.

    The handler works by:
    1. Intercepting on_chat_model_start() to capture model from serialized kwargs
    2. Storing the model_name keyed by run_id
    3. Making it available through a context variable for low-level instrumentation
    4. Cleaning up on_llm_end() to prevent memory leaks
    """

    def __init__(self) -> None:
        """Initialize the callback handler."""
        self.run_model: Dict[UUID, str] = {}

    def on_chat_model_start(
        self, serialized: Dict[str, Any], messages: Any, run_id: UUID, **kwargs
    ) -> None:
        """Called when a chat model starts processing.

        Args:
            serialized: Dict containing model configuration including 'kwargs' with
                       model initialization parameters like 'model' or 'model_name'
            messages: The input messages
            run_id: Unique identifier for this run
            **kwargs: Additional arguments
        """
        try:
            # LangChain passes the constructor kwargs in serialized["kwargs"]
            # For ChatVertexAI, this will contain the model parameter
            model_kwargs = serialized.get("kwargs") or {}
            model = model_kwargs.get("model") or model_kwargs.get("model_name")

            if model:
                self.run_model[run_id] = model
                _langchain_model_context.set(model)
                logger.debug(
                    f"[LangChain] Captured model_name from ChatVertexAI: {model} (run_id: {run_id})"
                )
            else:
                logger.debug(
                    f"[LangChain] No model found in serialized config for run_id: {run_id}. "
                    f"Serialized keys: {serialized.keys()}"
                )
        except Exception as e:
            logger.debug(f"[LangChain] Error in on_chat_model_start: {e}")

    def on_llm_end(self, response: Any, run_id: UUID, **kwargs) -> None:
        """Called when an LLM call completes.

        This is where we clean up the run-specific model tracking to prevent
        memory leaks in long-running applications.

        Args:
            response: The model response
            run_id: Unique identifier for this run
            **kwargs: Additional arguments
        """
        try:
            # Clean up the run_model tracking
            model = self.run_model.pop(run_id, None)
            if model:
                logger.debug(f"[LangChain] Cleaned up model tracking for run_id: {run_id}")
            # Note: We don't reset the context variable here because it may be
            # accessed by low-level instrumentation during response processing
        except Exception as e:
            logger.debug(f"[LangChain] Error in on_llm_end: {e}")


def get_langchain_model_context() -> Optional[str]:
    """Retrieve the captured model name from context.

    This function is called by the vertexai_instrumentor to get the model name
    that was captured at the LangChain framework level.

    Returns:
        The model name if available, None otherwise
    """
    try:
        return _langchain_model_context.get()
    except (LookupError, RuntimeError):
        # Context variable not available in this context
        return None


def set_langchain_model_context(model_name: Optional[str]) -> None:
    """Set the captured model name in context.

    This is primarily used by tests or external setup.

    Args:
        model_name: The model name to set, or None to clear
    """
    try:
        _langchain_model_context.set(model_name)
    except Exception as e:
        logger.debug(f"[LangChain] Error setting context: {e}")
