"""OpenAI instrumentor following OTEL patterns.

This module provides instrumentation for OpenAI SDK using the BaseInstrumentor
pattern with wrapt for consistent wrapping.
"""

from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..context import get_global_context
from ..instrument import should_log_prompts_responses
from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..logging_utils import (
    log_error,
    log_metrics,
    log_request_body,
    log_request_end,
    log_request_start,
    log_response_body,
)
from ..metered_usage import (
    MeteredUsageBuilder,
    safe_extract_field,
    safe_populate_metered_usage,
)
from ..metrics import Metric, add_metered_usage
from ..mvk_tracer import OTLPSpanKind, get_tracer
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger
from .common import get_common_attributes, normalize_messages_for_analysis
from .model_detection import detect_input_output_types, detect_model_type, get_model_family

logger = get_component_logger("instrumentation", "openai")


class OpenAIInstrumentor(BaseInstrumentor):
    """Instrumentor for OpenAI SDK following OTEL patterns."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """OpenAI SDK is required."""
        return ["openai"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "openai"

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to OpenAI SDK.

        Handles both v0.x and v1.x versions of the OpenAI SDK.
        """
        import openai  # type: ignore

        # Check OpenAI version
        version = getattr(openai, "__version__", "0.0.0")
        major_version = int(version.split(".")[0])

        if major_version >= 1:
            # OpenAI v1.x - wrap client methods
            self._instrument_v1()
        else:
            # OpenAI v0.x - wrap module methods
            self._instrument_v0()

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from OpenAI SDK."""
        # Unwrap all methods
        for key in list(self._wrapped_methods.keys()):
            module, name = key.rsplit(".", 1)
            self._unwrap_method(module, name)

    def _instrument_v1(self) -> None:
        """Instrument OpenAI v1.x SDK."""
        import openai  # type: ignore

        # Create wrapper for chat completions
        chat_wrapper = self._create_chat_completion_wrapper()

        # Create wrapper for embeddings
        embedding_wrapper = self._create_embedding_wrapper()

        # Wrap the resource methods
        self._wrap_method("openai.resources.chat.completions", "Completions.create", chat_wrapper)

        self._wrap_method("openai.resources.embeddings", "Embeddings.create", embedding_wrapper)

        # Also handle Azure OpenAI if available
        try:
            from openai import AzureOpenAI  # type: ignore

            self._wrap_method(
                "openai.resources.chat.completions",
                "AsyncCompletions.create",
                self._create_async_chat_wrapper(),
            )
        except ImportError:
            pass

    def _instrument_v0(self) -> None:
        """Instrument OpenAI v0.x SDK."""
        # Create wrappers
        chat_wrapper = self._create_chat_completion_wrapper()
        embedding_wrapper = self._create_embedding_wrapper()

        # Wrap module methods
        self._wrap_method("openai", "ChatCompletion.create", chat_wrapper)

        self._wrap_method("openai", "Embedding.create", embedding_wrapper)

    def _create_chat_completion_wrapper(self):
        """Create wrapper for chat completion methods."""
        return WrapperBase.create_wrapper(
            span_name="openai.chat.completion",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_chat_attributes,
            process_result=self._process_chat_result,
        )

    def _extract_chat_attributes(
        self, instance: Any, args: tuple[Any, ...], kwargs: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from chat completion call.

        Returns None if call is coming from a framework wrapper to avoid double instrumentation.
        """
        # Check if this call is coming from a framework wrapper
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(f"OpenAI call detected from {framework} - skipping to avoid double spans")
            return None

        attrs: Dict[str, Any] = {}

        # Get common attributes (safe even if SDK absent)
        try:
            import openai as openai_module  # type: ignore

            attrs.update(get_common_attributes("openai", "openai-python", openai_module))
        except Exception:
            pass

        model_provider, provider_attrs = self._identify_provider_details(instance, kwargs)

        # Extract model and request info
        model_name = self._resolve_model_name(instance, args, kwargs)
        is_stream = bool(kwargs.get("stream", False))

        # Detect input/output types
        try:
            norm_messages = normalize_messages_for_analysis(kwargs.get("messages"))
            kw_for_detection = dict(kwargs)
            if norm_messages is not None:
                kw_for_detection["messages"] = norm_messages
            input_type, output_type = detect_input_output_types(model_name, kw_for_detection)
        except Exception:
            input_type, output_type = "text", "text"

        attrs.update(
            {
                "model_name": model_name,
                "model_provider": model_provider,
                "model_type": detect_model_type(model_name, kwargs),
                "model_family": get_model_family(model_name),
                "input_type": input_type,
                "output_type": output_type,
                "operation": "completion",
                "operation_subtype": "stream" if is_stream else "batch",
                "mvk.step_type": MVKStepType.LLM,
            }
        )

        if provider_attrs:
            attrs.update(provider_attrs)

        if is_stream:
            attrs["stream_enabled"] = True

        # Azure-specific: capture reasoning_effort when provided
        try:
            if model_provider == "azure-openai" and "reasoning_effort" in kwargs:
                effort = kwargs.get("reasoning_effort")
                attrs["mvk.reasoning_effort"] = effort
                attrs["azure.reasoning_effort"] = effort
        except Exception:
            pass

        # Capture prompt if enabled
        if should_log_prompts_responses():
            messages = kwargs.get("messages", [])
            if messages:
                attrs["prompt"] = str(messages)[:1000]

        return attrs

    def _process_chat_result(self, span: Any, result: Any) -> None:
        """Process chat completion result."""
        # Handle non-streaming response
        # Note: Don't check for __iter__ since Pydantic models have it for field iteration
        # Only check for __next__ which indicates an actual iterator/generator
        logger.debug(
            f"[OpenAI] Processing chat result - type: {type(result)}, has __next__: {hasattr(result, '__next__')}"
        )

        if not hasattr(result, "__next__"):
            logger.debug("[OpenAI] Processing as non-streaming response")
            response_obj = self._materialize_response(result)

            # Extract token usage
            populate_metered_usage_with_advanced_metrics(span, response_obj)

            # Azure/OpenAI: Prefer completion_tokens_details.reasoning_tokens if larger
            try:
                augment_reasoning_tokens_from_completion_details(span, response_obj)
            except Exception as e:
                logger.debug(f"Reasoning augmentation failed: {e}")

            # Update model name with provider-returned value when available
            try:
                response_model = getattr(response_obj, "model", None)
                if response_model:
                    span.set_attribute("mvk.model_name", response_model)
            except Exception as e:
                logger.debug(f"Failed to capture response model name: {e}")

            # Capture response if enabled
            if should_log_prompts_responses():
                if hasattr(response_obj, "choices") and response_obj.choices:
                    first_choice = response_obj.choices[0]
                    if hasattr(first_choice, "message") and hasattr(
                        first_choice.message, "content"
                    ):
                        span.set_attribute("mvk.response", str(first_choice.message.content)[:1000])
        else:
            # Streaming response - tokens not currently extracted
            logger.warning(
                "[OpenAI] Streaming response detected. Token extraction for streaming responses "
                "is not currently implemented. Consider using stream_options={'include_usage': True} "
                "with OpenAI SDK v1.40.0+ or disable streaming to get token metrics."
            )

    def _identify_provider_details(
        self, instance: Any, call_kwargs: Optional[Dict[str, Any]] = None
    ) -> tuple[str, Dict[str, Any]]:
        """Determine provider details for the current call."""
        provider = "openai"
        azure_endpoint: Optional[str] = None
        azure_api_version: Optional[str] = None
        seen_ids: set[int] = set()

        def normalize_endpoint(value: str) -> str:
            if not value:
                return value
            if "/openai" in value:
                value = value.split("/openai", 1)[0]
            return value.rstrip("/")

        def inspect_object(obj: Any) -> None:
            nonlocal provider, azure_endpoint, azure_api_version
            if obj is None:
                return

            obj_id = id(obj)
            if obj_id in seen_ids:
                return
            seen_ids.add(obj_id)

            provider_attr = getattr(obj, "_mvk_provider", None)
            if isinstance(provider_attr, str) and provider_attr:
                provider_candidate = provider_attr.lower()
                if provider_candidate.startswith("azure"):
                    provider = "azure-openai"
            else:
                cls = getattr(obj, "__class__", None)
                if cls:
                    name = getattr(cls, "__name__", "")
                    module = getattr(cls, "__module__", "")
                    if "azure" in name.lower() or "azure" in module.lower():
                        provider = "azure-openai"

            base_url_raw = getattr(obj, "_base_url", None) or getattr(obj, "base_url", None)
            base_url_str = str(base_url_raw) if base_url_raw is not None else None
            if (
                isinstance(base_url_str, str)
                and base_url_str
                and "openai.azure.com" in base_url_str.lower()
            ):
                provider = "azure-openai"
                if not azure_endpoint:
                    azure_endpoint = normalize_endpoint(base_url_str)

            endpoint_attr = getattr(obj, "azure_endpoint", None)
            endpoint_str = str(endpoint_attr) if endpoint_attr else None
            if isinstance(endpoint_str, str) and endpoint_str:
                lower_endpoint = endpoint_str.lower()
                if "openai.azure" in lower_endpoint or "azureopenai" in lower_endpoint:
                    provider = "azure-openai"
                    if not azure_endpoint:
                        azure_endpoint = normalize_endpoint(endpoint_str)

            # Capture API version hints
            api_version_attr = getattr(obj, "api_version", None)
            if isinstance(api_version_attr, str) and api_version_attr:
                azure_api_version = azure_api_version or api_version_attr

            default_query = getattr(obj, "default_query", None)
            if isinstance(default_query, dict):
                api_version_query = default_query.get("api-version")
                if isinstance(api_version_query, str) and api_version_query:
                    azure_api_version = azure_api_version or api_version_query

        inspect_object(instance)
        inspect_object(getattr(instance, "_client", None))
        inspect_object(getattr(getattr(instance, "_client", None), "_client", None))
        inspect_object(getattr(instance, "_parent", None))

        if isinstance(call_kwargs, dict):
            endpoint_hint = call_kwargs.get("azure_endpoint")
            if isinstance(endpoint_hint, str) and endpoint_hint:
                provider = "azure-openai"
                if not azure_endpoint:
                    azure_endpoint = normalize_endpoint(endpoint_hint)

            api_version_hint = call_kwargs.get("api_version")
            if isinstance(api_version_hint, str) and api_version_hint:
                azure_api_version = azure_api_version or api_version_hint

        provider_attrs: Dict[str, Any] = {}
        if provider == "azure-openai":
            if azure_endpoint:
                provider_attrs["azure.endpoint"] = azure_endpoint
            if azure_api_version:
                provider_attrs["azure.api_version"] = azure_api_version

        return provider, provider_attrs

    def _resolve_model_name(self, instance: Any, args: tuple, kwargs: Dict[str, Any]) -> str:
        """Resolve model name, accounting for Azure deployment semantics."""
        model = kwargs.get("model")
        if not model and args:
            model = args[0]

        if not model:
            # Explicit Azure kwargs (various frameworks)
            for candidate_key in ("azure_deployment", "deployment", "deployment_name"):
                candidate_val = kwargs.get(candidate_key)
                if isinstance(candidate_val, str) and candidate_val:
                    model = candidate_val
                    break

        if not model:
            # Inspect known Azure client attributes
            for candidate in (
                kwargs.get("client"),
                instance,
                getattr(instance, "_client", None),
                getattr(instance, "_parent", None),
            ):
                if not candidate:
                    continue
                deployment = getattr(candidate, "_azure_deployment", None)
                if isinstance(deployment, str) and deployment:
                    model = deployment
                    break

        if not model:
            client = getattr(instance, "_client", None)
            if client:
                for attr_name in ("_deployment_id", "_deployment", "_default_deployment"):
                    deployment = getattr(client, attr_name, None)
                    if isinstance(deployment, str) and deployment:
                        model = deployment
                        break

        return str(model) if model else "unknown"

    def _materialize_response(self, result: Any) -> Any:
        """Return the concrete response object (handles raw API responses)."""
        if hasattr(result, "_mvk_materialized"):
            return getattr(result, "_mvk_materialized")

        if hasattr(result, "parse") and callable(result.parse):
            try:
                parsed = result.parse()
                setattr(result, "_mvk_materialized", parsed)
                return parsed
            except Exception as exc:
                logger.debug(f"Failed to parse raw OpenAI response: {exc}")

        return result

    def _create_embedding_wrapper(self):
        """Create wrapper for embedding methods."""

        def extract_attributes(instance, args, kwargs):
            """Extract attributes from embedding call."""
            attrs = {}

            try:
                import openai as openai_module  # type: ignore

                attrs.update(get_common_attributes("openai", "openai-python", openai_module))
            except Exception:
                pass

            model_provider, provider_attrs = self._identify_provider_details(instance, kwargs)

            # Extract model and request info
            model_name = self._resolve_model_name(instance, args, kwargs)
            input_type, output_type = detect_input_output_types(model_name, kwargs)

            attrs.update(
                {
                    "model_name": model_name,
                    "model_provider": model_provider,
                    "model_type": "embedding",
                    "model_family": "embedding",
                    "input_type": input_type,
                    "output_type": output_type,
                    "operation": "generate_embeddings",
                    "operation_subtype": "batch",
                    "mvk.step_type": MVKStepType.EMBEDDING,
                }
            )

            if provider_attrs:
                attrs.update(provider_attrs)

            # Count input texts
            input_param = kwargs.get("input", args[1] if len(args) > 1 else None)
            if input_param:
                if isinstance(input_param, list):
                    attrs["embeddings_count"] = len(input_param)
                else:
                    attrs["embeddings_count"] = 1

            # Capture input if enabled
            if should_log_prompts_responses():
                attrs["prompt"] = str(input_param)[:1000]

            return attrs

        def process_result(span, result):
            """Process embedding result."""
            # Extract embedding info
            if hasattr(result, "data") and result.data:
                span.set_attribute("mvk.embeddings_count", len(result.data))
                if hasattr(result.data[0], "embedding"):
                    span.set_attribute("mvk.embedding_dims", len(result.data[0].embedding))

            # Extract token usage
            if hasattr(result, "usage"):
                usage = result.usage
                prompt_tokens = getattr(usage, "prompt_tokens", 0)
                total_tokens = getattr(usage, "total_tokens", 0)

                span.set_attribute("mvk.prompt_tokens", prompt_tokens)
                span.set_attribute("mvk.total_tokens", total_tokens)

                # Build metered usage
                builder = MeteredUsageBuilder()
                if prompt_tokens > 0:
                    builder.add_embedding_metrics(
                        prompt_tokens=prompt_tokens,
                        vectors=len(result.data) if hasattr(result, "data") else 0,
                        dimensions=(
                            len(result.data[0].embedding)
                            if hasattr(result, "data")
                            and result.data
                            and hasattr(result.data[0], "embedding")
                            else 0
                        ),
                    )
                safe_populate_metered_usage(span, builder)

        # Create the wrapper using WrapperBase
        return WrapperBase.create_wrapper(
            span_name="openai.embeddings.create",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=extract_attributes,
            process_result=process_result,
        )

    def _create_async_chat_wrapper(self):
        """Create async wrapper for chat completions."""
        return WrapperBase.create_async_wrapper(
            span_name="openai.chat.completion.async",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_chat_attributes,
            process_result=self._process_chat_result,
        )


def populate_metered_usage_with_advanced_metrics(span, response) -> None:
    """Populate metered_usage with advanced token metrics for OpenAI.

    Supports:
    - Standard token metrics (prompt, completion, total)
    - Cached tokens (GPT-4 and newer)
    - Reasoning tokens (o-series models)
    - Audio/image token metrics (future)

    Args:
        span: The current span
        response: OpenAI response object
    """
    if not span:
        return

    builder = MeteredUsageBuilder()

    # Log response type for debugging
    logger.debug(f"[OpenAI] Processing response type: {type(response)}")
    logger.debug(f"[OpenAI] Response has 'usage' attr: {hasattr(response, 'usage')}")

    # Extract standard token metrics
    usage = safe_extract_field(response, "usage")
    logger.debug(f"[OpenAI] Extracted usage: {usage}")
    if usage:
        prompt_tokens = safe_extract_field(usage, "prompt_tokens", default=0)
        completion_tokens = safe_extract_field(usage, "completion_tokens", default=0)
        total_tokens = safe_extract_field(usage, "total_tokens", default=0)

        logger.debug(
            f"[OpenAI] Token usage - prompt: {prompt_tokens}, completion: {completion_tokens}, total: {total_tokens}"
        )

        # Check for advanced metrics (o-series models)
        reasoning_tokens = safe_extract_field(usage, "reasoning_tokens", default=0)

        # Check for cached tokens (GPT-4 and newer)
        prompt_details = safe_extract_field(usage, "prompt_tokens_details")
        cached_read = 0
        cached_write = 0
        if prompt_details:
            cached_read = safe_extract_field(prompt_details, "cached_tokens", default=0)
            cached_write = safe_extract_field(prompt_details, "cache_creation_tokens", default=0)

        # Check for audio/video tokens (multimodal models)
        audio_input_seconds = safe_extract_field(usage, "audio_input_seconds", default=0.0)
        audio_output_seconds = safe_extract_field(usage, "audio_output_seconds", default=0.0)
        video_input_seconds = safe_extract_field(usage, "video_input_seconds", default=0.0)
        video_output_seconds = safe_extract_field(usage, "video_output_seconds", default=0.0)

        # Check for image tokens
        image_input_count = safe_extract_field(usage, "image_input_count", default=0)
        image_input_pixels = safe_extract_field(usage, "image_input_pixels", default=0)

        # Add all metrics to builder
        builder.add_token_metrics(
            prompt=prompt_tokens,
            completion=completion_tokens,
            total=total_tokens,
            reasoning=reasoning_tokens,
            cached_read=cached_read,
            cached_write=cached_write,
            audio_input_seconds=audio_input_seconds,
            audio_output_seconds=audio_output_seconds,
            video_input_seconds=video_input_seconds,
            video_output_seconds=video_output_seconds,
            image_input_count=image_input_count,
            image_input_pixels=image_input_pixels,
        )

        # Store individual attributes for backward compatibility
        span.set_attribute("mvk.prompt_tokens", prompt_tokens)
        span.set_attribute("mvk.completion_tokens", completion_tokens)
        span.set_attribute("mvk.total_tokens", total_tokens)
        if reasoning_tokens > 0:
            span.set_attribute("mvk.reasoning_tokens", reasoning_tokens)
        if cached_read > 0:
            span.set_attribute("mvk.cached_tokens_read", cached_read)
        if cached_write > 0:
            span.set_attribute("mvk.cached_tokens_write", cached_write)
        if audio_input_seconds > 0:
            span.set_attribute("mvk.audio_input_seconds", audio_input_seconds)
        if audio_output_seconds > 0:
            span.set_attribute("mvk.audio_output_seconds", audio_output_seconds)
        if video_input_seconds > 0:
            span.set_attribute("mvk.video_input_seconds", video_input_seconds)
        if video_output_seconds > 0:
            span.set_attribute("mvk.video_output_seconds", video_output_seconds)
        if image_input_count > 0:
            span.set_attribute("mvk.image_input_count", image_input_count)
        if image_input_pixels > 0:
            span.set_attribute("mvk.image_input_pixels", image_input_pixels)
    else:
        # Log when usage information is missing
        logger.warning(
            f"[OpenAI] No usage information found in response. "
            f"Response type: {type(response).__name__}. "
            f"This may happen with streaming responses or when using certain LangChain wrappers. "
            f"Token metrics will not be available for this span."
        )

    # Safely populate metered_usage
    safe_populate_metered_usage(span, builder)


def augment_reasoning_tokens_from_completion_details(span, response) -> None:
    """Augment reasoning tokens using completion_tokens_details when higher.

    Azure/OpenAI responses may include completion-side reasoning tokens in
    usage.completion_tokens_details.reasoning_tokens. If present and larger
    than usage.reasoning_tokens (already processed), update the span attribute
    and add a token.reasoning metric to metered usage for accuracy.

    Args:
        span: The current span
        response: OpenAI/Azure response object
    """
    if not span or not response:
        return

    try:
        usage = safe_extract_field(response, "usage")
        if not usage:
            return

        completion_details = safe_extract_field(usage, "completion_tokens_details")
        if not completion_details:
            return

        detailed_reasoning = safe_extract_field(completion_details, "reasoning_tokens", default=0)
        if not isinstance(detailed_reasoning, (int, float)):
            return

        # Current recorded reasoning on span (if any)
        current_reasoning = 0
        try:
            if hasattr(span, "attributes"):
                current_reasoning = int(span.attributes.get("mvk.reasoning_tokens", 0))
        except Exception:
            current_reasoning = 0

        if detailed_reasoning > current_reasoning:
            span.set_attribute("mvk.reasoning_tokens", int(detailed_reasoning))

            # Also add/append metered usage entry for reasoning
            try:
                add_metered_usage(
                    [
                        Metric(
                            metric_kind="token.reasoning",
                            quantity=int(detailed_reasoning),
                            uom="token",
                        )
                    ]
                )
            except Exception as e:
                logger.debug(f"Failed to append reasoning metric: {e}")
    except Exception as e:
        logger.debug(f"Failed to augment reasoning tokens: {e}")
