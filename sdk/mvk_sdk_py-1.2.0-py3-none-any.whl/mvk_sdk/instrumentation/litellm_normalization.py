"""LiteLLM response normalization and provider detection.

This module provides comprehensive normalization across 10+ LLM provider response formats,
consistent with the LITELLM_INSTRUMENTATION_GUIDE.md and SDK patterns.

## Problem Statement

LiteLLM abstracts multiple LLM providers (OpenAI, Anthropic, Bedrock, Gemini, Cohere, etc.),
each with different response structures. This module normalizes these disparate formats into
consistent data structures for:
- Token usage tracking (input, output, cache, reasoning tokens)
- Provider detection (which vendor is actually being called)
- Response extraction (getting the generated text regardless of provider)
- Cost computation (all metrics in one place)

## Key Challenges

1. **Multiple Response Formats**: Each provider returns usage/response in different locations:
   - OpenAI: response.usage.{prompt_tokens, completion_tokens}
   - Anthropic: response.usage.{input_tokens, output_tokens}
   - Bedrock: response.usage nested differently
   - Gemini: No standard usage, must extract from metadata

2. **LiteLLM Wrapping**: LiteLLM wraps provider responses differently:
   - May return ModelResponse objects (internal class)
   - May return dicts
   - May cache provider names in _hidden_params['custom_llm_provider']

3. **Provider Detection**: Need to know which provider actually handled the request:
   - Model string alone is ambiguous (e.g., "gpt-4" could be local override)
   - Must extract from LiteLLM's routing decisions
   - Fallback pattern matching for when LiteLLM unavailable

4. **Streaming Responses**: Streaming doesn't include usage until final chunk:
   - Must accumulate chunks
   - Synthesize final usage from gathered data
   - Sometimes usage unavailable (vendor doesn't send it)

## Solution Architecture

**Three-Tier Detection Strategy** (resolve_model_identity):
1. **LiteLLM Routing** (highest confidence): Use LiteLLM's get_llm_provider() which implements
   vendor routing logic and model prefix matching
2. **Registry Lookup** (moderate confidence): Use LiteLLM's get_model_info() which has vendor
   metadata for known models
3. **Pattern Matching** (fallback): Use heuristic patterns (_fallback_provider_inference) when
   LiteLLM unavailable or fails

**Normalization Pipeline** (normalize_usage_and_output):
1. Try to extract from response based on detected provider
2. Look in standard locations (usage field, hidden_params, etc.)
3. Gracefully default to 0 for missing metrics
4. This ensures downstream code never breaks due to missing metrics

**Provider Mapping** (_get_model_family_from_provider):
- Maps LiteLLM provider strings to unified family names for cost tracking
- Example: "vertex_ai", "vertex_ai-language-models" → "google"
- Example: "azure", "azure_ai", "text-completion-openai" → "openai"

## Module Functions

normalize_usage_and_output(): Extract and normalize all response data
resolve_model_identity(): Detect provider and model family (3-tier strategy)
infer_provider_family(): Convenience wrapper for backward compatibility
_get_model_family_from_provider(): Map LiteLLM provider → cost family
_fallback_provider_inference(): Pattern matching when LiteLLM unavailable
"""

from typing import Any, Dict, Optional, Tuple, TypedDict

try:
    import litellm

    LITELLM_AVAILABLE = True
except ImportError:
    LITELLM_AVAILABLE = False


class UsageEnvelope(TypedDict, total=False):
    """Normalized usage metrics across all providers."""

    input_tokens: int
    output_tokens: int
    cache_tokens: int
    reasoning_tokens: int
    total_tokens: int


def normalize_usage_and_output(
    raw: Any,
) -> Tuple[UsageEnvelope, str, str, str]:
    """Normalize usage metrics and output text from any LLM provider response.

    Supports:
    - OpenAI-like (LiteLLM default shape)
    - Anthropic
    - Gemini / Vertex AI / Google Generative AI
    - Bedrock
    - Cohere
    - Mistral
    - Groq
    - LiteLLM ModelResponse objects
    - Other formats (graceful fallback)

    Args:
        raw: Response object from LiteLLM (dict, ModelResponse object, or other)

    Returns:
        Tuple of (usage_dict, output_text, model_id, provider) where:
        - usage_dict: Normalized UsageEnvelope with token counts
        - output_text: Extracted response text (empty string if not found)
        - model_id: Model identifier from response (empty string if not found)
        - provider: Actual LLM provider from response (empty string if not found)

    Notes:
        - Unknown/missing fields default to 0
        - This keeps cost computation safe if downstream code uses these values
        - For streams without final usage, set usage_estimated=True separately
        - Provider is extracted from response._hidden_params['custom_llm_provider'] when available
    """
    # Initialize default usage envelope
    usage: UsageEnvelope = {
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_tokens": 0,
        "reasoning_tokens": 0,
        "total_tokens": 0,
    }
    text, model_id, provider = "", "", ""

    # Extract provider from LiteLLM response if available
    if hasattr(raw, "_hidden_params"):
        hidden_params = getattr(raw, "_hidden_params", {})
        if isinstance(hidden_params, dict):
            provider = hidden_params.get("custom_llm_provider", "")

    # Try to extract from object attributes first (for LiteLLM ModelResponse)
    # before checking dict structure
    if not isinstance(raw, dict):
        # Handle object-based responses (e.g., LiteLLM ModelResponse)
        try:
            # Extract usage from ModelResponse.usage object
            if hasattr(raw, "usage") and raw.usage:
                usage_obj = raw.usage
                # Use max(0, value) to handle None or negative values, but preserve 0
                prompt = getattr(usage_obj, "prompt_tokens", 0)
                completion = getattr(usage_obj, "completion_tokens", 0)
                total = getattr(usage_obj, "total_tokens", 0)

                usage["input_tokens"] = max(0, prompt or 0)
                usage["output_tokens"] = max(0, completion or 0)
                usage["total_tokens"] = max(0, total or 0)

                # Extract cache tokens from completion_tokens_details
                if (
                    hasattr(usage_obj, "completion_tokens_details")
                    and usage_obj.completion_tokens_details
                ):
                    details = usage_obj.completion_tokens_details
                    cached = getattr(details, "cached_tokens", None)
                    if cached is not None:
                        usage["cache_tokens"] = max(0, cached)

                # Extract reasoning tokens
                if hasattr(usage_obj, "reasoning_tokens"):
                    reasoning = getattr(usage_obj, "reasoning_tokens", None)
                    if reasoning is not None:
                        usage["reasoning_tokens"] = max(0, reasoning)

            # Extract model ID
            if hasattr(raw, "model"):
                model_id = str(raw.model) if raw.model else ""

            # Extract text from choices - IMPORTANT: Always try this, not just on usage success
            if hasattr(raw, "choices") and raw.choices:
                try:
                    choice = raw.choices[0]
                    if hasattr(choice, "message") and hasattr(choice.message, "content"):
                        extracted_text = choice.message.content or ""
                        if extracted_text:
                            text = extracted_text
                except Exception:
                    pass  # Text extraction failed for this choice

            # If we got usage info, return it
            if any(usage.values()):
                return usage, text, model_id, provider
        except Exception:
            # Fall through to dict handling
            pass

        # If not a dict and didn't extract usage, return defaults
        # But still return extracted text if we got it
        if not isinstance(raw, dict):
            return usage, text, model_id, provider

    # --- OpenAI-like (includes LiteLLM standard shape) ---
    if "usage" in raw:
        u = raw.get("usage") or {}
        if isinstance(u, dict):
            # Standard token counts
            usage["input_tokens"] = u.get("prompt_tokens", u.get("input_tokens", 0)) or 0
            usage["output_tokens"] = u.get("completion_tokens", u.get("output_tokens", 0)) or 0
            usage["total_tokens"] = u.get("total_tokens", 0) or 0

            # If total is 0, compute from input + output
            if usage["total_tokens"] == 0:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

            # Reasoning tokens (o-series models)
            usage["reasoning_tokens"] = u.get("reasoning_tokens", 0) or 0

            # Cache tokens - check multiple locations
            ptd = u.get("prompt_tokens_details") or {}
            if isinstance(ptd, dict):
                usage["cache_tokens"] = ptd.get("cached_tokens", 0) or 0
            if usage["cache_tokens"] == 0:
                # Azure OpenAI / Anthropic style
                usage["cache_tokens"] = (
                    u.get("cache_creation_input_tokens", 0)
                    or u.get("cache_read_input_tokens", 0)
                    or 0
                )

            # Extract response text from choices
            if "choices" in raw and raw["choices"]:
                ch0 = raw["choices"][0]
                if isinstance(ch0, dict):
                    if "message" in ch0:
                        msg = ch0["message"]
                        text = (msg.get("content") or "") if isinstance(msg, dict) else str(msg)
                    elif "text" in ch0:
                        text = ch0.get("text") or ""

            model_id = raw.get("model", "")
            return usage, text, model_id, provider

    # --- Anthropic ---
    if ("content" in raw) and (
        "usage" in raw or ("id" in raw and "anthropic" in str(raw.get("id", "")).lower())
    ):
        u = raw.get("usage") or {}
        if isinstance(u, dict):
            usage["input_tokens"] = u.get("input_tokens", 0) or 0
            usage["output_tokens"] = u.get("output_tokens", 0) or 0
            usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

            # Cache tokens
            usage["cache_tokens"] = (u.get("cache_creation_input_tokens", 0) or 0) + (
                u.get("cache_read_input_tokens", 0) or 0
            )

            # Reasoning tokens
            usage["reasoning_tokens"] = u.get("reasoning_tokens", 0) or 0

            # Extract text from content blocks
            if isinstance(raw.get("content"), list):
                for block in raw["content"]:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text = block.get("text") or ""
                        if text:
                            break

            model_id = raw.get("model") or raw.get("model_id") or ""
            return usage, text, model_id, provider

    # --- Gemini / Vertex AI / Google Generative AI ---
    if "usageMetadata" in raw:
        um = raw.get("usageMetadata") or {}
        if isinstance(um, dict):
            usage["input_tokens"] = um.get("promptTokenCount", 0) or 0
            usage["output_tokens"] = um.get("candidatesTokenCount", 0) or 0
            usage["total_tokens"] = um.get("totalTokenCount", 0) or 0

            # If total is 0, compute
            if usage["total_tokens"] == 0:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

            # Gemini doesn't expose cache/reasoning in standard form
            usage["cache_tokens"] = 0
            usage["reasoning_tokens"] = 0

            # Extract text from candidates
            candidates = raw.get("candidates") or []
            if isinstance(candidates, list) and candidates:
                content = (candidates[0] or {}).get("content") or {}
                if isinstance(content, dict):
                    for p in content.get("parts", []):
                        if isinstance(p, dict) and "text" in p:
                            text = p.get("text", "")
                            if text:
                                break

            model_id = raw.get("model", "") or raw.get("modelId", "")
            return usage, text, model_id, provider

    # --- Bedrock ---
    if "usage" in raw or "amazon-bedrock-invocationMetrics" in raw:
        if "usage" in raw:
            u = raw.get("usage") or {}
            if isinstance(u, dict):
                usage["input_tokens"] = u.get("inputTokens", 0) or 0
                usage["output_tokens"] = u.get("outputTokens", 0) or 0
                usage["total_tokens"] = u.get("totalTokens", 0) or 0

                if usage["total_tokens"] == 0:
                    usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
        else:
            m = raw.get("amazon-bedrock-invocationMetrics") or {}
            if isinstance(m, dict):
                usage["input_tokens"] = m.get("inputTokenCount", 0) or 0
                usage["output_tokens"] = m.get("outputTokenCount", 0) or 0
                usage["total_tokens"] = m.get("totalTokenCount", 0) or 0

                if usage["total_tokens"] == 0:
                    usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

        # Bedrock doesn't expose cache/reasoning
        usage["cache_tokens"] = 0
        usage["reasoning_tokens"] = 0

        # Extract text
        text = raw.get("output_text") or raw.get("completion") or ""

        model_id = raw.get("modelId", "") or raw.get("model", "")
        return usage, text, model_id, provider

    # --- Cohere ---
    if isinstance(raw.get("meta"), dict) and "billed_units" in raw["meta"]:
        bu = raw["meta"].get("billed_units") or {}
        if isinstance(bu, dict):
            usage["input_tokens"] = bu.get("input_tokens", 0) or 0
            usage["output_tokens"] = bu.get("output_tokens", 0) or 0
            usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

        # Cohere doesn't expose cache/reasoning
        usage["cache_tokens"] = 0
        usage["reasoning_tokens"] = 0

        text = raw.get("text") or ""
        model_id = raw.get("model", "")
        return usage, text, model_id, provider

    # --- Mistral ---
    if "usage" in raw and isinstance(raw.get("usage"), dict):
        u = raw["usage"]
        if "prompt_tokens" in u or "completion_tokens" in u:
            usage["input_tokens"] = u.get("prompt_tokens", 0) or 0
            usage["output_tokens"] = u.get("completion_tokens", 0) or 0
            usage["total_tokens"] = u.get("total_tokens", 0) or 0

            if usage["total_tokens"] == 0:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]

            # Mistral doesn't expose cache/reasoning
            usage["cache_tokens"] = 0
            usage["reasoning_tokens"] = 0

            # Extract text
            if "choices" in raw and isinstance(raw["choices"], list) and raw["choices"]:
                ch0 = raw["choices"][0]
                if isinstance(ch0, dict):
                    if "message" in ch0:
                        msg = ch0["message"]
                        text = (msg.get("content") or "") if isinstance(msg, dict) else str(msg)
                    elif "text" in ch0:
                        text = ch0.get("text") or ""

            model_id = raw.get("model", "")
            return usage, text, model_id, provider

    # --- Groq (similar to OpenAI-like) ---
    if "usage" in raw and isinstance(raw.get("usage"), dict):
        # Already handled by OpenAI-like check above
        pass

    # Default: return initialized but empty usage
    return usage, text, model_id, provider


def resolve_model_identity(model: str, kwargs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Resolve comprehensive model identity information using LiteLLM's native methods.

    **Three-Tier Detection Strategy** (Most Reliable First):

    1. **LiteLLM Router (Highest Confidence)**:
       - Calls litellm.get_llm_provider(model, api_base)
       - Implements LiteLLM's full routing logic including model prefix matching
       - Handles special cases (e.g., "gemini-1.5-pro" → "vertex_ai" when Vertex AI is used)
       - Returns the provider that LiteLLM will actually use for the request

    2. **Registry Lookup (Moderate Confidence)**:
       - Calls litellm.get_model_info(model) to look up model metadata
       - Returns pricing, max_tokens, and mode from LiteLLM's registry
       - May return slightly different provider name (e.g., "vertex_ai-language-models" vs "vertex_ai")
       - Gracefully handles models not in registry (returns None, not error)

    3. **Fallback Pattern Matching (Last Resort)**:
       - Used when LiteLLM not available or both tier-1 and tier-2 fail
       - Uses heuristic patterns like "gpt-" prefix for OpenAI, "claude-" for Anthropic
       - Never throws exception, always returns (provider, family) tuple

    Args:
        model: Model identifier (e.g., "gpt-4", "anthropic/claude-3-5-sonnet")
        kwargs: Optional dict of call parameters (e.g., api_base for provider routing)

    Returns:
        Dictionary with comprehensive model information:
        - provider: Primary provider (e.g., "openai", "anthropic", "vertex_ai", "bedrock")
        - model_family: Model family for cost tracking (same as provider or mapped)
        - registry_provider: Provider from model registry (may differ slightly from provider)
        - mode: Model mode ("chat", "embedding", "completion", etc.)
        - max_tokens: Maximum token limit for the model (None if unknown)
        - pricing: Dict with "input" and "output" cost per token (None if unknown)
        - model_name: The original model identifier passed to this function

    Examples:
        "gpt-4" → {provider: "openai", model_family: "openai", mode: "chat", ...}
        "anthropic/claude-3-5-sonnet" → {provider: "anthropic", model_family: "anthropic", ...}
        "azure/gpt-4" → {provider: "azure", model_family: "openai", ...}
        "gemini-1.5-pro" → {provider: "vertex_ai-language-models", model_family: "google", ...}

    Notes:
        - Always returns a dict with all fields defined (never raises exception)
        - Unknown values are set to "unknown", None, or {} appropriately
        - Designed for robustness: gracefully degrades when dependencies unavailable
    """
    if not model:
        return {
            "provider": "unknown",
            "model_family": "unknown",
            "registry_provider": "unknown",
            "mode": None,
            "max_tokens": None,
            "pricing": {"input": None, "output": None},
            "model_name": model,
        }

    kwargs = kwargs or {}

    # Default response structure
    result: Dict[str, Any] = {
        "provider": "unknown",
        "model_family": "unknown",
        "registry_provider": "unknown",
        "mode": None,
        "max_tokens": None,
        "pricing": {"input": None, "output": None},
        "model_name": model,
    }

    if LITELLM_AVAILABLE:
        try:
            # 1) Get provider from LiteLLM router (authoritative routing logic)
            # get_llm_provider returns: (model, provider, dynamic_api_key, api_base)
            _, provider, _, _ = litellm.get_llm_provider(
                model=model, api_base=kwargs.get("api_base")
            )

            result["provider"] = provider

            # Map to model family for cost tracking
            result["model_family"] = _get_model_family_from_provider(provider)

            # 2) Get registry information (includes pricing, limits, etc.)
            try:
                info = litellm.get_model_info(model)

                result["registry_provider"] = info.get("litellm_provider", provider)
                result["mode"] = info.get("mode")
                max_tokens_val = info.get("max_tokens")
                if max_tokens_val is not None:
                    result["max_tokens"] = max_tokens_val
                input_cost = info.get("input_cost_per_token")
                output_cost = info.get("output_cost_per_token")
                if input_cost is not None or output_cost is not None:
                    result["pricing"] = {
                        "input": input_cost,
                        "output": output_cost,
                    }
            except Exception:
                # Model not in registry - that's OK, we have the provider
                result["registry_provider"] = provider

            return result

        except Exception:
            # If LiteLLM resolver fails, fall through to fallback
            pass

    # Fallback: basic pattern matching (used when LiteLLM not available or fails)
    provider, family = _fallback_provider_inference(model, kwargs)
    result["provider"] = provider
    result["model_family"] = family
    result["registry_provider"] = provider

    return result


def infer_provider_family(model: str, kwargs: Optional[Dict[str, Any]] = None) -> Tuple[str, str]:
    """Infer provider and model family from model identifier.

    This is a convenience wrapper around resolve_model_identity() that returns
    just the provider and family as a tuple for backward compatibility.

    Args:
        model: Model identifier (e.g., "gpt-4", "claude-3-sonnet", "gemini-1.5-pro")
        kwargs: Optional dict of call parameters for additional context

    Returns:
        Tuple of (provider, family) where:
        - provider: Specific provider name from LiteLLM (e.g., "openai", "anthropic", "vertex_ai")
        - family: Model family for cost tracking (mapped from provider)

    Examples:
        "gpt-4" → ("openai", "openai")
        "claude-3-sonnet" → ("anthropic", "anthropic")
        "anthropic/claude-3" → ("anthropic", "anthropic")
        "gemini-1.5-pro" → ("vertex_ai-language-models", "google")
    """
    identity = resolve_model_identity(model, kwargs)
    return identity["provider"], identity["model_family"]


def _get_model_family_from_provider(provider: str) -> str:
    """Map LiteLLM provider string to normalized model family for cost tracking.

    **Purpose**:
    Different LiteLLM provider names may represent the same vendor (e.g., "azure"
    and "text-completion-openai" both use OpenAI pricing). This function maps all
    variants to a canonical family name for grouping and cost calculations.

    **Mapping Strategy**:

    1. **OpenAI Ecosystem**:
       - "openai" → "openai"
       - "azure", "azure_ai" → "openai" (Azure still uses OpenAI models)
       - "text-completion-openai" → "openai"

    2. **Google / Vertex AI** (Complex due to routing changes):
       - "vertex_ai" → "google" (from get_llm_provider)
       - "vertex_ai_beta" → "google"
       - "vertex_ai-language-models" → "google" (from get_model_info for Gemini)
       - "gemini" → "google" (Google AI Studio)
       - "google" → "google"
       - "palm" → "google" (deprecated PaLM API)

    3. **Cohere Ecosystem**:
       - "cohere" → "cohere"
       - "cohere_chat" → "cohere" (chat variant)

    4. **Direct Mappings** (no consolidation needed):
       - "anthropic" → "anthropic"
       - "bedrock" → "bedrock"
       - "mistral" → "mistral"
       - "groq" → "groq"
       - (plus many others: together, replicate, huggingface, ollama, etc.)

    5. **Fallback**:
       - Unknown providers: return provider name as-is

    Args:
        provider: Provider string from LiteLLM (output of get_llm_provider() or inferred)

    Returns:
        Canonical model family name for cost tracking (lowercase, no spaces)

    Notes:
        - Map is case-insensitive (all keys converted to lowercase)
        - Handles multiple LiteLLM provider names mapping to same family
        - Useful for grouping costs by vendor, not by implementation detail
    """
    provider_lower = (provider or "").lower()

    # Map providers to families
    # Note: get_llm_provider() and get_model_info() may return slightly different provider names
    # e.g., get_llm_provider("gemini-1.5-pro") → "vertex_ai"
    #       get_model_info("gemini-1.5-pro") → "vertex_ai-language-models"
    provider_to_family = {
        "openai": "openai",
        "azure": "openai",
        "azure_ai": "openai",
        "text-completion-openai": "openai",
        "anthropic": "anthropic",
        "bedrock": "bedrock",
        "vertex_ai": "google",  # From get_llm_provider()
        "vertex_ai_beta": "google",
        "vertex_ai-language-models": "google",  # From get_model_info() for Vertex AI Gemini models
        "gemini": "google",  # LiteLLM uses "gemini" as provider for Google AI Studio
        "google": "google",
        "palm": "google",
        "cohere": "cohere",
        "cohere_chat": "cohere",  # From get_llm_provider() for Cohere chat models
        "mistral": "mistral",
        "groq": "groq",
        "together_ai": "together",
        "replicate": "replicate",
        "huggingface": "huggingface",
        "ollama": "ollama",
        "openrouter": "openrouter",
        "deepseek": "deepseek",
        "perplexity": "perplexity",
    }

    return provider_to_family.get(provider_lower, provider_lower)


def _fallback_provider_inference(
    model: str, kwargs: Optional[Dict[str, Any]] = None
) -> Tuple[str, str]:
    """Fallback provider inference using pattern matching.

    **When Used**:
    - LiteLLM is not installed (LITELLM_AVAILABLE=False)
    - LiteLLM.get_llm_provider() throws exception
    - resolve_model_identity fails in all other attempts

    **Pattern Matching Strategy** (in order of priority):

    1. **Explicit Provider Prefix** (e.g., "openai/gpt-4"):
       - Split on "/" and check prefix for known providers
       - Handles provider aliases (e.g., "vertex_ai" → "vertex_ai-google")
       - Returns provider as-is if not recognized (defensive)

    2. **Model Name Patterns** (case-insensitive):
       - OpenAI: "gpt-", "o1", "o3", "gpt4", "o-" prefixes
       - Anthropic: "claude-" prefix
       - Gemini/Google: "gemini-", "google/" prefixes
       - Mistral: "mistral-" prefix
       - Cohere: "command-", "cohere/" prefixes
       - Others: specific prefixes for Groq, Together, Replicate, etc.

    3. **api_base Parameter** (for API-compatible services):
       - Checks if "api_base" contains "openai.azure.com" → maps to Azure
       - Useful for Azure OpenAI and other drop-in replacements

    4. **Explicit Provider Kwarg** (fallback):
       - Checks kwargs.get("provider") for explicit provider name
       - Used when model name alone is ambiguous

    5. **Default Fallback**:
       - Returns ("unknown", "unknown") if no pattern matches

    Args:
        model: Model identifier (e.g., "gpt-4", "claude-3", "gemini-1.5-pro")
        kwargs: Optional dict with "api_base" and "provider" keys for additional context

    Returns:
        Tuple of (provider, family) where:
        - provider: Inferred provider name (or "unknown")
        - family: Model family for cost tracking (same as provider or mapped)

    Notes:
        - Never throws exception, always returns valid tuple
        - Designed as defensive fallback, prioritizes accuracy over coverage
        - Pattern matching is best-effort; LiteLLM resolver is more reliable
    """
    if not model:
        return "unknown", "unknown"

    m = (model or "").lower()
    kwargs = kwargs or {}

    # --- Check for explicit provider in model string (e.g., "openai/gpt-4") ---
    if "/" in m:
        prov, rest = m.split("/", 1)
        # Ensure both parts are non-empty (avoid edge case like model == "/")
        if prov and rest:
            # Normalize common provider aliases
            if prov in (
                "openai",
                "anthropic",
                "bedrock",
                "cohere",
                "mistral",
                "groq",
                "together",
                "replicate",
            ):
                return prov, prov
            elif prov == "google":
                return "gemini", "google"
            elif prov == "vertex" or prov == "vertex_ai":
                return "vertex_ai", "google"
            elif prov == "azure":
                return "azure", "openai"
            else:
                # Unknown provider prefix
                return prov, prov
        # If either part is empty, fall through to other pattern matching

    # --- OpenAI models (gpt-*) ---
    if m.startswith(("gpt-", "o1", "o3", "gpt4", "o-")):
        return "openai", "openai"

    # --- Azure OpenAI (via api_base or explicit provider) ---
    if "api_base" in kwargs and isinstance(kwargs.get("api_base"), str):
        if "openai.azure.com" in kwargs["api_base"].lower():
            return "azure", "openai"
    if kwargs.get("provider") == "azure":
        return "azure", "openai"

    # --- Anthropic models (claude-*) ---
    if m.startswith("claude-"):
        return "anthropic", "anthropic"

    # --- Gemini / Google (gemini-*, google/*) ---
    if m.startswith(("gemini-", "google/")):
        return "gemini", "google"

    # --- Vertex AI (vertex:*) ---
    if m.startswith("vertex:"):
        return "vertex_ai", "google"

    # --- Mistral models ---
    if m.startswith("mistral-"):
        return "mistral", "mistral"

    # --- Cohere models (command-*) ---
    if m.startswith(("command-", "cohere/")):
        return "cohere", "cohere"

    # --- Bedrock (bedrock in provider or model) ---
    if "bedrock" in m or kwargs.get("provider") == "bedrock":
        return "bedrock", "bedrock"

    # --- Groq models ---
    if m.startswith(("groq-", "mixtral-")) or "groq" in kwargs.get("provider", "").lower():
        return "groq", "groq"

    # --- Together models ---
    if "together" in kwargs.get("provider", "").lower():
        return "together", "together"

    # --- Replicate models ---
    if "replicate" in kwargs.get("provider", "").lower():
        return "replicate", "replicate"

    # --- Unknown provider ---
    return "unknown", "unknown"
