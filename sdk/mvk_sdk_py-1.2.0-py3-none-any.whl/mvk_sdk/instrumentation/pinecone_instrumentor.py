"""Pinecone instrumentor following OTEL patterns.

This module provides instrumentation for Pinecone SDK using the BaseInstrumentor
pattern with wrapt for consistent wrapping. Supports the official pinecone package
and captures Pinecone Serverless API usage metrics (Read Units, Write Units, etc.).

Reference: https://docs.pinecone.io/guides/manage-cost/understanding-cost
"""

import json
import re
import sys
from typing import Any, Collection, Dict, List, Optional, Tuple, Union
from weakref import WeakKeyDictionary

import wrapt

from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_extract_field, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "pinecone")

# Global registry to track index names by instance
_index_name_registry: WeakKeyDictionary = WeakKeyDictionary()

# Constants for Pinecone cost calculations
# Based on: https://docs.pinecone.io/guides/manage-cost/understanding-cost
PINECONE_DENSE_VECTOR_BYTES_PER_DIMENSION = 4  # 4 bytes per dimension for dense vectors
PINECONE_SPARSE_VECTOR_BYTES_PER_VALUE = 9  # 9 bytes per non-zero value for sparse vectors
PINECONE_MIN_UPSERT_WU = 5  # Minimum Write Units per upsert request
PINECONE_MIN_DELETE_WU = 5  # Minimum Write Units per delete request
PINECONE_MIN_UPDATE_WU = 5  # Minimum Write Units per update request
PINECONE_WU_PER_KB = 1  # 1 Write Unit per KB
PINECONE_RU_PER_GB_NAMESPACE = 1  # 1 Read Unit per 1 GB namespace size
PINECONE_MIN_QUERY_RU = 0.25  # Minimum 0.25 RU per query
PINECONE_FETCH_RU_PER_10_RECORDS = 1  # 1 RU per 10 records
PINECONE_MIN_FETCH_RU = 1  # Minimum 1 RU per fetch
PINECONE_LIST_RU = 1  # Fixed 1 RU per list operation
PINECONE_STATS_RU = 1  # Fixed 1 RU per describe_index_stats


class PineconeInstrumentor(BaseInstrumentor):
    """Instrumentor for Pinecone SDK following OTEL patterns.

    Supports both REST and gRPC APIs from the official pinecone package.
    Captures Pinecone Serverless API usage metrics:
    - Read Units (RUs) for query, fetch, list operations
    - Write Units (WUs) for upsert, update, delete, import operations
    - Token Units for embeddings operations
    - Request Units for rerank operations
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """Pinecone SDK is required."""
        return ["pinecone"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "pinecone"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Pinecone SDK.

        The base class handles unwrapping automatically.
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Pinecone SDK.

        Instruments both data operations (Index) and inference operations
        (embeddings, rerank) for the official pinecone package.
        """
        try:
            import pinecone

            logger.info("Starting Pinecone instrumentation")

            # Instrument the Pinecone client's Index factory method
            self._instrument_client_index_factory()

            # Instrument data operations (Index class)
            self._instrument_index_operations()

            # Instrument inference operations (embeddings, rerank)
            self._instrument_inference_operations()

            logger.info("Pinecone auto-instrumentation enabled")

        except Exception as e:
            logger.warning(f"Failed to instrument Pinecone: {e}")

    def _instrument_client_index_factory(self) -> None:
        """Instrument the Pinecone client's Index factory method.

        This wraps Pinecone.Index() to track what Index class is actually
        being instantiated at runtime.
        """
        try:
            from pinecone import Pinecone

            # Create a diagnostic wrapper for the Index factory
            def index_factory_wrapper(wrapped, instance, args, kwargs):
                """Wrapper for Pinecone.Index() factory method.

                The first argument (host_or_name) can be either:
                - An index name string (e.g., "my-index")
                - A full host URL (e.g., "https://my-index-abc123.svc.pinecone.io")
                """
                logger.debug(f"Pinecone.Index() called with args={args}, kwargs={kwargs}")
                result = wrapped(*args, **kwargs)

                # Extract index name/host from constructor arguments
                host_or_name = None
                if args and len(args) > 0:
                    host_or_name = args[0]
                elif "index_name" in kwargs:
                    host_or_name = kwargs["index_name"]
                elif "name" in kwargs:
                    host_or_name = kwargs["name"]
                elif "host" in kwargs:
                    host_or_name = kwargs["host"]

                # Extract index name from host_or_name
                index_name = None
                if host_or_name and isinstance(host_or_name, str):
                    # Check if it's a URL (contains http:// or https://)
                    if "http://" in host_or_name or "https://" in host_or_name:
                        # Extract index name from URL pattern
                        # Format: https://{index-name}-{project}.svc.{environment}.pinecone.io
                        match = re.search(r"https?://([^-]+)-", host_or_name)
                        if match:
                            index_name = match.group(1)
                            logger.debug(
                                f"Extracted index name '{index_name}' from host URL: {host_or_name}"
                            )
                    else:
                        # It's likely just the index name
                        index_name = host_or_name
                        logger.debug(f"Using index name directly: {index_name}")

                # Store index name in registry if we found it
                if index_name:
                    _index_name_registry[result] = index_name
                    logger.debug(
                        f"Stored index name '{index_name}' for instance {type(result).__name__}"
                    )

                logger.debug(
                    f"Pinecone.Index() returned instance of type: {type(result).__module__}.{type(result).__name__}"
                )
                return result

            # Wrap the Index factory method on Pinecone class
            self._wrap_method("pinecone", "Pinecone.Index", index_factory_wrapper)
            logger.debug("Successfully wrapped Pinecone.Index factory method")

            # Also wrap module-level Index function if it exists
            # Some code might use: from pinecone import Index; Index(name)
            try:
                import pinecone

                if hasattr(pinecone, "Index") and callable(pinecone.Index):
                    # Wrap the module-level Index function
                    self._wrap_method("pinecone", "Index", index_factory_wrapper)
                    logger.debug("Successfully wrapped pinecone.Index module-level function")
            except Exception:
                pass

        except Exception as e:
            logger.debug(f"Failed to instrument Pinecone.Index factory: {e}")

    def _instrument_index_operations(self) -> None:
        """Instrument Pinecone Index operations (data plane).

        Supports both REST API (Index) and gRPC API (GRPCIndex).
        """
        # Try gRPC Index (newer API) - try both module paths
        try:
            # Try pinecone.grpc.index (internal module)
            from pinecone.grpc.index import GRPCIndex

            logger.debug("Instrumenting Pinecone grpc.index.GRPCIndex")
            self._wrap_index_class("pinecone.grpc.index", "GRPCIndex", GRPCIndex)
        except ImportError:
            try:
                # Try pinecone.grpc (direct import)
                from pinecone.grpc import GRPCIndex

                logger.debug("Instrumenting Pinecone grpc.GRPCIndex")
                self._wrap_index_class("pinecone.grpc", "GRPCIndex", GRPCIndex)
            except ImportError:
                logger.debug("GRPCIndex not available in any known path")

        # Try REST Index - try db_data.index first (abstract base class returned by factory)
        try:
            # Try pinecone.db_data.index (ABC returned by factory in newer versions)
            from pinecone.db_data.index import Index as DBDataIndex

            logger.debug("Instrumenting Pinecone db_data.index.Index (ABC)")
            self._wrap_index_class("pinecone.db_data.index", "Index", DBDataIndex)
        except ImportError:
            logger.debug("pinecone.db_data.index.Index not available")

        # Try REST Index - try internal module path
        try:
            # Try pinecone.data.index (internal module where Index is actually defined)
            from pinecone.data.index import Index

            logger.debug("Instrumenting Pinecone data.index.Index (internal module)")
            self._wrap_index_class("pinecone.data.index", "Index", Index)
        except ImportError:
            logger.debug("pinecone.data.index.Index not available")

        # Try REST Index - public import path
        try:
            from pinecone import Index

            logger.debug("Instrumenting Pinecone Index (public import)")
            self._wrap_index_class("pinecone", "Index", Index)
        except ImportError:
            logger.debug("pinecone.Index not available")

        # Try pinecone.data direct import (pinecone-client compatibility)
        try:
            from pinecone.data import Index as DataIndex

            logger.debug("Instrumenting Pinecone data.Index")
            self._wrap_index_class("pinecone.data", "Index", DataIndex)
        except ImportError:
            logger.debug("pinecone.data.Index not available")

    def _wrap_index_class(self, module_name: str, class_name: str, index_class: type) -> None:
        """Wrap all supported methods on an Index class.

        Args:
            module_name: Module name (e.g., "pinecone.grpc")
            class_name: Class name (e.g., "GRPCIndex")
            index_class: The Index class to wrap
        """
        # Read operations (Read Units)
        if hasattr(index_class, "query"):
            self._wrap_method(module_name, f"{class_name}.query", self._create_query_wrapper())
        if hasattr(index_class, "search"):
            # search() is an alias or alternative to query()
            self._wrap_method(module_name, f"{class_name}.search", self._create_query_wrapper())
        if hasattr(index_class, "fetch"):
            self._wrap_method(module_name, f"{class_name}.fetch", self._create_fetch_wrapper())
        if hasattr(index_class, "list"):
            self._wrap_method(module_name, f"{class_name}.list", self._create_list_wrapper())
        if hasattr(index_class, "describe_index_stats"):
            self._wrap_method(
                module_name, f"{class_name}.describe_index_stats", self._create_stats_wrapper()
            )

        # Write operations (Write Units)
        if hasattr(index_class, "upsert"):
            self._wrap_method(module_name, f"{class_name}.upsert", self._create_upsert_wrapper())
        if hasattr(index_class, "upsert_records"):
            # upsert_records() is an alternative upsert method with different signature
            self._wrap_method(
                module_name, f"{class_name}.upsert_records", self._create_upsert_records_wrapper()
            )
        if hasattr(index_class, "update"):
            self._wrap_method(module_name, f"{class_name}.update", self._create_update_wrapper())
        if hasattr(index_class, "delete"):
            self._wrap_method(module_name, f"{class_name}.delete", self._create_delete_wrapper())

        # Import/bulk operations (Write Units)
        for import_method in ["import_data", "import_", "bulk_import"]:
            if hasattr(index_class, import_method):
                self._wrap_method(
                    module_name, f"{class_name}.{import_method}", self._create_import_wrapper()
                )
                break

    def _instrument_inference_operations(self) -> None:
        """Instrument Pinecone inference operations (embeddings, rerank).

        Wraps both the Inference class methods and module-level functions
        to ensure all embedding and rerank operations are instrumented.
        """
        # Try the Inference class (primary approach for client.inference.embed/rerank)
        try:
            from pinecone.inference.inference import Inference

            logger.debug("Instrumenting Pinecone Inference class")

            # Instrument embed method on Inference class
            if hasattr(Inference, "embed"):
                self._wrap_method(
                    "pinecone.inference.inference",
                    "Inference.embed",
                    self._create_embeddings_wrapper(),
                )
                logger.debug("Wrapped Inference.embed")

            # Instrument rerank method on Inference class
            if hasattr(Inference, "rerank"):
                self._wrap_method(
                    "pinecone.inference.inference",
                    "Inference.rerank",
                    self._create_rerank_wrapper(),
                )
                logger.debug("Wrapped Inference.rerank")

        except ImportError as e:
            logger.debug(f"Could not import Inference class: {e}")
        except Exception as e:
            logger.debug(f"Error instrumenting Inference class: {e}")

        # Also try module-level functions (fallback approach)
        inference_modules = [
            "pinecone.inference",
            "pinecone",
        ]

        for module_name in inference_modules:
            try:
                if module_name == "pinecone.inference":
                    from pinecone import inference as inf_module
                else:
                    import pinecone

                    inf_module = pinecone

                # Try to instrument module-level embed function
                if hasattr(inf_module, "embed"):
                    self._wrap_method(module_name, "embed", self._create_embeddings_wrapper())
                    logger.debug(f"Wrapped {module_name}.embed (module-level)")

                # Try to instrument Embed class __call__
                if hasattr(inf_module, "Embed"):
                    self._wrap_method(
                        module_name, "Embed.__call__", self._create_embeddings_wrapper()
                    )
                    logger.debug(f"Wrapped {module_name}.Embed.__call__")

                # Try to instrument module-level rerank function
                if hasattr(inf_module, "rerank"):
                    self._wrap_method(module_name, "rerank", self._create_rerank_wrapper())
                    logger.debug(f"Wrapped {module_name}.rerank (module-level)")

                # Try to instrument Rerank class __call__
                if hasattr(inf_module, "Rerank"):
                    self._wrap_method(module_name, "Rerank.__call__", self._create_rerank_wrapper())
                    logger.debug(f"Wrapped {module_name}.Rerank.__call__")

            except ImportError as e:
                logger.debug(f"Could not import {module_name} for inference ops: {e}")
            except Exception as e:
                logger.debug(f"Error instrumenting {module_name} inference ops: {e}")

        logger.debug("Pinecone inference operations instrumentation complete")

    def _extract_index_name(self, instance: Any) -> Optional[str]:
        """Extract index name from Index instance.

        Args:
            instance: Pinecone Index instance

        Returns:
            Index name if available
        """
        # First check registry (from factory method call)
        if instance in _index_name_registry:
            index_name = _index_name_registry[instance]
            if isinstance(index_name, str):
                logger.debug(f"Found index name from registry: {index_name}")
                return index_name

        # Try different attributes (in order of likelihood)
        for attr in [
            "_index_name",
            "index_name",
            "name",
            "_name",
            "index",
            "_index",
        ]:
            if hasattr(instance, attr):
                try:
                    name = getattr(instance, attr)
                    if isinstance(name, str) and name:
                        logger.debug(f"Found index name from attribute '{attr}': {name}")
                        return name
                except Exception:
                    pass

        # Try checking __dict__ directly
        if hasattr(instance, "__dict__"):
            for key in ["_index_name", "index_name", "name", "_name", "index", "_index"]:
                if key in instance.__dict__:
                    try:
                        name = instance.__dict__[key]
                        if isinstance(name, str) and name:
                            logger.debug(f"Found index name from __dict__['{key}']: {name}")
                            return name
                    except Exception:
                        pass

        # Try checking config object
        for config_attr in ["config", "_config", "connection", "_connection"]:
            if hasattr(instance, config_attr):
                try:
                    config = getattr(instance, config_attr)
                    if config and hasattr(config, "__dict__"):
                        for key in ["index_name", "_index_name", "name", "index"]:
                            if key in config.__dict__:
                                name = config.__dict__[key]
                                if isinstance(name, str) and name:
                                    logger.debug(
                                        f"Found index name from {config_attr}.{key}: {name}"
                                    )
                                    return name
                except Exception:
                    pass

        # Try checking host/endpoint for index name pattern
        for host_attr in ["host", "_host", "endpoint", "_endpoint"]:
            if hasattr(instance, host_attr):
                try:
                    host = getattr(instance, host_attr)
                    if isinstance(host, str):
                        # Extract index name from URL if present
                        # Format: https://{index-name}-{project}.svc.{environment}.pinecone.io
                        match = re.search(r"https?://([^-]+)-", host)
                        if match:
                            index_name = match.group(1)
                            logger.debug(f"Extracted index name from {host_attr}: {index_name}")
                            return index_name
                except Exception:
                    pass

        logger.debug(f"Could not extract index name from instance type: {type(instance).__name__}")
        return None

    def _extract_base_attributes(
        self, instance: Any, operation: str, operation_subtype: str
    ) -> Dict[str, Any]:
        """Extract base attributes common to all operations.

        Args:
            instance: Pinecone Index instance
            operation: Operation name (e.g., "vector_search")
            operation_subtype: Operation subtype (e.g., "query")

        Returns:
            Base attributes dictionary
        """
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": operation,
            "mvk.operation_subtype": operation_subtype,
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        return attrs

    def _extract_namespace(self, kwargs: Dict[str, Any], attrs: Dict[str, Any]) -> None:
        """Extract namespace from kwargs if present.

        Args:
            kwargs: Keyword arguments
            attrs: Attributes dictionary to update
        """
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

    def _extract_usage_units(
        self, result: Any, unit_type: str, fallback: Optional[float] = None
    ) -> Optional[float]:
        """Extract usage units from result.

        Args:
            result: Result object
            unit_type: Type of units ("read_units", "write_units", "total_tokens", "requests")
            fallback: Fallback value if not found

        Returns:
            Units value or fallback
        """
        units = safe_extract_field(result, "usage", unit_type)
        if units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                # Try alternative field names
                if unit_type == "read_units":
                    units = usage.get("readUnits") or usage.get("read_units")
                elif unit_type == "write_units":
                    units = usage.get("writeUnits") or usage.get("write_units")
                elif unit_type == "total_tokens":
                    units = usage.get("tokens") or usage.get("total_tokens")
                elif unit_type == "requests":
                    units = usage.get("requests")

        return units if units is not None and units > 0 else fallback

    def _calculate_dense_vector_size(self, vector: Any) -> int:
        """Calculate size of a dense vector in bytes.

        Dense vectors cost 4 bytes per dimension.

        Args:
            vector: Vector data (list, tuple, or array-like)

        Returns:
            Size in bytes
        """
        try:
            if vector and hasattr(vector, "__len__"):
                dimensions = len(vector)
                return dimensions * PINECONE_DENSE_VECTOR_BYTES_PER_DIMENSION
        except Exception:
            pass
        return 0

    def _calculate_sparse_vector_size(self, sparse_vector: Any) -> int:
        """Calculate size of a sparse vector in bytes.

        Sparse vectors cost 9 bytes per non-zero value.

        Args:
            sparse_vector: Sparse vector (dict with indices/values or raw dict)

        Returns:
            Size in bytes
        """
        try:
            if sparse_vector is None:
                return 0

            # Handle dict format like {"indices": [1, 3], "values": [0.5, 0.8]}
            if isinstance(sparse_vector, dict):
                if "indices" in sparse_vector and "values" in sparse_vector:
                    indices = sparse_vector.get("indices", [])
                    if hasattr(indices, "__len__"):
                        non_zero_count = len(indices)
                        return non_zero_count * PINECONE_SPARSE_VECTOR_BYTES_PER_VALUE
                # Or treat dict keys as indices
                else:
                    non_zero_count = len(sparse_vector)
                    return non_zero_count * PINECONE_SPARSE_VECTOR_BYTES_PER_VALUE
        except Exception:
            pass
        return 0

    def _calculate_metadata_size(self, metadata: Any) -> int:
        """Calculate size of metadata in bytes.

        Metadata is included in record size calculations for both storage and operations.

        Args:
            metadata: Metadata object (dict, JSON-serializable, etc.)

        Returns:
            Size in bytes
        """
        try:
            if metadata is None:
                return 0

            if isinstance(metadata, dict):
                # Serialize to JSON to get accurate byte size
                return len(json.dumps(metadata).encode("utf-8"))
            elif isinstance(metadata, str):
                return len(metadata.encode("utf-8"))
            else:
                # Try to serialize to JSON
                return len(json.dumps(metadata).encode("utf-8"))
        except Exception:
            # Fallback: use sys.getsizeof
            try:
                return sys.getsizeof(metadata)
            except Exception:
                return 0

    def _calculate_record_id_size(self, record_id: Any) -> int:
        """Calculate size of a record ID in bytes.

        IDs are strings and contribute to record size.

        Args:
            record_id: Record ID (string)

        Returns:
            Size in bytes
        """
        try:
            if isinstance(record_id, str):
                return len(record_id.encode("utf-8"))
            else:
                return len(str(record_id).encode("utf-8"))
        except Exception:
            return 0

    def _calculate_record_size(self, record: Any, record_id: Optional[str] = None) -> int:
        """Calculate total size of a record in bytes.

        Record size = ID size + vector size(s) + metadata size

        Args:
            record: Record object (dict with values/metadata/id)
            record_id: Optional explicit record ID

        Returns:
            Total record size in bytes
        """
        total_size = 0

        try:
            # Add ID size
            if record_id:
                total_size += self._calculate_record_id_size(record_id)
            elif isinstance(record, dict) and "id" in record:
                total_size += self._calculate_record_id_size(record["id"])

            # Add dense vector size
            if isinstance(record, dict) and "values" in record:
                total_size += self._calculate_dense_vector_size(record["values"])

            # Add sparse vector size
            if isinstance(record, dict) and "sparse_values" in record:
                total_size += self._calculate_sparse_vector_size(record["sparse_values"])

            # Add metadata size
            if isinstance(record, dict) and "metadata" in record:
                total_size += self._calculate_metadata_size(record["metadata"])

        except Exception as e:
            logger.debug(f"Error calculating record size: {e}")

        return total_size

    def _calculate_payload_size(self, data: Any) -> int:
        """Estimate payload size in bytes for write operations.

        Handles both individual records and collections.
        For dicts with Pinecone record structure, uses detailed calculation.
        For list items, assumes ~1KB per item if they're not dicts (backward compatible).

        Args:
            data: Data to estimate (vectors, records, etc.)

        Returns:
            Estimated size in bytes
        """
        try:
            if isinstance(data, (list, tuple)):
                # Calculate size for each record
                total_size = 0
                for item in data:
                    if isinstance(item, dict):
                        # Try detailed record calculation first
                        record_size = self._calculate_record_size(item)
                        if record_size > 0:
                            total_size += record_size
                        else:
                            # Fallback: ~1KB per item (backward compatible)
                            total_size += 1024
                    else:
                        # Non-dict items: assume ~1KB per item (backward compatible)
                        total_size += 1024
                return total_size
            elif isinstance(data, dict):
                # Try detailed record calculation
                record_size = self._calculate_record_size(data)
                return record_size if record_size > 0 else sys.getsizeof(data)
            else:
                return sys.getsizeof(data)
        except Exception as e:
            logger.debug(f"Error calculating payload size: {e}")
            return 0

    def _extract_vector_dimensions(self, vector: Any) -> Optional[int]:
        """Extract dimensions from a vector.

        Args:
            vector: Vector data (list, tuple, or array-like)

        Returns:
            Number of dimensions or None
        """
        try:
            if vector and hasattr(vector, "__len__"):
                return len(vector)
        except Exception:
            pass
        return None

    def _extract_sparse_dimensions(self, sparse_vector: Any) -> Optional[int]:
        """Extract non-zero value count from a sparse vector.

        Args:
            sparse_vector: Sparse vector dict with indices/values

        Returns:
            Count of non-zero values or None
        """
        try:
            if sparse_vector is None:
                return None

            if isinstance(sparse_vector, dict):
                if "indices" in sparse_vector:
                    indices = sparse_vector["indices"]
                    if hasattr(indices, "__len__"):
                        return len(indices)
                else:
                    # Dict keys represent indices
                    return len(sparse_vector)
        except Exception:
            pass
        return None

    def _extract_record_metadata(self, record: Any) -> Optional[Dict[str, Any]]:
        """Extract metadata from a record.

        Args:
            record: Record object (dict with metadata field)

        Returns:
            Metadata dict or None
        """
        try:
            if isinstance(record, dict) and "metadata" in record:
                metadata = record["metadata"]
                if isinstance(metadata, dict):
                    return metadata
        except Exception:
            pass
        return None

    # ==================== Query Operation (Read Units) ====================

    def _create_query_wrapper(self):
        """Create wrapper for Pinecone query operations.

        Query performs vector similarity search and consumes Read Units (RUs).
        RU scales with namespace size (min 0.25 RU/query).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.query",
            span_kind="CLIENT",
            extract_attributes=self._extract_query_attributes,
            process_result=self._process_query_result,
        )

    def _extract_query_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from query operation."""
        attrs = self._extract_base_attributes(instance, "vector_search", "query")

        # Extract top_k
        if "top_k" in kwargs:
            attrs["mvk.query_limit"] = kwargs["top_k"]
            attrs["mvk.top_k"] = kwargs["top_k"]

        # Extract namespace
        self._extract_namespace(kwargs, attrs)

        # Extract filter info
        if "filter" in kwargs:
            attrs["mvk.has_filter"] = True

        # Calculate payload bytes for query vector and extract dimensions
        if "vector" in kwargs and kwargs["vector"]:
            vector = kwargs["vector"]
            dimensions = self._extract_vector_dimensions(vector)
            if dimensions:
                attrs["mvk.dimensions"] = dimensions
                # Calculate vector size: 4 bytes per dimension
                attrs["mvk.payload_bytes"] = dimensions * PINECONE_DENSE_VECTOR_BYTES_PER_DIMENSION

        # Extract sparse vector if present (hybrid search)
        if "sparse_vector" in kwargs and kwargs["sparse_vector"]:
            sparse_vector = kwargs["sparse_vector"]
            sparse_dims = self._extract_sparse_dimensions(sparse_vector)
            if sparse_dims:
                attrs["mvk.sparse_dimensions"] = sparse_dims

        return attrs

    def _process_query_result(self, span, result) -> None:
        """Process query result and extract usage metrics.

        Captures Read Units (RUs) from usage field if available.
        """
        # Extract result count
        count = 0
        if hasattr(result, "matches"):
            count = len(result.matches)
        elif isinstance(result, dict) and "matches" in result:
            count = len(result["matches"])

        if count > 0:
            span.set_attribute("mvk.results_count", count)
            span.set_attribute("mvk.record_count", count)

        # Extract usage metrics (Read Units)
        read_units = self._extract_usage_units(result, "read_units", fallback=0.25)
        span.set_attribute("mvk.read_units", float(read_units or 0.25))

        # Build metered usage
        builder = MeteredUsageBuilder()

        # Add Pinecone-specific metrics
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        builder.add_pinecone_metrics(
            read_units=float(read_units or 0.25),
            index_name=index_name,
            namespace=namespace,
            record_count=count,
            operation="query",
        )

        # Also add vector retrieval metric
        if count > 0:
            builder.add_metric("vector.retrieved", count, "vector")

        safe_populate_metered_usage(span, builder)

    # ==================== Fetch Operation (Read Units) ====================

    def _create_fetch_wrapper(self):
        """Create wrapper for Pinecone fetch operations.

        Fetch retrieves records by ID and consumes ~1 RU per 10 records (min 1 RU).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.fetch",
            span_kind="CLIENT",
            extract_attributes=self._extract_fetch_attributes,
            process_result=self._process_fetch_result,
        )

    def _extract_fetch_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from fetch operation."""
        attrs = self._extract_base_attributes(instance, "vector_retrieve", "fetch")

        # Extract namespace
        self._extract_namespace(kwargs, attrs)

        # Extract IDs count
        if "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                attrs["mvk.fetch_ids_count"] = len(ids)
                # Calculate payload bytes (approximate - ID strings + overhead)
                attrs["mvk.payload_bytes"] = (
                    sum(len(str(id_val)) for id_val in ids) + len(ids) * 100
                )

        return attrs

    def _process_fetch_result(self, span, result) -> None:
        """Process fetch result and extract usage metrics.

        Fetch RU calculation: 1 RU per 10 records (min 1 RU)
        """
        count = 0
        dimensions = None

        # Extract result count and analyze vectors
        if hasattr(result, "vectors"):
            vectors = result.vectors
            if hasattr(vectors, "__len__"):
                count = len(vectors)
            elif isinstance(vectors, dict):
                count = len(vectors)
                vectors = result.vectors.values() if isinstance(vectors, dict) else vectors

            # Analyze first vector for dimensions and metadata
            if count > 0 and isinstance(vectors, (list, tuple)) and len(vectors) > 0:
                first_vector = vectors[0]
                if isinstance(first_vector, dict):
                    # Extract dimensions
                    if "values" in first_vector:
                        dimensions = self._extract_vector_dimensions(first_vector["values"])
                    # Extract metadata size
                    if "metadata" in first_vector:
                        metadata = first_vector["metadata"]
                        metadata_size = self._calculate_metadata_size(metadata)
                        if metadata_size > 0:
                            span.set_attribute("mvk.metadata_size_per_record", metadata_size)

        elif isinstance(result, dict) and "vectors" in result:
            vectors = result["vectors"]
            if hasattr(vectors, "__len__"):
                count = len(vectors)

            # Analyze for dimensions and metadata
            if count > 0 and isinstance(vectors, (list, tuple)) and len(vectors) > 0:
                first_vector = vectors[0]
                if isinstance(first_vector, dict):
                    if "values" in first_vector:
                        dimensions = self._extract_vector_dimensions(first_vector["values"])
                    if "metadata" in first_vector:
                        metadata = first_vector["metadata"]
                        metadata_size = self._calculate_metadata_size(metadata)
                        if metadata_size > 0:
                            span.set_attribute("mvk.metadata_size_per_record", metadata_size)

        if count > 0:
            span.set_attribute("mvk.results_count", count)
            span.set_attribute("mvk.record_count", count)

        # Add dimensional details
        if dimensions:
            span.set_attribute("mvk.dimensions", dimensions)

        # Extract usage metrics (Read Units)
        # Per docs: 1 RU per 10 records fetched (min 1 RU)
        fallback_read_units = (
            max(PINECONE_MIN_FETCH_RU, count / 10.0) if count > 0 else PINECONE_MIN_FETCH_RU
        )
        read_units = self._extract_usage_units(result, "read_units", fallback=fallback_read_units)
        read_units = float(read_units or fallback_read_units)
        span.set_attribute("mvk.read_units", read_units)
        span.set_attribute("mvk.ru_calculation", f"{count} records -> {read_units:.2f}RU")

        # Build metered usage
        builder = MeteredUsageBuilder()
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        builder.add_pinecone_metrics(
            read_units=read_units,
            index_name=index_name,
            namespace=namespace,
            record_count=count,
            operation="fetch",
        )

        if count > 0:
            builder.add_metric("vector.retrieved", count, "vector")

        safe_populate_metered_usage(span, builder)

    # ==================== List Operation (Read Units) ====================

    def _create_list_wrapper(self):
        """Create wrapper for Pinecone list operations.

        List returns record IDs or namespaces and consumes fixed 1 RU per call.
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.list",
            span_kind="CLIENT",
            extract_attributes=self._extract_list_attributes,
            process_result=self._process_list_result,
        )

    def _extract_list_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from list operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_list",
            "mvk.operation_subtype": "list",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        return attrs

    def _process_list_result(self, span, result) -> None:
        """Process list result and extract usage metrics."""
        # Extract Read Units from response if available
        read_units = safe_extract_field(result, "usage", "read_units")
        if read_units is None:
            read_units = 1.0  # Fixed cost per Pinecone docs

        # Set read_units as span attribute
        span.set_attribute("mvk.read_units", float(read_units))

        # Build metered usage
        builder = MeteredUsageBuilder()
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        builder.add_pinecone_metrics(
            read_units=float(read_units),
            index_name=index_name,
            namespace=namespace,
            operation="list",
        )

        safe_populate_metered_usage(span, builder)

    # ==================== Stats Operation (Read Units) ====================

    def _create_stats_wrapper(self):
        """Create wrapper for Pinecone describe_index_stats operations.

        Stats operation returns index statistics and consumes fixed 1 RU per call.
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.describe_index_stats",
            span_kind="CLIENT",
            extract_attributes=self._extract_stats_attributes,
            process_result=self._process_stats_result,
        )

    def _extract_stats_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from describe_index_stats operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_stats",
            "mvk.operation_subtype": "describe_stats",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract filter if present
        if "filter" in kwargs:
            attrs["mvk.has_filter"] = True

        return attrs

    def _process_stats_result(self, span, result) -> None:
        """Process describe_index_stats result and extract usage metrics."""
        # Extract Read Units from response if available
        read_units = safe_extract_field(result, "usage", "read_units")
        if read_units is None:
            read_units = 1.0  # Fixed cost per Pinecone docs

        # Set read_units as span attribute
        span.set_attribute("mvk.read_units", float(read_units))

        # Build metered usage
        builder = MeteredUsageBuilder()
        index_name = span.attributes.get("mvk.index_name")

        builder.add_pinecone_metrics(
            read_units=float(read_units),
            index_name=index_name,
            operation="describe_stats",
        )

        # Also capture stats metrics if available
        if hasattr(result, "total_vector_count"):
            span.set_attribute("mvk.total_vector_count", result.total_vector_count)
        elif isinstance(result, dict) and "total_vector_count" in result:
            span.set_attribute("mvk.total_vector_count", result["total_vector_count"])

        safe_populate_metered_usage(span, builder)

    # ==================== Upsert Operation (Write Units) ====================

    def _create_upsert_wrapper(self):
        """Create wrapper for Pinecone upsert operations.

        Upsert inserts or replaces records and consumes ~1 WU per KB of request (min 5 WUs).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.upsert",
            span_kind="CLIENT",
            extract_attributes=self._extract_upsert_attributes,
            process_result=self._process_upsert_result,
        )

    def _extract_upsert_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from upsert operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_upsert",
            "mvk.operation_subtype": "upsert",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        # Count vectors being upserted and analyze their structure
        vectors_count = 0

        if "vectors" in kwargs:
            vectors = kwargs["vectors"]
            if hasattr(vectors, "__len__"):
                vectors_count = len(vectors)
                attrs["mvk.vectors_count"] = vectors_count
                attrs["mvk.record_count"] = vectors_count

                # Analyze first vector to get dimensions
                if vectors_count > 0:
                    first_vector = vectors[0] if isinstance(vectors, (list, tuple)) else None
                    if first_vector:
                        # Extract dense vector dimensions
                        if isinstance(first_vector, dict) and "values" in first_vector:
                            dimensions = self._extract_vector_dimensions(first_vector["values"])
                            if dimensions:
                                attrs["mvk.dimensions"] = dimensions

                        # Extract sparse vector dimensions
                        if isinstance(first_vector, dict) and "sparse_values" in first_vector:
                            sparse_dims = self._extract_sparse_dimensions(
                                first_vector["sparse_values"]
                            )
                            if sparse_dims:
                                attrs["mvk.sparse_dimensions"] = sparse_dims

                        # Extract metadata size
                        metadata = self._extract_record_metadata(first_vector)
                        if metadata:
                            metadata_size = self._calculate_metadata_size(metadata)
                            if metadata_size > 0:
                                attrs["mvk.metadata_size_per_record"] = metadata_size

        # Estimate payload size (critical for WU calculation)
        if vectors_count > 0:
            payload_bytes = self._calculate_payload_size(kwargs.get("vectors"))
            attrs["mvk.payload_bytes"] = payload_bytes
            attrs["mvk.payload_size_kb"] = payload_bytes / 1024.0

        return attrs

    def _process_upsert_result(self, span, result) -> None:
        """Process upsert result and extract usage metrics.

        Upsert WU calculation: 1 WU per 1 KB of request (min 5 WUs)
        Record size = ID + vector(s) + metadata
        """
        # Extract usage metrics (Write Units)
        write_units = safe_extract_field(result, "usage", "write_units")
        if write_units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                write_units = usage.get("writeUnits") or usage.get("write_units")

        # Get context from span
        vectors_count = span.attributes.get("mvk.record_count", 0)
        payload_bytes = span.attributes.get("mvk.payload_bytes", 0)
        payload_size_kb = span.attributes.get("mvk.payload_size_kb", 0)
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")
        dimensions = span.attributes.get("mvk.dimensions")
        sparse_dimensions = span.attributes.get("mvk.sparse_dimensions")
        metadata_size = span.attributes.get("mvk.metadata_size_per_record")

        # Set write_units as span attribute
        if write_units is not None and write_units > 0:
            span.set_attribute("mvk.write_units", float(write_units))
        else:
            # Fallback: estimate WUs per Pinecone docs
            # 1 WU per KB, minimum 5 WUs per request
            calculated_wu = (
                max(PINECONE_MIN_UPSERT_WU, payload_bytes / 1024.0)
                if payload_bytes > 0
                else PINECONE_MIN_UPSERT_WU
            )
            write_units = calculated_wu
            span.set_attribute("mvk.write_units", write_units)

        # Add cost estimation detail
        span.set_attribute("mvk.wu_calculation", f"{payload_size_kb:.2f}KB -> {write_units:.1f}WU")

        # Build metered usage
        builder = MeteredUsageBuilder()

        builder.add_pinecone_metrics(
            write_units=float(write_units),
            index_name=index_name,
            namespace=namespace,
            record_count=vectors_count,
            payload_bytes=payload_bytes,
            operation="upsert",
        )

        # Add dimensional details
        if dimensions:
            span.set_attribute("mvk.vector_dimensions", dimensions)
        if sparse_dimensions:
            span.set_attribute("mvk.sparse_dimensions", sparse_dimensions)
        if metadata_size:
            span.set_attribute("mvk.metadata_bytes_per_record", metadata_size)

        if vectors_count > 0:
            builder.add_metric("vector.processed", vectors_count, "vector")

        safe_populate_metered_usage(span, builder)

    # ==================== Upsert Records Operation (Write Units) ====================

    def _create_upsert_records_wrapper(self):
        """Create wrapper for Pinecone upsert_records operations.

        upsert_records is an alternative upsert method that may accept different
        data formats (e.g., records with structured metadata). Costs are the same
        as upsert: ~1 WU per KB of request (min 5 WUs).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.upsert_records",
            span_kind="CLIENT",
            extract_attributes=self._extract_upsert_records_attributes,
            process_result=self._process_upsert_records_result,
        )

    def _extract_upsert_records_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from upsert_records operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_upsert",
            "mvk.operation_subtype": "upsert_records",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        # Count records being upserted
        # upsert_records typically accepts records as a list
        records_count = 0
        if "records" in kwargs:
            records = kwargs["records"]
            if hasattr(records, "__len__"):
                records_count = len(records)
                attrs["mvk.records_count"] = records_count
                attrs["mvk.record_count"] = records_count
        elif len(args) > 0:
            # First positional arg might be records
            records = args[0]
            if hasattr(records, "__len__"):
                records_count = len(records)
                attrs["mvk.records_count"] = records_count
                attrs["mvk.record_count"] = records_count

        # Estimate payload size
        if records_count > 0:
            payload_bytes = self._calculate_payload_size(
                kwargs.get("records") or (args[0] if args else None)
            )
            attrs["mvk.payload_bytes"] = payload_bytes

        return attrs

    def _process_upsert_records_result(self, span, result) -> None:
        """Process upsert_records result and extract usage metrics."""
        # Extract usage metrics (Write Units)
        write_units = safe_extract_field(result, "usage", "write_units")
        if write_units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                write_units = usage.get("writeUnits") or usage.get("write_units")

        # Get context from span
        records_count = span.attributes.get("mvk.record_count", 0)
        payload_bytes = span.attributes.get("mvk.payload_bytes", 0)
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        # Set write_units as span attribute
        if write_units is not None and write_units > 0:
            span.set_attribute("mvk.write_units", float(write_units))
        else:
            # Fallback: estimate WUs (~1 WU per KB, min 5 WUs)
            write_units = max(5.0, payload_bytes / 1024.0) if payload_bytes > 0 else 5.0
            span.set_attribute("mvk.write_units", write_units)

        # Build metered usage
        builder = MeteredUsageBuilder()

        builder.add_pinecone_metrics(
            write_units=float(write_units),
            index_name=index_name,
            namespace=namespace,
            record_count=records_count,
            payload_bytes=payload_bytes,
            operation="upsert_records",
        )

        if records_count > 0:
            builder.add_metric("vector.processed", records_count, "vector")

        safe_populate_metered_usage(span, builder)

    # ==================== Update Operation (Write Units) ====================

    def _create_update_wrapper(self):
        """Create wrapper for Pinecone update operations.

        Update modifies existing records and counts old + new record size for WUs.
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.update",
            span_kind="CLIENT",
            extract_attributes=self._extract_update_attributes,
            process_result=self._process_update_result,
        )

    def _extract_update_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from update operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_update",
            "mvk.operation_subtype": "write",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        # Extract ID (single record update)
        if "id" in kwargs:
            attrs["mvk.record_count"] = 1

        # Estimate payload size
        payload_bytes = self._calculate_payload_size(kwargs)
        attrs["mvk.payload_bytes"] = payload_bytes

        return attrs

    def _process_update_result(self, span, result) -> None:
        """Process update result and extract usage metrics."""
        # Extract usage metrics (Write Units)
        write_units = safe_extract_field(result, "usage", "write_units")
        if write_units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                write_units = usage.get("writeUnits") or usage.get("write_units")

        # Get context from span
        record_count = span.attributes.get("mvk.record_count", 1)
        payload_bytes = span.attributes.get("mvk.payload_bytes", 0)
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        # Set write_units as span attribute
        if write_units is not None and write_units > 0:
            span.set_attribute("mvk.write_units", float(write_units))
        else:
            # Fallback: estimate WUs (counts old + new size, min 5 WUs)
            write_units = max(5.0, (payload_bytes * 2) / 1024.0) if payload_bytes > 0 else 5.0
            span.set_attribute("mvk.write_units", write_units)

        # Build metered usage
        builder = MeteredUsageBuilder()

        builder.add_pinecone_metrics(
            write_units=float(write_units),
            index_name=index_name,
            namespace=namespace,
            record_count=record_count,
            payload_bytes=payload_bytes,
            operation="update",
        )

        safe_populate_metered_usage(span, builder)

    # ==================== Delete Operation (Write Units) ====================

    def _create_delete_wrapper(self):
        """Create wrapper for Pinecone delete operations.

        Delete removes records and consumes ~1 WU per KB of deleted data (min 5 WUs).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.delete",
            span_kind="CLIENT",
            extract_attributes=self._extract_delete_attributes,
            process_result=self._process_delete_result,
        )

    def _extract_delete_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from delete operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_delete",
            "mvk.operation_subtype": "delete",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        # Count IDs being deleted
        if "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                attrs["mvk.record_count"] = len(ids)

        # Delete all in namespace
        if "delete_all" in kwargs and kwargs["delete_all"]:
            attrs["mvk.delete_all"] = True

        return attrs

    def _process_delete_result(self, span, result) -> None:
        """Process delete result and extract usage metrics."""
        # Extract usage metrics (Write Units)
        write_units = safe_extract_field(result, "usage", "write_units")
        if write_units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                write_units = usage.get("writeUnits") or usage.get("write_units")

        # Get context from span
        record_count = span.attributes.get("mvk.record_count", 0)
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        # Set write_units as span attribute
        if write_units is not None and write_units > 0:
            span.set_attribute("mvk.write_units", float(write_units))
        else:
            # Fallback: minimum 5 WUs
            write_units = 5.0
            span.set_attribute("mvk.write_units", write_units)

        # Build metered usage
        builder = MeteredUsageBuilder()

        builder.add_pinecone_metrics(
            write_units=float(write_units),
            index_name=index_name,
            namespace=namespace,
            record_count=record_count,
            operation="delete",
        )

        safe_populate_metered_usage(span, builder)

    # ==================== Import Operation (Write Units) ====================

    def _create_import_wrapper(self):
        """Create wrapper for Pinecone import/bulk operations.

        Import bulk loads from object storage and costs = data size read (KB) in WUs.
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.import",
            span_kind="CLIENT",
            extract_attributes=self._extract_import_attributes,
            process_result=self._process_import_result,
        )

    def _extract_import_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from import operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "vector_import",
            "mvk.operation_subtype": "bulk_write",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract index name
        index_name = self._extract_index_name(instance)
        if index_name:
            attrs["mvk.index_name"] = index_name

        # Extract namespace
        if "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

        # Extract URI/source info
        if "uri" in kwargs:
            attrs["import_source"] = "object_storage"

        return attrs

    def _process_import_result(self, span, result) -> None:
        """Process import result and extract usage metrics."""
        # Extract usage metrics (Write Units)
        write_units = safe_extract_field(result, "usage", "write_units")
        if write_units is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                write_units = usage.get("writeUnits") or usage.get("write_units")

        # Get context from span
        index_name = span.attributes.get("mvk.index_name")
        namespace = span.attributes.get("mvk.namespace")

        # Set write_units as span attribute if available
        if write_units is not None and write_units > 0:
            span.set_attribute("mvk.write_units", float(write_units))

        # Build metered usage
        builder = MeteredUsageBuilder()

        if write_units is not None and write_units > 0:
            builder.add_pinecone_metrics(
                write_units=float(write_units),
                index_name=index_name,
                namespace=namespace,
                operation="import",
            )

        safe_populate_metered_usage(span, builder)

    # ==================== Embeddings Operation (Token Units) ====================

    def _create_embeddings_wrapper(self):
        """Create wrapper for Pinecone embeddings operations.

        Embeddings generation costs per token processed (not RU/WU).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.embeddings",
            span_kind="CLIENT",
            extract_attributes=self._extract_embeddings_attributes,
            process_result=self._process_embeddings_result,
        )

    def _extract_embeddings_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from embeddings operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "embedding",
            "mvk.operation_subtype": "generate",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract model info
        if "model" in kwargs:
            attrs["mvk.model_name"] = kwargs["model"]
            attrs["mvk.model_type"] = "embedding"

        # Extract input count
        if "inputs" in kwargs:
            inputs = kwargs["inputs"]
            if hasattr(inputs, "__len__"):
                attrs["mvk.input_count"] = len(inputs)

        return attrs

    def _process_embeddings_result(self, span, result) -> None:
        """Process embeddings result and extract usage metrics."""
        # Extract usage metrics (Token Units)
        tokens = safe_extract_field(result, "usage", "total_tokens")
        if tokens is None and hasattr(result, "usage"):
            usage = getattr(result, "usage", {})
            if isinstance(usage, dict):
                tokens = usage.get("tokens") or usage.get("total_tokens")

        # Set tokens as span attribute if available
        if tokens is not None and tokens > 0:
            span.set_attribute("mvk.tokens", int(tokens))

        # Extract dimensions and vector count
        vectors_count = 0
        dimensions = None
        if hasattr(result, "data"):
            data = result.data
            if hasattr(data, "__len__"):
                vectors_count = len(data)
                if vectors_count > 0 and hasattr(data[0], "values"):
                    values = data[0].values
                    if hasattr(values, "__len__"):
                        dimensions = len(values)

        if vectors_count > 0:
            span.set_attribute("mvk.record_count", vectors_count)
        if dimensions is not None:
            span.set_attribute("mvk.dimensions", dimensions)

        # Build metered usage
        builder = MeteredUsageBuilder()

        if tokens is not None and tokens > 0:
            builder.add_pinecone_metrics(
                tokens=int(tokens),
                record_count=vectors_count,
                operation="embeddings",
            )

        # Add embedding metrics
        if vectors_count > 0:
            builder.add_embedding_metrics(
                prompt_tokens=tokens,
                vectors=vectors_count,
                dimensions=dimensions,
            )

        safe_populate_metered_usage(span, builder)

    # ==================== Rerank Operation (Request Units) ====================

    def _create_rerank_wrapper(self):
        """Create wrapper for Pinecone rerank operations.

        Rerank costs per request (fixed per batch).
        """
        return WrapperBase.create_wrapper(
            span_name="pinecone.rerank",
            span_kind="CLIENT",
            extract_attributes=self._extract_rerank_attributes,
            process_result=self._process_rerank_result,
        )

    def _extract_rerank_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from rerank operation."""
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "pinecone",
            "mvk.operation": "rerank",
            "mvk.operation_subtype": "rerank",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract model info
        if "model" in kwargs:
            attrs["mvk.model_name"] = kwargs["model"]

        # Extract document count
        if "documents" in kwargs:
            docs = kwargs["documents"]
            if hasattr(docs, "__len__"):
                attrs["mvk.document_count"] = len(docs)

        return attrs

    def _process_rerank_result(self, span, result) -> None:
        """Process rerank result and extract usage metrics."""
        # Extract usage if provided
        requests = safe_extract_field(result, "usage", "requests")
        if requests is None:
            requests = 1  # Default to 1 request per call

        # Set requests as span attribute
        span.set_attribute("mvk.requests", int(requests))

        # Build metered usage
        builder = MeteredUsageBuilder()

        builder.add_pinecone_metrics(
            requests=int(requests),
            operation="rerank",
        )

        safe_populate_metered_usage(span, builder)
