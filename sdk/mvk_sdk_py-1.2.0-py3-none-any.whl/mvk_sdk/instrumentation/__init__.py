"""MVK SDK Instrumentation module following OpenTelemetry patterns."""

from .base import BaseInstrumentor

__all__ = ["BaseInstrumentor"]
