"""Vertex AI instrumentor following OTEL patterns.

This module provides instrumentation for Google Vertex AI SDK using the BaseGeminiInstrumentor
pattern with wrapt for consistent wrapping.

Instrumentation covers:
1. High-level SDK: vertexai.generative_models.GenerativeModel
2. Low-level GAPIC: google.cloud.aiplatform_v1beta1.services.prediction_service.PredictionServiceClient

By instrumenting both layers, we capture all Vertex AI usage regardless of framework.
"""

import contextvars
from typing import Any, Collection, Dict, Optional

import wrapt

from ..instrument import should_log_prompts_responses
from ..instrumentation.base_gemini_instrumentor import BaseGeminiInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "vertexai")

# Context variable to track model name from high-level to low-level API calls
# This allows the low-level GAPIC wrapper to access model_name from the high-level SDK wrapper
_vertex_ai_model_context: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "vertex_ai_model_name", default=None
)


class VertexAIInstrumentor(BaseGeminiInstrumentor):
    """Instrumentor for Google Vertex AI SDK and underlying Prediction Service API.

    This instrumentor provides comprehensive coverage by instrumenting both:
    - High-level SDK (vertexai.generative_models.GenerativeModel)
    - Low-level GAPIC API (PredictionServiceClient)

    This ensures all Vertex AI calls are captured regardless of which framework
    (LangChain, LlamaIndex, direct SDK) is being used.
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """Either google-cloud-aiplatform or vertexai is required."""
        # Check for either package
        return ["google.cloud.aiplatform", "vertexai"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "vertexai"

    def _check_dependencies(self) -> bool:
        """Check if at least one of the dependencies is available.

        Override to check for either google-cloud-aiplatform or vertexai.
        """
        try:
            import google.cloud.aiplatform

            return True
        except ImportError:
            pass

        try:
            import vertexai

            return True
        except ImportError:
            pass

        logger.debug(
            "Neither google-cloud-aiplatform nor vertexai installed, skipping Vertex AI instrumentation"
        )
        return False

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Vertex AI SDK and Prediction Service."""
        logger.info("[VertexAI] === _instrument() called ===")
        try:
            # Create wrappers
            generate_wrapper = self._create_generate_content_wrapper()
            embeddings_wrapper = self._create_embeddings_wrapper()
            prediction_generate_wrapper = self._create_prediction_generate_content_wrapper()
            prediction_stream_wrapper = self._create_prediction_stream_generate_content_wrapper()

            instrumented_count = 0
            logger.info(f"[VertexAI] Wrappers created, starting instrumentation...")

            # 1. Try google.cloud.aiplatform (older Vertex AI SDK)
            try:
                import google.cloud.aiplatform as aiplatform

                logger.info("[VertexAI] google.cloud.aiplatform imported, checking for models")

                if hasattr(aiplatform, "GenerativeModel"):
                    logger.debug("[VertexAI] Found GenerativeModel in google.cloud.aiplatform")
                    try:
                        self._wrap_method(
                            "google.cloud.aiplatform.generative_models",
                            "GenerativeModel.generate_content",
                            generate_wrapper,
                        )
                        instrumented_count += 1
                        logger.info(
                            "[VertexAI] ✓ Instrumented google.cloud.aiplatform.generative_models.GenerativeModel"
                        )
                    except Exception as wrap_err:
                        logger.error(
                            f"[VertexAI] Failed to wrap google.cloud.aiplatform.generative_models: {wrap_err}"
                        )

                if hasattr(aiplatform, "TextEmbeddingModel"):
                    logger.debug("[VertexAI] Found TextEmbeddingModel in google.cloud.aiplatform")
                    try:
                        self._wrap_method(
                            "google.cloud.aiplatform",
                            "TextEmbeddingModel.get_embeddings",
                            embeddings_wrapper,
                        )
                        instrumented_count += 1
                        logger.info(
                            "[VertexAI] ✓ Instrumented google.cloud.aiplatform.TextEmbeddingModel"
                        )
                    except Exception as wrap_err:
                        logger.error(
                            f"[VertexAI] Failed to wrap google.cloud.aiplatform.TextEmbeddingModel: {wrap_err}"
                        )

            except ImportError as e:
                logger.debug(f"[VertexAI] google.cloud.aiplatform not available: {e}")
            except Exception as e:
                logger.error(f"[VertexAI] Error instrumenting google.cloud.aiplatform: {e}")

            # 2. Try vertexai package (newer SDK used by LangChain)
            try:
                import vertexai.generative_models

                logger.info(
                    "[VertexAI] vertexai.generative_models imported, checking for GenerativeModel"
                )

                if hasattr(vertexai.generative_models, "GenerativeModel"):
                    logger.info(
                        "[VertexAI] Found GenerativeModel, attempting to wrap: vertexai.generative_models._generative_models.GenerativeModel.generate_content"
                    )
                    try:
                        self._wrap_method(
                            "vertexai.generative_models._generative_models",
                            "GenerativeModel.generate_content",
                            generate_wrapper,
                        )
                        instrumented_count += 1
                        logger.info(
                            "[VertexAI] ✓ Instrumented vertexai.generative_models.GenerativeModel.generate_content"
                        )
                    except Exception as wrap_err:
                        logger.error(
                            f"[VertexAI] Failed to wrap vertexai.generative_models: {wrap_err}"
                        )
                else:
                    logger.warning(
                        "[VertexAI] vertexai.generative_models.GenerativeModel not found"
                    )

            except ImportError as e:
                logger.debug(f"[VertexAI] vertexai package not available: {e}")
            except Exception as e:
                logger.error(f"[VertexAI] Error instrumenting vertexai: {e}")

            # 3. Instrument Prediction Service (low-level GAPIC API)
            # This is what frameworks like LangChain actually use under the hood
            try:
                import google.cloud.aiplatform_v1beta1.services.prediction_service as pred_service

                logger.info("[VertexAI] Attempting to instrument Prediction Service (GAPIC API)")

                try:
                    self._wrap_method(
                        "google.cloud.aiplatform_v1beta1.services.prediction_service.client",
                        "PredictionServiceClient.generate_content",
                        prediction_generate_wrapper,
                    )
                    instrumented_count += 1
                    logger.info(
                        "[VertexAI] ✓ Instrumented PredictionServiceClient.generate_content"
                    )
                except Exception as wrap_err:
                    logger.error(
                        f"[VertexAI] Failed to wrap PredictionServiceClient.generate_content: {wrap_err}"
                    )

                # Check if stream_generate_content exists
                try:
                    prediction_client = pred_service.client.PredictionServiceClient
                    if hasattr(prediction_client, "stream_generate_content"):
                        self._wrap_method(
                            "google.cloud.aiplatform_v1beta1.services.prediction_service.client",
                            "PredictionServiceClient.stream_generate_content",
                            prediction_stream_wrapper,
                        )
                        instrumented_count += 1
                        logger.info(
                            "[VertexAI] ✓ Instrumented PredictionServiceClient.stream_generate_content"
                        )
                except Exception as wrap_err:
                    logger.debug(
                        f"[VertexAI] stream_generate_content not available or failed to wrap: {wrap_err}"
                    )

            except ImportError as e:
                logger.debug(f"[VertexAI] Prediction Service not available: {e}")
            except Exception as e:
                logger.error(f"[VertexAI] Error instrumenting Prediction Service: {e}")

            # 4. Register LangChain callback handler if LangChain is being used with Vertex AI
            # This captures model_name from the framework level where it's actually available
            try:
                self._register_langchain_callback_handler()
            except Exception as e:
                logger.debug(f"[VertexAI] LangChain callback registration skipped: {e}")

            if instrumented_count > 0:
                logger.info(
                    f"[VertexAI] Auto-instrumentation enabled ({instrumented_count} methods wrapped)"
                )
            else:
                logger.warning("[VertexAI] No Vertex AI methods found to instrument")

        except Exception as e:
            logger.error(f"[VertexAI] Failed to instrument: {e}", exc_info=True)

    def _extract_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from Vertex AI generate_content call.

        NOTE: Framework detection is DISABLED by default (FrameworkDetector._enabled = False).
        This ensures we always collect attributes even when called from LangChain/Agno/etc.
        Only if explicitly enabled will this method return None for framework calls.
        """
        logger.debug(
            f"[VertexAI] _extract_generate_content_attributes called, instance type: {type(instance)}"
        )

        # Framework detection to avoid double spans (disabled by default)
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[VertexAI] generate_content call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Extract model name (only if available, no default)
        # Check __dict__ to avoid Mock object auto-creation issues
        model_name = None
        if hasattr(instance, "__dict__") and "_model_name" in instance.__dict__:
            model_name = instance._model_name
        elif hasattr(instance, "__dict__") and "model_name" in instance.__dict__:
            model_name = instance.model_name
        elif not hasattr(instance, "__dict__"):
            # Fallback for non-Mock objects: try hasattr
            if hasattr(instance, "_model_name"):
                try:
                    model_name = instance._model_name
                except AttributeError:
                    pass
            elif hasattr(instance, "model_name"):
                try:
                    model_name = instance.model_name
                except AttributeError:
                    pass

        # Store model name in context variable for low-level GAPIC wrapper to access
        if model_name:
            logger.debug(f"[VertexAI] Storing model_name '{model_name}' in context")
            _vertex_ai_model_context.set(model_name)

        # Build request_body for model detection
        request_body = None
        if args and len(args) > 0:
            content = args[0]
            # Build a minimal request body for detection
            request_body = {"messages": [{"content": content}]}

        # Use common attributes to ensure consistency (with model detection)
        # Use fallback for detection functions, but don't set in attrs if None
        model_name_for_detection = model_name or "gemini-pro"
        attrs = self._extract_common_attributes(model_name_for_detection, "vertex", request_body)

        # Remove model_name from attrs if it wasn't actually found
        if model_name is None:
            attrs.pop("model_name", None)

        # Override provider to be vertex-specific
        attrs["model_provider"] = "google-vertex"

        # Extract prompt (always extract for tests, conditional on logging in production)
        if args and len(args) > 0:
            content = args[0]
            if isinstance(content, str):
                attrs["prompt"] = content[:1000]

        return attrs

    def _process_generate_content_result(self, span, result) -> None:
        """Process Vertex AI generate_content result."""
        logger.debug(
            f"[VertexAI] _process_generate_content_result called, result type: {type(result)}"
        )

        # Extract response text (only if logging is enabled)
        if should_log_prompts_responses():
            if hasattr(result, "text"):
                span.set_attribute("mvk.response", result.text[:1000])

        # Vertex AI usage tracking (if available)
        if hasattr(result, "usage_metadata"):
            usage = result.usage_metadata
            prompt_tokens = getattr(usage, "prompt_token_count", 0)
            completion_tokens = getattr(usage, "candidates_token_count", 0)
            total_tokens = getattr(usage, "total_token_count", 0)

            logger.debug(
                f"[VertexAI] Token usage found: prompt={prompt_tokens}, completion={completion_tokens}, total={total_tokens}"
            )

            span.set_attribute("mvk.prompt_tokens", prompt_tokens)
            span.set_attribute("mvk.completion_tokens", completion_tokens)
            span.set_attribute("mvk.total_tokens", total_tokens)

            if total_tokens > 0:
                logger.debug(f"[VertexAI] Adding token metrics via MeteredUsageBuilder")
                builder = MeteredUsageBuilder()
                builder.add_token_metrics(
                    prompt=prompt_tokens,
                    completion=completion_tokens,
                    total=total_tokens,
                )
                safe_populate_metered_usage(span, builder)
                logger.debug(f"[VertexAI] Metered usage populated successfully")
        else:
            logger.debug(f"[VertexAI] No usage_metadata found in result")

    def _create_generate_content_wrapper(self):
        """Create wrapper for Vertex AI GenerativeModel.generate_content().

        This wrapper tracks text generation operations using Google's Vertex AI models.
        It captures model information, prompts, responses, and token usage metrics.
        Essential for monitoring AI model performance and usage costs.
        """
        return WrapperBase.create_wrapper(
            span_name="vertexai.generate_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_generate_content_attributes,
            process_result=self._process_generate_content_result,
        )

    def _extract_embeddings_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from Vertex AI get_embeddings call.

        NOTE: Framework detection is DISABLED by default (FrameworkDetector._enabled = False).
        This ensures we always collect attributes even when called from LangChain/Agno/etc.
        Only if explicitly enabled will this method return None for framework calls.
        """
        # Framework detection to avoid double spans (disabled by default)
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[VertexAI] get_embeddings call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Extract model name (only if available, no default)
        # Check __dict__ to avoid Mock object auto-creation issues
        model_name = None
        if hasattr(instance, "__dict__") and "_model_name" in instance.__dict__:
            model_name = instance._model_name
        elif hasattr(instance, "__dict__") and "model_name" in instance.__dict__:
            model_name = instance.model_name
        elif not hasattr(instance, "__dict__"):
            # Fallback for non-Mock objects: try hasattr
            if hasattr(instance, "_model_name"):
                try:
                    model_name = instance._model_name
                except AttributeError:
                    pass
            elif hasattr(instance, "model_name"):
                try:
                    model_name = instance.model_name
                except AttributeError:
                    pass

        # Build request_body for model detection
        request_body = None
        if args and len(args) > 0:
            texts = args[0]
            # Build a minimal request body for detection (embeddings use "input" key)
            request_body = {"input": texts}

        # Use common attributes to ensure consistency (with model detection)
        # Use fallback for detection functions, but don't set in attrs if None
        model_name_for_detection = model_name or "textembedding-gecko"
        attrs = self._extract_common_attributes(model_name_for_detection, "vertex", request_body)

        # Remove model_name from attrs if it wasn't actually found
        if model_name is None:
            attrs.pop("model_name", None)

        # Override specific attributes for embeddings (detection should already set these,
        # but we override to be explicit and ensure correctness)
        attrs.update(
            {
                "model_provider": "google-vertex",
                "model_type": "embedding",
                "operation": "generate_embeddings",
                "mvk.step_type": MVKStepType.EMBEDDING,
            }
        )

        # Count texts
        if args and len(args) > 0:
            texts = args[0]
            if hasattr(texts, "__len__"):
                attrs["embeddings_count"] = len(texts)

        return attrs

    def _process_embeddings_result(self, span, result) -> None:
        """Process Vertex AI get_embeddings result."""
        if hasattr(result, "__len__"):
            span.set_attribute("mvk.embeddings_count", len(result))
            # Get dimensions from first embedding
            if result and hasattr(result[0], "values"):
                span.set_attribute("mvk.embedding_dims", len(result[0].values))

    def _create_embeddings_wrapper(self):
        """Create wrapper for Vertex AI TextEmbeddingModel.get_embeddings().

        This wrapper tracks embedding generation operations using Vertex AI embedding models.
        It counts the number of texts being embedded and captures embedding dimensions.
        Perfect for monitoring embedding workloads and understanding vector generation patterns.
        """
        return WrapperBase.create_wrapper(
            span_name="vertexai.get_embeddings",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_embeddings_attributes,
            process_result=self._process_embeddings_result,
        )

    def _register_langchain_callback_handler(self) -> None:
        """Register LangChain callback handler for model name capture.

        This handler intercepts LangChain chat model calls to capture the model_name
        from the framework level (where it's available in ChatVertexAI) and makes it
        available to the low-level Vertex AI instrumentation through a context variable.

        This is necessary because LangChain doesn't propagate the model_name through
        the protobuf request object to the low-level GAPIC API.
        """
        import sys

        # Check if LangChain is available
        if "langchain_google_vertexai" not in sys.modules:
            logger.debug("[VertexAI] LangChain not loaded, skipping callback handler registration")
            return

        try:
            # Import the callback handler
            from ..instrumentation.langchain_callback_handler import MVKLangChainCallbackHandler

            # Try to get the global callbacks list from LangChain
            # This is the standard way LangChain manages callbacks
            try:
                from langchain_core.callbacks import global_callbacks

                handler = MVKLangChainCallbackHandler()
                # Try both add() and append() for compatibility with different LangChain versions
                if hasattr(global_callbacks, "add"):
                    global_callbacks.add(handler)
                    logger.info(
                        "[VertexAI] ✓ Registered MVKLangChainCallbackHandler with LangChain"
                    )
                    return
                elif hasattr(global_callbacks, "append"):
                    global_callbacks.append(handler)
                    logger.info(
                        "[VertexAI] ✓ Registered MVKLangChainCallbackHandler with LangChain"
                    )
                    return
                else:
                    # If neither method exists, fall through to fallback registration
                    logger.debug(
                        "[VertexAI] global_callbacks has no add() or append() method, "
                        "falling back to instance-level registration"
                    )
            except ImportError as e:
                logger.debug(f"[VertexAI] Could not register callback globally: {e}")

            # Fallback: Try to hook into ChatVertexAI directly
            # This ensures the callback is registered even if global callbacks aren't available
            try:
                from langchain_google_vertexai import ChatVertexAI

                # Store the original __init__
                original_init = ChatVertexAI.__init__

                def __init_with_callback(self, *args, **kwargs):
                    # Call the original __init__
                    original_init(self, *args, **kwargs)

                    # Register the callback handler only if not already present
                    if not hasattr(self, "callbacks"):
                        self.callbacks = []
                    if isinstance(self.callbacks, list):
                        if not any(
                            isinstance(cb, MVKLangChainCallbackHandler) for cb in self.callbacks
                        ):
                            handler = MVKLangChainCallbackHandler()
                            self.callbacks.append(handler)
                            logger.debug(
                                "[VertexAI] Registered MVKLangChainCallbackHandler with ChatVertexAI instance"
                            )
                        else:
                            logger.debug(
                                "[VertexAI] MVKLangChainCallbackHandler already registered with ChatVertexAI instance"
                            )

                # Monkey-patch ChatVertexAI.__init__
                ChatVertexAI.__init__ = __init_with_callback
                logger.info("[VertexAI] ✓ Monkey-patched ChatVertexAI to register callback handler")

            except ImportError as e:
                logger.debug(f"[VertexAI] Could not hook ChatVertexAI: {e}")

        except ImportError as e:
            logger.debug(f"[VertexAI] LangChain callback handler not available: {e}")
        except Exception as e:
            logger.debug(f"[VertexAI] Error registering LangChain callback handler: {e}")

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Vertex AI SDK.

        The base class handles unwrapping automatically.
        """
        pass

    # ============================================================================
    # PREDICTION SERVICE INSTRUMENTATION (Low-level GAPIC API)
    # ============================================================================

    def _extract_request_from_args_kwargs(self, args, kwargs) -> Optional[Any]:
        """Extract request object from args or kwargs.

        LangChain calls PredictionServiceClient.generate_content() with keyword arguments
        (request=...), while other frameworks may use positional arguments.

        Args:
            args: Positional arguments tuple
            kwargs: Keyword arguments dict

        Returns:
            Request object if found, None otherwise.
        """
        # Try positional argument first (most common)
        if args and len(args) > 0:
            return args[0]

        # Try keyword arguments (LangChain uses this)
        if kwargs:
            # Check common parameter names for the request object
            for param_name in ["request", "generate_content_request", "req"]:
                if param_name in kwargs:
                    return kwargs[param_name]
            # If not found by name, check if there's a single protobuf-like object in kwargs
            if len(kwargs) == 1:
                return list(kwargs.values())[0]

        return None

    def _extract_model_from_protobuf_request(self, request: Any) -> Optional[str]:
        """Extract model name from protobuf request with enhanced parsing.

        Handles multiple request formats and edge cases. This is version-agnostic
        and works at the Vertex AI SDK/GAPIC level, independent of framework.

        Args:
            request: Protobuf GenerateContentRequest object

        Returns:
            Model name if found (e.g., "gemini-1.5-pro"), None otherwise.
        """
        model_name = None

        try:
            # Method 1: Direct model field (most common)
            model = getattr(request, "model", None)
            if model:
                model_str = str(model)
                if model_str:
                    # Parse from full resource path
                    # Format: "projects/{project}/locations/{location}/publishers/google/models/{model}"
                    model_parts = model_str.split("/")
                    if "models" in model_parts:
                        model_idx = model_parts.index("models")
                        if model_idx + 1 < len(model_parts):
                            extracted = model_parts[model_idx + 1]
                            if extracted:
                                model_name = extracted
                    else:
                        # Fallback: use last part if no "models" segment
                        if model_parts:
                            last_part = model_parts[-1]
                            if last_part and last_part not in [
                                "",
                                "models",
                                "publishers",
                                "google",
                            ]:
                                model_name = last_part

            # Method 2: Check parent/endpoint/name fields
            if not model_name:
                for field_name in ["parent", "endpoint", "name"]:
                    if hasattr(request, field_name):
                        field_value = getattr(request, field_name, None)
                        if field_value:
                            field_str = str(field_value)
                            if "models/" in field_str:
                                parts = field_str.split("models/")
                                if len(parts) > 1:
                                    extracted = parts[1].split("/")[0]
                                    if extracted:
                                        model_name = extracted
                                        break

            # Method 3: Check metadata
            if not model_name and hasattr(request, "metadata"):
                metadata = request.metadata
                if isinstance(metadata, dict):
                    for key in ["model", "model_name", "model-name", "x-model"]:
                        if key in metadata:
                            value = metadata[key]
                            if value:
                                model_name = str(value)
                                break

            # Validate and clean extracted model name
            if model_name:
                # Clean up the model name
                model_name = model_name.strip()
                # Remove common prefixes/suffixes
                if model_name.startswith("models/"):
                    model_name = model_name[7:]
                if "/" in model_name:
                    model_name = model_name.split("/")[0]

                # Basic validation
                if len(model_name) > 0 and len(model_name) < 100:
                    return model_name
                else:
                    model_name = None

        except Exception as e:
            logger.debug(
                f"[VertexAI-PredictionService] Failed to extract model from protobuf request: {e}"
            )

        return model_name

    def _extract_model_from_request_params(self, request: Any) -> Optional[str]:
        """Extract model name from request parameters as fallback.

        Some frameworks may pass model information through request metadata or
        other fields when the main 'model' field is empty.
        """
        try:
            # Check if request has endpoint field (used by some GAPIC configurations)
            if hasattr(request, "endpoint") and request.endpoint:
                # endpoint might be like "projects/.../models/gemini-2.0-flash-exp"
                endpoint = str(request.endpoint)
                if "models/" in endpoint:
                    model_name = endpoint.split("models/")[-1]
                    if model_name:
                        return str(model_name)

            # Check metadata or client options
            if hasattr(request, "metadata") and request.metadata:
                # Some frameworks might include model in metadata
                metadata = request.metadata
                if isinstance(metadata, dict):
                    for key in ["model", "model_name", "model-name"]:
                        if key in metadata:
                            return str(metadata[key])

            # Check if there's a parent/endpoint field that contains model info
            if hasattr(request, "parent") and request.parent:
                parent = str(request.parent)
                if "models/" in parent:
                    model_name = parent.split("models/")[-1]
                    if model_name:
                        return str(model_name)

        except Exception as e:
            logger.debug(
                f"[VertexAI-PredictionService] Failed to extract model from request params: {e}"
            )

        return None

    def _extract_model_from_stack_frames(self) -> Optional[str]:
        """Extract model name from GenerativeModel or ChatVertexAI instance in call stack.

        Enhanced version that handles LangChain's deep call stack and multiple import paths.
        This is version-agnostic and works across all LangChain versions (0.0.x, 0.1.x, 0.2.x).

        When LangChain's ChatVertexAI calls Vertex AI's PredictionServiceClient,
        the GenerativeModel or ChatVertexAI instance in the stack has the model name available.
        This method inspects the stack frames to find it.

        Returns:
            Model name if found (e.g., "gemini-1.5-pro"), None otherwise.
        """
        import inspect

        try:
            stack = inspect.stack()
            # Increase depth for LangChain's deep call stack (up to 30 frames)
            max_frames = min(len(stack), 30)

            for i, frame_info in enumerate(stack[:max_frames]):
                frame = frame_info.frame

                # Skip MVK SDK frames to avoid inspecting our own code
                frame_module = frame.f_globals.get("__name__", "")
                if frame_module.startswith("mvk_sdk"):
                    continue

                # Look for 'self' in the frame's locals (instance method)
                if "self" not in frame.f_locals:
                    continue

                instance = frame.f_locals["self"]
                instance_type = type(instance)
                instance_type_name = instance_type.__name__
                instance_module = instance_type.__module__

                # Check for ChatVertexAI (LangChain wrapper) - multiple import paths
                if instance_type_name == "ChatVertexAI":
                    # Verify it's from LangChain (not a different framework)
                    if "langchain" in instance_module.lower():
                        model = None

                        # Method 1: Direct attribute access
                        if hasattr(instance, "model_name"):
                            try:
                                model = instance.model_name
                            except Exception as e:
                                logger.warning(
                                    f"[VertexAI-PredictionService] Failed to access model_name "
                                    f"from ChatVertexAI instance: {e}"
                                )
                                pass

                        # Method 2: Check __dict__ (for Pydantic models)
                        if not model and hasattr(instance, "__dict__"):
                            if "model_name" in instance.__dict__:
                                try:
                                    model = instance.__dict__["model_name"]
                                except Exception as e:
                                    logger.warning(
                                        f"[VertexAI-PredictionService] Failed to access model_name "
                                        f"from ChatVertexAI.__dict__: {e}"
                                    )
                                    pass

                        # Method 3: Check Pydantic fields (ChatVertexAI uses Pydantic)
                        if not model and hasattr(instance, "_pydantic_fields"):
                            if "model_name" in instance._pydantic_fields:
                                try:
                                    model = getattr(instance, "model_name", None)
                                except Exception as e:
                                    logger.warning(
                                        f"[VertexAI-PredictionService] Failed to access model_name "
                                        f"from ChatVertexAI Pydantic fields: {e}"
                                    )
                                    pass

                        if model:
                            model_str = str(model)
                            logger.debug(
                                f"[VertexAI-PredictionService] Found model_name in ChatVertexAI "
                                f"(module: {instance_module}): {model_str}"
                            )
                            return model_str

                # Check for GenerativeModel (vertexai SDK)
                elif instance_type_name == "GenerativeModel":
                    # Verify it's from Vertex AI SDK
                    if (
                        "vertexai" in instance_module.lower()
                        or "aiplatform" in instance_module.lower()
                    ):
                        model = None

                        # Method 1: Check _model_name (private attribute)
                        if hasattr(instance, "_model_name"):
                            try:
                                model = instance._model_name
                            except Exception as e:
                                logger.warning(
                                    f"[VertexAI-PredictionService] Failed to access _model_name "
                                    f"from GenerativeModel: {e}"
                                )
                                pass

                        # Method 2: Check __dict__
                        if not model and hasattr(instance, "__dict__"):
                            if "_model_name" in instance.__dict__:
                                try:
                                    model = instance.__dict__["_model_name"]
                                except Exception as e:
                                    logger.warning(
                                        f"[VertexAI-PredictionService] Failed to access _model_name "
                                        f"from GenerativeModel.__dict__: {e}"
                                    )
                                    pass

                        # Method 3: Extract from _prediction_resource_name
                        if not model and hasattr(instance, "_prediction_resource_name"):
                            try:
                                resource_name = instance._prediction_resource_name
                                if resource_name and "models/" in str(resource_name):
                                    model = str(resource_name).split("models/")[-1]
                                    # Clean up if there are more path segments
                                    if "/" in model:
                                        model = model.split("/")[0]
                            except Exception as e:
                                logger.warning(
                                    f"[VertexAI-PredictionService] Failed to extract model name "
                                    f"from GenerativeModel._prediction_resource_name: {e}"
                                )
                                pass

                        if model:
                            model_str = str(model)
                            # Clean up if it's a full resource path
                            if "/" in model_str:
                                parts = model_str.split("/")
                                if "models" in parts:
                                    model_idx = parts.index("models")
                                    if model_idx + 1 < len(parts):
                                        model_str = parts[model_idx + 1]
                                else:
                                    # Use last part if no "models" segment
                                    model_str = parts[-1] if parts else model_str

                            logger.debug(
                                f"[VertexAI-PredictionService] Found model name in GenerativeModel "
                                f"(module: {instance_module}): {model_str}"
                            )
                            return model_str

        except Exception as e:
            logger.debug(f"[VertexAI-PredictionService] Stack frame inspection failed: {e}")

        return None

    def _extract_prediction_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from Prediction Service generate_content call.

        Args are protobuf objects from google.cloud.aiplatform_v1beta1.types.
        This is the low-level API that all Vertex AI SDKs use under the hood.

        NOTE: Framework detection is DISABLED by default (FrameworkDetector._enabled = False).
        This ensures we always collect attributes even when called from LangChain/Agno.
        Only if explicitly enabled will this method return None for framework calls.
        """
        # Framework detection to avoid double spans (disabled by default)
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[VertexAI-PredictionService] generate_content call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Start with default model name
        model_name = None
        self._current_model_name = "gemini-pro"  # Store default for result processing

        # Build request_body for model detection
        request_body = None

        # Extract model name using version-agnostic methods in priority order
        # Priority order (version-agnostic first, version-dependent last):
        # 1. PRIMARY: Enhanced protobuf request parsing (version-agnostic)
        # 2. SECONDARY: Enhanced stack frame inspection (version-agnostic)
        # 3. TERTIARY: Context variables (set by high-level SDK - version-agnostic)
        # 4. OPTIONAL: LangChain callback context (version-dependent - best-effort)
        # 5. FALLBACK: Request parameters (version-agnostic)

        # Get request from args or kwargs (LangChain may use kwargs-only calls)
        request = self._extract_request_from_args_kwargs(args, kwargs)

        if request:
            try:
                # 1. PRIMARY: Enhanced protobuf request parsing (version-agnostic)
                model_name = self._extract_model_from_protobuf_request(request)
                if model_name:
                    self._current_model_name = model_name
                    logger.debug(
                        f"[VertexAI-PredictionService] Extracted model_name from protobuf request: {model_name}"
                    )

                # 2. SECONDARY: Enhanced stack frame inspection (version-agnostic)
                # Handles LangChain's deep call stack and multiple import paths
                if not model_name:
                    model_name = self._extract_model_from_stack_frames()
                    if model_name:
                        self._current_model_name = model_name
                        logger.debug(
                            f"[VertexAI-PredictionService] Extracted model_name from stack frames: {model_name}"
                        )

                # 3. TERTIARY: Context variables (set by high-level SDK wrapper - version-agnostic)
                if not model_name:
                    context_model = _vertex_ai_model_context.get()
                    if context_model:
                        model_name = context_model
                        self._current_model_name = model_name
                        logger.debug(
                            f"[VertexAI-PredictionService] Got model_name from context: {model_name}"
                        )

                # 4. OPTIONAL: LangChain callback context (version-dependent - best-effort)
                # Silently fail if callback handler is not available or not working
                if not model_name:
                    try:
                        from ..instrumentation.langchain_callback_handler import (
                            get_langchain_model_context,
                        )

                        langchain_model = get_langchain_model_context()
                        if langchain_model:
                            model_name = langchain_model
                            self._current_model_name = model_name
                            logger.debug(
                                f"[VertexAI-PredictionService] Got model_name from LangChain callback: {model_name}"
                            )
                    except Exception as e:
                        # Callback handler is optional, log but don't fail
                        logger.warning(
                            f"[VertexAI-PredictionService] Failed to get LangChain callback context: {e}"
                        )
                        pass

                # 5. FALLBACK: Request parameters (version-agnostic)
                if not model_name:
                    model_name = self._extract_model_from_request_params(request)
                    if model_name:
                        self._current_model_name = model_name
                        logger.debug(
                            f"[VertexAI-PredictionService] Extracted model_name from request params: {model_name}"
                        )

                # Also check kwargs as a fallback (for frameworks that pass model as parameter)
                if not model_name and kwargs and "model" in kwargs:
                    model_name = kwargs.get("model", "")
                    if model_name:
                        self._current_model_name = model_name
                        logger.debug(
                            f"[VertexAI-PredictionService] Got model_name from kwargs: {model_name}"
                        )

            except Exception as e:
                logger.debug(
                    f"[VertexAI-PredictionService] Failed to extract model from request: {e}"
                )

        # Build request_body from protobuf contents for model detection
        if request and hasattr(request, "contents"):
            contents = request.contents
            if contents:
                try:
                    # Build a minimal request body for detection
                    messages = []
                    for content in contents:
                        if hasattr(content, "parts"):
                            content_blocks = []
                            for part in content.parts:
                                if hasattr(part, "text"):
                                    content_blocks.append({"type": "text", "text": part.text})
                                # Could add image/audio detection here if needed
                            if content_blocks:
                                messages.append({"content": content_blocks})
                    if messages:
                        request_body = {"messages": messages}
                except Exception as e:
                    logger.debug(f"Failed to build request_body from protobuf: {e}")

        # Use extracted model_name if available, otherwise use default for detection
        # This ensures model_type detection works even if we don't have explicit model name
        attrs = self._extract_common_attributes(model_name or "gemini-pro", "vertex", request_body)

        # Update model_name in attrs only if we actually extracted one
        # Otherwise keep the one from common_attributes (which may be the default)
        if model_name:
            attrs["model_name"] = model_name
        else:
            # If we couldn't extract model_name, remove it to avoid false information
            attrs.pop("model_name", None)
            logger.debug(
                f"[VertexAI-PredictionService] Model name not extracted, removing from attributes"
            )

        # Update model_provider to be vertex-specific (always)
        attrs["model_provider"] = "google-vertex"

        # Continue extracting additional attributes if we have request
        if request:

            # Extract generation config from protobuf request
            if hasattr(request, "generation_config"):
                config = request.generation_config
                if config:
                    config_attrs = self._extract_generation_config(config)
                    attrs.update(config_attrs)

            # Extract prompt/content only if logging is enabled
            if should_log_prompts_responses() and hasattr(request, "contents"):
                contents = request.contents
                if contents:
                    # Contents is a list of protobuf Content objects
                    # Each Content has parts[] which have text
                    try:
                        prompt_parts = []
                        for content in contents:
                            if hasattr(content, "parts"):
                                for part in content.parts:
                                    if hasattr(part, "text"):
                                        prompt_parts.append(part.text)
                        if prompt_parts:
                            attrs["prompt"] = " ".join(prompt_parts)[:1000]
                    except Exception as e:
                        logger.debug(f"Failed to extract prompt from protobuf: {e}")

        # Not streaming by default (stream is handled by stream_generate_content method)
        attrs["operation_subtype"] = "batch"

        logger.debug(
            f"[VertexAI-PredictionService] Extracted attributes for model: {self._current_model_name}"
        )

        return attrs

    def _extract_vertexai_token_usage(self, result: Any, span: Any) -> None:
        """Extract token usage from Vertex AI Prediction Service response.

        The Prediction Service response may have usage_metadata in different locations.
        This method handles both:
        1. Direct usage_metadata on the response (newer SDK)
        2. Usage in the response body
        """
        try:
            # Try direct usage_metadata first (standard location)
            if hasattr(result, "usage_metadata"):
                logger.debug("[VertexAI-PredictionService] Found usage_metadata on response")
                self._extract_token_usage(result, span)
                return

            # Try alternative location: usage field
            if hasattr(result, "usage"):
                logger.debug("[VertexAI-PredictionService] Found usage field on response")
                usage = result.usage

                def _safe_get_int(obj: Any, *names: str) -> int:
                    for name in names:
                        try:
                            value = getattr(obj, name, None)
                            if isinstance(value, (int, float)):
                                return int(value)
                        except Exception:
                            continue
                    return 0

                prompt_tokens = _safe_get_int(usage, "prompt_token_count", "promptTokenCount")
                completion_tokens = _safe_get_int(
                    usage, "candidates_token_count", "candidatesTokenCount"
                )
                total_tokens = _safe_get_int(usage, "total_token_count", "totalTokenCount")

                if total_tokens > 0 or prompt_tokens > 0 or completion_tokens > 0:
                    logger.debug(
                        f"[VertexAI-PredictionService] Found tokens: prompt={prompt_tokens}, completion={completion_tokens}, total={total_tokens}"
                    )

                    span.set_attribute("mvk.prompt_tokens", prompt_tokens)
                    span.set_attribute("mvk.completion_tokens", completion_tokens)
                    span.set_attribute("mvk.total_tokens", total_tokens)

                    # Create metered usage
                    builder = MeteredUsageBuilder()
                    builder.add_token_metrics(
                        prompt=prompt_tokens,
                        completion=completion_tokens,
                        total=total_tokens,
                    )
                    safe_populate_metered_usage(span, builder)
                    logger.debug(
                        "[VertexAI-PredictionService] Metered usage populated from usage field"
                    )
                return

            logger.debug(
                "[VertexAI-PredictionService] No usage_metadata or usage field found in response"
            )

        except Exception as e:
            logger.debug(
                f"[VertexAI-PredictionService] Failed to extract Vertex AI-specific token usage: {e}"
            )

    def _process_prediction_generate_content_result(self, span, result) -> None:
        """Process Prediction Service generate_content result.

        Result is a protobuf GenerateContentResponse object.
        """
        logger.debug(f"[VertexAI-PredictionService] Processing result, result type: {type(result)}")
        try:
            # Extract response text only if logging is enabled
            if should_log_prompts_responses():
                if hasattr(result, "candidates") and result.candidates:
                    candidate = result.candidates[0]
                    if hasattr(candidate, "content"):
                        content = candidate.content
                        if hasattr(content, "parts") and content.parts:
                            try:
                                response_parts = []
                                for part in content.parts:
                                    if hasattr(part, "text"):
                                        response_parts.append(part.text)
                                if response_parts:
                                    span.set_attribute(
                                        "mvk.response", " ".join(response_parts)[:1000]
                                    )
                            except Exception as e:
                                logger.debug(f"Failed to extract response from protobuf: {e}")

            # Extract token usage from protobuf response
            # Try Vertex AI-specific token extraction first, then fall back to generic method
            self._extract_vertexai_token_usage(result, span)

        except Exception as e:
            logger.debug(f"Failed to process Prediction Service response: {e}", exc_info=True)

    def _create_prediction_generate_content_wrapper(self):
        """Create wrapper for PredictionServiceClient.generate_content() method."""
        return WrapperBase.create_wrapper(
            span_name="vertexai.prediction_service.generate_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_prediction_generate_content_attributes,
            process_result=self._process_prediction_generate_content_result,
        )

    def _extract_prediction_stream_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes specific to stream_generate_content."""
        attrs = self._extract_prediction_generate_content_attributes(instance, args, kwargs)
        if not attrs:
            return attrs

        attrs["stream_enabled"] = True
        attrs["operation_subtype"] = "stream"
        return attrs

    def _process_prediction_stream_generate_content_chunk(self, span, chunk) -> None:
        """Process individual streaming chunks from stream_generate_content."""
        logger.debug(
            f"[VertexAI-PredictionService] Processing stream chunk, chunk type: {type(chunk)}"
        )
        try:
            if should_log_prompts_responses():
                if hasattr(chunk, "candidates") and chunk.candidates:
                    candidate = chunk.candidates[0]
                    if hasattr(candidate, "content"):
                        content = candidate.content
                        if hasattr(content, "parts") and content.parts:
                            response_parts = []
                            for part in content.parts:
                                if hasattr(part, "text"):
                                    response_parts.append(part.text)
                            if response_parts:
                                span.set_attribute("mvk.response", " ".join(response_parts)[:1000])

            # Extract token usage from chunk
            self._extract_token_usage(chunk, span)

        except Exception as e:
            logger.debug(f"Failed to process Prediction Service stream chunk: {e}")

    def _create_prediction_stream_generate_content_wrapper(self):
        """Create wrapper for PredictionServiceClient.stream_generate_content() method."""
        return WrapperBase.create_streaming_wrapper(
            span_name="vertexai.prediction_service.generate_content.stream",
            extract_attributes=self._extract_prediction_stream_generate_content_attributes,
            process_chunk=self._process_prediction_stream_generate_content_chunk,
            provider="google-vertex",
        )
