"""Base wrapper functionality for consistent span creation.

This module provides utilities for creating consistent wrapper functions
that follow OpenTelemetry patterns while integrating with MVK's telemetry.
"""

import functools
import time
from typing import Any, Callable, Dict, Optional, Tuple

from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..mvk_tracer import OTLPStatusCode, get_tracer
from ..wrapper_logging import get_component_logger
from .error_boundary import never_break_client_code

logger = get_component_logger("instrumentation", "wrapper_base")


class WrapperBase:
    """Base class for wrapper functions with consistent span handling.

    This class provides utilities for creating standardized wrapper functions
    that handle span creation, attribute extraction, and error handling in
    a consistent way across all instrumentors.
    """

    @staticmethod
    def create_wrapper(
        span_name: str,
        span_kind: str = "SPAN_KIND_CLIENT",
        extract_attributes: Optional[Callable] = None,
        process_result: Optional[Callable] = None,
        process_error: Optional[Callable] = None,
        capture_input: bool = False,
        capture_output: bool = False,
    ) -> Callable:
        """Create a standard wrapper function following OTEL patterns.

        This factory function creates wrapper functions that can be used with
        wrapt.wrap_function_wrapper. The created wrapper handles span lifecycle,
        attribute extraction, and error handling.

        Args:
            span_name: Name for the span (e.g., 'openai.chat.completion')
            span_kind: OpenTelemetry span kind (CLIENT, SERVER, INTERNAL, etc.)
            extract_attributes: Function to extract attributes from args/kwargs
                Signature: (instance, args, kwargs) -> Dict[str, Any]
            process_result: Function to process result and add to span
                Signature: (span, result) -> None
            process_error: Function to process errors
                Signature: (span, error) -> None
            capture_input: Whether to capture input in span attributes
            capture_output: Whether to capture output in span attributes

        Returns:
            Wrapper function with signature (wrapped, instance, args, kwargs)
        """

        def wrapper(wrapped, instance, args, kwargs):
            """Standard OTEL-style wrapper for instrumented methods."""
            logger.debug(f"Wrapper called for {span_name}")
            tracer = get_tracer()

            # Start timing
            start_time = time.time()

            # Extract attributes if provided
            attributes = {}
            if extract_attributes:
                try:
                    attributes = extract_attributes(instance, args, kwargs) or {}
                    logger.debug(f"Extracted {len(attributes)} attributes")
                except Exception as e:
                    logger.error(f"Failed to extract attributes: {e}")
                    import traceback

                    logger.error(f"Traceback: {traceback.format_exc()}")
            else:
                logger.debug("No extract_attributes function provided")

            # Capture input if requested
            if capture_input:
                try:
                    attributes["mvk.input.args"] = str(args)[:1000]  # Limit size
                    attributes["mvk.input.kwargs"] = str(kwargs)[:1000]
                except Exception as e:
                    logger.debug(f"Failed to capture input: {e}")

            # Start span
            span = tracer.start_span(span_name, kind=span_kind, **attributes)

            try:
                # Call original method
                result = wrapped(*args, **kwargs)

                # Process result if handler provided
                if process_result:
                    try:
                        process_result(span, result)
                        logger.debug("Process result completed successfully")
                    except Exception as e:
                        logger.error(f"Failed to process result: {e}")
                        import traceback

                        logger.error(f"Traceback: {traceback.format_exc()}")
                else:
                    logger.debug("No process_result function provided")

                # Capture output if requested
                if capture_output:
                    try:
                        span.set_attribute("mvk.output", str(result)[:1000])
                    except Exception as e:
                        logger.debug(f"Failed to capture output: {e}")

                # Set success status
                span.status_code = OTLPStatusCode.OK  # OK status

                return result

            except Exception as e:
                # Process error if handler provided
                if process_error:
                    try:
                        process_error(span, e)
                    except Exception as ex:
                        logger.debug(f"Failed to process error: {ex}")
                else:
                    # Default error handling
                    span.set_error(e)

                # Re-raise the original exception
                raise

            finally:
                # Calculate duration
                duration_ms = (time.time() - start_time) * 1000
                span.set_attribute("mvk.duration_ms", duration_ms)

                # End span
                span.end()

        # Preserve function metadata
        functools.update_wrapper(wrapper, WrapperBase.create_wrapper)
        wrapper.__name__ = f"mvk_wrapped_{span_name.replace('.', '_')}"

        return wrapper

    @staticmethod
    def extract_model_attributes(
        instance: Any,
        args: Tuple,
        kwargs: Dict[str, Any],
        model_arg_name: str = "model",
        provider: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract common model-related attributes.

        Args:
            instance: Instance of the wrapped object
            args: Positional arguments
            kwargs: Keyword arguments
            model_arg_name: Name of the model parameter
            provider: Model provider name

        Returns:
            Dictionary of extracted attributes
        """
        attributes = {}

        # Extract model name
        model = kwargs.get(model_arg_name)
        if not model and args:
            model = args[0]

        if model:
            attributes["mvk.model_name"] = str(model)

        # Add provider if specified
        if provider:
            attributes["mvk.model_provider"] = provider

        # Extract common parameters
        if "temperature" in kwargs:
            attributes["mvk.temperature"] = kwargs["temperature"]

        if "max_tokens" in kwargs:
            attributes["mvk.max_tokens"] = kwargs["max_tokens"]

        if "stream" in kwargs:
            attributes["mvk.stream_enabled"] = kwargs["stream"]
            if kwargs["stream"]:
                attributes["mvk.operation_subtype"] = "stream"

        return attributes

    @staticmethod
    def process_token_usage(
        span: Any,
        result: Any,
        prompt_attr: str = "prompt_tokens",
        completion_attr: str = "completion_tokens",
        total_attr: str = "total_tokens",
        usage_obj: str = "usage",
    ) -> None:
        """Process token usage from result and add to span.

        Args:
            span: The active span
            result: The result object from the API call
            prompt_attr: Attribute name for prompt tokens
            completion_attr: Attribute name for completion tokens
            total_attr: Attribute name for total tokens
            usage_obj: Attribute name for usage object on result
        """
        try:
            # Get usage object
            usage = getattr(result, usage_obj, None)
            if not usage:
                return

            # Extract token counts
            prompt_tokens = getattr(usage, prompt_attr, None)
            completion_tokens = getattr(usage, completion_attr, None)
            total_tokens = getattr(usage, total_attr, None)

            # Set attributes
            if prompt_tokens is not None:
                span.set_attribute("mvk.prompt_tokens", int(prompt_tokens))

            if completion_tokens is not None:
                span.set_attribute("mvk.completion_tokens", int(completion_tokens))

            # Calculate total if not provided
            if total_tokens is not None:
                span.set_attribute("mvk.total_tokens", int(total_tokens))
            elif prompt_tokens is not None and completion_tokens is not None:
                span.set_attribute("mvk.total_tokens", int(prompt_tokens + completion_tokens))

        except Exception as e:
            logger.debug(f"Failed to process token usage: {e}")

    @staticmethod
    def create_streaming_wrapper(
        span_name: str,
        extract_attributes: Optional[Callable] = None,
        process_chunk: Optional[Callable] = None,
        provider: Optional[str] = None,
    ) -> Callable:
        """Create a wrapper for streaming responses.

        Streaming wrappers need special handling to track chunks while
        maintaining the iterator/generator interface.

        Args:
            span_name: Name for the span
            extract_attributes: Function to extract initial attributes
            process_chunk: Function to process each chunk
                Signature: (span, chunk) -> None
            provider: Model provider name

        Returns:
            Wrapper function for streaming methods
        """

        def wrapper(wrapped, instance, args, kwargs):
            """Wrapper for streaming methods."""
            tracer = get_tracer()

            # Extract attributes
            attributes = {}
            if extract_attributes:
                try:
                    attributes = extract_attributes(instance, args, kwargs) or {}
                except Exception as e:
                    logger.debug(f"Failed to extract attributes: {e}")

            # Add streaming indicator
            attributes["mvk.stream_enabled"] = True
            attributes["mvk.operation_subtype"] = "stream"

            if provider:
                attributes["mvk.model_provider"] = provider

            # Start span
            span = tracer.start_span(span_name, kind="SPAN_KIND_CLIENT", **attributes)

            try:
                # Call original method to get iterator/generator
                stream = wrapped(*args, **kwargs)

                # Wrap the stream to track chunks
                def wrapped_stream():
                    chunk_count = 0
                    total_tokens = 0

                    try:
                        for chunk in stream:
                            chunk_count += 1

                            # Process chunk if handler provided
                            if process_chunk:
                                try:
                                    process_chunk(span, chunk)
                                except Exception as e:
                                    logger.debug(f"Failed to process chunk: {e}")

                            # Track token usage from chunks if available
                            if hasattr(chunk, "usage"):
                                usage = chunk.usage
                                # Handle different usage formats
                                if hasattr(usage, "total_tokens"):
                                    # OpenAI format
                                    total_tokens = usage.total_tokens
                                elif hasattr(usage, "input_tokens") and hasattr(
                                    usage, "output_tokens"
                                ):
                                    # Anthropic format
                                    total_tokens = usage.input_tokens + usage.output_tokens
                                    # Also set individual token counts
                                    span.set_attribute("mvk.prompt_tokens", usage.input_tokens)
                                    span.set_attribute("mvk.completion_tokens", usage.output_tokens)

                                    # Build metered usage for Anthropic streaming
                                    builder = MeteredUsageBuilder()
                                    builder.add_token_metrics(
                                        prompt=usage.input_tokens,
                                        completion=usage.output_tokens,
                                        total=total_tokens,
                                    )
                                    safe_populate_metered_usage(span, builder)

                            yield chunk

                        # Set final metrics
                        span.set_attribute("mvk.stream.chunk_count", chunk_count)
                        if total_tokens > 0:
                            span.set_attribute("mvk.total_tokens", total_tokens)

                        span.status_code = OTLPStatusCode.OK  # OK status

                    except Exception as e:
                        span.set_error(e)
                        raise

                    finally:
                        span.end()

                return wrapped_stream()

            except Exception as e:
                # Handle errors in stream creation
                span.set_error(e)
                span.status_code = OTLPStatusCode.ERROR  # ERROR status
                span.end()
                raise

        return wrapper

    @staticmethod
    def create_async_wrapper(
        span_name: str,
        span_kind: str = "SPAN_KIND_CLIENT",
        extract_attributes: Optional[Callable] = None,
        process_result: Optional[Callable] = None,
        process_error: Optional[Callable] = None,
    ) -> Callable:
        """Create a wrapper for async methods.

        Args:
            span_name: Name for the span
            span_kind: OpenTelemetry span kind
            extract_attributes: Function to extract attributes
            process_result: Function to process result
            process_error: Function to process errors

        Returns:
            Async wrapper function
        """

        async def wrapper(wrapped, instance, args, kwargs):
            """Async wrapper for instrumented methods."""
            tracer = get_tracer()

            # Extract attributes
            attributes = {}
            if extract_attributes:
                try:
                    attributes = extract_attributes(instance, args, kwargs) or {}
                except Exception as e:
                    logger.debug(f"Failed to extract attributes: {e}")

            # Start span
            span = tracer.start_span(span_name, kind=span_kind, **attributes)

            try:
                # Call original async method
                result = await wrapped(*args, **kwargs)

                # Process result
                if process_result:
                    try:
                        process_result(span, result)
                    except Exception as e:
                        logger.debug(f"Failed to process result: {e}")

                span.status_code = OTLPStatusCode.OK  # OK status
                return result

            except Exception as e:
                # Process error
                if process_error:
                    try:
                        process_error(span, e)
                    except Exception as ex:
                        logger.debug(f"Failed to process error: {ex}")
                else:
                    span.set_error(e)
                raise

            finally:
                span.end()

        return wrapper
