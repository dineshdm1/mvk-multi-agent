"""Google Gemini instrumentor for the legacy google.generativeai SDK.

This module provides instrumentation for the legacy Google Generative AI SDK
using the BaseGeminiInstrumentor pattern with SDK-specific logic.
"""

from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..instrument import should_log_prompts_responses
from ..instrumentation.base_gemini_instrumentor import BaseGeminiInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "gemini")


class GeminiInstrumentor(BaseGeminiInstrumentor):
    """Instrumentor for Google Gemini SDK following OTEL patterns."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """google-generativeai is required."""
        return ["google.generativeai"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "gemini"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Google Gemini SDK.

        The base class handles unwrapping automatically.
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Google Gemini SDK."""
        try:
            import google.generativeai as genai  # type: ignore

            # Create wrappers following standard pattern
            generate_wrapper = self._create_generate_content_wrapper()
            embed_wrapper = self._create_embed_content_wrapper("gemini")

            # Wrap GenerativeModel.generate_content
            self._wrap_method(
                "google.generativeai.generative_models",
                "GenerativeModel.generate_content",
                generate_wrapper,
            )

            # Wrap embed_content if available
            if hasattr(genai, "embed_content"):
                embed_wrapper = self._create_embed_content_wrapper("gemini")
                self._wrap_method("google.generativeai", "embed_content", embed_wrapper)

            logger.info("Gemini auto-instrumentation enabled")

        except Exception as e:
            logger.warning(f"Failed to instrument Gemini: {e}")
            raise  # Re-raise the exception so base class knows instrumentation failed

    def _extract_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from generate_content call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Gemini] generate_content call detected from {framework} - skipping to avoid double spans"
            )
            return None

        attrs = {}

        # Get model name from instance (legacy SDK specific)
        model_name = getattr(instance, "_model_name", "gemini-pro")

        # Use base class common attributes
        attrs.update(self._extract_common_attributes(model_name, "gemini"))

        # Extract generation config if present (legacy SDK specific)
        if "generation_config" in kwargs:
            config = kwargs["generation_config"]
            attrs.update(self._extract_generation_config(config))

        # Extract prompt/content only if logging is enabled (legacy SDK specific - from args[0])
        if should_log_prompts_responses() and args and len(args) > 0:
            content = args[0]
            extracted_content = self._extract_content(content)
            if extracted_content:
                attrs["prompt"] = extracted_content

        # Check for streaming
        stream = kwargs.get("stream", False)
        if stream:
            attrs["stream_enabled"] = True
            attrs["operation_subtype"] = "stream"

        return attrs

    def _process_generate_content_result(self, span, result) -> None:
        """Process generate_content result.

        Uses enhanced token extraction that supports:
        - Standard tokens (prompt, completion, total)
        - Reasoning tokens (thoughtsTokenCount) for Gemini 2.5+ models
        - Cached tokens (cachedContentTokenCount)
        - Both legacy and new SDK field naming conventions
        """
        # Use base class response processing with enhanced token extraction
        self._process_gemini_response(result, span)

    def _create_generate_content_wrapper(self):
        """Create wrapper for GenerativeModel.generate_content() method."""
        # Return the wrapper function
        return WrapperBase.create_wrapper(
            span_name="gemini.generate_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_generate_content_attributes,
            process_result=self._process_generate_content_result,
        )
