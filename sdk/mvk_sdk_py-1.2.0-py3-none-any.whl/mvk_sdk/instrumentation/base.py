"""Base instrumentation class aligned with OpenTelemetry patterns.

This module provides the foundation for all MVK SDK instrumentors,
following OpenTelemetry Python patterns while maintaining MVK's
non-breaking guarantees.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..wrapper_logging import get_component_logger
from .error_boundary import never_break_client_code

logger = get_component_logger("instrumentation", "base")


class BaseInstrumentor(ABC):
    """Base class for all MVK instrumentors following OTEL patterns.

    This class provides a consistent interface for instrumenting Python libraries
    with MVK SDK telemetry. It follows OpenTelemetry patterns while maintaining
    MVK's strong non-breaking guarantees.

    Key features:
    - Consistent wrapt usage for all method wrapping
    - Clean instrument/uninstrument lifecycle
    - Signature preservation for wrapped methods
    - Error isolation to prevent breaking client code
    - Dependency checking before instrumentation

    Subclasses must implement:
    - instrumentation_dependencies: List of required packages
    - name: Name of this instrumentor
    - _instrument: Implementation-specific instrumentation logic
    - _uninstrument: Implementation-specific uninstrumentation logic
    """

    def __init__(self) -> None:
        """Initialize the instrumentor."""
        self._instrumented: bool = False
        self._wrapped_methods: Dict[str, Dict[str, Any]] = {}
        self._config: Optional[Dict[str, Any]] = None
        self.logger = get_component_logger("instrumentation", self.name)

    @property
    @abstractmethod
    def instrumentation_dependencies(self) -> Collection[str]:
        """List of required packages for this instrumentor.

        Returns:
            Collection of package names that must be installed
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of this instrumentor.

        Returns:
            String identifier for this instrumentor (e.g., 'openai', 'anthropic')
        """
        pass

    def instrument(self, **kwargs) -> None:
        """Apply instrumentation to target library.

        This method checks dependencies, applies instrumentation, and tracks
        the instrumented state. It's safe to call multiple times.

        Args:
            **kwargs: Configuration options for instrumentation, may include:
                - tracer: Custom tracer instance
                - config: MVK configuration dict
                - excluded_urls: URLs to exclude from instrumentation
        """
        self.logger.debug(f"BaseInstrumentor.instrument() called for {self.name}")
        if self._instrumented:
            self.logger.debug(f"{self.name} already instrumented, skipping")
            return

        # Check if dependencies are available
        deps_available = self._check_dependencies()
        if not deps_available:
            self.logger.warning(f"Dependencies not met for {self.name}, skipping instrumentation")
            return

        try:
            self._config = kwargs
            self.logger.debug(f"Starting {self.name} instrumentation")
            self._instrument(**kwargs)
            self._instrumented = True
            self.logger.info(f"{self.name} instrumentation enabled")
        except Exception as e:
            self.logger.warning(f"Failed to instrument {self.name}: {e}", exc_info=True)
            self._instrumented = False

    def uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from target library.

        This method removes all applied instrumentation and cleans up
        internal state. It's safe to call multiple times.

        Args:
            **kwargs: Configuration options for uninstrumentation
        """
        if not self._instrumented:
            self.logger.debug(f"{self.name} not instrumented, skipping uninstrument")
            return

        try:
            self.logger.debug(f"Starting {self.name} uninstrumentation")
            self._uninstrument(**kwargs)
            self._instrumented = False
            self._wrapped_methods.clear()
            self.logger.info(f"{self.name} instrumentation disabled")
        except Exception as e:
            self.logger.warning(f"Failed to uninstrument {self.name}: {e}", exc_info=True)

    @abstractmethod
    def _instrument(self, **kwargs) -> None:
        """Implementation-specific instrumentation logic.

        This method should use _wrap_method to apply instrumentation.

        Args:
            **kwargs: Configuration options for instrumentation
        """
        pass

    @abstractmethod
    def _uninstrument(self, **kwargs) -> None:
        """Implementation-specific uninstrumentation logic.

        This method should remove all instrumentation applied by _instrument.

        Args:
            **kwargs: Configuration options for uninstrumentation
        """
        pass

    def is_instrumented(self) -> bool:
        """Check if currently instrumented.

        Returns:
            True if instrumentation is currently active
        """
        return self._instrumented

    def _check_dependencies(self) -> bool:
        """Check if required dependencies are available.

        Returns:
            True if all dependencies are available
        """
        self.logger.debug(
            f"Checking dependencies for {self.name}: {self.instrumentation_dependencies}"
        )
        for dep in self.instrumentation_dependencies:
            try:
                __import__(dep)
                self.logger.debug(f"Dependency '{dep}' found")
            except ImportError as e:
                self.logger.warning(f"Required dependency '{dep}' not found: {e}")
                return False
        self.logger.debug(f"All dependencies available for {self.name}")
        return True

    def _wrap_method(self, module: str, name: str, wrapper) -> bool:
        """Safely wrap a method using wrapt.

        This method uses wrapt to wrap a target method while preserving its
        signature and ensuring error isolation.

        Args:
            module: Module path (e.g., 'openai.resources.chat.completions')
            name: Method name (e.g., 'Completions.create')
            wrapper: Wrapper function following wrapt signature

        Returns:
            True if wrapping succeeded, False otherwise
        """
        try:
            # Check if already wrapped
            key = f"{module}.{name}"
            if key in self._wrapped_methods:
                self.logger.debug(f"Method {key} already wrapped, skipping")
                return False

            # Apply wrapt wrapper
            wrapt.wrap_function_wrapper(module=module, name=name, wrapper=wrapper)

            # Track for uninstrumentation
            self._wrapped_methods[key] = {"module": module, "name": name, "wrapper": wrapper}

            self.logger.debug(f"Successfully wrapped {key}")
            return True

        except Exception as e:
            self.logger.warning(f"Failed to wrap {module}.{name}: {e}")
            return False

    def _unwrap_method(self, module: str, name: str) -> bool:
        """Safely unwrap a method.

        This method removes wrapt wrapping from a target method.

        Args:
            module: Module path
            name: Method name

        Returns:
            True if unwrapping succeeded, False otherwise
        """
        try:
            key = f"{module}.{name}"

            # Check if we wrapped this method
            if key not in self._wrapped_methods:
                self.logger.debug(f"Method {key} not in wrapped methods, skipping unwrap")
                return False

            # Parse the module and method path
            parts = name.split(".")

            # Import the module
            mod = __import__(module, fromlist=[parts[0]] if parts else [""])

            # Navigate to the parent object
            obj = mod
            for part in parts[:-1]:
                obj = getattr(obj, part)

            # Get the method
            method_name = parts[-1]
            if not hasattr(obj, method_name):
                self.logger.debug(f"Method {method_name} not found on {obj}")
                return False

            method = getattr(obj, method_name)

            # Check if it's wrapped and unwrap
            if hasattr(method, "__wrapped__"):
                setattr(obj, method_name, method.__wrapped__)
                self.logger.debug(f"Successfully unwrapped {key}")

                # Remove from tracking
                del self._wrapped_methods[key]
                return True
            else:
                self.logger.debug(f"Method {key} not wrapped (no __wrapped__ attribute)")
                return False

        except Exception as e:
            self.logger.warning(f"Failed to unwrap {module}.{name}: {e}")
            return False

    def get_wrapped_methods(self) -> Dict[str, Dict[str, Any]]:
        """Get information about currently wrapped methods.

        Returns:
            Dictionary mapping method keys to wrapper information
        """
        return self._wrapped_methods.copy()

    def __repr__(self) -> str:
        """String representation of the instrumentor."""
        return (
            f"{self.__class__.__name__}("
            f"name='{self.name}', "
            f"instrumented={self._instrumented}, "
            f"wrapped_methods={len(self._wrapped_methods)})"
        )
