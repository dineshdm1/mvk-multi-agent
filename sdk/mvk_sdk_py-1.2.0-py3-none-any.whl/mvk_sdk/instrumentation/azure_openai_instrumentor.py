"""Azure OpenAI instrumentor following OTEL patterns.

This module provides instrumentation for Azure OpenAI SDK using the BaseInstrumentor
pattern with wrapt for consistent wrapping.
"""

from typing import Collection

from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.openai_instrumentor import OpenAIInstrumentor
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "azure_openai")


class AzureOpenAIInstrumentor(OpenAIInstrumentor):
    """Instrumentor for Azure OpenAI SDK following OTEL patterns.

    Azure OpenAI uses the same SDK as OpenAI but with Azure-specific endpoints.
    We inherit from OpenAIInstrumentor and override only what's different.
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """OpenAI SDK is required (Azure uses the same SDK)."""
        return ["openai"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "azure_openai"

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Azure OpenAI SDK.

        Azure OpenAI uses the same OpenAI SDK, so we can reuse most of the logic.
        """
        try:
            import openai  # type: ignore

            # Check if AzureOpenAI client is available
            if not hasattr(openai, "AzureOpenAI"):
                logger.debug("AzureOpenAI client not found in openai module")
                return

            if not self._is_openai_wrapped():
                logger.debug("Base OpenAI instrumentation not detected, applying now")
                super()._instrument(**kwargs)
            else:
                logger.debug("OpenAI methods already instrumented; reusing wrappers")

            # Additionally, wrap Azure-specific initialization if needed
            init_wrapper = self._create_azure_init_wrapper()
            self._wrap_method("openai.lib.azure", "AzureOpenAI.__init__", init_wrapper)
            self._wrap_method("openai", "AzureOpenAI.__init__", init_wrapper)

            if hasattr(openai, "AsyncAzureOpenAI"):
                self._wrap_method("openai.lib.azure", "AsyncAzureOpenAI.__init__", init_wrapper)
                self._wrap_method("openai", "AsyncAzureOpenAI.__init__", init_wrapper)

        except Exception as e:
            logger.warning(f"Failed to instrument Azure OpenAI: {e}")

    def _create_azure_init_wrapper(self):
        """Wrapper for AzureOpenAI client initialization to track Azure usage."""

        def wrapper(wrapped, instance, args, kwargs):
            # Call original init
            result = wrapped(*args, **kwargs)

            # Mark this client as Azure for proper attribution
            try:
                instance._mvk_provider = "azure-openai"
            except Exception:
                pass

            # Best-effort: attach a marker used by OpenAI wrapper extraction
            try:
                setattr(instance, "_mvk_is_azure", True)
            except Exception:
                pass

            return result

        return wrapper

    def _is_openai_wrapped(self) -> bool:
        """Check whether core OpenAI methods are already instrumented."""
        try:
            from openai.resources.chat import completions  # type: ignore

            return hasattr(completions.Completions.create, "__wrapped__")
        except Exception:
            return False

    def _extract_provider(self, instance) -> str:
        """Extract provider name from instance."""
        # Check if we marked this as Azure
        if hasattr(instance, "_mvk_provider"):
            provider = getattr(instance, "_mvk_provider", "openai")
            return str(provider) if provider else "openai"

        # Check class name
        if hasattr(instance, "__class__"):
            if "Azure" in instance.__class__.__name__:
                return "azure-openai"

        return "openai"  # Default
