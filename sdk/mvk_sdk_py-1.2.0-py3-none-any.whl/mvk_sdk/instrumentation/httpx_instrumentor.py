"""HTTPX instrumentor following OTEL patterns.

This module provides instrumentation for HTTPX using the BaseInstrumentor
pattern with wrapt for consistent wrapping.
"""

import time
from typing import Any, Collection, Dict, Optional, Union

import wrapt

from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.wrapper_base import WrapperBase
from ..mvk_tracer import OTLPSpanKind, OTLPStatusCode, get_tracer
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger
from .httpx_exclusions import is_excluded_url

logger = get_component_logger("instrumentation", "httpx")


class HTTPXInstrumentor(BaseInstrumentor):
    """Instrumentor for HTTPX following OTEL patterns."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """HTTPX is required."""
        return ["httpx"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "httpx"

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to HTTPX."""
        # Create wrapper for Client.request
        request_wrapper = self._create_request_wrapper()

        # Create wrapper for AsyncClient.request
        async_request_wrapper = self._create_async_request_wrapper()

        # Wrap Client methods
        self._wrap_method("httpx", "Client.request", request_wrapper)

        self._wrap_method("httpx", "Client.get", self._create_http_method_wrapper("GET"))

        self._wrap_method("httpx", "Client.post", self._create_http_method_wrapper("POST"))

        self._wrap_method("httpx", "Client.put", self._create_http_method_wrapper("PUT"))

        self._wrap_method("httpx", "Client.patch", self._create_http_method_wrapper("PATCH"))

        self._wrap_method("httpx", "Client.delete", self._create_http_method_wrapper("DELETE"))

        # Wrap AsyncClient methods
        self._wrap_method("httpx", "AsyncClient.request", async_request_wrapper)

        self._wrap_method("httpx", "AsyncClient.get", self._create_async_http_method_wrapper("GET"))

        self._wrap_method(
            "httpx", "AsyncClient.post", self._create_async_http_method_wrapper("POST")
        )

        self._wrap_method("httpx", "AsyncClient.put", self._create_async_http_method_wrapper("PUT"))

        self._wrap_method(
            "httpx", "AsyncClient.patch", self._create_async_http_method_wrapper("PATCH")
        )

        self._wrap_method(
            "httpx", "AsyncClient.delete", self._create_async_http_method_wrapper("DELETE")
        )

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from HTTPX."""
        # Unwrap all methods
        for key in list(self._wrapped_methods.keys()):
            module, name = key.rsplit(".", 1)
            self._unwrap_method(module, name)

    def _create_request_wrapper(self):
        """Create wrapper for Client.request method."""

        # Create wrapper but handle excluded URLs
        def wrapper(wrapped, instance, args, kwargs):
            """Wrapper that checks for excluded URLs."""
            # Quick check for excluded URLs
            url = args[1] if len(args) > 1 else kwargs.get("url", "")
            if is_excluded_url(str(url)):
                # Skip instrumentation for excluded URLs
                return wrapped(*args, **kwargs)

            # Use standard wrapper
            return WrapperBase.create_wrapper(
                span_name="httpx.request",
                span_kind="SPAN_KIND_CLIENT",
                extract_attributes=self._extract_request_attributes,
                process_result=self._process_request_result,
            )(wrapped, instance, args, kwargs)

        return wrapper

    def _extract_request_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from HTTP request."""
        # Get method and URL
        method = args[0] if args else kwargs.get("method", "UNKNOWN")
        url = args[1] if len(args) > 1 else kwargs.get("url", "")

        # Skip excluded URLs
        if is_excluded_url(str(url)):
            return None  # Signal to skip instrumentation

        attrs = {
            "http.method": method,
            "http.url": str(url),
            "operation": "http_call",
            "mvk.step_type": MVKStepType.TOOL,
        }

        # Extract headers if present
        headers = kwargs.get("headers", {})
        if headers:
            attrs["http.request.header_count"] = len(headers)

        return attrs

    def _process_request_result(self, span, result) -> None:
        """Process HTTP response."""
        if hasattr(result, "status_code"):
            span.set_attribute("http.status_code", result.status_code)

            # Set error if status indicates failure
            if result.status_code >= 400:
                span.status_code = OTLPStatusCode.ERROR  # ERROR status
                span.status_message = f"HTTP {result.status_code}"

        if hasattr(result, "headers"):
            span.set_attribute("http.response.header_count", len(result.headers))

        if hasattr(result, "content"):
            span.set_attribute("http.response.size", len(result.content))

    def _create_http_method_wrapper(self, method: str):
        """Create wrapper for specific HTTP method."""

        def wrapper(wrapped, instance, args, kwargs):
            """Wrapper for HTTP method."""
            # Check if URL is excluded
            url = args[0] if args else kwargs.get("url", "")
            if is_excluded_url(str(url)):
                return wrapped(*args, **kwargs)

            # Reuse request wrapper logic by injecting method
            new_args = (method,) + args
            return self._create_request_wrapper()(wrapped, instance, new_args, kwargs)

        return wrapper

    def _create_async_request_wrapper(self):
        """Create async wrapper for AsyncClient.request."""

        async def wrapper(wrapped, instance, args, kwargs):
            """Async wrapper for HTTP request."""
            # Quick check for excluded URLs
            url = args[1] if len(args) > 1 else kwargs.get("url", "")
            if is_excluded_url(str(url)):
                # Skip instrumentation for excluded URLs
                return await wrapped(*args, **kwargs)

            # Extract attributes using helper method
            attrs = self._extract_async_request_attributes(instance, args, kwargs)
            if attrs is None:
                return await wrapped(*args, **kwargs)

            # Get tracer and start span
            tracer = get_tracer()
            span = tracer.start_span("httpx.request.async", kind="SPAN_KIND_CLIENT", **attrs)

            try:
                # Call original method
                result = await wrapped(*args, **kwargs)

                # Process result using helper method
                self._process_async_request_result(span, result)

                return result

            except Exception as e:
                span.set_error(e)
                raise
            finally:
                span.end()

        return wrapper

    def _extract_async_request_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from async HTTP request."""
        # Get method and URL
        method = args[0] if args else kwargs.get("method", "UNKNOWN")
        url = args[1] if len(args) > 1 else kwargs.get("url", "")

        attrs = {
            "http.method": method,
            "http.url": str(url),
            "operation": "http_call",
            "mvk.step_type": MVKStepType.TOOL,
        }

        return attrs

    def _process_async_request_result(self, span, result) -> None:
        """Process async HTTP response."""
        if hasattr(result, "status_code"):
            span.set_attribute("http.status_code", result.status_code)
            if result.status_code >= 400:
                span.status_code = OTLPStatusCode.ERROR  # ERROR
                span.status_message = f"HTTP {result.status_code}"
            else:
                span.status_code = OTLPStatusCode.OK  # OK

    def _create_async_http_method_wrapper(self, method: str):
        """Create async wrapper for specific HTTP method."""

        async def wrapper(wrapped, instance, args, kwargs):
            """Async wrapper for HTTP method."""
            # Check if URL is excluded
            url = args[0] if args else kwargs.get("url", "")
            if is_excluded_url(str(url)):
                return await wrapped(*args, **kwargs)

            # Inject method into args
            new_args = (method,) + args
            return await self._create_async_request_wrapper()(wrapped, instance, new_args, kwargs)

        return wrapper
