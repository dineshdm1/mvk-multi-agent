"""Error boundary for all instrumentors to ensure SDK never breaks client code.

This module provides a decorator that ensures all instrumentor functions are protected
by comprehensive error handling that:
1. Never breaks client code
2. Distinguishes between vendor exceptions (which propagate) and SDK exceptions (which don't)
3. Logs SDK errors for debugging
4. Ensures cleanup always happens
"""

import functools
import logging
import sys
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


def is_vendor_exception(exc: Exception) -> bool:
    """Check if exception is from vendor library (should propagate).

    Vendor exceptions (OpenAI, Anthropic, etc. API errors) should propagate
    to the client code as they represent actual API failures.
    SDK internal exceptions should be suppressed.
    """
    exc_type_name = type(exc).__name__
    exc_module = type(exc).__module__ or ""

    # Vendor exception patterns
    vendor_patterns = [
        # OpenAI
        ("openai", ["APIError", "APIConnectionError", "RateLimitError", "AuthenticationError"]),
        # Anthropic
        ("anthropic", ["APIError", "APIConnectionError", "RateLimitError", "AuthenticationError"]),
        # Google Generative AI (Gemini)
        ("google.generativeai", ["Error", "APIError"]),
        ("google.api_core", ["GoogleAPIError", "ClientError"]),
        # AWS Bedrock
        ("botocore.exceptions", ["ClientError", "BotoCoreError"]),
        # Azure
        ("azure.core.exceptions", ["AzureError", "ClientAuthenticationError"]),
        # Vertex AI
        ("google.cloud.exceptions", ["GoogleCloudError"]),
        # Vector DBs
        ("pinecone", ["PineconeException"]),
        ("qdrant_client", ["QdrantException"]),
        ("chromadb", ["ChromaError"]),
        ("weaviate", ["WeaviateException"]),
        # HTTP
        ("httpx", ["HTTPError", "RequestError"]),
        ("requests", ["RequestException", "HTTPError"]),
    ]

    # Check if this is a vendor exception
    for module_pattern, exception_names in vendor_patterns:
        if module_pattern in exc_module and exc_type_name in exception_names:
            return True

    # Common vendor exception base classes
    vendor_base_classes = [
        "APIError",
        "APIException",
        "HTTPError",
        "RequestError",
        "ClientError",
        "ServiceError",
        "AuthenticationError",
        "RateLimitError",
        "TimeoutError",
    ]

    if exc_type_name in vendor_base_classes:
        return True

    # Check if exception comes from any vendor module
    vendor_modules = [
        "openai",
        "anthropic",
        "google.generativeai",
        "google.api_core",
        "botocore",
        "azure",
        "pinecone",
        "qdrant_client",
        "chromadb",
        "weaviate",
        "httpx",
        "requests",
    ]

    for vendor_module in vendor_modules:
        if vendor_module in exc_module:
            return True

    return False


def never_break_client_code(func: Callable) -> Callable:
    """Decorator to ensure instrumentation never breaks client code.

    This decorator wraps instrumentor functions to:
    1. Allow vendor exceptions to propagate (these are expected by client)
    2. Suppress SDK internal exceptions (log and continue)
    3. Ensure original function result is preserved
    4. Provide comprehensive error context for debugging

    Args:
        func: Function to wrap with error boundary

    Returns:
        Wrapped function that never breaks client code
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            # Check if this is a vendor exception that should propagate
            if is_vendor_exception(exc):
                logger.debug(f"Vendor exception in {func.__name__}: {exc}")
                raise  # Let vendor exceptions propagate to client

            # This is an SDK internal exception - log and suppress
            logger.error(
                f"SDK error in {func.__name__}: {exc}",
                exc_info=True,
                extra={
                    "function": func.__name__,
                    "module": func.__module__,
                    "args_count": len(args),
                    "kwargs_keys": list(kwargs.keys()) if kwargs else [],
                    "exception_type": type(exc).__name__,
                    "exception_module": type(exc).__module__,
                },
            )

            # For instrumentor functions, we typically want to continue
            # and let the original function run uninstrumented
            return None

    return wrapper


def safe_call(func: Callable, *args, default: Any = None, **kwargs) -> Any:
    """Safely call a function with error boundary.

    Args:
        func: Function to call
        *args: Arguments to pass to function
        default: Default value to return on error
        **kwargs: Keyword arguments to pass to function

    Returns:
        Function result or default value on error
    """
    try:
        return func(*args, **kwargs)
    except Exception as exc:
        if is_vendor_exception(exc):
            raise  # Let vendor exceptions propagate

        logger.debug(f"Safe call failed for {func.__name__}: {exc}")
        return default


def safe_extract(obj: Any, attr: str, default: Any = None) -> Any:
    """Safely extract attribute from object.

    Args:
        obj: Object to extract from
        attr: Attribute name (supports dot notation)
        default: Default value if extraction fails

    Returns:
        Extracted value or default
    """
    try:
        result = obj
        for part in attr.split("."):
            if hasattr(result, part):
                result = getattr(result, part)
            elif isinstance(result, dict):
                result = result.get(part)
            else:
                return default
        return result
    except Exception:
        return default
