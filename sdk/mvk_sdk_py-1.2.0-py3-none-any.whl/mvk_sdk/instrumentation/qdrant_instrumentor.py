"""Qdrant instrumentor following OTEL patterns.

This module provides instrumentation for Qdrant SDK using the BaseInstrumentor
pattern with wrapt for consistent wrapping.
"""

from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "qdrant")


class QdrantInstrumentor(BaseInstrumentor):
    """Instrumentor for Qdrant SDK following OTEL patterns."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """qdrant-client is required."""
        return ["qdrant_client"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "qdrant"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Qdrant SDK.

        The base class handles unwrapping automatically.
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Qdrant SDK."""
        try:
            import qdrant_client  # type: ignore

            # Create wrapper factories
            search_wrapper_factory = self._create_search_wrapper()
            upsert_wrapper = self._create_upsert_wrapper()
            delete_wrapper = self._create_delete_wrapper()

            if hasattr(qdrant_client, "QdrantClient"):
                # Wrap the methods actually used in the application
                # Read operations
                if hasattr(qdrant_client.QdrantClient, "retrieve"):
                    retrieve_wrapper = search_wrapper_factory("qdrant.retrieve")
                    self._wrap_method("qdrant_client", "QdrantClient.retrieve", retrieve_wrapper)
                if hasattr(qdrant_client.QdrantClient, "scroll"):
                    scroll_wrapper = search_wrapper_factory("qdrant.scroll")
                    self._wrap_method("qdrant_client", "QdrantClient.scroll", scroll_wrapper)
                if hasattr(qdrant_client.QdrantClient, "search"):
                    search_wrapper = search_wrapper_factory("qdrant.search")
                    self._wrap_method("qdrant_client", "QdrantClient.search", search_wrapper)

                # Write operations
                if hasattr(qdrant_client.QdrantClient, "upsert"):
                    self._wrap_method("qdrant_client", "QdrantClient.upsert", upsert_wrapper)

                # Delete operations
                if hasattr(qdrant_client.QdrantClient, "delete"):
                    self._wrap_method("qdrant_client", "QdrantClient.delete", delete_wrapper)

            logger.info("Qdrant auto-instrumentation enabled")

        except Exception as e:
            logger.warning(f"Failed to instrument Qdrant: {e}")

    def _create_search_wrapper(self):
        """Create wrapper for Qdrant search operations.

        This wrapper tracks vector similarity search operations in Qdrant collections.
        It monitors search parameters like result limits and collection names.
        Essential for understanding search performance and query patterns in Qdrant.
        """

        def create_wrapper_with_name(span_name):
            return WrapperBase.create_wrapper(
                span_name=span_name,
                span_kind="SPAN_KIND_CLIENT",
                extract_attributes=self._extract_search_attributes,
                process_result=self._process_search_result,
            )

        return create_wrapper_with_name

    def _extract_search_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from search operation."""
        attrs = {
            "model_provider": "qdrant",
            "operation": "vector_search",
            "operation_subtype": "query",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract collection name
        if args and len(args) > 0:
            attrs["collection_name"] = str(args[0])

        # Extract limit
        if "limit" in kwargs:
            attrs["query_limit"] = kwargs["limit"]

        return attrs

    def _process_search_result(self, span, result) -> None:
        """Process search result."""
        # Handle different Qdrant result structures
        actual_results = None

        if isinstance(result, tuple) and len(result) >= 1:
            # scroll() returns (scrolled, next_page_offset)
            actual_results = result[0]
        elif hasattr(result, "__len__"):
            # retrieve() returns a list directly
            actual_results = result
        else:
            # Fallback for other result types
            actual_results = result

        if actual_results and hasattr(actual_results, "__len__"):
            count = len(actual_results)
            span.set_attribute("mvk.results_count", count)
            # Add metered usage for vectors retrieved
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.retrieved", count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_upsert_wrapper(self):
        """Create wrapper for Qdrant upsert operations.

        This wrapper tracks upsert operations that add or update points in Qdrant collections.
        It counts the number of points being processed and identifies the target collection.
        Perfect for monitoring data ingestion and vector database updates in Qdrant.
        """
        return WrapperBase.create_wrapper(
            span_name="qdrant.upsert",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_upsert_attributes,
            process_result=self._process_upsert_result,
        )

    def _extract_upsert_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from upsert operation."""
        attrs: Dict[str, Any] = {
            "model_provider": "qdrant",
            "operation": "vector_upsert",
            "operation_subtype": "write",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if args and len(args) > 0:
            attrs["collection_name"] = str(args[0])

        # Count points being upserted
        if "points" in kwargs:
            points = kwargs["points"]
            if hasattr(points, "__len__"):
                attrs["vectors_count"] = len(points)

        return attrs

    def _process_upsert_result(self, span, result) -> None:
        """Process upsert result."""
        # Track upsert count
        vectors_count = span.attributes.get("mvk.vectors_count", 0)
        if vectors_count > 0:
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.processed", vectors_count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_delete_wrapper(self):
        """Create wrapper for Qdrant delete operations.

        This wrapper monitors delete operations that remove points from Qdrant collections.
        It tracks deletion activities and identifies the target collection.
        Important for understanding data lifecycle and cleanup patterns in Qdrant.
        """
        return WrapperBase.create_wrapper(
            span_name="qdrant.delete",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_delete_attributes,
        )

    def _extract_delete_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from delete operation."""
        attrs = {
            "model_provider": "qdrant",
            "operation": "vector_delete",
            "operation_subtype": "delete",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if args and len(args) > 0:
            attrs["collection_name"] = str(args[0])

        return attrs
