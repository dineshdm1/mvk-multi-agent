#!/usr/bin/env python3
"""
Shared utilities for AI provider instrumentors to detect model types and input/output types.
"""

from typing import Any, Dict, Optional, Tuple


def detect_model_type(model_name: str, request_body: Optional[Dict[Any, Any]] = None) -> str:
    """Detect model type based on content analysis with minimal stable model name patterns.

    This approach prioritizes content analysis but uses minimal, stable model name patterns
    for specialized cases where model names are the most reliable indicator.

    Non-blocking contract: this function MUST NEVER raise. On any error,
    return a safe default of "chat" so client flows are not interrupted.
    """
    try:
        model_name_lower = (model_name or "").lower()

        # Use minimal, stable patterns for specialized models that are unlikely to change
        # These are broad patterns that are stable across model versions
        if "embed" in model_name_lower:
            return "embedding"

        # Analyze request content if available - content takes priority
        if request_body:
            content_type = _analyze_request_content(request_body)
            if content_type == "multimodal":
                return "multimodal"
            elif content_type == "audio":
                return "audio"
            elif content_type == "video":
                return "video"
            elif content_type == "image":
                return "multimodal"  # Images usually imply multimodal
            elif content_type == "embedding":
                return "embedding"

            # Also check if it's audio based on structure
            if "audio" in request_body or "file" in request_body:
                return "audio"

        # Fallback: Default to chat for unknown models
        # This is safe and will work with any model
        return "chat"

    except Exception:
        # Never interrupt client flow
        return "chat"


def detect_input_output_types(
    model_name: str, request_body: Optional[Dict[Any, Any]] = None
) -> Tuple[str, str]:
    """Detect input and output types based on content analysis with minimal stable patterns.

    This approach prioritizes content analysis but uses minimal, stable model name patterns
    for specialized cases where model names are the most reliable indicator.

    Non-blocking contract: this function MUST NEVER raise. On any error,
    return safe defaults of ("text", "text") so client flows are not interrupted.

    Returns:
        Tuple of (input_type, output_type)
    """
    try:
        model_name_lower = (model_name or "").lower()

        # Use minimal, stable patterns for specialized models
        if "embed" in model_name_lower:
            return ("text", "embedding")

        # Analyze request content if available
        if request_body:
            input_type = _analyze_input_content(request_body)
            output_type = _analyze_expected_output(request_body, model_name_lower)
            return (input_type, output_type)

        # Fallback: Safe defaults
        return ("text", "text")

    except Exception:
        # Never interrupt client flow
        return ("text", "text")


def get_model_family(model_name: str) -> str:
    """Get model family for the given model name.

    Non-blocking contract: this function MUST NEVER raise. On any error,
    return a safe default of "unknown" so client flows are not interrupted.
    """
    try:
        model_name_lower = (model_name or "").lower()

        # Common model families with stable patterns
        if "gpt" in model_name_lower:
            return "gpt"
        elif "claude" in model_name_lower:
            return "claude"
        elif "gemini" in model_name_lower or "bison" in model_name_lower:
            return "gemini"
        elif "llama" in model_name_lower:
            return "llama"
        elif "titan" in model_name_lower:
            return "titan"
        elif "nova" in model_name_lower:
            return "nova"
        elif "mistral" in model_name_lower:
            return "mistral"
        elif "whisper" in model_name_lower:
            return "whisper"
        elif "dall-e" in model_name_lower:
            return "dall-e"
        elif "bedrock" in model_name_lower:
            return "bedrock"
        elif "embed" in model_name_lower:
            return "embedding"

        return "unknown"

    except Exception:
        # Never interrupt client flow
        return "unknown"


def _analyze_request_content(request_body: Dict[Any, Any]) -> str:
    """Analyze request content to determine type."""
    try:
        # Check for messages with content blocks (multimodal)
        messages = request_body.get("messages", [])
        if messages and isinstance(messages, list):
            has_text = False
            has_media = False
            media_type = None

            media_counts = {"image": 0, "audio": 0, "video": 0, "embedding": 0}

            for message in messages:
                if isinstance(message, dict):
                    content = message.get("content", "")
                    if isinstance(content, list):
                        # Content blocks may indicate multimodal
                        for block in content:
                            if isinstance(block, dict):
                                block_type = block.get("type", "")
                                if block_type == "text":
                                    has_text = True
                                elif block_type in ["image", "image_url"]:
                                    has_media = True
                                    media_counts["image"] += 1
                                elif block_type in ["audio", "audio_url"]:
                                    has_media = True
                                    media_counts["audio"] += 1
                                elif block_type in ["video", "video_url"]:
                                    has_media = True
                                    media_counts["video"] += 1
                                elif block_type == "embedding":
                                    has_media = True
                                    media_counts["embedding"] += 1
                    elif isinstance(content, str) and content:
                        has_text = True

            # Determine media type based on counts
            media_type = None
            types_present = sum(1 for count in media_counts.values() if count > 0)

            if types_present > 1:
                media_type = "multimodal"
            elif media_counts["embedding"] > 0:
                # Embeddings are only "embedding" when alone, otherwise multimodal
                if has_text or media_counts["embedding"] > 1:
                    media_type = "multimodal"
                else:
                    media_type = "embedding"
            elif media_counts["image"] > 0:
                media_type = "image" if media_counts["image"] == 1 else "multimodal"
            elif media_counts["audio"] > 0:
                media_type = "audio" if media_counts["audio"] == 1 else "multimodal"
            elif media_counts["video"] > 0:
                media_type = "video" if media_counts["video"] == 1 else "multimodal"

            # Determine type based on content
            if has_media:
                if has_text or media_type == "multimodal":
                    return "multimodal"
                else:
                    return media_type or "multimodal"

        # Check for direct input field (embeddings)
        if "input" in request_body:
            return "text"  # Direct input doesn't imply embedding type

        # For audio-specific models
        if "audio" in request_body or "file" in request_body:
            return "audio"

        return "text"

    except Exception:
        return "text"


def _analyze_input_content(request_body: Dict[Any, Any]) -> str:
    """Analyze input content type."""
    try:
        # Check for multimodal content
        messages = request_body.get("messages", [])
        if messages and isinstance(messages, list):
            has_text = False
            has_image = False
            has_audio = False
            has_video = False
            has_embedding = False

            for message in messages:
                if isinstance(message, dict):
                    content = message.get("content", "")
                    if isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict):
                                block_type = block.get("type", "")
                                if block_type == "text":
                                    has_text = True
                                elif block_type in ["image", "image_url"]:
                                    has_image = True
                                elif block_type in ["audio", "audio_url"]:
                                    has_audio = True
                                elif block_type in ["video", "video_url"]:
                                    has_video = True
                                elif block_type == "embedding":
                                    has_embedding = True
                    elif isinstance(content, str) and content:
                        has_text = True

            # Count media types and instances
            media_types = sum([has_image, has_audio, has_video, has_embedding])

            # Count total media blocks to detect multiple instances of same type
            image_count = 0
            audio_count = 0
            video_count = 0
            for message in messages:
                if isinstance(message, dict):
                    content = message.get("content", "")
                    if isinstance(content, list):
                        for block in content:
                            if isinstance(block, dict):
                                block_type = block.get("type", "")
                                if block_type in ["image", "image_url"]:
                                    image_count += 1
                                elif block_type in ["audio", "audio_url"]:
                                    audio_count += 1
                                elif block_type in ["video", "video_url"]:
                                    video_count += 1

            # If we have multiple types or text + any media, it's multimodal
            # Also multimodal if we have multiple instances of the same media type
            if (
                (has_text and media_types > 0)
                or media_types > 1
                or has_embedding
                or image_count > 1
                or audio_count > 1
                or video_count > 1
            ):
                return "multimodal"
            # Single media type without text (single instance)
            elif has_image and not has_text:
                return "image"
            elif has_audio and not has_text:
                return "audio"
            elif has_video and not has_text:
                return "video"

        # Check for direct input field (embeddings)
        if "input" in request_body:
            # Don't assume embedding unless model name suggests it
            return "text"

        return "text"

    except Exception:
        return "text"


def _analyze_expected_output(request_body: Dict[Any, Any], model_name_lower: str) -> str:
    """Analyze expected output type."""
    try:
        # Embedding models output embeddings
        if "embed" in model_name_lower:
            return "embedding"

        # If input is multimodal, output is typically also multimodal for vision/audio models
        input_type = _analyze_input_content(request_body)
        if input_type == "multimodal":
            # Models that accept multimodal input typically produce multimodal-capable output
            return "multimodal"

        # Check for specific output requests
        if request_body.get("response_format"):
            format_type = request_body["response_format"]
            if isinstance(format_type, dict):
                format_type = format_type.get("type", "text")

            if format_type == "json_object":
                return "json"

        # Default to text for chat/completion models
        return "text"

    except Exception:
        return "text"
