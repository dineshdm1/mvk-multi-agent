"""Base Gemini instrumentor with shared functionality.

This module provides common functionality for all Google Gemini SDK instrumentors,
following the DRY principle and ensuring consistent behavior across different SDKs.
"""

from typing import Any, Dict, Optional

from ..instrument import should_log_prompts_responses
from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.model_detection import (
    detect_input_output_types,
    detect_model_type,
    get_model_family,
)
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "base_gemini")


class BaseGeminiInstrumentor(BaseInstrumentor):
    """Base class for all Google Gemini SDK instrumentors.

    This class provides common functionality that can be shared across different
    Google Gemini SDK versions (google.generativeai, google.genai, etc.).
    """

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "base_gemini"

    def _extract_common_attributes(
        self, model_name: str, model_family: str, request_body: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Extract common attributes for all Gemini SDKs.

        Args:
            model_name: Name of the model being used
            model_family: Family identifier (e.g., "gemini", "genai", "vertex")
            request_body: Optional request body for content analysis

        Returns:
            Dictionary of common attributes
        """
        # Detect model type dynamically based on model name and request content
        model_type = detect_model_type(model_name, request_body)

        # Detect input/output types dynamically based on model name and request content
        input_type, output_type = detect_input_output_types(model_name, request_body)

        return {
            "model_name": model_name,
            "model_provider": "google",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "batch",
            "mvk.step_type": MVKStepType.LLM,
        }

    def _extract_generation_config(self, config: Any) -> Dict[str, Any]:
        """Extract generation configuration parameters.

        Args:
            config: Configuration object from the SDK

        Returns:
            Dictionary of configuration attributes
        """
        attrs = {}
        if config:
            if hasattr(config, "temperature"):
                attrs["temperature"] = config.temperature
            if hasattr(config, "max_output_tokens"):
                attrs["max_tokens"] = config.max_output_tokens
            if hasattr(config, "max_tokens"):  # Alternative attribute name
                attrs["max_tokens"] = config.max_tokens
        return attrs

    def _extract_content(self, content: Any) -> Optional[str]:
        """Extract content text from various content formats.

        Args:
            content: Content object (string, list, or complex object)

        Returns:
            Extracted text content or None
        """
        # Only extract content if logging is enabled
        if not should_log_prompts_responses():
            return None

        if isinstance(content, str):
            return content[:1000]
        elif isinstance(content, list):
            return str(content)[:1000]
        elif content is not None:
            return str(content)[:1000]
        return None

    def _process_gemini_response(self, result: Any, span: Any) -> None:
        """Process Gemini API response and extract relevant information.

        Args:
            result: Response object from the API
            span: OpenTelemetry span to add attributes to
        """
        try:
            # Handle non-streaming response
            if not hasattr(result, "__next__"):
                # Extract response text only if logging is enabled
                if should_log_prompts_responses():
                    if hasattr(result, "candidates") and result.candidates:
                        candidate = result.candidates[0]
                        if hasattr(candidate, "content"):
                            content = candidate.content
                            if hasattr(content, "parts") and content.parts:
                                text = content.parts[0].text
                                span.set_attribute("mvk.response", text[:1000])

                # Extract token usage from usage_metadata
                self._extract_token_usage(result, span)

        except Exception as e:
            logger.debug(f"Failed to process Gemini response: {e}")

    def _extract_token_usage(self, result: Any, span: Any) -> None:
        """Extract token usage information from API response.

        Supports both legacy and new SDK field naming conventions, including
        reasoning tokens (thoughtsTokenCount) and cached tokens.

        Args:
            result: Response object from the API
            span: OpenTelemetry span to add attributes to
        """
        try:
            if hasattr(result, "usage_metadata"):
                usage = result.usage_metadata

                def _safe_get_int(obj: Any, *names: str) -> int:
                    for name in names:
                        try:
                            value = getattr(obj, name, None)
                            # Ignore Mock placeholders and non-numeric values
                            if isinstance(value, (int, float)):
                                return int(value)
                        except Exception:
                            continue
                    return 0

                # Standard tokens (handle both naming conventions) with safe coercion
                prompt_tokens = _safe_get_int(usage, "prompt_token_count", "promptTokenCount")
                completion_tokens = _safe_get_int(
                    usage, "candidates_token_count", "candidatesTokenCount"
                )
                total_tokens = _safe_get_int(usage, "total_token_count", "totalTokenCount")

                # Reasoning tokens (NEW) - for Gemini 2.5 series and newer
                reasoning_tokens = _safe_get_int(
                    usage, "thoughtsTokenCount", "thoughts_token_count"
                )

                # Cached tokens (NEW) - for cached content
                cached_tokens = _safe_get_int(
                    usage, "cachedContentTokenCount", "cached_content_token_count"
                )

                # Set individual attributes
                span.set_attribute("mvk.prompt_tokens", prompt_tokens)
                span.set_attribute("mvk.completion_tokens", completion_tokens)
                span.set_attribute("mvk.total_tokens", total_tokens)

                # Set reasoning tokens if present
                if reasoning_tokens > 0:
                    span.set_attribute("mvk.reasoning_tokens", reasoning_tokens)

                # Set cached tokens if present
                if cached_tokens > 0:
                    span.set_attribute("mvk.cached_tokens", cached_tokens)

                # Build enhanced metered usage
                self._create_metered_usage(
                    span,
                    prompt_tokens,
                    completion_tokens,
                    total_tokens,
                    reasoning_tokens,
                    cached_tokens,
                )

        except Exception as e:
            logger.debug(f"Failed to extract token usage: {e}")

    def _create_metered_usage(
        self,
        span: Any,
        prompt_tokens: int,
        completion_tokens: int,
        total_tokens: int,
        reasoning_tokens: int = 0,
        cached_tokens: int = 0,
    ) -> None:
        """Create and add metered usage to span with support for reasoning and cached tokens.

        Args:
            span: OpenTelemetry span to add metered usage to
            prompt_tokens: Number of prompt tokens
            completion_tokens: Number of completion tokens
            total_tokens: Total number of tokens
            reasoning_tokens: Number of reasoning/thinking tokens (Gemini 2.5+)
            cached_tokens: Number of cached tokens
        """
        try:
            if total_tokens > 0 or reasoning_tokens > 0:
                builder = MeteredUsageBuilder()
                builder.add_token_metrics(
                    prompt=prompt_tokens,
                    completion=completion_tokens,
                    total=total_tokens,
                    reasoning=reasoning_tokens,  # NEW: reasoning tokens
                    cached_read=cached_tokens,  # NEW: cached tokens
                )
                safe_populate_metered_usage(span, builder)
        except Exception as e:
            logger.debug(f"Failed to create metered usage: {e}")

    def _create_embed_content_wrapper(self, model_family: str):
        """Create wrapper for embed_content() function.

        Args:
            model_family: Family identifier for the SDK

        Returns:
            Wrapper function for embed_content
        """

        def extract_attributes(instance, args, kwargs):
            """Extract attributes from embed_content call."""
            attrs = {}

            # Get model name
            model_name = kwargs.get("model", f"models/embedding-001")

            attrs.update(self._extract_common_attributes(model_name, model_family))
            attrs.update(
                {
                    "model_type": "embedding",
                    "operation": "generate_embeddings",
                    "mvk.step_type": MVKStepType.EMBEDDING,
                }
            )

            # Extract content only if logging is enabled
            if "content" in kwargs:
                content = kwargs["content"]
                extracted_content = self._extract_content(content)
                if extracted_content:
                    attrs["prompt"] = extracted_content
                elif isinstance(content, list):
                    attrs["embeddings_count"] = len(content)

            return attrs

        def process_result(span, result):
            """Process embed_content result."""
            try:
                # Extract embedding dimensions
                if hasattr(result, "embedding") and result.embedding:
                    span.set_attribute("mvk.embedding_dims", len(result.embedding))

                # Note: Gemini embedding API doesn't provide token counts in response

            except Exception as e:
                logger.debug(f"Failed to process embed_content result: {e}")

        # Return the wrapper function
        return WrapperBase.create_wrapper(
            span_name=f"{model_family}.embed_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=extract_attributes,
            process_result=process_result,
        )
