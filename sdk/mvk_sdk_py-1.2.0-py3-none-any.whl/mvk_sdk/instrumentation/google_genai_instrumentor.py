"""Google GenAI instrumentor for the newer google.genai SDK.

This module provides instrumentation for the newer Google GenAI SDK (google.genai)
which is used by frameworks like Agno, using the BaseGeminiInstrumentor pattern.
"""

from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..instrument import should_log_prompts_responses
from ..instrumentation.base_gemini_instrumentor import BaseGeminiInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "google_genai")


class GoogleGenAIInstrumentor(BaseGeminiInstrumentor):
    """Instrumentor for the newer Google GenAI SDK (google.genai)."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """google.genai is required."""
        return ["google.genai"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "google_genai"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Google GenAI SDK.

        The base class handles unwrapping automatically.
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Google GenAI SDK."""
        try:
            import google.genai.models  # type: ignore

            # Create wrapper for Models.generate_content
            generate_wrapper = self._create_generate_content_wrapper()

            # Wrap Models.generate_content
            self._wrap_method(
                "google.genai.models",
                "Models.generate_content",
                generate_wrapper,
            )

            logger.info("Google GenAI auto-instrumentation enabled")

        except ImportError as e:
            logger.warning(f"Google GenAI SDK not available: {e}")
            raise  # Re-raise ImportError so base class knows instrumentation failed
        except Exception as e:
            logger.warning(f"Failed to instrument Google GenAI: {e}")
            raise  # Re-raise the exception so base class knows instrumentation failed

    def _extract_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from generate_content call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[GoogleGenAI] generate_content call detected from {framework} - skipping to avoid double spans"
            )
            return None

        attrs = {}

        # Get model name from kwargs (new SDK specific)
        model_name = kwargs.get("model", "unknown-model")

        # Use base class common attributes
        attrs.update(self._extract_common_attributes(model_name, "genai"))

        # Extract generation config if present (new SDK specific)
        if "config" in kwargs:
            config = kwargs["config"]
            attrs.update(self._extract_generation_config(config))

        # Extract contents/prompt only if logging is enabled (new SDK specific - from kwargs["contents"])
        if should_log_prompts_responses() and "contents" in kwargs:
            contents = kwargs["contents"]
            extracted_content = self._extract_content(contents)
            if extracted_content:
                attrs["prompt"] = extracted_content

        return attrs

    def _process_generate_content_result(self, span, result) -> None:
        """Process generate_content result.

        Uses enhanced token extraction that supports:
        - Standard tokens (prompt, completion, total)
        - Reasoning tokens (thoughtsTokenCount) for Gemini 2.5+ models
        - Cached tokens (cachedContentTokenCount)
        - Both legacy and new SDK field naming conventions
        """
        # Use base class response processing with enhanced token extraction
        self._process_gemini_response(result, span)

    def _create_generate_content_wrapper(self):
        """Create wrapper for Models.generate_content() method."""
        # Return the wrapper function
        return WrapperBase.create_wrapper(
            span_name="google.genai.generate_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_generate_content_attributes,
            process_result=self._process_generate_content_result,
        )
