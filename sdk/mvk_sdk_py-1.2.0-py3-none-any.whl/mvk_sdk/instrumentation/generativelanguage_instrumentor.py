"""Google Generative Language API instrumentor for the low-level protobuf API.

This module provides instrumentation for the low-level google.ai.generativelanguage_v1beta
gRPC/REST API client that LangChain uses directly instead of the high-level SDKs.

Target: google.ai.generativelanguage_v1beta.services.generative_service.client.GenerativeServiceClient
"""

from typing import Any, Collection, Dict, Optional

import wrapt  # type: ignore

from ..instrument import should_log_prompts_responses
from ..instrumentation.base_gemini_instrumentor import BaseGeminiInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "generativelanguage")


class GenerativeLanguageInstrumentor(BaseGeminiInstrumentor):
    """Instrumentor for low-level Google Generative Language API used by LangChain."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """google-ai-generativelanguage is required."""
        return ["google.ai.generativelanguage_v1beta"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "generativelanguage"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Generative Language API.

        The base class handles unwrapping automatically.
        """
        pass

    def _infer_model_from_context(self, request: Any, args: tuple, kwargs: dict) -> Optional[str]:
        """Try to infer the actual model name from calling context.

        When the request.model field is empty (e.g., from LangChain), we try to
        detect the model from:
        1. Calling stack inspection (looking for model parameter in caller)
        2. The ChatGoogleGenerativeAI instance (LangChain)
        3. The GenerativeModel instance if available
        4. Environment or configuration

        Args:
            request: The GenerateContentRequest protobuf object
            args: Positional arguments from the method call
            kwargs: Keyword arguments from the method call

        Returns:
            The inferred model name, or None if unable to determine
        """
        try:
            import inspect

            # Try to find model in calling stack
            stack = inspect.stack()

            # Look back through the call stack for model information
            # Skip the first 5 frames which are this function and the wrapper
            for frame_idx, frame_info in enumerate(stack[5:50], start=5):
                frame = frame_info.frame
                local_vars = frame.f_locals

                # Check for 'model' variable in locals
                if "model" in local_vars:
                    model_val = local_vars["model"]
                    if isinstance(model_val, str) and model_val.strip():
                        # Extract just the model name if it has a path
                        extracted = model_val.split("/")[-1]
                        if extracted and extracted != "models":
                            logger.debug(
                                f"[GenerativeLanguage] Inferred model from stack frame {frame_idx}: {extracted}"
                            )
                            return extracted

                # Check for 'self' with a model attribute (GenerativeModel or ChatGoogleGenerativeAI)
                if "self" in local_vars:
                    self_obj = local_vars["self"]
                    self_class_name = self_obj.__class__.__name__

                    # Check for ChatGoogleGenerativeAI (LangChain) - has 'model' attribute
                    if hasattr(self_obj, "model") and isinstance(
                        getattr(self_obj, "model", None), str
                    ):
                        model_str = str(self_obj.model).strip()
                        if model_str:
                            extracted = model_str.split("/")[-1]
                            if extracted and extracted != "models":
                                logger.debug(
                                    f"[GenerativeLanguage] Inferred model from {self_class_name}.model at frame {frame_idx}: {extracted}"
                                )
                                return extracted

                    # Check for GenerativeModel.model_name
                    if hasattr(self_obj, "model_name"):
                        model_name = str(self_obj.model_name).split("/")[-1]
                        if model_name and model_name != "models":
                            logger.debug(
                                f"[GenerativeLanguage] Inferred model from {self_class_name}.model_name at frame {frame_idx}: {model_name}"
                            )
                            return model_name

                    # Check for GenerativeModel._model_name
                    if hasattr(self_obj, "_model_name"):
                        model_name = str(self_obj._model_name).split("/")[-1]
                        if model_name and model_name != "models":
                            logger.debug(
                                f"[GenerativeLanguage] Inferred model from {self_class_name}._model_name at frame {frame_idx}: {model_name}"
                            )
                            return model_name

            logger.debug(
                f"[GenerativeLanguage] Unable to infer model from context - inspected {len(stack[5:50])} frames"
            )

        except Exception as e:
            logger.debug(
                f"[GenerativeLanguage] Failed to infer model from context: {e}", exc_info=True
            )

        return None

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Generative Language API."""
        try:
            import google.ai.generativelanguage_v1beta as genai_api  # type: ignore

            # Create wrappers following standard pattern
            generate_wrapper = self._create_generate_content_wrapper()
            stream_wrapper = self._create_stream_generate_content_wrapper()

            # Wrap GenerativeServiceClient.generate_content
            self._wrap_method(
                "google.ai.generativelanguage_v1beta.services.generative_service.client",
                "GenerativeServiceClient.generate_content",
                generate_wrapper,
            )

            generative_client = genai_api.services.generative_service.client.GenerativeServiceClient
            if hasattr(generative_client, "stream_generate_content"):
                self._wrap_method(
                    "google.ai.generativelanguage_v1beta.services.generative_service.client",
                    "GenerativeServiceClient.stream_generate_content",
                    stream_wrapper,
                )

            logger.info("Generative Language API auto-instrumentation enabled")

        except Exception as e:
            logger.warning(f"Failed to instrument Generative Language API: {e}")
            raise

    def _extract_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from generate_content call.

        Args are protobuf objects from google.ai.generativelanguage_v1beta.types
        """
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[GenerativeLanguage] generate_content call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize model_name and request_body
        model_name = None
        request_body = None

        # First, check kwargs for 'model' parameter (LangChain passes it via kwargs)
        if "model" in kwargs and isinstance(kwargs["model"], str):
            model_str = kwargs["model"].strip()
            if model_str:
                model_name = model_str.split("/")[-1]
                self._current_model_name = model_name
                logger.info(f"[GenerativeLanguage] Extracted model from kwargs: {model_name}")

        # Extract model name from request (protobuf object) if not found in kwargs
        # Request structure: GenerateContentRequest(model="models/gemini-xxx", contents=[...])
        if not model_name and args and len(args) > 0:
            request = args[0]
            # Extract model name from protobuf request
            model = getattr(request, "model", "")
            if model:
                # Model is typically "models/gemini-2.0-flash-exp" - extract just the model name
                model_name = model.split("/")[-1] if "/" in model else model
                self._current_model_name = model_name
                logger.info(f"[GenerativeLanguage] Extracted model from request: {model_name}")
            else:
                # Try to infer model from calling context when not in request
                model_name = self._infer_model_from_context(request, args, kwargs)
                if model_name:
                    self._current_model_name = model_name
                    logger.info(f"[GenerativeLanguage] Inferred model from context: {model_name}")
                else:
                    # Only fallback to default if we can't infer
                    model_name = "gemini-pro"
                    self._current_model_name = model_name
                    logger.info(f"[GenerativeLanguage] Fallback to default model: {model_name}")

            # Build request_body from protobuf contents for model detection
            # The structure must match what model_detection.py expects
            if hasattr(request, "contents"):
                contents = request.contents
                if contents:
                    try:
                        messages = []
                        for content in contents:
                            if hasattr(content, "parts"):
                                content_blocks = []
                                for part in content.parts:
                                    # Extract text content
                                    if hasattr(part, "text"):
                                        content_blocks.append({"type": "text", "text": part.text})
                                    # Extract multimodal content (image/audio/video)
                                    elif hasattr(part, "inline_data"):
                                        inline_data = part.inline_data
                                        mime_type = getattr(inline_data, "mime_type", "")
                                        # Map MIME types to content types for model_detection.py
                                        if "image" in mime_type:
                                            content_blocks.append({"type": "image"})
                                        elif "audio" in mime_type:
                                            content_blocks.append({"type": "audio"})
                                        elif "video" in mime_type:
                                            content_blocks.append({"type": "video"})
                                if content_blocks:
                                    messages.append({"content": content_blocks})
                        if messages:
                            # Build request_body in format expected by model_detection utilities
                            request_body = {"messages": messages}
                    except Exception as e:
                        logger.debug(f"Failed to build request_body from protobuf: {e}")
        else:
            # No request args - try to get model from kwargs first
            if "model" in kwargs and isinstance(kwargs["model"], str):
                model_str = kwargs["model"].strip()
                if model_str:
                    model_name = model_str.split("/")[-1]
                    self._current_model_name = model_name
                    logger.info(
                        f"[GenerativeLanguage] Extracted model from kwargs (no args): {model_name}"
                    )

            # If still no model, try to infer from context
            if not model_name:
                model_name = self._infer_model_from_context(None, args, kwargs)
                if model_name:
                    self._current_model_name = model_name
                    logger.info(
                        f"[GenerativeLanguage] Inferred model from context (no args): {model_name}"
                    )
                else:
                    # Only fallback to default if we can't infer
                    model_name = "gemini-pro"
                    self._current_model_name = model_name
                    logger.info(
                        f"[GenerativeLanguage] Fallback to default model (no args): {model_name}"
                    )

        # Resolve model identity using LiteLLM to get model_family
        from .litellm_normalization import resolve_model_identity

        identity = resolve_model_identity(model_name, kwargs)

        # IMPORTANT: Override provider to "google" since this instrumentor is specifically
        # for the low-level Google Generative Language API, NOT Vertex AI.
        # The instrumentor wraps google.ai.generativelanguage_v1beta.services.generative_service.client.GenerativeServiceClient
        # which uses the Google Generative AI API (api.generativeai.google.dev), not Vertex AI.
        provider = "google"

        logger.info(
            f"[GenerativeLanguage] Final model_name for span: {model_name}, provider: {provider}"
        )

        # Extract common attributes with correct provider for Google Generative AI API
        attrs = self._extract_common_attributes(model_name, provider, request_body)

        # Override model_provider with correct provider (google, not vertex_ai)
        attrs["model_provider"] = provider
        # For Google Generative AI API, model_family should be "gemini" to distinguish from Vertex AI
        # This is the new Google API (api.generativeai.google.dev), not the legacy Vertex AI API
        attrs["model_family"] = "gemini"

        # Extract generation config from protobuf request
        if args and len(args) > 0:
            request = args[0]
            if hasattr(request, "generation_config"):
                config = request.generation_config
                if config:
                    if hasattr(config, "temperature"):
                        attrs["temperature"] = config.temperature
                    if hasattr(config, "max_output_tokens"):
                        attrs["max_tokens"] = config.max_output_tokens

            # Extract prompt/content only if logging is enabled
            if should_log_prompts_responses() and hasattr(request, "contents"):
                contents = request.contents
                if contents:
                    # Contents is a list of protobuf Content objects
                    # Each Content has parts[] which have text
                    try:
                        prompt_parts = []
                        for content in contents:
                            if hasattr(content, "parts"):
                                for part in content.parts:
                                    if hasattr(part, "text"):
                                        prompt_parts.append(part.text)
                        if prompt_parts:
                            attrs["prompt"] = " ".join(prompt_parts)[:1000]
                    except Exception as e:
                        logger.debug(f"Failed to extract prompt from protobuf: {e}")

        # Not streaming by default (stream is handled by stream_generate_content method)
        attrs["operation_subtype"] = "batch"

        return attrs

    def _process_generate_content_result(self, span, result) -> None:
        """Process generate_content result.

        Result is a protobuf GenerateContentResponse object.
        """
        logger.debug(f"[GenerativeLanguage] Processing result, result type: {type(result)}")
        try:
            # Extract response text only if logging is enabled
            if should_log_prompts_responses():
                if hasattr(result, "candidates") and result.candidates:
                    candidate = result.candidates[0]
                    if hasattr(candidate, "content"):
                        content = candidate.content
                        if hasattr(content, "parts") and content.parts:
                            try:
                                response_parts = []
                                for part in content.parts:
                                    if hasattr(part, "text"):
                                        response_parts.append(part.text)
                                if response_parts:
                                    span.set_attribute(
                                        "mvk.response", " ".join(response_parts)[:1000]
                                    )
                            except Exception as e:
                                logger.debug(f"Failed to extract response from protobuf: {e}")

            # Extract token usage from protobuf response
            # Use base class method which supports reasoning and cached tokens
            self._extract_token_usage(result, span)

        except Exception as e:
            logger.debug(f"Failed to process Generative Language API response: {e}")

    def _create_generate_content_wrapper(self):
        """Create wrapper for GenerativeServiceClient.generate_content() method."""
        return WrapperBase.create_wrapper(
            span_name="gemini.generate_content",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_generate_content_attributes,
            process_result=self._process_generate_content_result,
        )

    def _create_stream_generate_content_wrapper(self):
        """Create wrapper for GenerativeServiceClient.stream_generate_content() method."""
        return WrapperBase.create_streaming_wrapper(
            span_name="gemini.generate_content.stream",
            extract_attributes=self._extract_stream_generate_content_attributes,
            process_chunk=self._process_stream_generate_content_chunk,
            provider="google",
        )

    def _extract_stream_generate_content_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes specific to stream_generate_content."""
        attrs = self._extract_generate_content_attributes(instance, args, kwargs)
        if not attrs:
            return attrs

        attrs["stream_enabled"] = True
        attrs["operation_subtype"] = "stream"
        return attrs

    def _process_stream_generate_content_chunk(self, span, chunk) -> None:
        """Process individual streaming chunks from stream_generate_content."""
        logger.debug(f"[GenerativeLanguage] Processing stream chunk, chunk type: {type(chunk)}")
        try:
            if should_log_prompts_responses():
                if hasattr(chunk, "candidates") and chunk.candidates:
                    candidate = chunk.candidates[0]
                    if hasattr(candidate, "content"):
                        content = candidate.content
                        if hasattr(content, "parts") and content.parts:
                            response_parts = []
                            for part in content.parts:
                                if hasattr(part, "text"):
                                    response_parts.append(part.text)
                            if response_parts:
                                span.set_attribute("mvk.response", " ".join(response_parts)[:1000])

            # Use base class method which supports reasoning and cached tokens
            self._extract_token_usage(chunk, span)

        except Exception as e:
            logger.debug(f"Failed to process Generative Language API stream chunk: {e}")
