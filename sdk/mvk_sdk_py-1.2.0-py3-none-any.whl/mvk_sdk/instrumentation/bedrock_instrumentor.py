"""AWS Bedrock instrumentor following OTEL patterns.

This module provides instrumentation for AWS Bedrock SDK, allowing you to automatically
track and monitor your AI model calls without changing your existing code.

What this does:
- Automatically wraps your Bedrock API calls to capture telemetry data
- Tracks token usage, response times, and model performance
- Supports all major Bedrock operations (chat, streaming, token counting)
- Works with Claude, Titan, Llama, Mistral, and other Bedrock models
- Follows OpenTelemetry standards for consistent observability

Example:
    Once instrumented, your existing Bedrock code will automatically
    generate spans and metrics:

    ```python
    import boto3

    # Your existing code works unchanged
    client = boto3.client('bedrock-runtime')
    response = client.invoke_model(
        modelId='anthropic.claude-3-sonnet-20240229-v1:0',
        body=json.dumps({'prompt': 'Hello world'})
    )
    # This automatically creates spans with token usage, timing, etc.
    ```
"""

import json
from typing import Any, Collection, Dict, Optional

import wrapt

from ..instrument import should_log_prompts_responses
from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.model_detection import (
    detect_input_output_types,
    detect_model_type,
    get_model_family,
)
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "bedrock")


class BedrockInstrumentor(BaseInstrumentor):
    """Instrumentor for AWS Bedrock SDK following OTEL patterns.

    This instrumentor automatically wraps your AWS Bedrock API calls to provide
    comprehensive observability. It tracks everything you need to monitor your
    AI applications:

    - **Token Usage**: Automatically counts input and output tokens
    - **Model Performance**: Tracks response times and success rates
    - **Content Tracking**: Optionally logs prompts and responses (when enabled)
    - **Streaming Support**: Handles both regular and streaming API calls
    - **Multi-Model Support**: Works with Claude, Titan, Llama, Mistral, and more

    The instrumentor is designed to be completely transparent - your existing
    Bedrock code will work exactly the same, but now with automatic telemetry.

    Supported Operations:
    - `InvokeModel`: Standard chat completions
    - `InvokeModelWithResponseStream`: Streaming responses
    - `Converse`: Newer chat API with better structure
    - `ConverseStream`: Streaming version of Converse
    - `InvokeModelWithBidirectionalStream`: Two-way streaming
    - `CountTokens`: Token counting utility

    Example:
        ```python
        # Your existing Bedrock code works unchanged
        client = boto3.client('bedrock-runtime')
        response = client.invoke_model(
            modelId='anthropic.claude-3-sonnet-20240229-v1:0',
            body=json.dumps({
                'messages': [{'role': 'user', 'content': 'Hello!'}]
            })
        )
        # Automatically creates spans with:
        # - Token usage (input/output/total)
        # - Model information
        # - Response timing
        # - Content (if logging enabled)
        ```
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """List of packages required for Bedrock instrumentation.

        Returns:
            List containing 'boto3' - the AWS SDK for Python that provides
            the Bedrock client functionality.

        Note:
            This instrumentor requires boto3 to be installed. If boto3 is not
            available, instrumentation will be skipped automatically.
        """
        return ["boto3"]

    @property
    def name(self) -> str:
        """Name identifier for this instrumentor.

        Returns:
            String 'bedrock' - used internally to identify this instrumentor
            in logs and configuration.
        """
        return "bedrock"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from AWS Bedrock SDK.

        This method removes all the wrappers that were applied during
        instrumentation, restoring the original Bedrock client behavior.

        The base class automatically handles the unwrapping process,
        so this method doesn't need to do anything special.

        Args:
            **kwargs: Additional configuration options (unused)
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to AWS Bedrock SDK.

        This method sets up the core instrumentation by wrapping the
        botocore client's API call method. This allows us to intercept
        all Bedrock API calls and add telemetry without changing your code.

        The instrumentation works by:
        1. Wrapping the low-level API call method in botocore
        2. Detecting when calls are made to bedrock-runtime service
        3. Routing specific operations to their specialized wrappers
        4. Extracting telemetry data from requests and responses

        Args:
            **kwargs: Configuration options passed from the main instrument() call

        Raises:
            Exception: If wrapping fails, logs the error but doesn't break your app
        """
        try:
            # Wrap the bedrock-runtime client methods via botocore
            success = self._wrap_method(
                "botocore.client", "BaseClient._make_api_call", self._create_bedrock_wrapper()
            )

            if not success:
                logger.warning(
                    "Failed to wrap BaseClient._make_api_call for Bedrock instrumentation"
                )

        except Exception as e:
            logger.error(f"Failed to instrument Bedrock: {e}")
            import traceback

            logger.error(f"Traceback: {traceback.format_exc()}")

    def _create_bedrock_wrapper(self):
        """Create the main wrapper that intercepts all Bedrock API calls.

        This is the entry point for all Bedrock instrumentation. It creates
        a wrapper that sits between your code and the actual Bedrock API,
        allowing us to capture telemetry data without changing your application.

        How it works:
        1. Intercepts all API calls made through botocore
        2. Checks if the call is for the bedrock-runtime service
        3. Identifies the specific operation being called
        4. Routes the call to the appropriate specialized wrapper
        5. Returns the result unchanged to your application

        Supported operations:
        - InvokeModel: Standard chat completions
        - InvokeModelWithResponseStream: Streaming responses
        - Converse: Newer structured chat API
        - ConverseStream: Streaming version of Converse
        - InvokeModelWithBidirectionalStream: Two-way streaming
        - CountTokens: Token counting utility

        Returns:
            A wrapper function that can be used with wrapt to intercept
            botocore API calls.
        """

        def wrapper(wrapped, instance, args, kwargs):
            # Check if this is a bedrock-runtime client
            if not hasattr(instance, "_service_model"):
                return wrapped(*args, **kwargs)

            service_name = instance._service_model.service_name
            if service_name != "bedrock-runtime":
                return wrapped(*args, **kwargs)

            # Get the operation name
            operation_name = args[0] if args else kwargs.get("operation_name", "")

            # Instrument specific operations
            if operation_name == "InvokeModel":
                return self._create_invoke_model_wrapper()(wrapped, instance, args, kwargs)
            elif operation_name == "InvokeModelWithResponseStream":
                return self._create_invoke_model_with_response_stream_wrapper()(
                    wrapped, instance, args, kwargs
                )
            elif operation_name == "Converse":
                return self._create_converse_wrapper()(wrapped, instance, args, kwargs)
            elif operation_name == "ConverseStream":
                return self._create_converse_stream_wrapper()(wrapped, instance, args, kwargs)
            elif operation_name == "InvokeModelWithBidirectionalStream":
                return self._create_bidirectional_stream_wrapper()(wrapped, instance, args, kwargs)
            elif operation_name == "CountTokens":
                return self._create_count_tokens_wrapper()(wrapped, instance, args, kwargs)
            else:
                return wrapped(*args, **kwargs)

        return wrapper

    def _extract_invoke_model_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract useful information from an InvokeModel request.

        This function analyzes the incoming request to extract metadata
        that will be attached to the telemetry span. It handles different
        request formats and model types automatically.

        What it extracts:
        - **Model Details**: Name, provider, family (Claude, Titan, etc.)
        - **Request Content**: The actual prompt or messages
        - **Parameters**: Temperature, max tokens, and other settings
        - **Operation Info**: Type of operation and whether it's streaming

        The function is smart about different formats:
        - Claude models: Looks for 'messages' array
        - Titan models: Looks for 'inputText' field
        - Generic models: Looks for 'prompt' field

        Args:
            instance: The botocore client instance making the call
            args: Positional arguments passed to the API call
            kwargs: Keyword arguments passed to the API call

        Returns:
            Dictionary of attributes to attach to the telemetry span.
            These attributes will be visible in your observability platform.
        """
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] InvokeModel call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize with basic attributes
        model_name = None
        request_data = {}

        # Extract model name from request body
        try:
            request_body = kwargs.get("body", {})
            if isinstance(request_body, (str, bytes)):
                try:
                    if isinstance(request_body, bytes):
                        request_body = request_body.decode("utf-8")
                    request_data = json.loads(request_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    request_data = {}
            else:
                request_data = request_body

            # Extract model name from various possible locations
            if "modelId" in request_data:
                model_name = request_data["modelId"]
            elif "model_id" in request_data:
                model_name = request_data["model_id"]
            elif "model" in request_data:
                model_name = request_data["model"]
            elif "modelId" in kwargs:
                model_name = kwargs["modelId"]

        except Exception as e:
            logger.debug(f"Failed to extract model name from request: {e}")

        # Detect model type, input/output types dynamically based on model name and request content
        # Use "unknown-model" as fallback for detection functions, but don't set in attrs if None
        model_name_for_detection = model_name or "unknown-model"
        model_type = detect_model_type(model_name_for_detection, request_data)
        input_type, output_type = detect_input_output_types(model_name_for_detection, request_data)
        model_family = get_model_family(model_name_for_detection)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs: Dict[str, Any] = {
            "model_provider": "aws-bedrock",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "batch",
            "mvk.step_type": MVKStepType.LLM,
        }

        # Only include model_name if it was successfully extracted
        if model_name:
            attrs["model_name"] = model_name

        # Extract prompt/content for logging
        try:
            prompt_content = None
            if "messages" in request_data:
                # Chat format
                messages = request_data["messages"]
                if isinstance(messages, list) and messages:
                    prompt_content = " ".join(
                        [
                            msg.get("content", "")
                            for msg in messages
                            if isinstance(msg, dict) and msg.get("content")
                        ]
                    )
            elif "prompt" in request_data:
                # Completion format
                prompt_content = request_data["prompt"]
            elif "inputText" in request_data:
                # Titan format
                prompt_content = request_data["inputText"]

            if prompt_content:
                attrs["prompt"] = prompt_content[:1000]  # Limit size

            # Extract generation parameters
            if "max_tokens" in request_data:
                attrs["max_tokens"] = request_data["max_tokens"]
            elif "maxTokensToSample" in request_data:
                attrs["max_tokens"] = request_data["maxTokensToSample"]

            if "temperature" in request_data:
                attrs["temperature"] = request_data["temperature"]

        except Exception as e:
            logger.debug(f"Failed to extract attributes from request: {e}")

        return attrs

    def _process_invoke_model_result(self, span, result) -> None:
        """Process the response from an InvokeModel call and extract telemetry data.

        This function takes the response from Bedrock and extracts all the
        important telemetry information to attach to the span. It handles
        different response formats and automatically counts tokens.

        What it processes:
        - **Token Usage**: Counts input, output, and total tokens
        - **Response Content**: Extracts the AI's response text
        - **Usage Metrics**: Creates metered usage records for billing
        - **Error Handling**: Safely handles malformed responses

        Token counting is smart and handles different formats:
        - Some models return 'usage' object with token counts
        - Others use 'tokenUsage', 'inputTokenCount', etc.
        - Falls back to calculating total from input + output

        The function also respects your logging preferences:
        - Only logs response content if 'log_prompts_responses' is enabled
        - Limits content size to prevent overwhelming logs
        - Handles both JSON and text response formats

        Args:
            span: The OpenTelemetry span to attach data to
            result: The response object returned by Bedrock

        Example:
            ```python
            # Response from Bedrock might look like:
            {
                'body': '{"content": [{"text": "Hello! How can I help?"}], "usage": {"inputTokens": 5, "outputTokens": 8, "totalTokens": 13}}'
            }

            # This function extracts:
            # - mvk.prompt_tokens: 5
            # - mvk.completion_tokens: 8
            # - mvk.total_tokens: 13
            # - mvk.response: "Hello! How can I help?" (if logging enabled)
            ```
        """
        try:
            # Extract response body
            response_body = result.get("body", {})
            if isinstance(response_body, (str, bytes)):
                try:
                    if isinstance(response_body, bytes):
                        response_body = response_body.decode("utf-8")
                    response_data = json.loads(response_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    response_data = {}
            else:
                response_data = response_body

            # Extract response content (only if log_prompts_responses is enabled)
            if should_log_prompts_responses():
                response_content = None
                if "content" in response_data:
                    content_list = response_data["content"]
                    if isinstance(content_list, list):
                        response_content = " ".join(
                            [
                                item.get("text", "")
                                for item in content_list
                                if isinstance(item, dict) and item.get("text")
                            ]
                        )
                elif "completion" in response_data:
                    response_content = response_data["completion"]
                elif "outputText" in response_data:
                    response_content = response_data["outputText"]

                if response_content:
                    span.set_attribute("mvk.response", response_content[:1000])

            # Extract token usage (varies by model)
            prompt_tokens = None
            completion_tokens = None
            total_tokens = None

            # Try different token usage field names
            usage_fields = [
                "usage",
                "tokenUsage",
                "token_usage",
                "inputTokenCount",
                "outputTokenCount",
                "totalTokenCount",
            ]

            for field in usage_fields:
                if field in response_data:
                    usage_data = response_data[field]
                    if isinstance(usage_data, dict):
                        # Try different field names for prompt tokens
                        prompt_tokens = (
                            usage_data.get("inputTokens")
                            or usage_data.get("promptTokens")
                            or usage_data.get("inputTokenCount")
                            or prompt_tokens
                        )
                        # Try different field names for completion tokens
                        completion_tokens = (
                            usage_data.get("outputTokens")
                            or usage_data.get("completionTokens")
                            or usage_data.get("outputTokenCount")
                            or completion_tokens
                        )
                        # Try different field names for total tokens
                        total_tokens = (
                            usage_data.get("totalTokens")
                            or usage_data.get("totalTokenCount")
                            or total_tokens
                        )
                    break

            # Set token attributes
            if prompt_tokens is not None:
                span.set_attribute("mvk.prompt_tokens", int(prompt_tokens))
            if completion_tokens is not None:
                span.set_attribute("mvk.completion_tokens", int(completion_tokens))
            if total_tokens is not None:
                span.set_attribute("mvk.total_tokens", int(total_tokens))
            elif prompt_tokens is not None and completion_tokens is not None:
                total_tokens = prompt_tokens + completion_tokens
                span.set_attribute("mvk.total_tokens", int(total_tokens))

            # Create metered usage if we have token data
            if total_tokens and total_tokens > 0:
                builder = MeteredUsageBuilder()
                builder.add_token_metrics(
                    prompt=prompt_tokens or 0,
                    completion=completion_tokens or 0,
                    total=total_tokens,
                )
                safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process Bedrock result: {e}")

    def _create_invoke_model_wrapper(self):
        """Create wrapper for Bedrock InvokeModel operation.

        This wrapper handles the most common Bedrock operation - standard
        chat completions. It's used when you call `client.invoke_model()`
        to get a complete response from your AI model.

        What it tracks:
        - **Model Information**: Which model you're using (Claude, Titan, etc.)
        - **Token Usage**: Input tokens, output tokens, and total tokens
        - **Request Content**: The prompt or messages you sent
        - **Response Content**: The AI's response (if logging enabled)
        - **Timing**: How long the request took
        - **Parameters**: Temperature, max tokens, and other settings

        The wrapper automatically detects different model families and formats:
        - Claude models: Uses 'messages' format
        - Titan models: Uses 'inputText' format
        - Generic models: Uses 'prompt' format

        Example:
            ```python
            # This call will be automatically wrapped
            response = client.invoke_model(
                modelId='anthropic.claude-3-sonnet-20240229-v1:0',
                body=json.dumps({
                    'messages': [{'role': 'user', 'content': 'Hello!'}],
                    'max_tokens': 100,
                    'temperature': 0.7
                })
            )
            # Creates a span with:
            # - model_name: 'anthropic.claude-3-sonnet-20240229-v1:0'
            # - model_family: 'claude'
            # - prompt: 'Hello!'
            # - mvk.prompt_tokens: <actual count>
            # - mvk.completion_tokens: <actual count>
            # - mvk.total_tokens: <actual count>
            ```

        Returns:
            A wrapper function that extracts telemetry data from InvokeModel calls.
        """
        # Create and return the wrapper
        return WrapperBase.create_wrapper(
            span_name="bedrock.invoke_model",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_invoke_model_attributes,
            process_result=self._process_invoke_model_result,
        )

    def _extract_invoke_model_with_response_stream_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from streaming InvokeModel call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] InvokeModelWithResponseStream call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize with basic attributes
        model_name = None
        request_data = {}

        # Extract model name from request body (same logic as non-streaming)
        try:
            request_body = kwargs.get("body", {})
            if isinstance(request_body, (str, bytes)):
                try:
                    if isinstance(request_body, bytes):
                        request_body = request_body.decode("utf-8")
                    request_data = json.loads(request_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    request_data = {}
            else:
                request_data = request_body

            # Extract model name
            if "modelId" in request_data:
                model_name = request_data["modelId"]
            elif "model_id" in request_data:
                model_name = request_data["model_id"]
            elif "model" in request_data:
                model_name = request_data["model"]
            elif "modelId" in kwargs:
                model_name = kwargs["modelId"]

        except Exception as e:
            logger.debug(f"Failed to extract model name from streaming request: {e}")

        # Detect model type, input/output types dynamically based on model name and request content
        # Use "unknown-model" as fallback for detection functions, but don't set in attrs if None
        model_name_for_detection = model_name or "unknown-model"
        model_type = detect_model_type(model_name_for_detection, request_data)
        input_type, output_type = detect_input_output_types(model_name_for_detection, request_data)
        model_family = get_model_family(model_name_for_detection)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs: Dict[str, Any] = {
            "model_provider": "aws-bedrock",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "stream",
            "mvk.step_type": MVKStepType.LLM,
            "stream_enabled": True,
        }

        # Only include model_name if it was successfully extracted
        if model_name:
            attrs["model_name"] = model_name

        # Extract prompt content
        try:
            prompt_content = None
            if "messages" in request_data:
                messages = request_data["messages"]
                if isinstance(messages, list) and messages:
                    prompt_content = " ".join(
                        [
                            msg.get("content", "")
                            for msg in messages
                            if isinstance(msg, dict) and msg.get("content")
                        ]
                    )
            elif "prompt" in request_data:
                prompt_content = request_data["prompt"]
            elif "inputText" in request_data:
                prompt_content = request_data["inputText"]

            if prompt_content:
                attrs["prompt"] = prompt_content[:1000]

        except Exception as e:
            logger.debug(f"Failed to extract prompt content from streaming request: {e}")

        return attrs

    def _process_invoke_model_with_response_stream_chunk(self, span, chunk) -> None:
        """Process each streaming chunk."""
        try:
            # Extract chunk data
            chunk_data = chunk.get("chunk", {})
            if isinstance(chunk_data, bytes):
                try:
                    chunk_json = json.loads(chunk_data.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    chunk_json = {}
            else:
                chunk_json = chunk_data

            # Track chunk count
            current_count = span.get_attribute("mvk.stream.chunk_count") or 0
            span.set_attribute("mvk.stream.chunk_count", current_count + 1)

            # Extract content from chunk (only if log_prompts_responses is enabled)
            if should_log_prompts_responses():
                if "bytes" in chunk_json:
                    # Claude streaming format
                    content_data = chunk_json["bytes"]
                    if isinstance(content_data, bytes):
                        try:
                            content_json = json.loads(content_data.decode("utf-8"))
                            if "delta" in content_json and "text" in content_json["delta"]:
                                text_content = content_json["delta"]["text"]
                                if text_content:
                                    # Accumulate response text
                                    current_response = span.get_attribute("mvk.response") or ""
                                    span.set_attribute(
                                        "mvk.response", (current_response + text_content)[:1000]
                                    )
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            pass

            # Check for usage information in final chunk
            if "usage" in chunk_json:
                usage_data = chunk_json["usage"]
                if isinstance(usage_data, dict):
                    prompt_tokens = usage_data.get("inputTokens", usage_data.get("promptTokens"))
                    completion_tokens = usage_data.get(
                        "outputTokens", usage_data.get("completionTokens")
                    )
                    total_tokens = usage_data.get("totalTokens")

                    if prompt_tokens is not None:
                        span.set_attribute("mvk.prompt_tokens", int(prompt_tokens))
                    if completion_tokens is not None:
                        span.set_attribute("mvk.completion_tokens", int(completion_tokens))
                    if total_tokens is not None:
                        span.set_attribute("mvk.total_tokens", int(total_tokens))

                        # Create metered usage
                        builder = MeteredUsageBuilder()
                        builder.add_token_metrics(
                            prompt=prompt_tokens or 0,
                            completion=completion_tokens or 0,
                            total=total_tokens,
                        )
                        safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process Bedrock streaming chunk: {e}")

    def _create_invoke_model_with_response_stream_wrapper(self):
        """Create wrapper for Bedrock streaming InvokeModel calls.

        This wrapper handles streaming responses from Bedrock, where the AI
        model sends back its response in chunks as it generates text. This
        is useful for real-time applications where you want to show the
        response as it's being generated.

        How streaming works:
        1. Your code calls `invoke_model_with_response_stream()`
        2. Bedrock starts sending chunks of the response
        3. This wrapper processes each chunk as it arrives
        4. Accumulates the full response text
        5. Extracts token usage from the final chunk

        What it tracks:
        - **Chunk Count**: How many chunks were received
        - **Streaming Content**: Accumulates the full response text
        - **Token Usage**: Extracted from the final chunk
        - **Timing**: Total time for the streaming operation

        The wrapper is smart about different streaming formats:
        - Claude streaming: Uses 'bytes' field with delta text
        - Other models: May use different chunk structures

        Example:
            ```python
            # Streaming call
            response = client.invoke_model_with_response_stream(
                modelId='anthropic.claude-3-sonnet-20240229-v1:0',
                body=json.dumps({
                    'messages': [{'role': 'user', 'content': 'Tell me a story'}]
                })
            )

            # Process the stream
            for event in response['body']:
                # Each chunk is automatically processed
                # Creates span with:
                # - mvk.stream.chunk_count: <number of chunks>
                # - mvk.response: <accumulated full response>
                # - mvk.total_tokens: <from final chunk>
            ```

        Returns:
            A streaming wrapper that processes chunks as they arrive.
        """
        # Create streaming wrapper
        return WrapperBase.create_streaming_wrapper(
            span_name="bedrock.invoke_model_with_response_stream",
            extract_attributes=self._extract_invoke_model_with_response_stream_attributes,
            process_chunk=self._process_invoke_model_with_response_stream_chunk,
            provider="aws-bedrock",
        )

    def _extract_converse_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from Converse call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] Converse call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Extract model name - check all possible sources
        model_name = "unknown-model"
        request_data = {}

        try:
            # Try to get model name from various sources
            # 1. Check if modelId is directly in kwargs
            if "modelId" in kwargs:
                model_name = kwargs["modelId"]

            # 2. Check args for modelId (Converse API passes modelId in args)
            elif args and len(args) > 1 and isinstance(args[1], dict) and "modelId" in args[1]:
                model_name = args[1]["modelId"]

            # 3. Check request body for modelId
            elif "body" in kwargs:
                request_body = kwargs.get("body", {})

                if isinstance(request_body, (str, bytes)):
                    try:
                        if isinstance(request_body, bytes):
                            request_body = request_body.decode("utf-8")
                        request_data = json.loads(request_body)
                        if "modelId" in request_data:
                            model_name = request_data["modelId"]
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        request_data = {}
                else:
                    request_data = request_body
                    if "modelId" in request_data:
                        model_name = request_data["modelId"]

            # 4. Check if we can extract from URL path (if available)
            if model_name == "unknown-model" and "url_path" in kwargs:
                url_path = kwargs.get("url_path", "")
                if url_path and "/model/" in url_path:
                    parts = url_path.split("/model/")
                    if len(parts) > 1:
                        model_part = parts[1].split("/")[0]
                        import urllib.parse

                        model_name = urllib.parse.unquote(model_part)

        except Exception as e:
            logger.debug(f"Failed to extract model name from Converse request: {e}")

        # Detect model type, input/output types dynamically based on model name and request content
        model_type = detect_model_type(model_name, request_data)
        input_type, output_type = detect_input_output_types(model_name, request_data)
        model_family = get_model_family(model_name)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs = {
            "model_name": model_name,
            "model_provider": "aws-bedrock",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "batch",
            "mvk.step_type": MVKStepType.LLM,
        }

        # Extract messages for prompt content and generation parameters
        try:
            messages = request_data.get("messages", [])
            if messages:
                prompt_content = " ".join(
                    [
                        (
                            msg.get("content", [{}])[0].get("text", "")
                            if isinstance(msg.get("content"), list)
                            else str(msg.get("content", ""))
                        )
                        for msg in messages
                        if isinstance(msg, dict)
                    ]
                )
                if prompt_content:
                    attrs["prompt"] = prompt_content[:1000]

            # Extract generation parameters
            if "inferenceConfig" in request_data:
                config = request_data["inferenceConfig"]
                if "maxTokens" in config:
                    attrs["max_tokens"] = config["maxTokens"]
                if "temperature" in config:
                    attrs["temperature"] = config["temperature"]

        except Exception as e:
            logger.debug(f"Failed to extract attributes from Converse request: {e}")

        return attrs

    def _process_converse_result(self, span, result) -> None:
        """Process Converse result and extract token usage."""
        try:
            # The result is already the parsed botocore response object
            # No need to extract from "body" - the usage is at the top level
            response_data = result

            # Extract response content (only if log_prompts_responses is enabled)
            if should_log_prompts_responses():
                output = response_data.get("output", {})
                if "message" in output:
                    message = output["message"]
                    if "content" in message:
                        content_list = message["content"]
                        if isinstance(content_list, list):
                            response_content = " ".join(
                                [
                                    item.get("text", "")
                                    for item in content_list
                                    if isinstance(item, dict) and item.get("text")
                                ]
                            )
                            if response_content:
                                span.set_attribute("mvk.response", response_content[:1000])

            # Extract token usage (Converse API has usage at top level)
            usage = response_data.get("usage", {})

            if usage:
                input_tokens = usage.get("inputTokens", 0)
                output_tokens = usage.get("outputTokens", 0)
                total_tokens = usage.get("totalTokens", input_tokens + output_tokens)

                span.set_attribute("mvk.prompt_tokens", int(input_tokens))
                span.set_attribute("mvk.completion_tokens", int(output_tokens))
                span.set_attribute("mvk.total_tokens", int(total_tokens))

                # Create metered usage
                if total_tokens > 0:
                    builder = MeteredUsageBuilder()
                    builder.add_token_metrics(
                        prompt=input_tokens, completion=output_tokens, total=total_tokens
                    )
                    safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process Converse result: {e}")

    def _create_converse_wrapper(self):
        """Create wrapper for Bedrock Converse operation (newer chat API).

        This wrapper handles the newer Converse API, which provides a more
        structured way to interact with Bedrock models. It's designed to
        be more consistent across different model providers.

        What makes Converse different:
        - **Structured Messages**: Uses a consistent message format
        - **Better Token Counting**: More reliable token usage reporting
        - **Unified Interface**: Same API across different model families
        - **Enhanced Metadata**: Better support for conversation context

        What it tracks:
        - **Model Information**: Which model and family you're using
        - **Message Content**: The conversation messages you sent
        - **Response Content**: The AI's structured response
        - **Token Usage**: Precise input/output token counts
        - **Parameters**: Inference configuration settings

        The Converse API is particularly good for:
        - Multi-turn conversations
        - Applications that need consistent token counting
        - Projects using multiple model providers

        Example:
            ```python
            # Converse API call
            response = client.converse(
                modelId='anthropic.claude-3-sonnet-20240229-v1:0',
                messages=[
                    {'role': 'user', 'content': [{'text': 'Hello!'}]}
                ],
                inferenceConfig={
                    'maxTokens': 100,
                    'temperature': 0.7
                }
            )

            # Creates span with:
            # - model_name: 'anthropic.claude-3-sonnet-20240229-v1:0'
            # - model_family: 'claude'
            # - prompt: 'Hello!'
            # - mvk.prompt_tokens: <precise count>
            # - mvk.completion_tokens: <precise count>
            # - mvk.total_tokens: <precise count>
            ```

        Returns:
            A wrapper function optimized for the Converse API.
        """
        # Create and return the wrapper
        return WrapperBase.create_wrapper(
            span_name="bedrock.converse",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_converse_attributes,
            process_result=self._process_converse_result,
        )

    def _extract_converse_stream_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from ConverseStream call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] ConverseStream call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize with basic attributes
        model_name = "unknown-model"
        request_data = {}

        # Extract model name from request body (same logic as Converse)
        try:
            request_body = kwargs.get("body", {})
            if isinstance(request_body, (str, bytes)):
                try:
                    if isinstance(request_body, bytes):
                        request_body = request_body.decode("utf-8")
                    request_data = json.loads(request_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    request_data = {}
            else:
                request_data = request_body

            # Extract model name
            model_name = request_data.get("modelId", kwargs.get("modelId", "unknown-model"))

        except Exception as e:
            logger.debug(f"Failed to extract model name from ConverseStream request: {e}")

        # Detect model type, input/output types dynamically based on model name and request content
        model_type = detect_model_type(model_name, request_data)
        input_type, output_type = detect_input_output_types(model_name, request_data)
        model_family = get_model_family(model_name)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs = {
            "model_name": model_name,
            "model_provider": "aws-bedrock",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "stream",
            "mvk.step_type": MVKStepType.LLM,
            "stream_enabled": True,
        }

        # Extract messages for prompt content
        try:
            messages = request_data.get("messages", [])
            if messages:
                prompt_content = " ".join(
                    [
                        (
                            msg.get("content", [{}])[0].get("text", "")
                            if isinstance(msg.get("content"), list)
                            else str(msg.get("content", ""))
                        )
                        for msg in messages
                        if isinstance(msg, dict)
                    ]
                )
                if prompt_content:
                    attrs["prompt"] = prompt_content[:1000]

        except Exception as e:
            logger.debug(f"Failed to extract prompt content from ConverseStream request: {e}")

        return attrs

    def _process_converse_stream_chunk(self, span, chunk) -> None:
        """Process each streaming chunk from ConverseStream."""
        try:
            # Extract chunk data
            chunk_data = chunk.get("chunk", {})
            if isinstance(chunk_data, bytes):
                try:
                    chunk_json = json.loads(chunk_data.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    chunk_json = {}
            else:
                chunk_json = chunk_data

            # Track chunk count
            current_count = span.get_attribute("mvk.stream.chunk_count") or 0
            span.set_attribute("mvk.stream.chunk_count", current_count + 1)

            # Extract content from chunk (only if log_prompts_responses is enabled)
            if should_log_prompts_responses():
                if "contentBlockDelta" in chunk_json:
                    delta = chunk_json["contentBlockDelta"]
                    if "delta" in delta and "text" in delta["delta"]:
                        text_content = delta["delta"]["text"]
                        if text_content:
                            # Accumulate response text
                            current_response = span.get_attribute("mvk.response") or ""
                            span.set_attribute(
                                "mvk.response", (current_response + text_content)[:1000]
                            )

            # Check for usage information in final chunk
            if "usage" in chunk_json:
                usage_data = chunk_json["usage"]
                if isinstance(usage_data, dict):
                    input_tokens = usage_data.get("inputTokens", 0)
                    output_tokens = usage_data.get("outputTokens", 0)
                    total_tokens = usage_data.get("totalTokens", input_tokens + output_tokens)

                    span.set_attribute("mvk.prompt_tokens", int(input_tokens))
                    span.set_attribute("mvk.completion_tokens", int(output_tokens))
                    span.set_attribute("mvk.total_tokens", int(total_tokens))

                    # Create metered usage
                    if total_tokens > 0:
                        builder = MeteredUsageBuilder()
                        builder.add_token_metrics(
                            prompt=input_tokens, completion=output_tokens, total=total_tokens
                        )
                        safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process ConverseStream chunk: {e}")

    def _create_converse_stream_wrapper(self):
        """Create wrapper for ConverseStream operation.

        This wrapper handles streaming responses from the Converse API.
        """
        # Create streaming wrapper
        return WrapperBase.create_streaming_wrapper(
            span_name="bedrock.converse_stream",
            extract_attributes=self._extract_converse_stream_attributes,
            process_chunk=self._process_converse_stream_chunk,
            provider="aws-bedrock",
        )

    def _extract_bidirectional_stream_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from bidirectional streaming call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] InvokeModelWithBidirectionalStream call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize with basic attributes
        model_name = "unknown-model"
        request_data = {}

        # Extract model name from request body
        try:
            request_body = kwargs.get("body", {})
            if isinstance(request_body, (str, bytes)):
                try:
                    if isinstance(request_body, bytes):
                        request_body = request_body.decode("utf-8")
                    request_data = json.loads(request_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    request_data = {}
            else:
                request_data = request_body

            # Extract model name
            model_name = request_data.get("modelId", kwargs.get("modelId", "unknown-model"))

        except Exception as e:
            logger.debug(f"Failed to extract model name from bidirectional stream request: {e}")

        # Detect model type, input/output types dynamically based on model name and request content
        model_type = detect_model_type(model_name, request_data)
        input_type, output_type = detect_input_output_types(model_name, request_data)
        model_family = get_model_family(model_name)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs = {
            "model_name": model_name,
            "model_provider": "aws-bedrock",
            "model_type": model_type,
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "completion",
            "operation_subtype": "bidirectional_stream",
            "mvk.step_type": MVKStepType.LLM,
            "stream_enabled": True,
        }

        # Extract prompt content
        try:
            prompt_content = None
            if "messages" in request_data:
                messages = request_data["messages"]
                if isinstance(messages, list) and messages:
                    prompt_content = " ".join(
                        [
                            msg.get("content", "")
                            for msg in messages
                            if isinstance(msg, dict) and msg.get("content")
                        ]
                    )
            elif "prompt" in request_data:
                prompt_content = request_data["prompt"]

            if prompt_content:
                attrs["prompt"] = prompt_content[:1000]

        except Exception as e:
            logger.debug(f"Failed to extract prompt content from bidirectional stream request: {e}")

        return attrs

    def _process_bidirectional_stream_chunk(self, span, chunk) -> None:
        """Process each bidirectional streaming chunk."""
        try:
            # Extract chunk data
            chunk_data = chunk.get("chunk", {})
            if isinstance(chunk_data, bytes):
                try:
                    chunk_json = json.loads(chunk_data.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    chunk_json = {}
            else:
                chunk_json = chunk_data

            # Track chunk count
            current_count = span.get_attribute("mvk.stream.chunk_count") or 0
            span.set_attribute("mvk.stream.chunk_count", current_count + 1)

            # Extract content from chunk (only if log_prompts_responses is enabled)
            if should_log_prompts_responses():
                if "bytes" in chunk_json:
                    content_data = chunk_json["bytes"]
                    if isinstance(content_data, bytes):
                        try:
                            content_json = json.loads(content_data.decode("utf-8"))
                            if "delta" in content_json and "text" in content_json["delta"]:
                                text_content = content_json["delta"]["text"]
                                if text_content:
                                    # Accumulate response text
                                    current_response = span.get_attribute("mvk.response") or ""
                                    span.set_attribute(
                                        "mvk.response", (current_response + text_content)[:1000]
                                    )
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            pass

            # Check for usage information
            if "usage" in chunk_json:
                usage_data = chunk_json["usage"]
                if isinstance(usage_data, dict):
                    input_tokens = (
                        usage_data.get("inputTokens") or usage_data.get("promptTokens") or 0
                    )
                    output_tokens = (
                        usage_data.get("outputTokens") or usage_data.get("completionTokens") or 0
                    )
                    total_tokens = usage_data.get("totalTokens") or (input_tokens + output_tokens)

                    span.set_attribute("mvk.prompt_tokens", int(input_tokens))
                    span.set_attribute("mvk.completion_tokens", int(output_tokens))
                    span.set_attribute("mvk.total_tokens", int(total_tokens))

                    # Create metered usage
                    if total_tokens > 0:
                        builder = MeteredUsageBuilder()
                        builder.add_token_metrics(
                            prompt=input_tokens, completion=output_tokens, total=total_tokens
                        )
                        safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process bidirectional stream chunk: {e}")

    def _create_bidirectional_stream_wrapper(self):
        """Create wrapper for Bedrock InvokeModelWithBidirectionalStream operation."""
        # Create streaming wrapper
        return WrapperBase.create_streaming_wrapper(
            span_name="bedrock.invoke_model_with_bidirectional_stream",
            extract_attributes=self._extract_bidirectional_stream_attributes,
            process_chunk=self._process_bidirectional_stream_chunk,
            provider="aws-bedrock",
        )

    def _extract_count_tokens_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from CountTokens call."""
        # Framework detection to avoid double spans
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"[Bedrock] CountTokens call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Initialize with basic attributes
        model_name = "unknown-model"
        request_data = {}

        # Extract model name from request body
        try:
            request_body = kwargs.get("body", {})
            if isinstance(request_body, (str, bytes)):
                try:
                    if isinstance(request_body, bytes):
                        request_body = request_body.decode("utf-8")
                    request_data = json.loads(request_body)
                except (json.JSONDecodeError, UnicodeDecodeError):
                    request_data = {}
            else:
                request_data = request_body

            # Extract model name
            model_name = request_data.get("modelId", kwargs.get("modelId", "unknown-model"))

        except Exception as e:
            logger.debug(f"Failed to extract model name from CountTokens request: {e}")

        # Detect input/output types dynamically (but keep model_type as "utility" for this operation)
        input_type, output_type = detect_input_output_types(model_name, request_data)
        model_family = get_model_family(model_name)
        # Override "unknown" with "bedrock" as fallback for Bedrock context
        if model_family == "unknown":
            model_family = "bedrock"

        attrs = {
            "model_name": model_name,
            "model_provider": "aws-bedrock",
            "model_type": "utility",  # CountTokens is always utility operation
            "model_family": model_family,
            "input_type": input_type,
            "output_type": output_type,
            "operation": "count_tokens",
            "operation_subtype": "batch",
            "mvk.step_type": MVKStepType.LLM,
        }

        # Extract text to count tokens for
        try:
            text_to_count = None
            if "text" in request_data:
                text_to_count = request_data["text"]
            elif "messages" in request_data:
                messages = request_data["messages"]
                if isinstance(messages, list):
                    text_to_count = " ".join(
                        [
                            msg.get("content", "")
                            for msg in messages
                            if isinstance(msg, dict) and msg.get("content")
                        ]
                    )

            if text_to_count:
                attrs["prompt"] = text_to_count[:1000]

        except Exception as e:
            logger.debug(f"Failed to extract text content from CountTokens request: {e}")

        return attrs

    def _process_count_tokens_result(self, span, result) -> None:
        """Process CountTokens result."""
        try:
            # Extract response body
            response_body = result.get("body", {})
            if isinstance(response_body, bytes):
                try:
                    response_data = json.loads(response_body.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    response_data = {}
            else:
                response_data = response_body

            # Extract token count
            total_tokens = response_data.get("totalTokens", 0)
            if total_tokens > 0:
                span.set_attribute("mvk.total_tokens", int(total_tokens))
                span.set_attribute(
                    "mvk.prompt_tokens", int(total_tokens)
                )  # CountTokens typically counts input tokens

                # Create metered usage
                builder = MeteredUsageBuilder()
                builder.add_token_metrics(prompt=total_tokens, completion=0, total=total_tokens)
                safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Failed to process CountTokens result: {e}")

    def _create_count_tokens_wrapper(self):
        """Create wrapper for Bedrock CountTokens operation.

        This wrapper handles the CountTokens utility operation, which is used
        to count the number of tokens in a text without actually generating
        a response. This is useful for:

        - **Cost Estimation**: Calculate token costs before making API calls
        - **Text Analysis**: Understand the token count of your prompts
        - **Budget Planning**: Estimate usage for large text processing
        - **Validation**: Ensure prompts fit within model limits

        What it tracks:
        - **Model Information**: Which model you're using for tokenization
        - **Input Text**: The text you're counting tokens for
        - **Token Count**: The total number of tokens
        - **Timing**: How long the counting operation took

        The CountTokens operation is particularly useful for:
        - Applications with token budgets
        - Text preprocessing pipelines
        - Cost optimization workflows
        - Model selection based on token limits

        Example:
            ```python
            # Count tokens before making a call
            count_response = client.count_tokens(
                modelId='anthropic.claude-3-sonnet-20240229-v1:0',
                body=json.dumps({
                    'text': 'This is a long prompt that I want to count tokens for...'
                })
            )

            # Creates span with:
            # - model_name: 'anthropic.claude-3-sonnet-20240229-v1:0'
            # - model_family: 'claude'
            # - prompt: 'This is a long prompt...'
            # - mvk.total_tokens: <token count>
            # - mvk.prompt_tokens: <same count>
            ```

        Returns:
            A wrapper function for token counting operations.
        """
        # Create and return the wrapper
        return WrapperBase.create_wrapper(
            span_name="bedrock.count_tokens",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_count_tokens_attributes,
            process_result=self._process_count_tokens_result,
        )
