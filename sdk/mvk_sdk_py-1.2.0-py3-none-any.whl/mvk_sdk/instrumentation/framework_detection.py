"""Framework detection utility for identifying LLM framework wrappers.

This module provides universal framework detection using call stack inspection.
It works across all frameworks (LangChain, CrewAI, Agno, LiteLLM, etc.) and
all LLM providers (OpenAI, Anthropic, Bedrock, Gemini, etc.).
"""

import inspect
from typing import List, Optional

from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "framework_detection")


class FrameworkDetector:
    """Universal framework detection using call stack inspection.

    This detector identifies when LLM provider SDK calls are being made
    through intermediate framework wrappers (like LangChain, CrewAI, etc.)
    by inspecting the call stack for known framework module names.

    **IMPORTANT**: Framework detection is DISABLED by default because MVK SDK
    does not have framework instrumentation (LangChain, CrewAI, etc.). If we
    skip provider instrumentation, you get NO spans at all.

    Only enable framework detection if:
    1. You have framework-level instrumentation that creates spans
    2. You want to avoid double spans from both framework and provider

    Enable via: FrameworkDetector.enable()
    Disable via: FrameworkDetector.disable()

    Supports:
    - LangChain (langchain, langchain_openai, langchain_anthropic, etc.)
    - LangGraph (langgraph)
    - CrewAI (crewai)
    - Agno (agno)
    - LiteLLM (litellm)
    - Custom frameworks (configurable via set_framework_modules)
    """

    # Default framework modules that wrap LLM providers
    DEFAULT_FRAMEWORK_MODULES = {
        # LangChain ecosystem
        "langchain",
        "langchain_openai",
        "langchain_anthropic",
        "langchain_community",
        "langchain_core",
        "langchain_text_splitters",
        "langchain_aws",
        "langchain_google_genai",
        "langchain_google_vertexai",
        # LangGraph
        "langgraph",
        # CrewAI
        "crewai",
        # Agno
        "agno",
        # LiteLLM
        "litellm",
    }

    # Class-level configuration for framework modules
    _framework_modules: set = DEFAULT_FRAMEWORK_MODULES.copy()

    # Framework detection is DISABLED by default
    _enabled: bool = False

    @classmethod
    def set_framework_modules(cls, modules: List[str]) -> None:
        """Configure custom framework modules to detect.

        Args:
            modules: List of framework module names to detect
        """
        cls._framework_modules = set(modules)
        logger.debug(f"Framework detection modules configured: {cls._framework_modules}")

    @classmethod
    def add_framework_module(cls, module: str) -> None:
        """Add a framework module to the detection list.

        Args:
            module: Framework module name to add
        """
        cls._framework_modules.add(module)
        logger.debug(f"Added framework module to detection: {module}")

    @classmethod
    def reset_framework_modules(cls) -> None:
        """Reset framework modules to defaults."""
        cls._framework_modules = cls.DEFAULT_FRAMEWORK_MODULES.copy()
        logger.debug("Framework detection modules reset to defaults")

    @classmethod
    def enable(cls) -> None:
        """Enable framework detection.

        Only enable this if you have framework-level instrumentation that
        creates spans for LangChain, CrewAI, etc. Otherwise, you'll get
        NO spans at all.

        Example:
            from mvk_sdk.instrumentation.framework_detection import FrameworkDetector
            FrameworkDetector.enable()
        """
        cls._enabled = True
        logger.info(
            "Framework detection ENABLED - will skip provider instrumentation when frameworks detected"
        )

    @classmethod
    def disable(cls) -> None:
        """Disable framework detection (default).

        This ensures provider instrumentation always runs, even when called
        through frameworks like LangChain.

        Example:
            from mvk_sdk.instrumentation.framework_detection import FrameworkDetector
            FrameworkDetector.disable()
        """
        cls._enabled = False
        logger.info("Framework detection DISABLED - provider instrumentation will always run")

    @classmethod
    def is_enabled(cls) -> bool:
        """Check if framework detection is enabled."""
        return cls._enabled

    @classmethod
    def detect_calling_framework(cls, stack_depth: int = 15, skip_frames: int = 1) -> Optional[str]:
        """Detect if call is coming from a known framework wrapper.

        Inspects the call stack to identify framework module names.
        Returns the first (closest) framework module found.

        **NOTE**: This method returns None if framework detection is disabled (default).

        Args:
            stack_depth: Number of frames to inspect (default 15)
            skip_frames: Number of frames to skip from the top (default 1 to skip this method)

        Returns:
            Framework module name if detected and enabled, None otherwise
        """
        # If framework detection is disabled, always return None
        if not cls._enabled:
            return None

        try:
            stack = inspect.stack()
            # Skip this method's frame + skip_frames parameter
            start_idx = skip_frames + 1
            end_idx = min(start_idx + stack_depth, len(stack))

            for frame_info in stack[start_idx:end_idx]:
                frame_module = frame_info.frame.f_globals.get("__name__", "")
                if not frame_module:
                    continue

                # Check if any framework module matches (prefix matching)
                for framework in cls._framework_modules:
                    if frame_module.startswith(framework):
                        logger.debug(
                            f"Detected calling framework '{framework}' from module '{frame_module}'"
                        )
                        return str(framework)

        except Exception as e:
            logger.debug(f"Framework detection failed (proceeding normally): {e}")

        return None

    @classmethod
    def get_all_calling_frameworks(cls, stack_depth: int = 15, skip_frames: int = 1) -> List[str]:
        """Get all framework modules in the call stack.

        Inspects the call stack and returns all detected framework modules
        in order from closest to furthest.

        Args:
            stack_depth: Number of frames to inspect (default 15)
            skip_frames: Number of frames to skip from the top (default 1 to skip this method)

        Returns:
            List of framework module names found in call stack
        """
        frameworks: List[str] = []

        try:
            stack = inspect.stack()
            start_idx = skip_frames + 1
            end_idx = min(start_idx + stack_depth, len(stack))

            seen = set()

            for frame_info in stack[start_idx:end_idx]:
                frame_module = frame_info.frame.f_globals.get("__name__", "")
                if not frame_module:
                    continue

                # Check if any framework module matches (prefix matching)
                for framework in cls._framework_modules:
                    if frame_module.startswith(framework) and framework not in seen:
                        frameworks.append(framework)
                        seen.add(framework)
                        break

        except Exception as e:
            logger.debug(f"Framework stack inspection failed: {e}")

        return frameworks

    @classmethod
    def should_skip_instrumentation(cls, stack_depth: int = 15, skip_frames: int = 1) -> bool:
        """Check if instrumentation should be skipped due to framework wrapper.

        Returns True if a framework wrapper is detected in the call stack,
        indicating that the framework will handle instrumentation.

        Args:
            stack_depth: Number of frames to inspect (default 15)
            skip_frames: Number of frames to skip from the top (default 1 to skip this method)

        Returns:
            True if framework wrapper detected, False otherwise
        """
        framework = cls.detect_calling_framework(
            stack_depth=stack_depth, skip_frames=skip_frames + 1
        )
        return framework is not None

    @classmethod
    def get_framework_context(cls, stack_depth: int = 15, skip_frames: int = 1) -> dict:
        """Get detailed framework context from call stack.

        Returns a dictionary containing:
        - primary_framework: The closest framework in the stack
        - all_frameworks: All detected frameworks in order
        - is_framework_wrapped: Boolean indicating if wrapped
        - should_skip: Whether to skip instrumentation

        Args:
            stack_depth: Number of frames to inspect (default 15)
            skip_frames: Number of frames to skip from the top (default 1 to skip this method)

        Returns:
            Dictionary with framework context information
        """
        all_frameworks = cls.get_all_calling_frameworks(
            stack_depth=stack_depth, skip_frames=skip_frames + 1
        )
        primary = all_frameworks[0] if all_frameworks else None

        return {
            "primary_framework": primary,
            "all_frameworks": all_frameworks,
            "is_framework_wrapped": bool(all_frameworks),
            "should_skip": bool(all_frameworks),
        }
