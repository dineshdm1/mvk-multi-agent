"""Anthropic instrumentor following OTEL patterns.

This module provides instrumentation for Anthropic SDK using the BaseInstrumentor
pattern with wrapt for consistent wrapping.
"""

from typing import Any, Collection, Dict, Optional

import wrapt

from ..context import get_global_context
from ..instrument import should_log_prompts_responses
from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.framework_detection import FrameworkDetector
from ..instrumentation.wrapper_base import WrapperBase
from ..logging_utils import (
    log_error,
    log_metrics,
    log_request_body,
    log_request_end,
    log_request_start,
    log_response_body,
)
from ..metered_usage import (
    MeteredUsageBuilder,
    safe_extract_field,
    safe_populate_metered_usage,
)
from ..metrics import Metric, add_metered_usage
from ..mvk_tracer import OTLPSpanKind, get_tracer
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger
from .common import get_common_attributes

logger = get_component_logger("instrumentation", "anthropic")


class AnthropicInstrumentor(BaseInstrumentor):
    """Instrumentor for Anthropic SDK following OTEL patterns."""

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """Anthropic SDK is required."""
        return ["anthropic"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "anthropic"

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Anthropic SDK with version-aware wrapping.

        This implementation supports multiple Anthropic SDK versions (0.18.0+) by:
        - Detecting the installed SDK version at runtime
        - Applying version-appropriate wrapping strategies for modern (0.25.0+) and legacy (0.18.0-0.24.x) versions
        - Using a single wrapping attempt per method to prevent duplicate instrumentation
        - Providing best-effort async support across all versions

        The version detection ensures compatibility as the SDK evolves while maintaining
        clean, non-duplicated instrumentation regardless of internal module structure changes.
        """
        try:
            import anthropic
        except ImportError:
            logger.warning("Anthropic SDK not available")
            return

        # Detect SDK version
        version = self._get_anthropic_version(anthropic)
        logger.info(f"Detected Anthropic SDK version: {'.'.join(map(str, version))}")

        # Create wrappers
        messages_wrapper = self._create_messages_wrapper()
        stream_wrapper = self._create_stream_wrapper()

        # Version-specific wrapping
        if version >= (0, 25, 0):  # Modern versions (0.25.0+)
            success = self._wrap_modern_anthropic(messages_wrapper, stream_wrapper)
        elif version >= (0, 18, 0):  # Older versions (0.18.0-0.24.x)
            success = self._wrap_legacy_anthropic(messages_wrapper, stream_wrapper)
        else:
            logger.warning(
                f"Unsupported Anthropic SDK version: {'.'.join(map(str, version))}. "
                f"Minimum supported version is 0.18.0"
            )
            return

        if success:
            logger.info(f"Successfully instrumented Anthropic SDK v{'.'.join(map(str, version))}")
        else:
            logger.warning("Failed to instrument Anthropic SDK")
            return

        # Async support (version-independent, best-effort)
        self._wrap_async_methods()

    def _get_anthropic_version(self, anthropic_module) -> tuple:
        """Extract and parse the Anthropic SDK version from the module.

        Parses the __version__ attribute and handles pre-release versions by stripping
        suffixes like 'rc1', 'a1', 'b1'. If version parsing fails, returns a high
        version number to assume modern SDK structure.

        Args:
            anthropic_module: The imported anthropic module

        Returns:
            Tuple of (major, minor, patch) version numbers, e.g., (0, 25, 0)
        """
        try:
            version_str = getattr(anthropic_module, "__version__", "0.0.0")
            # Strip pre-release suffixes (e.g., "1.0.0rc1" -> "1.0.0")
            version_str = version_str.split("rc")[0].split("a")[0].split("b")[0]
            parts = version_str.split(".")
            return tuple(int(x) for x in parts[:3])
        except Exception as e:
            logger.warning(f"Could not parse Anthropic version, assuming latest: {e}")
            # Return high version number to use modern wrapping strategy
            return (999, 0, 0)

    def _wrap_modern_anthropic(self, messages_wrapper, stream_wrapper) -> bool:
        """Apply instrumentation to Anthropic SDK 0.25.0+ with standardized module structure.

        Modern Anthropic SDK versions (0.25.0 and later) use a consistent module layout
        with well-defined paths to the Messages and AsyncMessages classes. This method
        wraps the synchronous methods using a single wrapping attempt per method to avoid
        duplicate instrumentation.

        Module structure for modern versions:
        - anthropic.resources.messages.Messages.create
        - anthropic.resources.messages.Messages.stream

        Args:
            messages_wrapper: Wrapper function for messages.create method
            stream_wrapper: Wrapper function for messages.stream method

        Returns:
            True if wrapping succeeded, False otherwise
        """
        try:
            # Single wrapping attempt - prevents duplicate instrumentation
            self._wrap_method("anthropic.resources.messages", "Messages.create", messages_wrapper)
            self._wrap_method("anthropic.resources.messages", "Messages.stream", stream_wrapper)
            logger.debug("Successfully wrapped modern Anthropic SDK")
            return True
        except Exception as e:
            logger.warning(f"Failed to wrap modern Anthropic SDK: {e}")
            return False

    def _wrap_legacy_anthropic(self, messages_wrapper, stream_wrapper) -> bool:
        """Apply instrumentation to Anthropic SDK 0.18.0-0.24.x with legacy module structure.

        Legacy Anthropic SDK versions (0.18.0 through 0.24.x) generally follow a similar
        module structure to modern versions, but may have minor variations. This method
        attempts the standard wrapping path which is compatible with most legacy versions.

        Uses a single wrapping attempt per method to ensure no duplicate instrumentation
        occurs, even if the internal module aliasing has changed between versions.

        Args:
            messages_wrapper: Wrapper function for messages.create method
            stream_wrapper: Wrapper function for messages.stream method

        Returns:
            True if wrapping succeeded, False otherwise
        """
        try:
            # Use standard path (compatible with most legacy versions)
            self._wrap_method("anthropic.resources.messages", "Messages.create", messages_wrapper)
            self._wrap_method("anthropic.resources.messages", "Messages.stream", stream_wrapper)
            logger.debug("Successfully wrapped legacy Anthropic SDK")
            return True
        except Exception as e:
            logger.warning(f"Failed to wrap legacy Anthropic SDK: {e}")
            return False

    def _wrap_async_methods(self) -> None:
        """Apply instrumentation to async methods with best-effort approach.

        Attempts to wrap AsyncMessages.create and AsyncMessages.stream methods which
        are available in most Anthropic SDK versions. This is done independently of
        version detection as async support is generally consistent across versions.

        Uses debug-level logging (not warnings) for failures since async methods may
        not be available in all environments or versions, and their absence is not
        a critical issue for the instrumentation to function.
        """
        try:
            self._wrap_method(
                "anthropic.resources.messages",
                "AsyncMessages.create",
                self._create_async_messages_wrapper(),
            )
            self._wrap_method(
                "anthropic.resources.messages",
                "AsyncMessages.stream",
                self._create_async_stream_wrapper(),
            )
            logger.debug("Successfully wrapped AsyncMessages methods")
        except Exception as e:
            # Debug level only - async support is optional
            logger.debug(f"AsyncMessages not available or already wrapped: {e}")

    def _uninstrument(self, **kwargs) -> None:
        """Remove all instrumentation from Anthropic SDK.

        Iterates through all wrapped methods tracked in self._wrapped_methods
        and unwraps them, restoring the original SDK behavior.
        """
        # Unwrap all methods tracked during instrumentation
        for key in list(self._wrapped_methods.keys()):
            module, name = key.rsplit(".", 1)
            self._unwrap_method(module, name)

    def _create_messages_wrapper(self):
        """Create wrapper function for the synchronous messages.create method.

        Returns a wrapper that:
        - Creates a span named "anthropic.messages.create"
        - Extracts attributes (model, messages, parameters) from the call
        - Processes the result to capture token usage and response data
        """
        return WrapperBase.create_wrapper(
            span_name="anthropic.messages.create",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_messages_attributes,
            process_result=self._process_messages_result,
        )

    def _extract_messages_attributes(
        self, instance: Any, args: tuple[Any, ...], kwargs: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract telemetry attributes from a messages.create call.

        Captures model information, request parameters, and optionally the prompt/messages
        if configured. Also detects if the call originates from a framework wrapper
        (LangChain, LlamaIndex) to prevent duplicate instrumentation.

        Returns None if the call is from a framework wrapper, preventing double spans.
        """
        # Check if this call is coming from a framework wrapper
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"Anthropic call detected from {framework} - skipping to avoid double spans"
            )
            return None

        attrs = {}

        # Get common attributes
        try:
            import anthropic as anthropic_module

            common_attrs = get_common_attributes("anthropic", "anthropic-python", anthropic_module)
            attrs.update(common_attrs)
        except Exception as e:
            logger.error(f"Failed to get common attributes: {e}")

        # Extract model and request info
        model_name = kwargs.get("model", args[0] if args else "unknown")
        is_stream = bool(kwargs.get("stream", False))

        # Get max tokens for cost calculation
        max_tokens = kwargs.get("max_tokens", 1024)

        attrs.update(
            {
                "model_name": model_name,
                "model_provider": "anthropic",
                "model_type": "chat",  # Anthropic is primarily chat
                "model_family": "claude",
                "input_type": "text",
                "output_type": "text",
                "operation": "completion",
                "operation_subtype": "stream" if is_stream else "sync",
                "max_tokens": max_tokens,
                "mvk.step_type": MVKStepType.LLM,
            }
        )

        if is_stream:
            attrs["stream_enabled"] = True

        # Capture messages if enabled
        if should_log_prompts_responses():
            messages = kwargs.get("messages", [])
            if messages:
                attrs["prompt"] = str(messages)[:1000]

        # Extract temperature if present
        if "temperature" in kwargs:
            attrs["temperature"] = kwargs["temperature"]

        # Extract system prompt if present and logging is enabled
        if should_log_prompts_responses() and "system" in kwargs:
            attrs["system_prompt"] = str(kwargs["system"])[:500]

        logger.debug(f"Extracted attributes: {len(attrs)} items")
        return attrs

    def _process_messages_result(self, span: Any, result: Any) -> None:
        """Process the result from messages.create to extract token usage and response data.

        For non-streaming responses (Message objects), extracts:
        - Token usage (input_tokens, output_tokens, total_tokens)
        - Response content (if prompt/response logging is enabled)
        - Metered usage metrics for billing/cost tracking

        For streaming responses, skips token extraction as tokens are counted
        incrementally through the stream wrapper.
        """
        logger.debug(f"Processing Anthropic result: {type(result)}")

        # Check if this is a Message object (non-streaming) vs a generator (streaming)
        is_message_object = (
            hasattr(result, "usage") and hasattr(result, "content") and hasattr(result, "id")
        )

        if is_message_object:
            # Extract token usage
            if hasattr(result, "usage"):
                usage = result.usage
                logger.debug(f"Extracting usage from: {type(usage)}")

                # Anthropic provides input_tokens and output_tokens
                input_tokens = getattr(usage, "input_tokens", 0)
                output_tokens = getattr(usage, "output_tokens", 0)
                total_tokens = input_tokens + output_tokens

                logger.debug(
                    f"Token counts - input: {input_tokens}, output: {output_tokens}, total: {total_tokens}"
                )

                span.set_attribute("mvk.prompt_tokens", input_tokens)
                span.set_attribute("mvk.completion_tokens", output_tokens)
                span.set_attribute("mvk.total_tokens", total_tokens)

                # Build metered usage
                builder = MeteredUsageBuilder()
                builder.add_token_metrics(
                    prompt=input_tokens, completion=output_tokens, total=total_tokens
                )
                safe_populate_metered_usage(span, builder)
                logger.debug(
                    f"Successfully set token metrics: input={input_tokens}, output={output_tokens}, total={total_tokens}"
                )
            else:
                logger.warning("Result object does not have 'usage' attribute")
        else:
            logger.debug("Result appears to be a streaming response, skipping token extraction")

            # Capture response if enabled
            if should_log_prompts_responses():
                if hasattr(result, "content") and result.content:
                    # Anthropic returns content as a list of blocks
                    if isinstance(result.content, list) and len(result.content) > 0:
                        first_block = result.content[0]
                        if hasattr(first_block, "text"):
                            span.set_attribute("mvk.response", str(first_block.text)[:1000])

    def _create_stream_wrapper(self):
        """Create wrapper function for the streaming messages.stream method.

        Returns a streaming wrapper that:
        - Creates a span for the streaming operation
        - Extracts attributes similar to non-streaming calls
        - Tracks token usage incrementally as the stream progresses
        """
        return WrapperBase.create_streaming_wrapper(
            span_name="anthropic.messages.stream",
            extract_attributes=self._extract_stream_attributes,
            provider="anthropic",
        )

    def _extract_stream_attributes(
        self, instance: Any, args: tuple[Any, ...], kwargs: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract telemetry attributes from a messages.stream call.

        Reuses the non-streaming attribute extraction logic and adds stream-specific
        flags. Also checks for framework wrapper calls to prevent duplicate spans.

        Returns None if the call is from a framework wrapper.
        """
        # Check if this call is coming from a framework wrapper
        framework = FrameworkDetector.detect_calling_framework(stack_depth=15, skip_frames=2)
        if framework:
            logger.debug(
                f"Anthropic streaming call detected from {framework} - skipping to avoid double spans"
            )
            return None

        # Reuse non-streaming extraction logic
        attrs = self._extract_messages_attributes(instance, args, kwargs)
        if attrs:
            attrs["stream_enabled"] = True
            attrs["operation_subtype"] = "stream"
        return attrs

    def _create_async_messages_wrapper(self):
        """Create wrapper function for async messages.create method.

        Returns an async-compatible wrapper that handles asynchronous Anthropic API calls
        while maintaining the same attribute extraction and result processing logic.
        """
        return WrapperBase.create_async_wrapper(
            span_name="anthropic.messages.create.async",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_messages_attributes,
            process_result=self._process_messages_result,
        )

    def _create_async_stream_wrapper(self):
        """Create wrapper function for async streaming messages.stream method.

        Returns an async-compatible streaming wrapper that handles asynchronous
        streaming Anthropic API calls. Note that result processing is omitted
        as streaming responses don't have a single final result object.
        """
        return WrapperBase.create_async_wrapper(
            span_name="anthropic.messages.stream.async",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_stream_attributes,
            process_result=None,  # Streaming tracks results incrementally, not in final result
        )
