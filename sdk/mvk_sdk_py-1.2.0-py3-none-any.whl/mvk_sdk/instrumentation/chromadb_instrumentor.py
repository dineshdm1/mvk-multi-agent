"""ChromaDB instrumentor following OTEL patterns.

This module provides instrumentation for ChromaDB v0.6.x, v1.1.x and v1.2.x using the
BaseInstrumentor pattern with wrapt for consistent wrapping. It supports all
CRUD operations and helper methods on Collection objects across all versions.
"""

from typing import Any, Collection

from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "chromadb")


class ChromaDBInstrumentor(BaseInstrumentor):
    """Instrumentor for ChromaDB v0.6.x, v1.1.x and v1.2.x following OTEL patterns."""

    def __init__(self) -> None:
        """Initialize the ChromaDB instrumentor."""
        super().__init__()

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """ChromaDB is required."""
        return ["chromadb"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "chromadb"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from ChromaDB.

        The base class handles unwrapping automatically.
        """
        # The base class handles unwrapping automatically via _wrapped_methods
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to ChromaDB v0.6.x, v1.1.x and v1.2.x."""
        logger.info("ChromaDB instrumentor _instrument method called")
        try:
            import chromadb

            logger.info(f"ChromaDB imported successfully, version: {chromadb.__version__}")
            logger.info(f"ChromaDB module path: {chromadb.__file__}")

            # Create wrappers
            add_wrapper = self._create_add_wrapper()
            get_wrapper = self._create_get_wrapper()
            query_wrapper = self._create_query_wrapper()
            update_wrapper = self._create_update_wrapper()
            upsert_wrapper = self._create_upsert_wrapper()
            delete_wrapper = self._create_delete_wrapper()
            count_wrapper = self._create_count_wrapper()
            peek_wrapper = self._create_peek_wrapper()

            # Track successful instrumentations
            instrumented_count = 0

            # Try to instrument the Collection class using direct imports
            # ChromaDB v0.6.x uses chromadb.api.models.Collection.Collection
            try:
                from chromadb.api.models.Collection import Collection

                logger.info(f"Found Collection class at chromadb.api.models.Collection.Collection")

                # Debug: Log available methods
                available_methods = [
                    method for method in dir(Collection) if not method.startswith("_")
                ]
                logger.info(f"Collection methods: {available_methods}")

                # Instrument CRUD methods
                methods_wrapped = 0
                if hasattr(Collection, "add"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.add", add_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.add")
                if hasattr(Collection, "get"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.get", get_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.get")
                if hasattr(Collection, "query"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.query", query_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.query")
                if hasattr(Collection, "update"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.update", update_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.update")
                if hasattr(Collection, "upsert"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.upsert", upsert_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.upsert")
                if hasattr(Collection, "delete"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.delete", delete_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.delete")
                if hasattr(Collection, "count"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.count", count_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.count")
                if hasattr(Collection, "peek"):
                    result = self._wrap_method(
                        "chromadb.api.models.Collection", "Collection.peek", peek_wrapper
                    )
                    if result:
                        methods_wrapped += 1
                        logger.info(f"Instrumented Collection.peek")

                instrumented_count += methods_wrapped
                logger.info(
                    f"ChromaDB auto-instrumentation enabled via chromadb.api.models.Collection.Collection - wrapped {methods_wrapped} methods"
                )

            except ImportError as e:
                logger.debug(
                    f"Could not import Collection from chromadb.api.models.Collection: {e}"
                )

                # Fallback: try other possible import paths for different ChromaDB versions
                collection_paths = [
                    ("chromadb.api", "Collection"),
                    ("chromadb", "Collection"),
                ]

                for module_path, class_name in collection_paths:
                    try:
                        logger.info(f"Trying fallback import {module_path}.{class_name}")
                        module = __import__(module_path, fromlist=[class_name])
                        if hasattr(module, class_name):
                            collection_cls = getattr(module, class_name)
                            logger.info(f"Found Collection class at {module_path}.{class_name}")

                            # Instrument CRUD methods
                            methods_wrapped = 0
                            for method_name, wrapper in [
                                ("add", add_wrapper),
                                ("get", get_wrapper),
                                ("query", query_wrapper),
                                ("update", update_wrapper),
                                ("upsert", upsert_wrapper),
                                ("delete", delete_wrapper),
                                ("count", count_wrapper),
                                ("peek", peek_wrapper),
                            ]:
                                if hasattr(collection_cls, method_name):
                                    result = self._wrap_method(
                                        module_path, f"{class_name}.{method_name}", wrapper
                                    )
                                    if result:
                                        methods_wrapped += 1
                                        logger.info(f"Instrumented {class_name}.{method_name}")

                            instrumented_count += methods_wrapped
                            logger.info(
                                f"ChromaDB auto-instrumentation enabled via {module_path}.{class_name} - wrapped {methods_wrapped} methods"
                            )
                            break

                    except (ImportError, AttributeError) as e:
                        logger.debug(f"Could not import {module_path}.{class_name}: {e}")
                        continue

            if instrumented_count > 0:
                logger.info(f"ChromaDB auto-instrumentation enabled ({instrumented_count} methods)")
            else:
                logger.warning("No ChromaDB Collection methods were instrumented")

        except Exception as e:
            logger.warning(f"Failed to instrument ChromaDB: {e}", exc_info=True)

    def _extract_add_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB add operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_insert",
            "operation_subtype": "create",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract collection name
        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Count documents/embeddings being added
        vectors_count = 0
        if "documents" in kwargs:
            docs = kwargs["documents"]
            if hasattr(docs, "__len__"):
                vectors_count = len(docs)
        elif "embeddings" in kwargs:
            embs = kwargs["embeddings"]
            if hasattr(embs, "__len__"):
                vectors_count = len(embs)
        elif "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                vectors_count = len(ids)

        if vectors_count > 0:
            attrs["vectors_count"] = vectors_count

        return attrs

    def _process_add_result(self, span, result):
        """Process result from ChromaDB add operation."""
        vectors_count = span.attributes.get("mvk.vectors_count", 0)
        if vectors_count > 0:
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.processed", vectors_count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_add_wrapper(self):
        """Create wrapper for ChromaDB add operations (Create/Insert).

        This wrapper tracks when documents or embeddings are added to a ChromaDB collection.
        It counts the number of vectors being inserted and captures the collection name.
        Perfect for monitoring data ingestion and storage operations.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.add",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_add_attributes,
            process_result=self._process_add_result,
        )

    def _extract_upsert_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB upsert operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_upsert",
            "operation_subtype": "upsert",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Count documents/embeddings being upserted
        vectors_count = 0
        if "documents" in kwargs:
            docs = kwargs["documents"]
            if hasattr(docs, "__len__"):
                vectors_count = len(docs)
        elif "embeddings" in kwargs:
            embs = kwargs["embeddings"]
            if hasattr(embs, "__len__"):
                vectors_count = len(embs)
        elif "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                vectors_count = len(ids)

        if vectors_count > 0:
            attrs["vectors_count"] = vectors_count

        return attrs

    def _process_upsert_result(self, span, result):
        """Process result from ChromaDB upsert operation."""
        vectors_count = span.attributes.get("mvk.vectors_count", 0)
        if vectors_count > 0:
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.processed", vectors_count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_upsert_wrapper(self):
        """Create wrapper for ChromaDB upsert operations (Create or Update).

        This wrapper monitors upsert operations that either create new vectors or update existing ones.
        It tracks the number of vectors being processed and identifies the target collection.
        Ideal for monitoring data synchronization and update workflows.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.upsert",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_upsert_attributes,
            process_result=self._process_upsert_result,
        )

    def _extract_get_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB get operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_retrieve",
            "operation_subtype": "get",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Extract query parameters
        if "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                attrs["query_ids_count"] = len(ids)
        if "where" in kwargs:
            attrs["has_where_filter"] = True
        if "where_document" in kwargs:
            attrs["has_where_document_filter"] = True
        if "include" in kwargs:
            include = kwargs["include"]
            if isinstance(include, list):
                attrs["include_fields"] = ",".join(include)

        return attrs

    def _process_get_result(self, span, result):
        """Process result from ChromaDB get operation."""
        # ChromaDB get returns dict with 'ids', 'documents', 'metadatas', etc.
        if isinstance(result, dict) and "ids" in result:
            ids = result["ids"]
            if isinstance(ids, list):
                count = len(ids)
                span.set_attribute("mvk.results_count", count)
                # Add metered usage
                builder = MeteredUsageBuilder()
                builder.add_metric("vector.retrieved", count, "vector")
                safe_populate_metered_usage(span, builder)

    def _create_get_wrapper(self):
        """Create wrapper for ChromaDB get operations (Read by ID or filter).

        This wrapper tracks retrieval operations that fetch vectors by their IDs or using filters.
        It captures query parameters like filter conditions and tracks the number of results returned.
        Great for monitoring data access patterns and query performance.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.get",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_get_attributes,
            process_result=self._process_get_result,
        )

    def _extract_query_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB query operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_search",
            "operation_subtype": "query",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Extract query parameters
        if "n_results" in kwargs:
            attrs["query_limit"] = kwargs["n_results"]
        if "query_texts" in kwargs:
            texts = kwargs["query_texts"]
            if hasattr(texts, "__len__"):
                attrs["query_texts_count"] = len(texts)
        if "query_embeddings" in kwargs:
            embs = kwargs["query_embeddings"]
            if hasattr(embs, "__len__"):
                attrs["query_embeddings_count"] = len(embs)
        if "where" in kwargs:
            attrs["has_where_filter"] = True
        if "where_document" in kwargs:
            attrs["has_where_document_filter"] = True
        if "include" in kwargs:
            include = kwargs["include"]
            if isinstance(include, list):
                attrs["include_fields"] = ",".join(include)

        return attrs

    def _process_query_result(self, span, result):
        """Process result from ChromaDB query operation."""
        # ChromaDB query returns dict with 'ids', 'distances', 'documents', etc.
        if isinstance(result, dict) and "ids" in result:
            ids = result["ids"]
            if isinstance(ids, list) and len(ids) > 0:
                # Count results from first query
                count = len(ids[0]) if isinstance(ids[0], list) else len(ids)
                span.set_attribute("mvk.results_count", count)
                # Add metered usage
                builder = MeteredUsageBuilder()
                builder.add_metric("vector.retrieved", count, "vector")
                safe_populate_metered_usage(span, builder)

    def _create_query_wrapper(self):
        """Create wrapper for ChromaDB query operations (Vector search).

        This wrapper monitors vector similarity search operations that find the most relevant vectors.
        It tracks search parameters like query texts, result limits, and filters applied.
        Essential for monitoring search performance and understanding query patterns.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.query",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_query_attributes,
            process_result=self._process_query_result,
        )

    def _extract_update_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB update operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_update",
            "operation_subtype": "update",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Count items being updated
        if "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                attrs["vectors_count"] = len(ids)

        return attrs

    def _process_update_result(self, span, result):
        """Process result from ChromaDB update operation."""
        vectors_count = span.attributes.get("mvk.vectors_count", 0)
        if vectors_count > 0:
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.processed", vectors_count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_update_wrapper(self):
        """Create wrapper for ChromaDB update operations (Update by ID).

        This wrapper tracks update operations that modify existing vectors in the collection.
        It counts the number of vectors being updated and identifies the target collection.
        Useful for monitoring data modification activities and update frequencies.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.update",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_update_attributes,
            process_result=self._process_update_result,
        )

    def _extract_delete_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB delete operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_delete",
            "operation_subtype": "delete",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Extract delete parameters
        if "ids" in kwargs:
            ids = kwargs["ids"]
            if hasattr(ids, "__len__"):
                attrs["delete_ids_count"] = len(ids)
        if "where" in kwargs:
            attrs["has_where_filter"] = True
        if "where_document" in kwargs:
            attrs["has_where_document_filter"] = True

        return attrs

    def _process_delete_result(self, span, result):
        """Process result from ChromaDB delete operation."""
        # Delete operation doesn't return specific count, but we can track it as processed
        delete_ids_count = span.attributes.get("mvk.delete_ids_count", 0)
        if delete_ids_count > 0:
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.processed", delete_ids_count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_delete_wrapper(self):
        """Create wrapper for ChromaDB delete operations (Delete by ID or filter).

        This wrapper monitors deletion operations that remove vectors from the collection.
        It tracks deletion parameters like IDs or filter conditions used for removal.
        Important for monitoring data cleanup activities and deletion patterns.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.delete",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_delete_attributes,
            process_result=self._process_delete_result,
        )

    def _extract_count_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB count operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_count",
            "operation_subtype": "count",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        return attrs

    def _process_count_result(self, span, result):
        """Process result from ChromaDB count operation."""
        # Count operation returns the number of items
        if isinstance(result, (int, float)):
            count = int(result)
            span.set_attribute("mvk.results_count", count)
            # Add metered usage for count operation
            builder = MeteredUsageBuilder()
            builder.add_metric("vector.retrieved", count, "vector")
            safe_populate_metered_usage(span, builder)

    def _create_count_wrapper(self):
        """Create wrapper for ChromaDB count operations.

        This wrapper tracks count operations that return the total number of vectors in a collection.
        It captures the collection name and tracks the count result for monitoring collection sizes.
        Helpful for understanding data volume and collection growth over time.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.count",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_count_attributes,
            process_result=self._process_count_result,
        )

    def _extract_peek_attributes(self, instance, args, kwargs):
        """Extract attributes from ChromaDB peek operation."""
        attrs = {
            "model_provider": "chromadb",
            "operation": "vector_peek",
            "operation_subtype": "peek",
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        if hasattr(instance, "name"):
            attrs["collection_name"] = instance.name

        # Extract limit parameter
        if "limit" in kwargs:
            attrs["peek_limit"] = kwargs["limit"]

        return attrs

    def _process_peek_result(self, span, result):
        """Process result from ChromaDB peek operation."""
        # Peek returns a sample of data
        if isinstance(result, dict) and "ids" in result:
            ids = result["ids"]
            if isinstance(ids, list):
                count = len(ids)
                span.set_attribute("mvk.results_count", count)
                # Add metered usage for peek operation
                builder = MeteredUsageBuilder()
                builder.add_metric("vector.retrieved", count, "vector")
                safe_populate_metered_usage(span, builder)

    def _create_peek_wrapper(self):
        """Create wrapper for ChromaDB peek operations (Sample data).

        This wrapper monitors peek operations that return a sample of vectors from the collection.
        It tracks the sample limit and counts the number of vectors returned in the sample.
        Useful for monitoring data sampling activities and collection inspection.
        """
        return WrapperBase.create_wrapper(
            span_name="chromadb.peek",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_peek_attributes,
            process_result=self._process_peek_result,
        )
