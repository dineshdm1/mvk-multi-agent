"""Common utilities for all instrumentors.

Includes shared helpers for attribute population and token estimation to
normalize telemetry across providers when native usage is missing.

Also provides minimal, scalable instrumentation primitives used by all
instrumentors to guarantee that interception NEVER interrupts client flows.
"""

import logging
import math
from typing import Any, Callable, Dict, Iterable, Optional, Sequence, Union

from ..context import get_global_context
from ..wrapper_logging import get_component_logger

# Module logger for safety messages in instrumentors
logger = get_component_logger("instrumentation", "common")


def get_common_attributes(
    vendor_name: str, vendor_sdk: str, sdk_module: Any = None
) -> Dict[str, Any]:
    """Get common attributes that all instrumentors should include.

    Args:
        vendor_name: Name of the vendor (e.g., "openai", "anthropic")
        vendor_sdk: Name of the SDK being wrapped (e.g., "openai-python")
        sdk_module: Optional module to extract version from

    Returns:
        Dictionary with common attributes including agent info and versions
    """
    # Get global context for agent info
    global_ctx = get_global_context()

    # Get vendor SDK version if module provided
    vendor_sdk_version = "unknown"
    if sdk_module:
        try:
            vendor_sdk_version = getattr(sdk_module, "__version__", "unknown")
        except (AttributeError, Exception) as e:
            logger.debug(f"Could not get vendor SDK version: {e}")
            vendor_sdk_version = "unknown"

    # Get MVK SDK version
    import mvk_sdk

    mvk_sdk_version = getattr(mvk_sdk, "__version__", "1.1.0")
    mvk_schema_version = mvk_sdk.get_schema_version()

    # Return all common attributes
    return {
        "agent_id": global_ctx.get("mvk.agent_id", ""),
        "vendor.name": vendor_name,
        "vendor.sdk.name": vendor_sdk,
        "vendor.sdk.version": vendor_sdk_version,
        "mvk.sdk.version": mvk_sdk_version,
        "mvk.schema.version": mvk_schema_version,
    }


def normalize_messages_for_analysis(messages) -> str:
    """Normalize message data for analysis and metrics.

    Converts various message formats (OpenAI format, Anthropic format, etc.)
    into a normalized string for consistent analysis.

    Args:
        messages: Messages in any format (list, dict, string)

    Returns:
        Normalized string representation suitable for analysis
    """
    if not messages:
        return ""

    try:
        # Handle list of messages (most common format)
        if isinstance(messages, list):
            normalized_parts = []
            for msg in messages:
                if isinstance(msg, dict):
                    # Extract content from various formats
                    content = msg.get("content", "")
                    if isinstance(content, list):
                        # Handle content blocks (like Anthropic format)
                        content_text = ""
                        for block in content:
                            if isinstance(block, dict):
                                if block.get("type") == "text":
                                    content_text += block.get("text", "")
                                elif "text" in block:
                                    content_text += block.get("text", "")
                        content = content_text

                    role = msg.get("role", "")
                    if content:
                        normalized_parts.append(f"{role}: {content}")
                elif isinstance(msg, str):
                    normalized_parts.append(msg)

            return " ".join(normalized_parts)

        # Handle single message dict
        elif isinstance(messages, dict):
            content = messages.get("content", "")
            if isinstance(content, list):
                # Handle content blocks
                content_text = ""
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        content_text += block.get("text", "")
                content = content_text
            return str(content)

        # Handle string
        elif isinstance(messages, str):
            return messages

        # Fallback: convert to string
        else:
            return str(messages)

    except Exception as e:
        logger.debug(f"Error normalizing messages: {e}")
        return str(messages) if messages else ""


def estimate_tokens(text: str, model: str = "gpt-3.5-turbo") -> int:
    """Estimate token count for text when provider doesn't return usage.

    This is a rough approximation used as fallback when native usage metrics
    are not available from the provider.

    Args:
        text: Text to estimate tokens for
        model: Model name for provider-specific estimation

    Returns:
        Estimated token count
    """
    if not text:
        return 0

    try:
        # Basic estimation: roughly 4 characters per token for most models
        # This is a simplified heuristic - real tokenization varies by model
        char_count = len(str(text))

        # Different models have different token-to-character ratios
        if model and any(x in model.lower() for x in ["gpt-4", "claude-3", "gemini"]):
            # More advanced models tend to be more efficient
            ratio = 3.5
        elif model and "claude-2" in model.lower():
            # Claude-2 has specific characteristics
            ratio = 4.0
        else:
            # Default estimation
            ratio = 4.0

        estimated = max(1, math.ceil(char_count / ratio))
        return estimated

    except Exception as e:
        logger.debug(f"Error estimating tokens: {e}")
        # Very conservative fallback
        return max(1, len(str(text)) // 4)


def safe_extract(obj: Any, path: str, default: Any = None) -> Any:
    """Safely extract value from nested object using dot notation.

    Args:
        obj: Object to extract from
        path: Dot-separated path (e.g., "response.usage.total_tokens")
        default: Default value if path not found

    Returns:
        Extracted value or default
    """
    try:
        current = obj
        for part in path.split("."):
            if hasattr(current, part):
                current = getattr(current, part)
            elif isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return default
        return current
    except Exception:
        return default


def create_safe_wrapper(
    original_func: Callable, wrapper_func: Callable, error_fallback: Any = None
) -> Callable:
    """Create a wrapper that never breaks the original function.

    If the wrapper fails, the original function is called unchanged.

    Args:
        original_func: Original function to wrap
        wrapper_func: Wrapper function that takes (original, *args, **kwargs)
        error_fallback: Value to return if both original and wrapper fail

    Returns:
        Safe wrapper function
    """

    def safe_wrapper(*args, **kwargs):
        try:
            return wrapper_func(original_func, *args, **kwargs)
        except Exception as e:
            logger.debug(f"Wrapper failed, calling original: {e}")
            try:
                return original_func(*args, **kwargs)
            except Exception as original_error:
                logger.error(f"Both wrapper and original failed: {original_error}")
                if error_fallback is not None:
                    return error_fallback
                raise original_error

    return safe_wrapper
