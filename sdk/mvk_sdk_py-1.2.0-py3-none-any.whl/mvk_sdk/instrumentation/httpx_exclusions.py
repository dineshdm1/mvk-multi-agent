"""HTTPX URL exclusion patterns for instrumentation.

This module defines which URLs should be excluded from HTTPX instrumentation
to avoid infinite loops and unnecessary overhead.
"""

import re
from typing import List, Optional, Pattern
from urllib.parse import urlparse

# Default exclusion patterns - these URLs should never be instrumented
DEFAULT_EXCLUSIONS = [
    # MVK/observability endpoints to prevent infinite loops
    r".*\.mavvrik\.ai.*",
    r".*ingest\.mavvrik\.ai.*",
    # Common observability/telemetry endpoints
    r".*\.datadog\.com.*",
    r".*\.newrelic\.com.*",
    r".*\.honeycomb\.io.*",
    r".*\.segment\.com.*",
    r".*analytics\.google\.com.*",
    # Common health/monitoring endpoints
    r".*/health.*",
    r".*/healthz.*",
    r".*/ping.*",
    r".*/metrics.*",
    r".*/status.*",
    # Development/local endpoints
    r".*localhost.*",
    r".*127\.0\.0\.1.*",
    r".*0\.0\.0\.0.*",
]

# Compiled patterns for performance
_compiled_patterns: List[Pattern] = []


def _compile_patterns():
    """Compile regex patterns for better performance."""
    global _compiled_patterns
    if not _compiled_patterns:
        _compiled_patterns = [re.compile(pattern, re.IGNORECASE) for pattern in DEFAULT_EXCLUSIONS]


def is_excluded_url(url: str, additional_exclusions: Optional[List[str]] = None) -> bool:
    """Check if URL should be excluded from instrumentation.

    Args:
        url: URL to check
        additional_exclusions: Additional exclusion patterns

    Returns:
        True if URL should be excluded, False otherwise
    """
    if not url:
        return True

    # Ensure patterns are compiled
    _compile_patterns()

    try:
        # Parse URL to get clean components
        parsed = urlparse(url)
        host = parsed.netloc.lower()
        full_url = url.lower()

        # Check against default patterns
        for pattern in _compiled_patterns:
            if pattern.search(full_url) or pattern.search(host):
                return True

        # Check against additional exclusions
        if additional_exclusions:
            for exclusion in additional_exclusions:
                try:
                    if re.search(exclusion, full_url, re.IGNORECASE):
                        return True
                    if re.search(exclusion, host, re.IGNORECASE):
                        return True
                except re.error:
                    # Invalid regex pattern, skip
                    continue

        return False

    except Exception:
        # On any error, exclude the URL to be safe
        return True


def add_exclusion_pattern(pattern: str):
    """Add a new exclusion pattern.

    Args:
        pattern: Regex pattern to add to exclusions
    """
    global _compiled_patterns
    try:
        compiled = re.compile(pattern, re.IGNORECASE)
        _compiled_patterns.append(compiled)
        DEFAULT_EXCLUSIONS.append(pattern)
    except re.error:
        # Invalid pattern, ignore
        pass


def get_default_exclusions() -> List[str]:
    """Get list of default exclusion patterns.

    Returns:
        List of default exclusion regex patterns
    """
    return DEFAULT_EXCLUSIONS.copy()
