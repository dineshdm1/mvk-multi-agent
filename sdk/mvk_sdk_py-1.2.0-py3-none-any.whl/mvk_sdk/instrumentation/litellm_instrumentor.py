"""LiteLLM instrumentor following OTEL patterns.

This module provides comprehensive instrumentation for LiteLLM's public API (completion,
acompletion, Router) to capture all LLM calls regardless of provider routing.

## Key Concepts

**LiteLLM Abstraction Layer**: LiteLLM provides a unified interface to multiple LLM providers
(OpenAI, Anthropic, Bedrock, Gemini, etc.) with automatic model routing and fallbacks. This
instrumentor hooks into LiteLLM's completion/acompletion entry points to capture calls before
provider routing, ensuring consistent instrumentation across all providers.

**Instrumentation Strategy**:
1. Store original LiteLLM functions at module load time
2. Replace them with wrapper functions that:
   - Extract request parameters (model, messages, etc.)
   - Create OTEL spans with standardized attributes
   - Call original function
   - Capture response/error data and add to span
   - Synthesize responses from streaming data
3. Restore original functions on uninstrument

**Span Creation Pattern**: Each LLM call creates a "litellm.completion" span with:
- Standard OTEL attributes (name, kind, status, duration)
- LLM-specific attributes (model, provider, tokens, temperature, etc.)
- Request/response content (when logging enabled)
- Error information (status code, error message)

Supports:
- Synchronous completion calls (litellm.completion)
- Asynchronous completion calls (litellm.acompletion)
- Streaming responses (sync and async)
- Router-based calls
- All LiteLLM provider formats (OpenAI, Anthropic, Bedrock, Gemini, etc.)

## Module Structure

Helper Functions:
- _read_chunk_text_delta(): Extract text from stream chunks
- _make_final_from_stream(): Synthesize final response from accumulated stream data

Main Class:
- LiteLLMInstrumentor: Main instrumentor class managing lifecycle

Internal Wrappers:
- _completion_wrapper(): Sync completion wrapper
- _acompletion_wrapper(): Async completion wrapper
- _handle_streaming_completion(): Sync streaming logic
- _handle_async_streaming_completion(): Async streaming logic
"""

import functools
import time
from typing import Any, AsyncIterable, Collection, Dict, Iterable, Optional

from ..instrument import should_log_prompts_responses
from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.litellm_normalization import (
    _get_model_family_from_provider,
    normalize_usage_and_output,
)
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..mvk_tracer import OTLPStatusCode, get_tracer
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "litellm")

# Store original functions for uninstall
_ORIG_COMPLETION: Optional[Any] = None
_ORIG_ACOMPLETION: Optional[Any] = None


def _read_chunk_text_delta(chunk: Any) -> str:
    """Extract text delta from a stream chunk.

    **Purpose**:
    Streaming responses send text incrementally as "delta" objects within each chunk.
    This function safely extracts the text content from a single chunk, returning
    empty string if the chunk doesn't contain text (e.g., usage-only chunks).

    **Chunk Structure** (expected):
    ```json
    {
      "choices": [
        {
          "delta": {
            "content": "The text content here"
          }
        }
      ]
    }
    ```

    **Resilience**:
    - Returns "" if chunk is not a dict
    - Returns "" if choices array is empty (sometimes final chunk has no text)
    - Returns "" if delta is missing or content is None
    - Never throws exception, always returns string

    Args:
        chunk: Single chunk from a streaming response (expected dict with choices)

    Returns:
        Text content from chunk.choices[0].delta.content, or empty string if unavailable
    """
    try:
        if not isinstance(chunk, dict):
            return ""
        choices = chunk.get("choices") or []
        if not choices:
            return ""
        ch0 = choices[0]
        if not isinstance(ch0, dict):
            return ""
        delta = ch0.get("delta") or {}
        return delta.get("content") or ""
    except Exception:
        return ""


def _make_final_from_stream(last_raw: Optional[dict], full_text: str) -> dict:
    """Synthesize a final response object from accumulated stream chunks.

    **Problem This Solves**:
    Streaming responses send text incrementally as separate chunks. The final chunk
    typically contains usage information (tokens consumed), but does NOT contain the
    full response text. This function reconstructs what a non-streaming response would
    look like by combining:
    - Text accumulated from all chunks
    - Usage information from the last chunk
    - Model name from the last chunk

    **Output Format**:
    The returned dict matches the OpenAI-like response format that downstream code
    expects:
    ```json
    {
      "model": "gpt-4",
      "choices": [
        {
          "message": {
            "role": "assistant",
            "content": "The full accumulated text"
          }
        }
      ],
      "usage": {
        "prompt_tokens": 10,
        "completion_tokens": 50,
        "total_tokens": 60
      }
    }
    ```

    **Usage Information**:
    - If last_raw contains usage, it's copied as-is
    - Some providers don't send usage with streaming (set {} if unavailable)
    - Downstream normalize_usage_and_output() gracefully handles missing usage

    Args:
        last_raw: The final chunk dict received from the streaming iterator
                  (may be None if stream ended unexpectedly)
        full_text: Accumulated text from all chunks in the stream

    Returns:
        Dict matching OpenAI-like response format with text and usage populated
    """
    usage = {}
    if isinstance(last_raw, dict) and "usage" in last_raw:
        usage = last_raw.get("usage", {})

    return {
        "model": (last_raw or {}).get("model", ""),
        "choices": [{"message": {"role": "assistant", "content": full_text}}],
        "usage": usage,
    }


class LiteLLMInstrumentor(BaseInstrumentor):
    """Instrumentor for LiteLLM's public API.

    **Purpose**:
    LiteLLM provides a unified interface to 100+ LLM providers. This instrumentor
    hooks at the LiteLLM API entry points (completion, acompletion) to capture all
    LLM calls regardless of provider routing, ensuring consistent instrumentation
    across OpenAI, Anthropic, Bedrock, Gemini, Cohere, and other providers.

    **Instrumentation Strategy**:
    1. **At Module Load** (_instrument method):
       - Saves original litellm.completion and litellm.acompletion functions
       - Replaces them with wrapper functions

    2. **Request Phase** (wrappers extract):
       - Extract model, messages, parameters from request args/kwargs
       - Create OTEL span with "litellm.completion" name
       - Add standard LLM attributes (model, provider, temperature, etc.)

    3. **Execution Phase**:
       - Call original LiteLLM function
       - Capture response or exception

    4. **Response Phase**:
       - Extract text and usage from response using provider-specific logic
       - For streaming: accumulate chunks, synthesize final response
       - Add all extracted data to span attributes

    5. **At Shutdown** (_uninstrument method):
       - Restores original LiteLLM functions

    **Supported Scenarios**:
    - Synchronous completion(): litellm.completion(...)
    - Asynchronous completion(): await litellm.acompletion(...)
    - Streaming responses: stream=True parameter
    - Router-based calls: LiteLLM Router for A/B testing, fallbacks
    - All provider formats: OpenAI-like, Anthropic, Bedrock, Gemini, etc.

    **Key Design Decisions**:
    - Wraps at module level (not class methods) to catch all provider routing
    - Stores original functions to enable clean uninstrumentation
    - Handles streaming by accumulating chunks and synthesizing responses
    - Uses provider detection to normalize responses across vendors
    - Gracefully handles missing metrics (defaults to 0)

    **Span Attributes**:
    - gen_ai.request.model: Model name
    - gen_ai.system: LLM provider
    - gen_ai.request.temperature: Temperature parameter
    - gen_ai.usage.input_tokens: Prompt tokens
    - gen_ai.usage.output_tokens: Completion tokens
    - gen_ai.response.finish_reason: Stop reason
    - (plus many more standard OTEL attributes)
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """LiteLLM package is required."""
        return ["litellm"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "litellm"

    def _instrument(self, **kwargs: Any) -> None:
        """Apply instrumentation to LiteLLM module functions."""
        try:
            import litellm  # type: ignore

            global _ORIG_COMPLETION, _ORIG_ACOMPLETION

            # Store originals
            if _ORIG_COMPLETION is None:
                _ORIG_COMPLETION = litellm.completion
            if _ORIG_ACOMPLETION is None and hasattr(litellm, "acompletion"):
                _ORIG_ACOMPLETION = litellm.acompletion

            # Create and apply wrappers
            @functools.wraps(litellm.completion)
            def wrapped_completion(*args: Any, **kw: Any) -> Any:
                return self._wrapped_completion_impl(*args, **kw)

            setattr(litellm, "completion", wrapped_completion)

            if _ORIG_ACOMPLETION is not None:

                @functools.wraps(litellm.acompletion)
                async def wrapped_acompletion(*args: Any, **kw: Any) -> Any:
                    return await self._wrapped_acompletion_impl(*args, **kw)

                setattr(litellm, "acompletion", wrapped_acompletion)

            logger.info("LiteLLM instrumentation enabled")

        except ImportError:
            logger.warning("LiteLLM not found, skipping instrumentation")

    def _uninstrument(self, **kwargs: Any) -> None:
        """Remove instrumentation from LiteLLM."""
        try:
            import litellm  # type: ignore

            global _ORIG_COMPLETION, _ORIG_ACOMPLETION

            if _ORIG_COMPLETION is not None:
                setattr(litellm, "completion", _ORIG_COMPLETION)
                _ORIG_COMPLETION = None

            if _ORIG_ACOMPLETION is not None and hasattr(litellm, "acompletion"):
                setattr(litellm, "acompletion", _ORIG_ACOMPLETION)
                _ORIG_ACOMPLETION = None

            logger.info("LiteLLM instrumentation disabled")

        except ImportError:
            logger.warning("LiteLLM not found, cannot uninstrument")
            pass

    # --- Attribute extraction following standard pattern ---

    def _extract_completion_attributes(
        self, instance: Any, args: tuple[Any, ...], kwargs: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract request attributes from completion call for span initialization.

        **Purpose**:
        This method extracts model name, messages, parameters, and other attributes
        from the completion call arguments before the LLM is invoked. These attributes
        are added to the OTEL span to provide context about the request.

        **Attribute Extraction Order**:
        1. Model name: from kwargs["model"] or first positional arg
        2. Messages: from kwargs["messages"] or appropriate positional arg
        3. Parameters: temperature, max_tokens, top_p, frequency_penalty, etc.
        4. Provider: inferred from model using resolve_model_identity()
        5. Streaming flag: from kwargs["stream"]

        **Extracted Span Attributes** (standard OTEL names):
        - gen_ai.request.model: The model identifier
        - gen_ai.system: Provider name (e.g., "openai", "anthropic")
        - gen_ai.request.temperature: Sampling temperature
        - gen_ai.request.max_tokens: Maximum output tokens
        - gen_ai.request.top_p: Top-p sampling parameter
        - llm.is_streaming: True if stream=True
        - (plus user/system message counts if available)

        **Note About Framework Detection**:
        LiteLLM is always instrumented regardless of calling framework context.
        LiteLLM is a thin proxy/multiplexer and doesn't represent "framework
        instrumentation". Framework detection prevents double instrumentation at
        the actual provider level (OpenAI SDK, Anthropic SDK), not at the proxy.

        Args:
            instance: Instance object (not used for module-level functions like
                      litellm.completion which are wrapped at module level)
            args: Positional arguments from completion call
                  (typically: model, messages, ...)
            kwargs: Keyword arguments from completion call
                    (typically: model=..., messages=..., temperature=...)

        Returns:
            Dictionary of attributes to add to span, or None if extraction fails
        """
        # NOTE: LiteLLM should always be instrumented regardless of calling framework.
        # LiteLLM is a thin proxy/multiplexer and doesn't represent "framework instrumentation".
        # Framework detection is for preventing double instrumentation at the actual provider
        # level (OpenAI SDK, Anthropic SDK, etc.), not at the proxy level.

        attrs: Dict[str, Any] = {}

        # Extract model
        model = kwargs.get("model") or (args[0] if args else "")

        # Resolve comprehensive model identity using LiteLLM's native methods
        from .litellm_normalization import resolve_model_identity

        identity = resolve_model_identity(str(model), kwargs)

        # Set core attributes with comprehensive model information
        attrs.update(
            {
                "model_name": str(model),
                "model_provider": identity[
                    "provider"
                ],  # Initial value - will be updated from response
                "model_family": identity[
                    "model_family"
                ],  # Initial value - will be updated from response
                "mvk.step_type": MVKStepType.LLM,
                "operation": "completion",
            }
        )

        # Add registry information if available
        if identity.get("mode"):
            attrs["model_mode"] = identity["mode"]

        if identity.get("max_tokens"):
            attrs["model_max_tokens"] = identity["max_tokens"]

        if identity.get("registry_provider"):
            attrs["registry_provider"] = identity["registry_provider"]

        # Check for streaming
        is_stream = kwargs.get("stream", False)
        if is_stream:
            attrs["stream_enabled"] = True
            attrs["operation_subtype"] = "stream"
        else:
            attrs["operation_subtype"] = "batch"

        # Log prompts if enabled
        if should_log_prompts_responses():
            input_prompt = kwargs.get("messages") or kwargs.get("prompt")
            if input_prompt:
                try:
                    # Handle both dict/list formats and plain text
                    if isinstance(input_prompt, (list, dict)):
                        import json

                        prompt_str = json.dumps(input_prompt, default=str)[:1000]
                    else:
                        prompt_str = str(input_prompt)[:1000]

                    if prompt_str.strip():  # Only set if non-empty after conversion
                        attrs["prompt"] = prompt_str
                except Exception as e:
                    logger.debug(f"Failed to serialize prompt: {e}")

        return attrs

    def _process_completion_result(self, span: Any, result: Any) -> None:
        """Process completion result following standard pattern.

        Args:
            span: The active span
            result: The result from the LiteLLM call
        """
        # Handle streaming responses - don't process (streaming wrapper handles it)
        if hasattr(result, "__next__") or hasattr(result, "__aiter__"):
            logger.debug("[LiteLLM] Streaming response detected - skipping result processing")
            return

        try:
            # Normalize response
            usage, output_text, response_model, response_provider = normalize_usage_and_output(
                result
            )

            # Update model if response provides one
            if response_model:
                span.set_attribute("mvk.model_name", response_model)

            # Update provider if response provides one
            if response_provider:
                span.set_attribute("mvk.model_provider", response_provider)
                # Also derive model family from actual provider
                family = _get_model_family_from_provider(response_provider)
                if family:
                    span.set_attribute("mvk.model_family", family)

            # Set token attributes (always, even if zero - for schema compliance)
            if usage:
                prompt_tokens = usage.get("input_tokens", 0)
                completion_tokens = usage.get("output_tokens", 0)
                total_tokens = usage.get("total_tokens", 0)
                cache_tokens = usage.get("cache_tokens", 0)
                reasoning_tokens = usage.get("reasoning_tokens", 0)

                # Always set token attributes (even if zero - they represent the response structure)
                span.set_attribute("mvk.prompt_tokens", prompt_tokens)
                span.set_attribute("mvk.completion_tokens", completion_tokens)
                span.set_attribute("mvk.total_tokens", total_tokens)

                if cache_tokens > 0:
                    span.set_attribute("mvk.cache_tokens", cache_tokens)

                if reasoning_tokens > 0:
                    span.set_attribute("mvk.reasoning_tokens", reasoning_tokens)

                # Populate metered usage ONLY if we have non-zero token counts
                if prompt_tokens > 0 or completion_tokens > 0 or total_tokens > 0:
                    builder = MeteredUsageBuilder()
                    builder.add_token_metrics(
                        prompt=prompt_tokens,
                        completion=completion_tokens,
                        total=total_tokens,
                        reasoning=reasoning_tokens,
                        cached_read=cache_tokens,
                    )
                    safe_populate_metered_usage(span, builder)
                else:
                    # Log when usage is available but all counts are zero
                    logger.debug(
                        f"[LiteLLM] No token usage available. "
                        f"Response may not include usage metadata."
                    )

            # Log responses if enabled
            if should_log_prompts_responses():
                if output_text and isinstance(output_text, str) and output_text.strip():
                    span.set_attribute("mvk.response", output_text[:1000])
                elif output_text:
                    # Fallback: try to serialize non-string responses
                    try:
                        import json

                        response_str = json.dumps(output_text, default=str)[:1000]
                        if response_str.strip():
                            span.set_attribute("mvk.response", response_str)
                    except Exception as e:
                        logger.debug(f"Failed to serialize response: {e}")

            # Set success status
            span.status_code = OTLPStatusCode.OK

        except Exception as e:
            logger.debug(f"Error processing completion result: {e}", exc_info=True)

    def _process_completion_error(self, span: Any, error: Exception) -> None:
        """Process completion error following standard pattern.

        Args:
            span: The active span
            error: The exception that occurred
        """
        try:
            span.set_attribute("mvk.error", str(error))
            span.set_attribute("mvk.error_type", type(error).__name__)
            span.set_error(error)
        except Exception as e:
            logger.debug(f"Error processing completion error: {e}", exc_info=True)

    # --- Wrapper creation following standard pattern ---

    def _create_completion_wrapper(self):
        """Create wrapper for completion method following standard pattern."""
        return WrapperBase.create_wrapper(
            span_name="litellm.completion",
            span_kind="SPAN_KIND_CLIENT",
            extract_attributes=self._extract_completion_attributes,
            process_result=self._process_completion_result,
            process_error=self._process_completion_error,
        )

    # --- Sync implementation ---

    def _wrapped_completion_impl(self, *args: Any, **kwargs: Any) -> Any:
        """Implementation of wrapped completion using standard wrapper pattern."""
        if _ORIG_COMPLETION is None:
            raise RuntimeError("LiteLLM completion not available")

        # Check for streaming - if streaming, handle separately
        is_streaming = kwargs.get("stream", False)

        if is_streaming:
            # For streaming, we need custom handling to accumulate chunks
            return self._handle_streaming_completion(args, kwargs)
        else:
            # For non-streaming, use the standard wrapper
            wrapper = self._create_completion_wrapper()
            return wrapper(_ORIG_COMPLETION, None, args, kwargs)

    # --- Async implementation ---

    async def _wrapped_acompletion_impl(self, *args: Any, **kwargs: Any) -> Any:
        """Implementation of wrapped acompletion using standard wrapper pattern."""
        if _ORIG_ACOMPLETION is None:
            raise RuntimeError("LiteLLM acompletion not available")

        # Check for streaming - if streaming, handle separately
        is_streaming = kwargs.get("stream", False)

        if is_streaming:
            # For streaming, we need custom handling to accumulate chunks
            return self._handle_async_streaming_completion(args, kwargs)
        else:
            # For non-streaming async, we need a special async wrapper
            return await self._async_wrapper_call(args, kwargs)

    async def _async_wrapper_call(self, args: tuple, kwargs: Dict[str, Any]) -> Any:
        """Async wrapper call following standard pattern.

        Note: WrapperBase doesn't directly support async, so we implement
        the same pattern manually for async calls.
        """
        tracer = get_tracer()
        start_time = time.time()

        # Extract attributes
        attributes = {}
        try:
            attributes = self._extract_completion_attributes(None, args, kwargs) or {}
        except Exception as e:
            logger.error(f"Failed to extract attributes: {e}")

        # Start span
        span = tracer.start_span("litellm.completion", kind="SPAN_KIND_CLIENT", **attributes)

        try:
            # Call original method
            if _ORIG_ACOMPLETION is None:
                raise RuntimeError("Original acompletion method not initialized")
            result = await _ORIG_ACOMPLETION(*args, **kwargs)

            # Process result
            try:
                self._process_completion_result(span, result)
            except Exception as e:
                logger.error(f"Failed to process result: {e}")

            return result

        except Exception as e:
            # Process error
            try:
                self._process_completion_error(span, e)
            except Exception as ex:
                logger.debug(f"Failed to process error: {ex}")

            # Re-raise the original exception
            raise

        finally:
            # Calculate duration
            duration_ms = (time.time() - start_time) * 1000
            span.set_attribute("mvk.duration_ms", duration_ms)

            # End span
            span.end()

    # --- Streaming handlers ---

    def _handle_streaming_completion(self, args: tuple, kwargs: Dict[str, Any]) -> Iterable:
        """Handle sync streaming completion following standard pattern."""
        tracer = get_tracer()
        start_time = time.time()

        # Extract attributes
        attributes = {}
        try:
            attributes = self._extract_completion_attributes(None, args, kwargs) or {}
        except Exception as e:
            logger.error(f"Failed to extract attributes: {e}")

        # Start span
        span = tracer.start_span("litellm.completion", kind="SPAN_KIND_CLIENT", **attributes)

        buffer = []
        last_raw = None

        try:
            # Call original method to get stream
            if _ORIG_COMPLETION is None:
                raise RuntimeError("Original completion method not initialized")
            gen = _ORIG_COMPLETION(*args, **kwargs)

            for chunk in gen:
                last_raw = chunk
                # Extract text delta and accumulate
                delta = _read_chunk_text_delta(chunk)
                if delta:
                    buffer.append(delta)
                # Pass through chunk unchanged
                yield chunk

            # After stream completes, synthesize final response
            full_text = "".join(buffer)
            final_raw = _make_final_from_stream(
                last_raw if isinstance(last_raw, dict) else {}, full_text
            )

            # Process the synthesized response
            try:
                self._process_completion_result(span, final_raw)
            except Exception as e:
                logger.error(f"Failed to process streaming result: {e}")

        except Exception as e:
            # Process error
            try:
                self._process_completion_error(span, e)
            except Exception as ex:
                logger.debug(f"Failed to process error: {ex}")

            # Re-raise the original exception
            raise

        finally:
            # Calculate duration
            duration_ms = (time.time() - start_time) * 1000
            span.set_attribute("mvk.duration_ms", duration_ms)

            # End span
            span.end()

    async def _handle_async_streaming_completion(
        self, args: tuple, kwargs: Dict[str, Any]
    ) -> AsyncIterable:
        """Handle async streaming completion following standard pattern."""
        tracer = get_tracer()
        start_time = time.time()

        # Extract attributes
        attributes = {}
        try:
            attributes = self._extract_completion_attributes(None, args, kwargs) or {}
        except Exception as e:
            logger.error(f"Failed to extract attributes: {e}")

        # Start span
        span = tracer.start_span("litellm.completion", kind="SPAN_KIND_CLIENT", **attributes)

        buffer = []
        last_raw = None

        try:
            # Call original method to get async stream
            if _ORIG_ACOMPLETION is None:
                raise RuntimeError("Original acompletion method not initialized")
            agen = _ORIG_ACOMPLETION(*args, **kwargs)

            async for chunk in agen:
                last_raw = chunk
                # Extract text delta and accumulate
                delta = _read_chunk_text_delta(chunk)
                if delta:
                    buffer.append(delta)
                # Pass through chunk unchanged
                yield chunk

            # After stream completes, synthesize final response
            full_text = "".join(buffer)
            final_raw = _make_final_from_stream(
                last_raw if isinstance(last_raw, dict) else {}, full_text
            )

            # Process the synthesized response
            try:
                self._process_completion_result(span, final_raw)
            except Exception as e:
                logger.error(f"Failed to process streaming result: {e}")

        except Exception as e:
            # Process error
            try:
                self._process_completion_error(span, e)
            except Exception as ex:
                logger.debug(f"Failed to process error: {ex}")

            # Re-raise the original exception
            raise

        finally:
            # Calculate duration
            duration_ms = (time.time() - start_time) * 1000
            span.set_attribute("mvk.duration_ms", duration_ms)

            # End span
            span.end()
