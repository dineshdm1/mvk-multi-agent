"""Weaviate instrumentor following OTEL patterns.

This module provides instrumentation for Weaviate using the BaseInstrumentor
pattern with wrapt for consistent wrapping. Supports both HTTP REST API
and gRPC API from Weaviate Python client v3.x and v4.x.

Reference: https://weaviate.io/developers/weaviate/api/rest
"""

import json
import sys
from typing import Any, Collection, Dict, Optional
from weakref import WeakKeyDictionary

import wrapt

from ..instrumentation.base import BaseInstrumentor
from ..instrumentation.wrapper_base import WrapperBase
from ..metered_usage import MeteredUsageBuilder, safe_populate_metered_usage
from ..schema import MVKStepType
from ..wrapper_logging import get_component_logger

logger = get_component_logger("instrumentation", "weaviate")

# Global registry to track collection names by instance
_collection_name_registry: WeakKeyDictionary = WeakKeyDictionary()


class WeaviateInstrumentor(BaseInstrumentor):
    """Instrumentor for Weaviate following OTEL patterns.

    Supports both HTTP REST API and gRPC API from Weaviate Python client.
    Captures Weaviate operations:
    - Query operations: fetch_objects, fetch_object_by_id, GraphQL queries
    - Write operations: insert, replace, update, batch operations
    - Delete operations: delete_by_id, batch delete
    """

    @property
    def instrumentation_dependencies(self) -> Collection[str]:
        """Weaviate client is required."""
        return ["weaviate"]

    @property
    def name(self) -> str:
        """Name of this instrumentor."""
        return "weaviate"

    def _uninstrument(self, **kwargs) -> None:
        """Remove instrumentation from Weaviate SDK.

        The base class handles unwrapping automatically.
        """
        pass

    def _instrument(self, **kwargs) -> None:
        """Apply instrumentation to Weaviate v3.x and v4.x."""
        try:
            import weaviate

            logger.info("Starting Weaviate instrumentation")

            # Instrument collection factory methods (v4.x)
            self._instrument_collection_factory()

            # Detect Weaviate version and instrument accordingly
            version = self._detect_weaviate_version(weaviate)

            if version == "4.x":
                self._instrument_v4(weaviate)
            elif version == "3.x":
                self._instrument_v3(weaviate)
            else:
                logger.warning(f"Unsupported Weaviate version: {version}")

            # Try to enable gRPC auto-instrumentation (optional dependency)
            self._instrument_grpc()

            logger.info("Weaviate auto-instrumentation enabled")

        except Exception as e:
            logger.warning(f"Failed to instrument Weaviate: {e}")

    def _instrument_collection_factory(self) -> None:
        """Instrument Weaviate v4.x collection factory methods.

        This wraps WeaviateClient.collections.get() to track collection names.
        """
        try:
            from weaviate import WeaviateClient

            # Create wrapper for collections.get() factory method
            def collection_factory_wrapper(wrapped, instance, args, kwargs):
                """Wrapper for WeaviateClient.collections.get() factory method."""
                logger.debug(
                    f"WeaviateClient.collections.get() called with args={args}, kwargs={kwargs}"
                )
                result = wrapped(*args, **kwargs)

                # Extract collection name from constructor arguments
                collection_name = None
                if args and len(args) > 0:
                    collection_name = args[0]
                elif "name" in kwargs:
                    collection_name = kwargs["name"]
                elif "collection_name" in kwargs:
                    collection_name = kwargs["collection_name"]

                # Store collection name in registry if we found it
                if collection_name and isinstance(collection_name, str):
                    _collection_name_registry[result] = collection_name
                    logger.debug(
                        f"Stored collection name '{collection_name}' for instance {type(result).__name__}"
                    )

                # Instance-level wrapping to guarantee instrumentation regardless of class path
                try:
                    # Wrap query methods on the instance
                    if hasattr(result, "query"):
                        q = result.query
                        instance_query_methods = [
                            ("near_vector", self._create_near_vector_wrapper()),
                            ("near_object", self._create_near_object_wrapper()),
                            ("fetch_objects", self._create_fetch_objects_wrapper()),
                            ("fetch_object_by_id", self._create_fetch_object_by_id_wrapper()),
                        ]
                        for method_name, wrapper in instance_query_methods:
                            try:
                                if hasattr(q, method_name):
                                    bound = getattr(q, method_name)
                                    # Avoid double-wrapping
                                    if not hasattr(bound, "__wrapped__"):
                                        setattr(
                                            q, method_name, wrapt.FunctionWrapper(bound, wrapper)
                                        )
                                        logger.debug(f"Wrapped instance query.{method_name}")
                            except Exception as e:
                                logger.debug(f"Failed to wrap instance query.{method_name}: {e}")

                    # Wrap data methods on the instance
                    if hasattr(result, "data"):
                        d = result.data
                        instance_data_methods = [
                            ("insert", self._create_insert_wrapper()),
                            ("replace", self._create_replace_wrapper()),
                            ("delete_by_id", self._create_delete_wrapper()),
                            ("fetch_by_id", self._create_fetch_by_id_wrapper()),
                        ]
                        for method_name, wrapper in instance_data_methods:
                            try:
                                if hasattr(d, method_name):
                                    bound = getattr(d, method_name)
                                    if not hasattr(bound, "__wrapped__"):
                                        setattr(
                                            d, method_name, wrapt.FunctionWrapper(bound, wrapper)
                                        )
                                        logger.debug(f"Wrapped instance data.{method_name}")
                            except Exception as e:
                                logger.debug(f"Failed to wrap instance data.{method_name}: {e}")

                    # Wrap aggregate methods on the instance
                    if hasattr(result, "aggregate"):
                        a = result.aggregate
                        if hasattr(a, "over_all"):
                            try:
                                bound = getattr(a, "over_all")
                                if not hasattr(bound, "__wrapped__"):
                                    setattr(
                                        a,
                                        "over_all",
                                        wrapt.FunctionWrapper(
                                            bound, self._create_aggregate_over_all_wrapper()
                                        ),
                                    )
                                    logger.debug("Wrapped instance aggregate.over_all")
                            except Exception as e:
                                logger.debug(f"Failed to wrap instance aggregate.over_all: {e}")
                except Exception as e:
                    logger.debug(f"Instance-level wrapping failed: {e}")

                return result

            # Wrap the collections.get() method
            try:
                self._wrap_method(
                    "weaviate.collections",
                    "Collections.get",
                    collection_factory_wrapper,
                )
                logger.debug("Successfully wrapped WeaviateClient.collections.get factory method")
            except Exception as e:
                logger.debug(f"Could not wrap collections.get: {e}")

        except ImportError:
            logger.debug("WeaviateClient not available")

    def _detect_weaviate_version(self, weaviate_module):
        """Detect Weaviate version based on available classes and modules."""
        # Check for v4.x indicators
        if hasattr(weaviate_module, "WeaviateClient"):
            try:
                # Try to import v4.x specific modules
                import weaviate.collections

                return "4.x"
            except ImportError:
                pass

        # Check for v3.x indicators
        if hasattr(weaviate_module, "Client"):
            try:
                # Try to import v3.x specific modules
                import weaviate.gql

                return "3.x"
            except ImportError:
                pass

        # Fallback: try to determine from version string
        if hasattr(weaviate_module, "__version__"):
            version_str = weaviate_module.__version__
            if version_str.startswith("4."):
                return "4.x"
            elif version_str.startswith("3."):
                return "3.x"

        return "unknown"

    def _instrument_grpc(self) -> None:
        """Attach a gRPC client-side interceptor for Weaviate RPCs if grpc is available.

        This wraps channels created via grpc.insecure_channel / grpc.secure_channel and
        instruments unary_unary calls to emit DB spans with zero-result handling.
        """
        try:
            import grpc  # type: ignore

            class _WeaviateUnaryClientInterceptor(grpc.UnaryUnaryClientInterceptor):  # type: ignore
                def __init__(self, outer: "WeaviateInstrumentor") -> None:
                    self._outer = outer

                def intercept_unary_unary(self, continuation, client_call_details, request):  # type: ignore[override]
                    method = getattr(client_call_details, "method", "") or ""
                    # Derive op/subtype heuristically from method name
                    method_lower = method.lower()
                    if "search" in method_lower:
                        op, subtype = "vector_search", "search"
                    elif "get" in method_lower:
                        op, subtype = "vector_retrieve", "get_by_id"
                    elif "batch" in method_lower or "upsert" in method_lower:
                        op, subtype = "vector_upsert", "batch_create"
                    elif "delete" in method_lower:
                        op, subtype = "vector_delete", "delete"
                    else:
                        op, subtype = "vector_search", "query"

                    span = WrapperBase.start_span(
                        name=f"weaviate.grpc.{subtype}",
                        attributes={
                            "mvk.model_provider": "weaviate",
                            "mvk.operation": op,
                            "mvk.operation_subtype": subtype,
                            "mvk.step_type": MVKStepType.RETRIEVER,
                            "mvk.read_units": (
                                1.0 if op in ("vector_search", "vector_retrieve") else None
                            ),
                        },
                    )
                    try:
                        response = continuation(client_call_details, request)
                        # Attempt to extract counts/class from response via heuristics
                        count = 0
                        try:
                            if hasattr(response, "objects") and hasattr(
                                response.objects, "__len__"
                            ):
                                count = len(response.objects)
                            elif hasattr(response, "results") and hasattr(
                                response.results, "__len__"
                            ):
                                count = len(response.results)
                            elif hasattr(response, "total_count"):
                                count = int(getattr(response, "total_count", 0) or 0)
                        except Exception as e:
                            logger.debug(f"Failed to extract count from gRPC response: {e}")
                            count = 0

                        # collection/class name best-effort
                        try:
                            if hasattr(request, "class_name"):
                                span.set_attribute(
                                    "mvk.collection_name", getattr(request, "class_name")
                                )
                            elif hasattr(request, "collection"):
                                span.set_attribute(
                                    "mvk.collection_name", getattr(request, "collection")
                                )
                        except Exception as e:
                            logger.debug(
                                f"Failed to extract collection name from gRPC request: {e}"
                            )

                        span.set_attribute("mvk.results_count", count)
                        span.set_attribute("mvk.record_count", count)

                        # Write units heuristic for batch writes
                        if op == "vector_upsert" and count and not hasattr(span, "mvk.write_units"):
                            span.set_attribute("mvk.write_units", float(max(5.0, count)))

                        WrapperBase.end_span(span)
                        return response
                    except Exception as e:  # pragma: no cover - passthrough
                        span.set_attribute("mvk.results_count", 0)
                        span.set_attribute("mvk.record_count", 0)
                        WrapperBase.record_exception(span, e)
                        WrapperBase.end_span(span)
                        raise

            interceptor = _WeaviateUnaryClientInterceptor(self)

            # Wrap channel constructors to inject our interceptor
            original_insecure = grpc.insecure_channel
            original_secure = grpc.secure_channel

            def insecure_channel_wrapper(target, options=None, compression=None, credentials=None):  # type: ignore[override]
                ch = original_insecure(target, options=options, compression=compression)
                try:
                    return grpc.intercept_channel(ch, interceptor)
                except Exception as e:
                    logger.debug(f"Failed to intercept insecure gRPC channel: {e}")
                    return ch

            def secure_channel_wrapper(target, credentials, options=None, compression=None):  # type: ignore[override]
                ch = original_secure(target, credentials, options=options, compression=compression)
                try:
                    return grpc.intercept_channel(ch, interceptor)
                except Exception as e:
                    logger.debug(f"Failed to intercept secure gRPC channel: {e}")
                    return ch

            # Avoid double patching
            if not hasattr(grpc.insecure_channel, "_mvk_wrapped"):
                grpc.insecure_channel = insecure_channel_wrapper  # type: ignore[assignment]
                setattr(grpc.insecure_channel, "_mvk_wrapped", True)
            if not hasattr(grpc.secure_channel, "_mvk_wrapped"):
                grpc.secure_channel = secure_channel_wrapper  # type: ignore[assignment]
                setattr(grpc.secure_channel, "_mvk_wrapped", True)

            logger.info("Weaviate gRPC client auto-instrumentation enabled")
        except Exception:
            # grpc not installed or environment does not use grpc
            logger.debug("gRPC not available; skipping Weaviate gRPC instrumentation")

    def _instrument_v4(self, weaviate_module):
        """Instrument Weaviate v4.x API."""
        logger.info("Detected Weaviate v4.x, instrumenting v4.x API")

        # Create wrappers for actual router operations
        fetch_objects_wrapper = self._create_fetch_objects_wrapper()
        fetch_object_by_id_wrapper = self._create_fetch_object_by_id_wrapper()
        insert_wrapper = self._create_insert_wrapper()
        replace_wrapper = self._create_replace_wrapper()
        delete_wrapper = self._create_delete_wrapper()

        # Track successful instrumentations
        instrumented_count = 0

        # Instrument the actual Weaviate v4.x classes
        instrumented_count += self._instrument_weaviate_v4_classes(
            fetch_objects_wrapper,
            fetch_object_by_id_wrapper,
            insert_wrapper,
            replace_wrapper,
            delete_wrapper,
        )

        if instrumented_count > 0:
            logger.info(
                f"Weaviate v4.x auto-instrumentation enabled ({instrumented_count} methods)"
            )
        else:
            logger.warning("No Weaviate v4.x methods were instrumented")

    def _instrument_weaviate_v4_classes(
        self,
        fetch_objects_wrapper,
        fetch_object_by_id_wrapper,
        insert_wrapper,
        replace_wrapper,
        delete_wrapper,
    ):
        """Instrument the actual Weaviate v4.x classes directly."""
        count = 0

        try:
            # Import the actual Weaviate v4.x classes
            from weaviate.collections.data.sync import _DataCollection
            from weaviate.collections.query import _QueryCollection

            try:
                from weaviate.collections.aggregate import _AggregateCollection  # type: ignore
            except Exception as e:
                logger.debug(f"Could not import _AggregateCollection: {e}")
                _AggregateCollection = None  # type: ignore

            # Also try public (non-underscored) classes as fallbacks
            PublicDataCollection = None
            PublicQueryCollection = None
            PublicAggregateCollection = None
            try:
                from weaviate.collections.data import (
                    DataCollection as PublicDataCollection,  # type: ignore
                )
            except Exception as e:
                logger.debug(f"Could not import DataCollection as PublicDataCollection: {e}")
            try:
                from weaviate.collections.query import (
                    QueryCollection as PublicQueryCollection,  # type: ignore
                )
            except Exception as e:
                logger.debug(f"Could not import QueryCollection as PublicQueryCollection: {e}")
            try:
                from weaviate.collections.aggregate import (
                    AggregateCollection as PublicAggregateCollection,  # type: ignore
                )
            except Exception as e:
                logger.debug(
                    f"Could not import AggregateCollection as PublicAggregateCollection: {e}"
                )

            logger.info(f"Found QueryCollection class: {_QueryCollection}")
            logger.info(f"Found DataCollection class: {_DataCollection}")

            # Instrument query methods (underscored class)
            query_methods = [
                ("fetch_objects", fetch_objects_wrapper),
                ("fetch_object_by_id", fetch_object_by_id_wrapper),
                ("near_vector", self._create_near_vector_wrapper()),
                ("near_object", self._create_near_object_wrapper()),
            ]

            for method_name, wrapper in query_methods:
                if hasattr(_QueryCollection, method_name):
                    try:
                        self._wrap_method(
                            "weaviate.collections.query", f"_QueryCollection.{method_name}", wrapper
                        )
                        count += 1
                        logger.info(f"Instrumented _QueryCollection.{method_name}")
                    except Exception as e:
                        logger.warning(f"Failed to instrument _QueryCollection.{method_name}: {e}")
                else:
                    logger.debug(f"Method {method_name} not found on _QueryCollection")

            # Instrument data methods (underscored class)
            data_methods = [
                ("insert", insert_wrapper),
                ("replace", replace_wrapper),
                ("delete_by_id", delete_wrapper),
                ("fetch_by_id", self._create_fetch_by_id_wrapper()),
            ]

            for method_name, wrapper in data_methods:
                if hasattr(_DataCollection, method_name):
                    try:
                        self._wrap_method(
                            "weaviate.collections.data.sync",
                            f"_DataCollection.{method_name}",
                            wrapper,
                        )
                        count += 1
                        logger.info(f"Instrumented _DataCollection.{method_name}")
                    except Exception as e:
                        logger.warning(f"Failed to instrument _DataCollection.{method_name}: {e}")
                else:
                    logger.debug(f"Method {method_name} not found on _DataCollection")

            # Instrument aggregate over_all (stats) for underscored class
            try:
                if _AggregateCollection is not None and hasattr(_AggregateCollection, "over_all"):
                    self._wrap_method(
                        "weaviate.collections.aggregate",
                        "_AggregateCollection.over_all",
                        self._create_aggregate_over_all_wrapper(),
                    )
                    count += 1
                    logger.info("Instrumented _AggregateCollection.over_all")
            except Exception as e:
                logger.warning(f"Failed to instrument _AggregateCollection.over_all: {e}")

            # Instrument public classes as fallbacks
            if PublicQueryCollection is not None:
                for method_name, wrapper in query_methods:
                    if hasattr(PublicQueryCollection, method_name):
                        try:
                            self._wrap_method(
                                "weaviate.collections.query",
                                f"QueryCollection.{method_name}",
                                wrapper,
                            )
                            count += 1
                            logger.info(f"Instrumented QueryCollection.{method_name}")
                        except Exception as e:
                            logger.warning(
                                f"Failed to instrument QueryCollection.{method_name}: {e}"
                            )
            if PublicDataCollection is not None:
                for method_name, wrapper in data_methods:
                    if hasattr(PublicDataCollection, method_name):
                        try:
                            self._wrap_method(
                                "weaviate.collections.data",
                                f"DataCollection.{method_name}",
                                wrapper,
                            )
                            count += 1
                            logger.info(f"Instrumented DataCollection.{method_name}")
                        except Exception as e:
                            logger.warning(
                                f"Failed to instrument DataCollection.{method_name}: {e}"
                            )
            if PublicAggregateCollection is not None and hasattr(
                PublicAggregateCollection, "over_all"
            ):
                try:
                    self._wrap_method(
                        "weaviate.collections.aggregate",
                        "AggregateCollection.over_all",
                        self._create_aggregate_over_all_wrapper(),
                    )
                    count += 1
                    logger.info("Instrumented AggregateCollection.over_all")
                except Exception as e:
                    logger.warning(f"Failed to instrument AggregateCollection.over_all: {e}")

        except ImportError as e:
            logger.warning(f"Could not import Weaviate v4.x classes: {e}")
        except Exception as e:
            logger.warning(f"Failed to instrument Weaviate v4.x classes: {e}")

        return count

    def _create_near_vector_wrapper(self):
        """Create wrapper for v4 QueryCollection.near_vector (vector search)."""
        return WrapperBase.create_wrapper(
            span_name="weaviate.near_vector",
            span_kind="CLIENT",
            extract_attributes=lambda instance, args, kwargs: self._extract_near_attributes(
                instance, args, kwargs, operation_subtype="near_vector"
            ),
            process_result=self._process_query_result,
        )

    def _create_near_object_wrapper(self):
        """Create wrapper for v4 QueryCollection.near_object (object-based search)."""
        return WrapperBase.create_wrapper(
            span_name="weaviate.near_object",
            span_kind="CLIENT",
            extract_attributes=lambda instance, args, kwargs: self._extract_near_attributes(
                instance, args, kwargs, operation_subtype="near_object"
            ),
            process_result=self._process_query_result,
        )

    def _extract_near_attributes(
        self, instance, args, kwargs, operation_subtype: str
    ) -> Optional[Dict[str, Any]]:
        attrs = self._extract_base_attributes(instance, "vector_search", operation_subtype)

        # top_k/limit
        if "limit" in kwargs:
            attrs["mvk.query_limit"] = kwargs["limit"]
            attrs["mvk.top_k"] = kwargs["limit"]

        # namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # read units baseline
        attrs["mvk.read_units"] = 1.0
        return attrs

    def _create_fetch_by_id_wrapper(self):
        """Create wrapper for v4 DataCollection.fetch_by_id (single fetch)."""
        return WrapperBase.create_wrapper(
            span_name="weaviate.fetch_by_id",
            span_kind="CLIENT",
            extract_attributes=self._extract_fetch_by_id_attributes,
            process_result=self._process_fetch_object_by_id_result,
        )

    def _extract_fetch_by_id_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        attrs = self._extract_base_attributes(instance, "vector_retrieve", "fetch_by_id")

        # UUID first positional or kw
        if args:
            attrs["mvk.object_uuid"] = str(args[0])
        elif "uuid" in kwargs:
            attrs["mvk.object_uuid"] = str(kwargs["uuid"])

        # namespace/tenant
        self._extract_namespace(kwargs, attrs)
        attrs["mvk.read_units"] = 1.0
        return attrs

    def _create_aggregate_over_all_wrapper(self):
        """Create wrapper for v4 AggregateCollection.over_all (stats)."""
        return WrapperBase.create_wrapper(
            span_name="weaviate.aggregate.over_all",
            span_kind="CLIENT",
            extract_attributes=self._extract_aggregate_over_all_attributes,
            process_result=self._process_aggregate_over_all_result,
        )

    def _extract_aggregate_over_all_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        # Treat as vector_stats
        attrs = self._extract_base_attributes(instance, "vector_stats", "aggregate_over_all")
        # Namespace/tenant if present
        self._extract_namespace(kwargs, attrs)
        # Read units baseline
        attrs["mvk.read_units"] = 1.0
        return attrs

    def _process_aggregate_over_all_result(self, span, result) -> None:
        # Mark as aggregate result
        span.set_attribute("mvk.aggregate_result", True)
        # If result contains total_count, set it
        try:
            total = 0
            if hasattr(result, "total_count"):
                total = int(getattr(result, "total_count", 0) or 0)
            elif isinstance(result, dict) and "total_count" in result:
                total = int(result.get("total_count") or 0)
            if total > 0:
                span.set_attribute("mvk.results_count", total)
                span.set_attribute("mvk.record_count", total)
        except Exception as e:
            logger.debug(f"Failed to extract total_count from aggregate result: {e}")
        # Metered usage builder (no special metrics beyond read unit already set)
        builder = MeteredUsageBuilder()
        safe_populate_metered_usage(span, builder)

    def _process_query_result(self, span, result) -> None:
        """Process query result from near_vector, near_object operations.

        This handles results from Weaviate v4 query operations that return
        objects with similarity scores/distances.
        """
        # Handle Weaviate v4.x query result structure
        count = 0

        try:
            if hasattr(result, "objects"):
                # Query returns a result with objects attribute
                objects = result.objects
                if hasattr(objects, "__len__"):
                    count = len(objects)
            elif hasattr(result, "__len__"):
                # Direct list result
                count = len(result)

            if count > 0:
                span.set_attribute("mvk.results_count", count)
                span.set_attribute("mvk.record_count", count)
            else:
                span.set_attribute("mvk.results_count", 0)
                span.set_attribute("mvk.record_count", 0)

            # Extract distance/certainty metrics if available (vector search results)
            if hasattr(result, "objects") and count > 0:
                try:
                    first_obj = result.objects[0]
                    if hasattr(first_obj, "metadata"):
                        metadata = first_obj.metadata
                        if hasattr(metadata, "distance") and metadata.distance is not None:
                            span.set_attribute("mvk.similarity_metric", "distance")
                            span.set_attribute("mvk.top_distance", float(metadata.distance))
                        elif hasattr(metadata, "certainty") and metadata.certainty is not None:
                            span.set_attribute("mvk.similarity_metric", "certainty")
                            span.set_attribute("mvk.top_certainty", float(metadata.certainty))
                except Exception as e:
                    logger.debug(f"Failed to extract similarity metric from query result: {e}")

            # Add metered usage
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=count,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Error processing query result: {e}")
            # Ensure we at least set zero counts on error
            span.set_attribute("mvk.results_count", 0)
            span.set_attribute("mvk.record_count", 0)

    def _instrument_v3(self, weaviate_module):
        """Instrument Weaviate v3.x API."""
        logger.info("Detected Weaviate v3.x, instrumenting v3.x API")

        import importlib

        # Define candidate targets for v3.x
        query_targets = [
            ("weaviate.gql.get", "GetBuilder.do", "query"),
            ("weaviate.gql.aggregate", "AggregateBuilder.do", "aggregate"),
        ]

        data_targets = [
            ("weaviate.data.data_object", "DataObject.create", "create"),
            ("weaviate.data.data_object", "DataObject.update", "update"),
            ("weaviate.data.data_object", "DataObject.delete", "delete"),
            ("weaviate.data.data_object", "DataObject.get", "get"),
        ]

        batch_targets = [
            ("weaviate.batch", "Batch.create_objects"),
        ]

        # Only attempt wrapping when module and class.method actually exist
        def try_wrap(module_path: str, class_dot_method: str, wrapper):
            try:
                module = importlib.import_module(module_path)
                class_name, method_name = class_dot_method.split(".")
                cls = getattr(module, class_name, None)
                if cls is None or not hasattr(cls, method_name):
                    return False
                return self._wrap_method(module_path, class_dot_method, wrapper)
            except Exception:
                return False

        # Queries
        for mod, name, op in query_targets:
            wrapper = self._create_v3_query_wrapper(op)
            try_wrap(mod, name, wrapper)

        # Data operations
        for mod, name, op in data_targets:
            wrapper = self._create_v3_data_wrapper(op)
            try_wrap(mod, name, wrapper)

        # Batch
        for mod, name in batch_targets:
            try_wrap(mod, name, self._create_v3_batch_wrapper())

        logger.info("Weaviate v3.x auto-instrumentation enabled")

    def _extract_collection_name(self, instance: Any) -> Optional[str]:
        """Extract collection name from instance.

        Args:
            instance: Weaviate collection or query instance

        Returns:
            Collection name if available
        """
        # First check registry (from factory method call)
        if instance in _collection_name_registry:
            collection_name = _collection_name_registry[instance]
            if isinstance(collection_name, str):
                logger.debug(f"Found collection name from registry: {collection_name}")
                return collection_name

        # Try different attributes (in order of likelihood)
        for attr in ["_collection", "collection", "_collection_name", "collection_name", "name"]:
            if hasattr(instance, attr):
                try:
                    attr_value = getattr(instance, attr)
                    # If it's an object with a name attribute
                    if hasattr(attr_value, "name"):
                        name = getattr(attr_value, "name")
                        if isinstance(name, str) and name:
                            logger.debug(
                                f"Found collection name from attribute '{attr}.name': {name}"
                            )
                            return name
                    # If it's a string directly
                    elif isinstance(attr_value, str) and attr_value:
                        logger.debug(f"Found collection name from attribute '{attr}': {attr_value}")
                        return attr_value
                except Exception:
                    pass

        # Try checking __dict__ directly
        if hasattr(instance, "__dict__"):
            for key in ["_collection_name", "collection_name", "name", "_name"]:
                if key in instance.__dict__:
                    try:
                        name = instance.__dict__[key]
                        if isinstance(name, str) and name:
                            logger.debug(f"Found collection name from __dict__['{key}']: {name}")
                            return name
                    except Exception:
                        pass

        logger.debug(
            f"Could not extract collection name from instance type: {type(instance).__name__}"
        )
        return None

    def _extract_namespace(self, kwargs: Dict[str, Any], attrs: Dict[str, Any]) -> None:
        """Extract namespace/tenant from kwargs if present.

        Args:
            kwargs: Keyword arguments
            attrs: Attributes dictionary to update
        """
        # Weaviate uses 'tenant' for multi-tenancy
        if "tenant" in kwargs:
            attrs["mvk.namespace"] = kwargs["tenant"]
        elif "namespace" in kwargs:
            attrs["mvk.namespace"] = kwargs["namespace"]

    def _extract_base_attributes(
        self, instance: Any, operation: str, operation_subtype: str
    ) -> Dict[str, Any]:
        """Extract base attributes common to all operations.

        Args:
            instance: Weaviate collection or query instance
            operation: Operation name (e.g., "vector_search")
            operation_subtype: Operation subtype (e.g., "fetch_objects")

        Returns:
            Base attributes dictionary
        """
        attrs: Dict[str, Any] = {
            "mvk.model_provider": "weaviate",
            "mvk.operation": operation,
            "mvk.operation_subtype": operation_subtype,
            "mvk.step_type": MVKStepType.RETRIEVER,
        }

        # Extract collection name
        collection_name = self._extract_collection_name(instance)
        if collection_name:
            attrs["mvk.collection_name"] = collection_name

        return attrs

    def _calculate_payload_size(self, data: Any) -> int:
        """Estimate payload size in bytes.

        Args:
            data: Data to estimate (objects, properties, vectors, etc.)

        Returns:
            Estimated size in bytes
        """
        try:
            if isinstance(data, (list, tuple)):
                # Estimate: each object ~1KB minimum
                return len(data) * 1024
            elif isinstance(data, dict):
                # Estimate from dict size using JSON serialization
                return len(json.dumps(data).encode("utf-8"))
            elif isinstance(data, str):
                return len(data.encode("utf-8"))
            else:
                return sys.getsizeof(data)
        except Exception:
            return 0

    def _extract_vector_dimensions(self, data: Any) -> Optional[int]:
        """Extract vector dimensions from Weaviate object data.

        Args:
            data: Object data (dict, properties, or vector data)

        Returns:
            Total vector dimensions if found, None otherwise
        """
        try:
            total_dims = 0

            # Handle dict (properties object)
            if isinstance(data, dict):
                # Check for direct 'vector' field (single vector or named vectors)
                if "vector" in data:
                    vector = data["vector"]
                    if isinstance(vector, (list, tuple)):
                        # Single vector
                        total_dims += len(vector)
                    elif isinstance(vector, dict):
                        # Named vectors: sum all vector dimensions
                        for vec_name, vec_data in vector.items():
                            if isinstance(vec_data, (list, tuple)):
                                total_dims += len(vec_data)

                # Check for other vector fields (e.g., "vector_1", "vector_2", but skip "vector" already processed)
                for key, value in data.items():
                    if key != "vector" and key.startswith("vector"):
                        if isinstance(value, (list, tuple)):
                            total_dims += len(value)
                        elif isinstance(value, dict):
                            # Nested vector dict
                            for vec_data in value.values():
                                if isinstance(vec_data, (list, tuple)):
                                    total_dims += len(vec_data)

            # Handle list/tuple (direct vector or list of objects)
            elif isinstance(data, (list, tuple)) and len(data) > 0:
                # Check if it's a list of objects or a single vector
                if isinstance(data[0], dict):
                    # List of objects - extract dimensions from each
                    for obj in data:
                        dims = self._extract_vector_dimensions(obj)
                        if dims:
                            total_dims += dims
                else:
                    # Single vector - return its length
                    return len(data)

            if total_dims > 0:
                return total_dims

        except Exception as e:
            logger.debug(f"Error extracting vector dimensions: {e}")
            pass

        return None

    def _create_fetch_objects_wrapper(self):
        """Create wrapper for Weaviate fetch_objects operations (list/search).

        This wrapper tracks object retrieval operations that fetch multiple objects from Weaviate.
        It monitors search parameters like result limits and collection names.
        Essential for understanding data access patterns and search performance in Weaviate.
        """
        return WrapperBase.create_wrapper(
            span_name="weaviate.fetch_objects",
            span_kind="CLIENT",
            extract_attributes=self._extract_fetch_objects_attributes,
            process_result=self._process_fetch_objects_result,
        )

    def _extract_fetch_objects_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from fetch_objects operation."""
        attrs = self._extract_base_attributes(instance, "vector_search", "fetch_objects")

        # Extract limit
        if "limit" in kwargs:
            attrs["mvk.query_limit"] = kwargs["limit"]
            attrs["mvk.top_k"] = kwargs["limit"]

        # Extract offset (pagination)
        if "offset" in kwargs:
            attrs["mvk.query_offset"] = kwargs["offset"]

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # Extract where filter
        if "where" in kwargs or "where_filter" in kwargs:
            attrs["mvk.has_filter"] = True

        # Calculate payload bytes from kwargs
        payload_bytes = self._calculate_payload_size(kwargs)
        if payload_bytes > 0:
            attrs["mvk.payload_bytes"] = payload_bytes

        # Estimate read units (similar to Pinecone: min 0.25 RU, scales with namespace size)
        # For simplicity, use 1 RU per query as baseline
        attrs["mvk.read_units"] = 1.0

        return attrs

    def _process_fetch_objects_result(self, span, result) -> None:
        """Process fetch_objects result."""
        # Handle Weaviate v4.x fetch_objects result structure
        count = 0

        try:
            if hasattr(result, "objects"):
                # fetch_objects returns a result with objects attribute
                objects = result.objects
                if hasattr(objects, "__len__"):
                    count = len(objects)
            elif hasattr(result, "__len__"):
                # Direct list result
                count = len(result)

            if count > 0:
                span.set_attribute("mvk.results_count", count)
                span.set_attribute("mvk.record_count", count)
            else:
                span.set_attribute("mvk.results_count", 0)
                span.set_attribute("mvk.record_count", 0)

            # Add metered usage
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=count,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Error processing Weaviate fetch_objects result: {e}")
            # Set a default count of 0 if we can't determine the actual count
            span.set_attribute("mvk.results_count", 0)
            span.set_attribute("mvk.record_count", 0)
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=0,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)

    def _create_fetch_object_by_id_wrapper(self):
        """Create wrapper for Weaviate fetch_object_by_id operations (get single object).

        This wrapper tracks single object retrieval operations that fetch one object by its UUID.
        It captures the object UUID and collection information for monitoring specific object access.
        Great for tracking individual object lookups and debugging specific object operations.
        """
        return WrapperBase.create_wrapper(
            span_name="weaviate.fetch_object_by_id",
            span_kind="CLIENT",
            extract_attributes=self._extract_fetch_object_by_id_attributes,
            process_result=self._process_fetch_object_by_id_result,
        )

    def _extract_fetch_object_by_id_attributes(
        self, instance, args, kwargs
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from fetch_object_by_id operation."""
        attrs = self._extract_base_attributes(instance, "vector_retrieve", "fetch_object_by_id")

        # Extract UUID
        if args:
            attrs["mvk.object_uuid"] = str(args[0])
        elif "uuid" in kwargs:
            attrs["mvk.object_uuid"] = str(kwargs["uuid"])

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # Estimate read units (~1 RU per fetch)
        attrs["mvk.read_units"] = 1.0

        return attrs

    def _process_fetch_object_by_id_result(self, span, result) -> None:
        """Process fetch_object_by_id result."""
        # fetch_object_by_id returns a single object or None
        if result is not None:
            span.set_attribute("mvk.results_count", 1)
            span.set_attribute("mvk.record_count", 1)
            # Add metered usage
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=1,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)
        else:
            span.set_attribute("mvk.results_count", 0)
            span.set_attribute("mvk.record_count", 0)

    def _create_insert_wrapper(self):
        """Create wrapper for Weaviate insert operations.

        This wrapper tracks object insertion operations that add new objects to Weaviate collections.
        It captures the object UUID and collection information for monitoring data ingestion.
        Perfect for tracking new data additions and understanding insertion patterns.
        """
        return WrapperBase.create_wrapper(
            span_name="weaviate.insert",
            span_kind="CLIENT",
            extract_attributes=self._extract_insert_attributes,
            process_result=self._process_insert_result,
        )

    def _extract_insert_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from insert operation."""
        attrs = self._extract_base_attributes(instance, "vector_upsert", "insert")

        # Extract UUID
        if "uuid" in kwargs:
            attrs["mvk.object_uuid"] = str(kwargs["uuid"])

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # Extract properties/object data for payload size and vector dimensions
        properties_data = None
        if "properties" in kwargs:
            properties_data = kwargs["properties"]
        elif args:
            # First arg might be the properties dict
            properties_data = args[0]

        if properties_data:
            # Calculate payload size
            payload_bytes = self._calculate_payload_size(properties_data)
            attrs["mvk.payload_bytes"] = payload_bytes
            attrs["mvk.record_count"] = 1

            # Extract vector dimensions
            vector_dims = self._extract_vector_dimensions(properties_data)
            if vector_dims:
                attrs["mvk.dimensions"] = vector_dims
                attrs["mvk.vector_dimensions"] = vector_dims

        # Estimate write units (similar to Pinecone: ~1 WU per KB, min 5 WUs)
        payload_bytes = attrs.get("mvk.payload_bytes", 0)
        if payload_bytes > 0:
            write_units = max(5.0, payload_bytes / 1024.0)
            attrs["mvk.write_units"] = write_units

        return attrs

    def _process_insert_result(self, span, result) -> None:
        """Process insert result."""
        # insert returns the inserted object or success indicator
        span.set_attribute("mvk.results_count", 1)
        span.set_attribute("mvk.record_count", 1)

        # Set write_units if not already set
        if "mvk.write_units" not in span.attributes:
            payload_bytes = span.attributes.get("mvk.payload_bytes", 0)
            write_units = max(5.0, payload_bytes / 1024.0) if payload_bytes > 0 else 5.0
            span.set_attribute("mvk.write_units", write_units)

        # Extract vector dimensions from result if not already captured
        if "mvk.dimensions" not in span.attributes and result is not None:
            try:
                # Try to extract dimensions from result object
                if hasattr(result, "properties"):
                    vector_dims = self._extract_vector_dimensions(result.properties)
                elif isinstance(result, dict):
                    vector_dims = self._extract_vector_dimensions(result)
                else:
                    vector_dims = None

                if vector_dims:
                    span.set_attribute("mvk.dimensions", vector_dims)
                    span.set_attribute("mvk.vector_dimensions", vector_dims)
            except Exception:
                pass

        # Add metered usage
        builder = MeteredUsageBuilder()
        collection_name = span.attributes.get("mvk.collection_name")
        namespace = span.attributes.get("mvk.namespace")
        builder.add_vector_db_metrics(
            vectors_processed=1,
            namespace=namespace or collection_name,
        )
        safe_populate_metered_usage(span, builder)

    def _create_replace_wrapper(self):
        """Create wrapper for Weaviate replace operations.

        This wrapper tracks object replacement operations that update existing objects in Weaviate.
        It captures the object UUID and collection information for monitoring data updates.
        Useful for tracking object modifications and understanding update patterns.
        """
        return WrapperBase.create_wrapper(
            span_name="weaviate.replace",
            span_kind="CLIENT",
            extract_attributes=self._extract_replace_attributes,
            process_result=self._process_replace_result,
        )

    def _extract_replace_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from replace operation."""
        attrs = self._extract_base_attributes(instance, "vector_upsert", "replace")

        # Extract UUID
        if "uuid" in kwargs:
            attrs["mvk.object_uuid"] = str(kwargs["uuid"])

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # Extract properties/object data for payload size and vector dimensions
        properties_data = None
        if "properties" in kwargs:
            properties_data = kwargs["properties"]
        elif args:
            properties_data = args[0]

        if properties_data:
            # Calculate payload size
            payload_bytes = self._calculate_payload_size(properties_data)
            attrs["mvk.payload_bytes"] = payload_bytes
            attrs["mvk.record_count"] = 1

            # Extract vector dimensions
            vector_dims = self._extract_vector_dimensions(properties_data)
            if vector_dims:
                attrs["mvk.dimensions"] = vector_dims
                attrs["mvk.vector_dimensions"] = vector_dims

        # Estimate write units (similar to Pinecone: ~1 WU per KB, min 5 WUs)
        payload_bytes = attrs.get("mvk.payload_bytes", 0)
        if payload_bytes > 0:
            write_units = max(5.0, payload_bytes / 1024.0)
            attrs["mvk.write_units"] = write_units

        return attrs

    def _process_replace_result(self, span, result) -> None:
        """Process replace result."""
        # replace returns the updated object or success indicator
        span.set_attribute("mvk.results_count", 1)
        span.set_attribute("mvk.record_count", 1)

        # Extract vector dimensions from result if not already captured
        if "mvk.dimensions" not in span.attributes and result is not None:
            try:
                # Try to extract dimensions from result object
                if hasattr(result, "properties"):
                    vector_dims = self._extract_vector_dimensions(result.properties)
                elif isinstance(result, dict):
                    vector_dims = self._extract_vector_dimensions(result)
                else:
                    vector_dims = None

                if vector_dims:
                    span.set_attribute("mvk.dimensions", vector_dims)
                    span.set_attribute("mvk.vector_dimensions", vector_dims)
            except Exception:
                pass

        # Set write_units if not already set
        if "mvk.write_units" not in span.attributes:
            payload_bytes = span.attributes.get("mvk.payload_bytes", 0)
            write_units = max(5.0, payload_bytes / 1024.0) if payload_bytes > 0 else 5.0
            span.set_attribute("mvk.write_units", write_units)

        # Add metered usage
        builder = MeteredUsageBuilder()
        collection_name = span.attributes.get("mvk.collection_name")
        namespace = span.attributes.get("mvk.namespace")
        builder.add_vector_db_metrics(
            vectors_processed=1,
            namespace=namespace or collection_name,
        )
        safe_populate_metered_usage(span, builder)

    def _create_delete_wrapper(self):
        """Create wrapper for Weaviate delete_by_id operations.

        This wrapper tracks object deletion operations that remove objects from Weaviate collections.
        It captures the object UUID and collection information for monitoring data cleanup.
        Important for understanding data lifecycle and deletion patterns in Weaviate.
        """
        return WrapperBase.create_wrapper(
            span_name="weaviate.delete_by_id",
            span_kind="CLIENT",
            extract_attributes=self._extract_delete_attributes,
            process_result=self._process_delete_result,
        )

    def _extract_delete_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from delete_by_id operation."""
        attrs = self._extract_base_attributes(instance, "vector_delete", "delete_by_id")

        # Extract UUID
        if args:
            attrs["mvk.object_uuid"] = str(args[0])
        elif "uuid" in kwargs:
            attrs["mvk.object_uuid"] = str(kwargs["uuid"])

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        attrs["mvk.record_count"] = 1

        # Estimate write units (min 5 WUs for delete)
        attrs["mvk.write_units"] = 5.0

        return attrs

    def _process_delete_result(self, span, result) -> None:
        """Process delete_by_id result."""
        # delete_by_id returns success indicator
        span.set_attribute("mvk.results_count", 1)
        span.set_attribute("mvk.record_count", 1)
        # Add metered usage
        builder = MeteredUsageBuilder()
        collection_name = span.attributes.get("mvk.collection_name")
        builder.add_vector_db_metrics(
            vectors_processed=1,
            namespace=collection_name,
        )
        safe_populate_metered_usage(span, builder)

    # v3.x wrapper methods for backward compatibility
    def _create_v3_query_wrapper(self, operation_type: str):
        """Create wrapper for Weaviate v3.x query operations."""
        return WrapperBase.create_wrapper(
            span_name=f"weaviate.{operation_type}",
            span_kind="CLIENT",
            extract_attributes=lambda instance, args, kwargs: self._extract_v3_query_attributes(
                instance, args, kwargs, operation_type
            ),
            process_result=self._process_v3_query_result,
        )

    def _extract_v3_query_attributes(
        self, instance, args, kwargs, operation_type: str
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from v3.x query operation."""
        attrs = self._extract_base_attributes(instance, "vector_search", operation_type)

        # Try to extract class name from the query builder
        if hasattr(instance, "_class_name"):
            class_name = instance._class_name
            if isinstance(class_name, str):
                attrs["mvk.collection_name"] = class_name
        elif hasattr(instance, "class_name"):
            class_name = instance.class_name
            if isinstance(class_name, str):
                attrs["mvk.collection_name"] = class_name

        # Extract namespace/tenant from kwargs if present
        self._extract_namespace(kwargs, attrs)

        # Extract query details if available
        if hasattr(instance, "_properties"):
            attrs["mvk.properties_count"] = len(instance._properties)

        if hasattr(instance, "_where"):
            attrs["mvk.has_filter"] = True

        if hasattr(instance, "_limit"):
            attrs["mvk.query_limit"] = instance._limit
            attrs["mvk.top_k"] = instance._limit

        # Calculate payload size from query builder state
        payload_bytes = self._calculate_payload_size(kwargs)
        if payload_bytes > 0:
            attrs["mvk.payload_bytes"] = payload_bytes

        # Estimate read units (similar to Pinecone: min 0.25 RU, baseline 1 RU)
        attrs["mvk.read_units"] = 1.0

        return attrs

    def _process_v3_query_result(self, span, result) -> None:
        """Process v3.x query result."""
        count = 0

        try:
            if result:
                # Count results from v3.x structure
                if isinstance(result, dict):
                    if "data" in result:
                        data = result["data"]
                        if "Get" in data:
                            for class_name, objects in data["Get"].items():
                                count = len(objects)
                                break
                        elif "Aggregate" in data:
                            count = 1  # Aggregate returns single result
                            span.set_attribute("weaviate.aggregate_result", True)
                elif hasattr(result, "__len__"):
                    count = len(result)

            if count > 0:
                span.set_attribute("mvk.results_count", count)
                span.set_attribute("mvk.record_count", count)
            else:
                span.set_attribute("mvk.results_count", 0)
                span.set_attribute("mvk.record_count", 0)

            # Add metered usage
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=count,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Error processing Weaviate v3.x query result: {e}")
            # Set a default count of 0 if we can't determine the actual count
            span.set_attribute("mvk.results_count", 0)
            span.set_attribute("mvk.record_count", 0)
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            builder.add_vector_db_metrics(
                vectors_retrieved=0,
                namespace=collection_name,
            )
            safe_populate_metered_usage(span, builder)

    def _create_v3_data_wrapper(self, operation: str):
        """Create wrapper for Weaviate v3.x data operations."""
        return WrapperBase.create_wrapper(
            span_name=f"weaviate.data.{operation}",
            span_kind="CLIENT",
            extract_attributes=lambda instance, args, kwargs: self._extract_v3_data_attributes(
                instance, args, kwargs, operation
            ),
            process_result=lambda span, result: self._process_v3_data_result(
                span, result, operation
            ),
        )

    def _extract_v3_data_attributes(
        self, instance, args, kwargs, operation: str
    ) -> Optional[Dict[str, Any]]:
        """Extract attributes from v3.x data operation."""
        operation_type = (
            "vector_upsert"
            if operation in ["create", "update"]
            else "vector_retrieve" if operation == "get" else "vector_delete"
        )
        attrs = self._extract_base_attributes(instance, operation_type, operation)

        # Extract class name
        class_name = kwargs.get("class_name")
        if not class_name and args:
            # Positional arguments vary by method
            if operation in ["create", "update"]:
                class_name = args[1] if len(args) > 1 else None
            elif operation == "get":
                class_name = args[0] if args else None

        if class_name:
            attrs["mvk.collection_name"] = class_name

        # Extract UUID for operations that use it
        if operation in ["update", "delete", "get"]:
            uuid = kwargs.get("uuid")
            if not uuid and args:
                uuid = args[0] if args else None
            if uuid:
                attrs["mvk.object_uuid"] = str(uuid)

        # Extract namespace/tenant
        self._extract_namespace(kwargs, attrs)

        # Extract payload size for write operations
        if operation in ["create", "update"]:
            data_object = None
            if "data_object" in kwargs:
                data_object = kwargs["data_object"]
            elif args and len(args) > 0:
                data_object = args[0]

            if data_object:
                # Calculate payload size
                payload_bytes = self._calculate_payload_size(data_object)
                attrs["mvk.payload_bytes"] = payload_bytes
                attrs["mvk.record_count"] = 1

                # Extract vector dimensions
                vector_dims = self._extract_vector_dimensions(data_object)
                if vector_dims:
                    attrs["mvk.dimensions"] = vector_dims
                    attrs["mvk.vector_dimensions"] = vector_dims

                # Estimate write units
                if payload_bytes > 0:
                    write_units = max(5.0, payload_bytes / 1024.0)
                    attrs["mvk.write_units"] = write_units
        elif operation == "delete":
            attrs["mvk.record_count"] = 1
            attrs["mvk.write_units"] = 5.0
        elif operation == "get":
            # Estimate read units for get
            attrs["mvk.read_units"] = 1.0

        return attrs

    def _process_v3_data_result(self, span, result, operation: str) -> None:
        """Process v3.x data operation result."""
        count = 0

        try:
            if result:
                if isinstance(result, dict):
                    # Track if operation succeeded
                    if "id" in result:
                        span.set_attribute("weaviate.object_id", result["id"])

                    # Extract vector dimensions from result
                    if "vector" in result:
                        vector = result["vector"]
                        if isinstance(vector, (list, tuple)):
                            span.set_attribute("mvk.dimensions", len(vector))
                            span.set_attribute("mvk.vector_dimensions", len(vector))
                        # Also keep legacy attribute for compatibility
                        span.set_attribute(
                            "weaviate.vector_dims",
                            len(vector) if isinstance(vector, (list, tuple)) else 0,
                        )

                    # Try to extract dimensions from full object if not found
                    if "mvk.dimensions" not in span.attributes:
                        vector_dims = self._extract_vector_dimensions(result)
                        if vector_dims:
                            span.set_attribute("mvk.dimensions", vector_dims)
                            span.set_attribute("mvk.vector_dimensions", vector_dims)

                    count = 1
                elif hasattr(result, "__len__"):
                    count = len(result)
                else:
                    count = 1

            if count > 0:
                span.set_attribute("mvk.results_count", count)
                span.set_attribute("mvk.record_count", count)
                # Add metered usage
                builder = MeteredUsageBuilder()
                collection_name = span.attributes.get("mvk.collection_name")
                namespace = span.attributes.get("mvk.namespace")
                if operation in ["create", "update"]:
                    builder.add_vector_db_metrics(
                        vectors_processed=count,
                        namespace=namespace or collection_name,
                    )
                else:
                    builder.add_vector_db_metrics(
                        vectors_retrieved=count,
                        namespace=namespace or collection_name,
                    )
                safe_populate_metered_usage(span, builder)
            else:
                span.set_attribute("mvk.results_count", 0)
                span.set_attribute("mvk.record_count", 0)

        except Exception as e:
            logger.debug(f"Error processing Weaviate v3.x data result: {e}")
            # Set a default count based on operation
            span.set_attribute("mvk.results_count", 1)
            span.set_attribute("mvk.record_count", 1)
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            namespace = span.attributes.get("mvk.namespace")
            if operation in ["create", "update"]:
                builder.add_vector_db_metrics(
                    vectors_processed=1,
                    namespace=namespace or collection_name,
                )
            else:
                builder.add_vector_db_metrics(
                    vectors_retrieved=1,
                    namespace=namespace or collection_name,
                )
            safe_populate_metered_usage(span, builder)

    def _create_v3_batch_wrapper(self):
        """Create wrapper for Weaviate v3.x batch operations."""
        return WrapperBase.create_wrapper(
            span_name="weaviate.batch.create",
            span_kind="CLIENT",
            extract_attributes=self._extract_v3_batch_attributes,
            process_result=self._process_v3_batch_result,
        )

    def _extract_v3_batch_attributes(self, instance, args, kwargs) -> Optional[Dict[str, Any]]:
        """Extract attributes from v3.x batch operation."""
        attrs = self._extract_base_attributes(instance, "vector_upsert", "batch_create")

        # Count objects in batch
        objects = args[0] if args else kwargs.get("objects", [])
        if objects:
            batch_size = len(objects)
            attrs["mvk.batch_size"] = batch_size
            attrs["mvk.record_count"] = batch_size

            # Calculate payload size
            payload_bytes = self._calculate_payload_size(objects)
            attrs["mvk.payload_bytes"] = payload_bytes

            # Extract vector dimensions for each object and sum them
            total_vector_dims = 0
            for obj in objects:
                if isinstance(obj, dict):
                    vector_dims = self._extract_vector_dimensions(obj)
                    if vector_dims:
                        total_vector_dims += vector_dims

                    # Get class name from first object if available
                    if obj == objects[0]:
                        if "class" in obj:
                            attrs["mvk.collection_name"] = obj["class"]
                        # Extract namespace/tenant from first object if present
                        if "tenant" in obj:
                            attrs["mvk.namespace"] = obj["tenant"]

            # Set total vector dimensions (sum of all objects)
            if total_vector_dims > 0:
                attrs["mvk.dimensions"] = total_vector_dims
                attrs["mvk.vector_dimensions"] = total_vector_dims

        # Estimate write units (similar to Pinecone: ~1 WU per KB, min 5 WUs)
        payload_bytes = attrs.get("mvk.payload_bytes", 0)
        if payload_bytes > 0:
            write_units = max(5.0, payload_bytes / 1024.0)
            attrs["mvk.write_units"] = write_units

        return attrs

    def _process_v3_batch_result(self, span, result) -> None:
        """Process v3.x batch result."""
        count = 0

        try:
            if result:
                if isinstance(result, list):
                    count = len(result)
                    span.set_attribute("mvk.results_count", count)
                    span.set_attribute("mvk.record_count", count)

                    # Count successes and failures
                    success_count = sum(
                        1 for r in result if r.get("result", {}).get("status") == "SUCCESS"
                    )
                    failure_count = count - success_count

                    span.set_attribute("mvk.batch_success_count", success_count)
                    if failure_count > 0:
                        span.set_attribute("mvk.batch_failure_count", failure_count)

                    # Extract vector dimensions from successful results if not already captured
                    if "mvk.dimensions" not in span.attributes:
                        total_dims = 0
                        for r in result:
                            if isinstance(r, dict):
                                # Check if result contains object data
                                obj_data = r.get("object") or r.get("properties") or r
                                vector_dims = self._extract_vector_dimensions(obj_data)
                                if vector_dims:
                                    total_dims += vector_dims
                        if total_dims > 0:
                            span.set_attribute("mvk.dimensions", total_dims)
                            span.set_attribute("mvk.vector_dimensions", total_dims)

                    # Add metered usage
                    builder = MeteredUsageBuilder()
                    collection_name = span.attributes.get("mvk.collection_name")
                    namespace = span.attributes.get("mvk.namespace")
                    builder.add_vector_db_metrics(
                        vectors_processed=count,
                        namespace=namespace or collection_name,
                    )
                    safe_populate_metered_usage(span, builder)
                else:
                    count = 1
                    span.set_attribute("mvk.results_count", count)
                    span.set_attribute("mvk.record_count", count)
                    builder = MeteredUsageBuilder()
                    collection_name = span.attributes.get("mvk.collection_name")
                    namespace = span.attributes.get("mvk.namespace")
                    builder.add_vector_db_metrics(
                        vectors_processed=count,
                        namespace=namespace or collection_name,
                    )
                    safe_populate_metered_usage(span, builder)

        except Exception as e:
            logger.debug(f"Error processing Weaviate v3.x batch result: {e}")
            # Set a default count of 1
            span.set_attribute("mvk.results_count", 1)
            span.set_attribute("mvk.record_count", 1)
            builder = MeteredUsageBuilder()
            collection_name = span.attributes.get("mvk.collection_name")
            namespace = span.attributes.get("mvk.namespace")
            builder.add_vector_db_metrics(
                vectors_processed=1,
                namespace=namespace or collection_name,
            )
            safe_populate_metered_usage(span, builder)
