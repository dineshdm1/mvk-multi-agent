"""
Configuration Schema for MVK SDK v1.1

This module provides configuration loading logic using the centralized config registry package.
Configuration definitions are maintained in config_registry.registry.py for better maintainability.

⚠️  IMPORTANT: Configuration definitions are maintained in config_registry.registry.py
    This file contains only the loading logic and helper functions.
    Do not modify configuration parameters here - use config_registry.registry.py instead.

Features:
- Handles type conversion and validation
- Manages precedence (env vars > function params > defaults)
- Auto-generates documentation
- Uses centralized registry for configuration definitions

Industry Best Practices:
- OpenTelemetry SDK: Centralized environment variable registry
- AWS SDK: Clear hierarchical precedence
- Pydantic: Type safety and validation
"""

import logging
import os
from typing import Any, Dict, List, Optional

# Import configuration definitions from centralized config registry package
from .config_registry.registry import (
    ALLOWED_WRAPPERS,
    CONFIG_SCHEMA,
    WRAPPER_DEFINITIONS,
    ConfigParameter,
    generate_documentation_table,
    generate_wrapper_documentation,
    get_all_wrappers,
    get_registry_info,
    get_wrapper_info,
    validate_wrapper,
)

logger = logging.getLogger(__name__)


# ============================================================================
# CONFIGURATION LOADING LOGIC - USES CENTRALIZED REGISTRY
# ============================================================================

# Configuration schema is now imported from config_registry.registry.py


# Wrapper definitions are now imported from config_registry.registry.py

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def _set_nested_value(d: Dict[str, Any], path: str, value: Any) -> None:
    """
    Set a value in a nested dict using dot notation with square bracket support.

    Args:
        d: Dictionary to modify
        path: Dot-separated path (e.g., "exporter.timeout" or "[service.instance.id]")
        value: Value to set

    Example:
        >>> config = {}
        >>> _set_nested_value(config, "exporter.timeout", 30)
        >>> config
        {'exporter': {'timeout': 30}}
    """
    # Handle square bracket notation for keys that contain dots
    keys = []

    # First, handle square brackets that span multiple dot-separated parts
    if ".[" in path and "]" in path:
        # Find the start and end of square bracket content
        start_bracket = path.find("[")
        end_bracket = path.rfind("]")

        if start_bracket != -1 and end_bracket != -1:
            # Split into parts before, inside, and after brackets
            before_brackets = path[:start_bracket].rstrip(".")
            inside_brackets = path[start_bracket + 1 : end_bracket]
            after_brackets = path[end_bracket + 1 :].lstrip(".")

            # Add parts before brackets
            if before_brackets:
                keys.extend(before_brackets.split("."))

            # Add parts inside brackets
            keys.extend(inside_brackets.split("."))

            # Add parts after brackets
            if after_brackets:
                keys.extend(after_brackets.split("."))
        else:
            # Fallback to regular dot splitting
            keys = path.split(".")
    else:
        # Regular dot splitting
        keys = path.split(".")

    for key in keys[:-1]:
        if key not in d or not isinstance(d[key], dict):
            d[key] = {}
        d = d[key]
    d[keys[-1]] = value


def _get_nested_value(d: Dict[str, Any], path: str) -> Any:
    """
    Get a value from a nested dict using dot notation with square bracket support.

    Args:
        d: Dictionary to read from
        path: Dot-separated path (e.g., "exporter.timeout" or "[service.instance.id]")

    Returns:
        The value at the path, or None if not found

    Example:
        >>> config = {'exporter': {'timeout': 30}}
        >>> _get_nested_value(config, "exporter.timeout")
        30
    """
    # Handle square bracket notation for keys that contain dots
    keys = []

    # First, handle square brackets that span multiple dot-separated parts
    if ".[" in path and "]" in path:
        # Find the start and end of square bracket content
        start_bracket = path.find("[")
        end_bracket = path.rfind("]")

        if start_bracket != -1 and end_bracket != -1:
            # Split into parts before, inside, and after brackets
            before_brackets = path[:start_bracket].rstrip(".")
            inside_brackets = path[start_bracket + 1 : end_bracket]
            after_brackets = path[end_bracket + 1 :].lstrip(".")

            # Add parts before brackets
            if before_brackets:
                keys.extend(before_brackets.split("."))

            # Add parts inside brackets
            keys.extend(inside_brackets.split("."))

            # Add parts after brackets
            if after_brackets:
                keys.extend(after_brackets.split("."))
        else:
            # Fallback to regular dot splitting
            keys = path.split(".")
    else:
        # Regular dot splitting
        keys = path.split(".")

    for key in keys:
        if not isinstance(d, dict) or key not in d:
            return None
        d = d[key]
    return d


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries, with override taking precedence.

    Args:
        base: Base dictionary
        override: Override dictionary (takes precedence)

    Returns:
        Merged dictionary

    Example:
        >>> base = {'a': 1, 'b': {'c': 2}}
        >>> override = {'b': {'d': 3}}
        >>> _deep_merge(base, override)
        {'a': 1, 'b': {'c': 2, 'd': 3}}
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _convert_type(value: str, target_type: type) -> Any:
    """
    Convert string value to target type.

    Args:
        value: String value from environment variable
        target_type: Target Python type

    Returns:
        Converted value

    Example:
        >>> _convert_type("true", bool)
        True
        >>> _convert_type("42", int)
        42
    """
    if target_type == bool:
        return value.lower() in ("1", "true", "yes", "on")
    elif target_type == int:
        return int(value)
    elif target_type == float:
        return float(value)
    else:
        return value


def _load_tags(tags: Optional[Dict[str, str]]) -> Dict[str, str]:
    """
    Load tags from both function parameter and MVK_TAG_* env vars.

    Environment variables have higher priority and override function tags.

    Args:
        tags: Tags from function parameter

    Returns:
        Merged tags dictionary

    Example:
        >>> os.environ['MVK_TAG_ENV'] = 'prod'
        >>> _load_tags({'env': 'dev', 'region': 'us-east-1'})
        {'env': 'prod', 'region': 'us-east-1'}  # env overridden by MVK_TAG_ENV
    """
    merged_tags = (tags or {}).copy()

    # Load all MVK_TAG_* environment variables
    for key, value in os.environ.items():
        if key.startswith("MVK_TAG_"):
            tag_name = key[8:].lower()  # Remove MVK_TAG_ prefix and lowercase
            if tag_name in merged_tags:
                logger.debug(
                    f"MVK TAG OVERRIDE: Function tag '{tag_name}' overridden by "
                    f"environment variable {key}"
                )
            merged_tags[tag_name] = value

    return merged_tags


def _load_wrappers(
    wrappers: Optional[List[str]], config_wrappers_include: Optional[List[str]] = None
) -> List[str]:
    """
    Load wrappers from env var or function parameter with validation.

    Args:
        wrappers: Wrappers from function parameter

    Returns:
        Final wrappers list (only allowed wrappers)

    Example:
        >>> os.environ['MVK_WRAPPERS'] = 'genai,vectordb'
        >>> _load_wrappers(None)
        ['genai', 'vectordb']
    """

    def validate_wrappers(wrapper_list: List[str], source: str) -> List[str]:
        """Validate wrappers against allowed list and log warnings for unknown values."""
        valid_wrappers = []
        for wrapper in wrapper_list:
            if wrapper in ALLOWED_WRAPPERS:
                valid_wrappers.append(wrapper)
            else:
                logger.warning(
                    f"Unknown wrapper '{wrapper}' from {source} is not in allowed list "
                    f"{sorted(ALLOWED_WRAPPERS)}. This wrapper will be ignored."
                )
        return valid_wrappers

    env_wrappers = os.getenv("MVK_WRAPPERS")
    if env_wrappers:
        wrappers_list = [w.strip() for w in env_wrappers.split(",") if w.strip()]
        validated_wrappers = validate_wrappers(wrappers_list, "environment variable MVK_WRAPPERS")
        if wrappers is not None:
            logger.debug(
                f"MVK WRAPPERS OVERRIDE: Function wrappers {wrappers} overridden by "
                f"environment MVK_WRAPPERS={validated_wrappers}"
            )
        return validated_wrappers

    if wrappers is not None:
        return validate_wrappers(wrappers, "function parameter")

    # If not provided as a separate function param, allow config-style
    if config_wrappers_include is not None:
        return validate_wrappers(list(config_wrappers_include), "config wrappers.include")

    # Default wrappers from schema
    default_wrappers = CONFIG_SCHEMA["wrappers"].default
    if isinstance(default_wrappers, list):
        return default_wrappers
    else:
        # Fallback to empty list if default is not a list
        return []


# ============================================================================
# CONFIGURATION LOADER - SCHEMA-DRIVEN WITH CLEAR PRECEDENCE
# ============================================================================


def _normalize_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize configuration to unified structure per DESIGN_RATIONALE.md.

    This function handles the simplified configuration structure where all
    settings are at the root level with logical groupings (exporter.*, batching.*, etc.).

    Example:
        >>> _normalize_config({"api_key": "test", "exporter": {"timeout": 30}})
        {"api_key": "test", "exporter": {"timeout": 30}}
    """
    if not config:
        return config

    # For the simplified design, we just pass through the config as-is
    # since the schema already defines the correct structure
    return config


# Documentation functions are now imported from config_registry.registry.py
