"""Unified schema validator for MVK SDK v1.1 with OTLP compliance.

This module provides centralized validation for all spans, ensuring compliance
with both MVK schema requirements and OTLP v1 specifications. Supports strict
and lenient validation modes, proper ID format validation, timestamp conversion,
attribute namespacing, and metered_usage validation.
"""

import json
import logging
import os
import re
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple, Union

logger = logging.getLogger("mvk.schema")


def get_tag_limit() -> int:
    """Get the configured tag limit for spans.

    Returns the user-configured tag limit (1-10) or SDK default (10).
    The SDK enforces a maximum of 10 tags regardless of user configuration.

    Returns:
        int: The maximum number of tags allowed per span (1-10)
    """
    try:
        from .instrument import _effective_config

        if _effective_config:
            # Get tag_limit from config, with fallback to SDK default
            tag_limit = _effective_config.get("tag_limit", SDK_MAX_TAGS)
            # Ensure it doesn't exceed SDK maximum
            return min(max(1, int(tag_limit)), SDK_MAX_TAGS)
    except (ImportError, KeyError, TypeError, ValueError):
        pass

    # Fallback to SDK default if configuration not available
    return SDK_MAX_TAGS


# Tag validation regex (v1.1 - dots allowed in keys)
TAG_KEY_PATTERN = re.compile(r"^[a-z0-9._-]{1,64}$")  # v1.1: dots allowed, 64 chars
TAG_VALUE_PATTERN = re.compile(r"^.{1,256}$")  # v1.1: any chars, 256 max
SDK_MAX_TAGS = 10  # SDK-enforced maximum, cannot be exceeded

# OTLP validation patterns
TRACE_ID_PATTERN = re.compile(r"^[0-9a-f]{32}$")  # 32 hex chars
SPAN_ID_PATTERN = re.compile(r"^[0-9a-f]{16}$")  # 16 hex chars

# OTLP limits
MAX_ATTRIBUTES = 128
MAX_STRING_LENGTH = 8192
MAX_ARRAY_LENGTH = 128
MAX_EVENTS = 128
MAX_LINKS = 128
MAX_SPAN_NAME_LENGTH = 256

# OTLP SpanKind enum values
OTLP_SPAN_KINDS = {
    "SPAN_KIND_UNSPECIFIED",
    "SPAN_KIND_INTERNAL",
    "SPAN_KIND_SERVER",
    "SPAN_KIND_CLIENT",
    "SPAN_KIND_PRODUCER",
    "SPAN_KIND_CONSUMER",
}

# OTLP StatusCode enum values
OTLP_STATUS_CODES = {"STATUS_CODE_UNSET", "STATUS_CODE_OK", "STATUS_CODE_ERROR"}


# MVK semantic step types (v1.1 - active step types only)
class MVKStepType(str, Enum):
    """MVK semantic step types for v1.1.

    These represent the type of operation being performed,
    stored in the 'mvk.step_type' attribute. This is separate
    from OpenTelemetry's SpanKind (CLIENT, SERVER, etc.).

    v1.1: LLM, EMBEDDING, RETRIEVER, and TOOL are active.
    TOOL, MEMORY and AGENT_CALL are reserved but not active.
    """

    LLM = "LLM"
    EMBEDDING = "EMBEDDING"
    RETRIEVER = "RETRIEVER"
    TOOL = "TOOL"
    # Reserved for future use
    MEMORY = "MEMORY"  # Reserved
    AGENT_CALL = "AGENT_CALL"  # Reserved


# v1.1 active step types (LLM, EMBEDDING, RETRIEVER, and TOOL are active)
ACTIVE_STEP_TYPES = {
    MVKStepType.LLM,
    MVKStepType.EMBEDDING,
    MVKStepType.RETRIEVER,
    MVKStepType.TOOL,
}
RESERVED_STEP_TYPES = {
    MVKStepType.MEMORY,
    MVKStepType.AGENT_CALL,
}


# Required fields for all spans according to OTLP v1.1 schema
REQUIRED_FIELDS = {
    "trace_id",
    "span_id",
    "name",
    "kind",  # OTLP SpanKind (CLIENT, SERVER, etc.)
    "start_time_unix_nano",
    "end_time_unix_nano",
    "status",  # Status object with code
    "attributes",  # All MVK fields go in attributes
}

# Field type validators
FIELD_TYPES = {
    # OTEL core
    "trace_id": str,
    "span_id": str,
    "parent_span_id": str,  # Now required, not optional
    "start_time_unix_nano": (int, float),  # v1.0: OTLP field name
    "end_time_unix_nano": (int, float),  # v1.0: OTLP field name
    "mvk.duration_ms": (int, float),  # MVK-specific duration metric
    "status_code": int,
    "status_message": str,
    # Service identity (v1.1)
    "service.namespace": str,
    "service.instance.id": str,
    # MVK context (v1.1)
    "mvk.agent_id": str,  # v1.0: Required agent ID from config
    "mvk.agent_name": str,  # Optional agent name
    "mvk.session_id": str,
    "mvk.user_id": str,  # v1.0: with mvk_ prefix for consistency
    "mvk.client_id": str,  # v1.0: with mvk_ prefix for consistency
    "mvk.cloud_provider_code": str,  # Optional, user-provided
    "mvk.model_provider": str,  # v1.0: model_provider not model_provider_code
    "mvk.sdk_version": str,  # v1.0: SDK version field
    # Operation
    "kind": str,  # v1.0: OTLP SpanKind as string enum
    "mvk.step_type": str,  # v1.0: step_type not span.kind per schema
    "name": str,
    "mvk.operation": str,  # v1.0: with mvk_ prefix
    "mvk.operation_subtype": str,  # v1.0: with mvk_ prefix
    # Model fields (v3.0: with mvk_ prefix)
    "mvk.model_name": str,
    "mvk.model_family": str,
    "mvk.model_type": str,
    "mvk.model_version": str,
    # Request metrics (v3.0: with mvk_ prefix)
    "mvk.prompt_tokens": int,
    "mvk.completion_tokens": int,
    "mvk.total_tokens": int,
    "mvk.embeddings_count": int,
    "mvk.embedding_dims": int,
    "mvk.total_images": int,
    "mvk.image_size": str,
    "mvk.total_characters": int,
    # Audio/Video/Image token metrics
    "mvk.audio_input_seconds": (int, float),
    "mvk.audio_output_seconds": (int, float),
    "mvk.video_input_seconds": (int, float),
    "mvk.video_output_seconds": (int, float),
    "mvk.image_input_count": int,
    "mvk.image_input_pixels": int,
    # Retriever / Vector DB
    "mvk.vectordb_provider": str,
    "mvk.vectordb_index": str,
    "mvk.vectordb_match_count": int,
    # Tool fields
    "mvk.tool_name": str,
    "mvk.tool_provider": str,
    # Memory
    "mvk.memory_op": str,
    "mvk.bytes_read": int,
    "mvk.bytes_written": int,
    # Latency
    "mvk.time_to_first_token_ms": (int, float),
    "mvk.e2e_latency_ms": (int, float),
    # Streaming
    "mvk.stream_enabled": bool,
    # Vendor info
    "mvk.vendor_name": str,
    "mvk.vendor_sdk": str,
    # Tags and vendor
    "mvk.tags": (dict, str),  # v1.0: JSON string or dict - flattened to mvk.tags.*
    "mvk.vendor_attributes": (dict, str),  # JSON string or dict
    "events": (list, str),  # OTLP standard
    "mvk.metered_usage": (list, str),  # v1.0: metered_usage array
}

# Allowed attributes per MVK step type (v1.1: LLM, EMBEDDING, RETRIEVER, and TOOL active)
MVK_STEP_TYPE_ATTRIBUTES = {
    MVKStepType.LLM: {
        "mvk.model_name",
        "mvk.model_family",
        "mvk.model_type",
        "mvk.model_version",
        "mvk.model_provider",
        "mvk.prompt_tokens",
        "mvk.completion_tokens",
        "mvk.total_tokens",
        "mvk.time_to_first_token_ms",
        "mvk.duration_ms",
        "mvk.stream_enabled",
        "mvk.operation",
        "mvk.operation_subtype",
        "mvk.vendor_name",
        "mvk.vendor_sdk",
        "mvk.metered_usage",
        "mvk.vendor_attributes",
        # Audio/Video/Image token attributes
        "mvk.audio_input_seconds",
        "mvk.audio_output_seconds",
        "mvk.video_input_seconds",
        "mvk.video_output_seconds",
        "mvk.image_input_count",
        "mvk.image_input_pixels",
    },
    MVKStepType.EMBEDDING: {
        "mvk.model_name",
        "mvk.model_family",
        "mvk.model_type",
        "mvk.model_version",
        "mvk.model_provider",
        "mvk.prompt_tokens",
        "mvk.total_tokens",
        "mvk.duration_ms",
        "mvk.operation",
        "mvk.vendor_name",
        "mvk.vendor_sdk",
        "mvk.metered_usage",
        "mvk.embeddings_count",
        "mvk.embedding_dims",
    },
    MVKStepType.RETRIEVER: {
        "mvk.vectordb_provider",
        "mvk.vectordb_index",
        "mvk.vectordb_match_count",
        "mvk.operation",
        "mvk.operation_subtype",
        "mvk.duration_ms",
        "mvk.vendor_name",
        "mvk.vendor_sdk",
    },
    MVKStepType.TOOL: {
        "mvk.tool_name",
        "mvk.tool_provider",
        "mvk.operation",
        "mvk.operation_subtype",
        "mvk.duration_ms",
    },
    # v1.1: Reserved types not active yet
    MVKStepType.MEMORY: {"mvk.operation"},
    MVKStepType.AGENT_CALL: {"mvk.operation"},
}


def merge_tags_with_limit(
    *tag_dicts: Dict[str, Any], source_names: Optional[List[str]] = None
) -> Dict[str, str]:
    """Merge multiple tag dictionaries with configurable tag limit enforcement.

    Tag priority: later dictionaries override earlier ones.
    If merged result exceeds the configured limit, logs warning with discarded tags.

    Args:
        *tag_dicts: Variable number of tag dictionaries to merge (lowest to highest priority)
        source_names: Optional list of source names for better warning messages

    Returns:
        Merged and validated tags (max configured limit, default 10)
    """
    if not tag_dicts:
        return {}

    # Get the configured tag limit
    tag_limit = get_tag_limit()

    # Merge all tag dicts (later ones override earlier)
    merged = {}
    for tag_dict in tag_dicts:
        if tag_dict and isinstance(tag_dict, dict):
            merged.update(tag_dict)

    # If within limit, validate and return
    if len(merged) <= tag_limit:
        valid_tags, errors = validate_tags(merged)
        if errors:
            logger.warning(f"Tag validation errors: {errors}")
        return valid_tags

    # Exceeds limit - take first N tags and log warning
    all_keys = list(merged.keys())
    kept_keys = all_keys[:tag_limit]
    discarded_keys = all_keys[tag_limit:]

    kept_tags = {k: merged[k] for k in kept_keys}

    # Log warning with helpful information
    source_info = f" from {', '.join(source_names)}" if source_names else ""
    logger.warning(
        f"Tag limit exceeded: {len(merged)} tags provided{source_info}, "
        f"maximum is {tag_limit}. Keeping first {tag_limit} tags, "
        f"discarding: {', '.join(discarded_keys)}"
    )

    # Validate the kept tags
    valid_tags, errors = validate_tags(kept_tags)
    if errors:
        logger.warning(f"Tag validation errors after limiting: {errors}")

    return valid_tags


def validate_tags(tags: Dict[str, Any]) -> Tuple[Dict[str, str], List[str]]:
    """Validate and clean tags according to v1.1 rules.

    Args:
        tags: Dictionary of tags to validate

    Returns:
        Tuple of (valid_tags, error_messages)
    """
    valid_tags = {}
    errors = []

    if not isinstance(tags, dict):
        return {}, ["Tags must be a dictionary"]

    # Check tag count
    if len(tags) > SDK_MAX_TAGS:
        errors.append(f"Too many tags: {len(tags)} > {SDK_MAX_TAGS} maximum")

    for key, value in list(tags.items())[:SDK_MAX_TAGS]:
        # Validate key
        if not isinstance(key, str):
            errors.append(f"Tag key must be string, got {type(key).__name__}: {key}")
            continue

        if not TAG_KEY_PATTERN.match(key):
            errors.append(f"Invalid tag key '{key}': must match [a-z0-9._-]{{1,64}}")
            continue

        # Validate value
        if value is None:
            errors.append(f"Tag value for '{key}' cannot be None")
            continue

        # Convert value to string
        str_value = str(value)

        if not TAG_VALUE_PATTERN.match(str_value):
            errors.append(
                f"Invalid tag value '{str_value}' for key '{key}': must be 1-256 characters"
            )
            continue

        valid_tags[key] = str_value

    return valid_tags, errors


def validate_metered_usage(metered_usage: Union[List, str]) -> Tuple[List[Dict], List[str]]:
    """Validate metered_usage array for v1.1 compliance.

    Args:
        metered_usage: Metered usage array or JSON string

    Returns:
        Tuple of (valid_metered_usage, errors)
    """
    errors = []

    # Parse if JSON string
    if isinstance(metered_usage, str):
        try:
            metered_usage = json.loads(metered_usage)
        except json.JSONDecodeError as e:
            return [], [f"Invalid metered_usage JSON: {e}"]

    if not isinstance(metered_usage, list):
        return [], ["metered_usage must be an array"]

    valid_entries = []
    for i, entry in enumerate(metered_usage):
        if not isinstance(entry, dict):
            errors.append(f"metered_usage[{i}] must be an object")
            continue

        # Validate required fields
        if "metric_kind" not in entry:
            errors.append(f"metered_usage[{i}] missing metric_kind")
            continue
        if "quantity" not in entry:
            errors.append(f"metered_usage[{i}] missing quantity")
            continue
        if "uom" not in entry:
            errors.append(f"metered_usage[{i}] missing uom")
            continue

        # Validate types
        if not isinstance(entry["metric_kind"], str):
            errors.append(f"metered_usage[{i}].metric_kind must be string")
            continue
        if not isinstance(entry["quantity"], (int, float)):
            errors.append(f"metered_usage[{i}].quantity must be number")
            continue
        if not isinstance(entry["uom"], str):
            errors.append(f"metered_usage[{i}].uom must be string")
            continue

        # Validate known metric kinds (optional validation)
        known_metrics = {
            "token.prompt",
            "token.completion",
            "token.total",
            "embedding.tokens",
            "embedding.dimensions",
            "vector.processed",
            "vector.count",
        }
        if entry["metric_kind"] not in known_metrics:
            # Allow custom metrics but log warning
            logger.debug(f"Unknown metric_kind: {entry['metric_kind']}")

        valid_entries.append(entry)

    return valid_entries, errors


def validate_field_type(field: str, value: Any) -> Tuple[bool, Optional[str]]:
    """Validate a field's type.

    Args:
        field: Field name
        value: Field value

    Returns:
        Tuple of (is_valid, error_message)
    """
    if field not in FIELD_TYPES:
        # Unknown fields are allowed
        return True, None

    expected_types = FIELD_TYPES[field]
    if not isinstance(expected_types, tuple):
        expected_types = (expected_types,)

    if not isinstance(value, expected_types):
        type_names = " or ".join(t.__name__ for t in expected_types)
        return (
            False,
            f"Field '{field}' must be {type_names}, got {type(value).__name__}",
        )

    return True, None


def validate_trace_id(trace_id: str, strict: bool = False) -> Tuple[str, Optional[str]]:
    """Validate and fix OTLP trace ID format.

    Args:
        trace_id: Trace ID to validate
        strict: If True, don't attempt to fix

    Returns:
        Tuple of (valid_trace_id, error_message)
    """
    if not trace_id:
        return "", "Trace ID is required"

    # Remove hyphens if present (UUID format)
    if "-" in trace_id and not strict:
        trace_id = trace_id.replace("-", "")

    # Validate format
    if not TRACE_ID_PATTERN.match(trace_id):
        if strict:
            return (
                trace_id,
                f"Invalid trace_id format: must be 32 hex characters, got '{trace_id}'",
            )
        # Try to fix by padding or truncating
        if len(trace_id) < 32:
            trace_id = trace_id.zfill(32)
        elif len(trace_id) > 32:
            trace_id = trace_id[:32]
        # Ensure all hex
        try:
            int(trace_id, 16)
        except ValueError:
            return trace_id, f"Invalid trace_id: contains non-hex characters"

    return trace_id, None


def validate_span_id(span_id: str, strict: bool = False) -> Tuple[str, Optional[str]]:
    """Validate and fix OTLP span ID format.

    Args:
        span_id: Span ID to validate
        strict: If True, don't attempt to fix

    Returns:
        Tuple of (valid_span_id, error_message)
    """
    if not span_id:
        return "", "Span ID is required"

    # Remove hyphens if present
    if "-" in span_id and not strict:
        span_id = span_id.replace("-", "")

    # Validate format
    if not SPAN_ID_PATTERN.match(span_id):
        if strict:
            return (
                span_id,
                f"Invalid span_id format: must be 16 hex characters, got '{span_id}'",
            )
        # Try to fix by padding or truncating
        if len(span_id) < 16:
            span_id = span_id.zfill(16)
        elif len(span_id) > 16:
            span_id = span_id[:16]
        # Ensure all hex
        try:
            int(span_id, 16)
        except ValueError:
            return span_id, f"Invalid span_id: contains non-hex characters"

    return span_id, None


def validate_otlp_timestamp(
    timestamp: Union[int, float], field_name: str
) -> Tuple[int, Optional[str]]:
    """Validate OTLP timestamp (should be int64 nanoseconds).

    Args:
        timestamp: Timestamp value
        field_name: Name of the field for error messages

    Returns:
        Tuple of (nanosecond_timestamp, error_message)
    """
    if not isinstance(timestamp, (int, float)):
        return 0, f"{field_name} must be numeric, got {type(timestamp).__name__}"

    # Check for negative timestamps
    if timestamp < 0:
        return 0, f"{field_name} must be non-negative, got {timestamp}"

    # Check if it's already in nanoseconds (very large number)
    if timestamp > 1e15:  # Likely already nanoseconds
        return int(timestamp), None

    # Convert from seconds to nanoseconds
    return int(timestamp * 1_000_000_000), None


def validate_otlp_span(span_dict: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
    """Validate span for OTLP compliance with camelCase fields.

    Args:
        span_dict: Span dictionary in OTLP format (camelCase)
        strict: If True, raise on violations. If False, fix issues.

    Returns:
        OTLP-compliant span dictionary

    Raises:
        ValueError: If strict=True and validation fails
    """
    errors = []
    warnings = []

    # Support both snake_case and camelCase for compatibility
    trace_id_key = "traceId" if "traceId" in span_dict else "trace_id"
    span_id_key = "spanId" if "spanId" in span_dict else "span_id"
    parent_span_id_key = "parentSpanId" if "parentSpanId" in span_dict else "parent_span_id"

    # Validate trace_id
    if trace_id_key in span_dict:
        trace_id, error = validate_trace_id(span_dict[trace_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["traceId"] = trace_id
        if trace_id_key == "trace_id":
            del span_dict["trace_id"]
    else:
        error = "Missing required field: traceId"
        if strict:
            raise ValueError(error)
        errors.append(error)

    # Validate span_id
    if span_id_key in span_dict:
        span_id, error = validate_span_id(span_dict[span_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["spanId"] = span_id
        if span_id_key == "span_id":
            del span_dict["span_id"]
    else:
        error = "Missing required field: spanId"
        if strict:
            raise ValueError(error)
        errors.append(error)

    # Validate parent_span_id if present
    if parent_span_id_key in span_dict and span_dict[parent_span_id_key]:
        parent_id, error = validate_span_id(span_dict[parent_span_id_key], strict)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        span_dict["parentSpanId"] = parent_id
        if parent_span_id_key == "parent_span_id":
            del span_dict["parent_span_id"]

    # Validate timestamps (support both snake_case and camelCase)
    start_time_key = (
        "startTimeUnixNano" if "startTimeUnixNano" in span_dict else "start_time_unix_nano"
    )
    end_time_key = "endTimeUnixNano" if "endTimeUnixNano" in span_dict else "end_time_unix_nano"

    if start_time_key in span_dict:
        # Convert string to int for validation if needed
        start_val = span_dict[start_time_key]
        if isinstance(start_val, str):
            start_val = int(start_val)
        start_ns, error = validate_otlp_timestamp(start_val, start_time_key)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        # Store as string for OTLP JSON (64-bit int)
        span_dict["startTimeUnixNano"] = str(start_ns)
        if start_time_key == "start_time_unix_nano":
            del span_dict["start_time_unix_nano"]

    if end_time_key in span_dict:
        # Convert string to int for validation if needed
        end_val = span_dict[end_time_key]
        if isinstance(end_val, str):
            end_val = int(end_val)
        end_ns, error = validate_otlp_timestamp(end_val, end_time_key)
        if error:
            if strict:
                raise ValueError(error)
            warnings.append(error)
        # Store as string for OTLP JSON (64-bit int)
        span_dict["endTimeUnixNano"] = str(end_ns)
        if end_time_key == "end_time_unix_nano":
            del span_dict["end_time_unix_nano"]

    # Validate that end_time >= start_time
    if "startTimeUnixNano" in span_dict and "endTimeUnixNano" in span_dict:
        start_ns = int(span_dict["startTimeUnixNano"])
        end_ns = int(span_dict["endTimeUnixNano"])
        if end_ns < start_ns:
            error = f"endTimeUnixNano ({end_ns}) must be >= startTimeUnixNano ({start_ns})"
            if strict:
                raise ValueError(error)
            warnings.append(error)
            # Fix by setting end = start (zero duration)
            span_dict["endTimeUnixNano"] = span_dict["startTimeUnixNano"]

    # Validate OTLP SpanKind
    if "kind" in span_dict:
        if span_dict["kind"] not in OTLP_SPAN_KINDS:
            error = f"Invalid OTLP SpanKind: {span_dict['kind']}"
            if strict:
                raise ValueError(error)
            warnings.append(error)
            span_dict["kind"] = "SPAN_KIND_INTERNAL"

    # Validate status
    if "status" in span_dict:
        if not isinstance(span_dict["status"], dict):
            error = "Status must be an object with 'code' field"
            if strict:
                raise ValueError(error)
            span_dict["status"] = {"code": "STATUS_CODE_UNSET"}
        elif "code" not in span_dict["status"]:
            error = "Status object missing 'code' field"
            if strict:
                raise ValueError(error)
            span_dict["status"]["code"] = "STATUS_CODE_UNSET"
        elif span_dict["status"]["code"] not in OTLP_STATUS_CODES:
            error = f"Invalid status code: {span_dict['status']['code']}"
            if strict:
                raise ValueError(error)
            span_dict["status"]["code"] = "STATUS_CODE_UNSET"

    # Validate attributes (now a list of typed key-value pairs)
    if "attributes" in span_dict:
        if isinstance(span_dict["attributes"], list):
            # Already in OTLP format (list of typed attributes)
            # Check attribute count
            if len(span_dict["attributes"]) > MAX_ATTRIBUTES:
                error = f"Too many attributes: {len(span_dict['attributes'])} > {MAX_ATTRIBUTES}"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                # Truncate to max
                span_dict["attributes"] = span_dict["attributes"][:MAX_ATTRIBUTES]

            # Validate typed attribute values
            for attr in span_dict["attributes"]:
                if "key" in attr and "value" in attr:
                    value_obj = attr["value"]
                    # Check string length in stringValue
                    if "stringValue" in value_obj:
                        str_val = value_obj["stringValue"]
                        if isinstance(str_val, str) and len(str_val) > MAX_STRING_LENGTH:
                            if strict:
                                raise ValueError(
                                    f"Attribute '{attr['key']}' string too long: {len(str_val)} > {MAX_STRING_LENGTH}"
                                )
                            value_obj["stringValue"] = str_val[:MAX_STRING_LENGTH]
                    # Check array length in arrayValue
                    elif "arrayValue" in value_obj:
                        arr_val = value_obj["arrayValue"].get("values", [])
                        if len(arr_val) > MAX_ARRAY_LENGTH:
                            if strict:
                                raise ValueError(
                                    f"Attribute '{attr['key']}' array too long: {len(arr_val)} > {MAX_ARRAY_LENGTH}"
                                )
                            value_obj["arrayValue"]["values"] = arr_val[:MAX_ARRAY_LENGTH]
        elif isinstance(span_dict["attributes"], dict):
            # Legacy format - convert to typed list
            typed_attrs = []
            for key, value in span_dict["attributes"].items():
                typed_attr = {"key": key}
                if isinstance(value, bool):
                    typed_attr["value"] = {"boolValue": value}
                elif isinstance(value, int):
                    typed_attr["value"] = {"intValue": str(value)}
                elif isinstance(value, float):
                    typed_attr["value"] = {"doubleValue": value}
                elif isinstance(value, str):
                    # Check string length
                    if len(value) > MAX_STRING_LENGTH:
                        if strict:
                            raise ValueError(
                                f"Attribute '{key}' string too long: {len(value)} > {MAX_STRING_LENGTH}"
                            )
                        value = value[:MAX_STRING_LENGTH]
                    typed_attr["value"] = {"stringValue": value}
                elif isinstance(value, list):
                    # Check array length
                    if len(value) > MAX_ARRAY_LENGTH:
                        if strict:
                            raise ValueError(
                                f"Attribute '{key}' array too long: {len(value)} > {MAX_ARRAY_LENGTH}"
                            )
                        value = value[:MAX_ARRAY_LENGTH]
                    typed_attr["value"] = {
                        "arrayValue": {"values": [{"stringValue": str(v)} for v in value]}
                    }
                else:
                    typed_attr["value"] = {"stringValue": str(value)}
                typed_attrs.append(typed_attr)

            # Check attribute count
            if len(typed_attrs) > MAX_ATTRIBUTES:
                error = f"Too many attributes: {len(typed_attrs)} > {MAX_ATTRIBUTES}"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                typed_attrs = typed_attrs[:MAX_ATTRIBUTES]

            span_dict["attributes"] = typed_attrs
        else:
            error = "Attributes must be a list or dictionary"
            if strict:
                raise ValueError(error)
            span_dict["attributes"] = []

    # Validate span name length
    if "name" in span_dict:
        if isinstance(span_dict["name"], str) and len(span_dict["name"]) > MAX_SPAN_NAME_LENGTH:
            if strict:
                raise ValueError(
                    f"Span name too long: {len(span_dict['name'])} > {MAX_SPAN_NAME_LENGTH}"
                )
            span_dict["name"] = span_dict["name"][:MAX_SPAN_NAME_LENGTH]

    # Validate events
    if "events" in span_dict:
        if not isinstance(span_dict["events"], list):
            error = "Events must be an array"
            if strict:
                raise ValueError(error)
            span_dict["events"] = []
        elif len(span_dict["events"]) > MAX_EVENTS:
            if strict:
                raise ValueError(f"Too many events: {len(span_dict['events'])} > {MAX_EVENTS}")
            span_dict["events"] = span_dict["events"][:MAX_EVENTS]

    # Log warnings
    if warnings and not strict:
        logger.debug(f"OTLP validation warnings: {'; '.join(warnings[:3])}")

    return span_dict


def validate(span_dict: Dict[str, Any], strict: bool = False) -> Dict[str, Any]:
    """Validate and normalize span data according to MVK v1.1 schema.

    This is the central validation function that enforces all schema rules:
    - Required fields
    - Field types
    - Span kind validation
    - Tag constraints
    - Attribute filtering per span kind

    Args:
        span_dict: Span data to validate
        strict: If True, raise ValueError on first violation.
                If False, drop invalid fields and log warnings.
                Can be overridden by MVK_STRICT_VALIDATION env var.

    Returns:
        Cleaned span dictionary

    Raises:
        ValueError: If strict=True and validation fails
    """
    # Use centralized strict validation check (from instrument.py)
    # Also check env var directly for cases where instrument() hasn't been called yet
    try:
        from .instrument import is_strict_validation

        if is_strict_validation():
            strict = True
    except ImportError:
        pass

    # Fallback: check env var directly if instrument() hasn't set the global
    if not strict and os.getenv("MVK_STRICT_VALIDATION", "").lower() in ("1", "true", "yes"):
        strict = True

    errors = []
    warnings = []
    cleaned: Dict[str, Any] = {}

    # Handle OTLP format - flatten attributes if present
    if "attributes" in span_dict and isinstance(span_dict["attributes"], dict):
        # Flatten attributes into the span dict
        flattened = dict(span_dict)
        flattened.update(span_dict["attributes"])
        span_dict = flattened

    # Validate required fields
    for field in REQUIRED_FIELDS:
        if field not in span_dict:
            error = f"Missing required field: {field}"
            errors.append(error)
            if strict:
                raise ValueError(error)

    # Validate MVK step type (v1.1: step_type not span.kind)
    mvk_step_type = span_dict.get("mvk.step_type")
    if mvk_step_type and not (
        isinstance(mvk_step_type, MVKStepType) or mvk_step_type in [k.value for k in MVKStepType]
    ):
        error = f"Invalid MVK step type: {mvk_step_type}"
        errors.append(error)
        if strict:
            raise ValueError(error)
        mvk_step_type = None  # Drop invalid type
        span_dict = dict(span_dict)  # Make a copy to avoid modifying original
        del span_dict["mvk.step_type"]  # Remove invalid type from the dict

    # Get allowed attributes for this MVK step type
    if mvk_step_type:
        try:
            mvk_step_type_enum = MVKStepType(mvk_step_type)
            allowed_attrs = MVK_STEP_TYPE_ATTRIBUTES.get(mvk_step_type_enum, set())
        except ValueError:
            allowed_attrs = set()
    else:
        allowed_attrs = set()

    # Always allowed fields (v1.1)
    always_allowed = {
        # OTEL core
        "trace_id",
        "span_id",
        "parent_span_id",
        "start_time_unix_nano",
        "end_time_unix_nano",
        "status",  # v1.0: status object
        "status_code",
        "status_message",
        # Service identity
        "service.namespace",
        "service.instance.id",
        # MVK context
        "mvk.agent_id",
        "mvk.agent_name",
        "mvk.step_type",  # v1.0: step_type not span.kind
        "mvk.session_id",
        "mvk.schema_version",  # v1.0: schema version
        "mvk.sdk_version",
        "mvk.user_id",  # v1.0: with mvk_ prefix
        "mvk.client_id",  # v1.0: with mvk_ prefix
        "mvk.cloud_provider_code",
        "mvk.model_provider",  # v1.0: model_provider not model_provider_code
        # Operation basics
        "kind",
        "name",
        "attributes",  # v1.0: attributes container
        # Special fields
        "mvk.tags",
        "events",
        "links",  # v1.0: span links
        "mvk.metered_usage",
        "mvk.vendor_attributes",  # v1.0: vendor_attributes
        # Latency
        "mvk.duration_ms",
        "mvk.e2e_latency_ms",
    }

    # Process all fields
    for field, value in span_dict.items():
        # Skip None values
        if value is None:
            continue

        # Validate field type
        is_valid, type_error = validate_field_type(field, value)
        if not is_valid:
            assert type_error is not None
            if strict:
                raise ValueError(type_error)
            warnings.append(type_error)
            continue

        # Check if field is allowed for this step type
        if field not in always_allowed and field not in allowed_attrs:
            # Check if it's a custom field (starts with x- or vendor prefix)
            if not (field.startswith("x-") or field.startswith("vendor.")):
                warning = f"Field '{field}' not allowed for MVK step type '{mvk_step_type}'"
                if strict:
                    raise ValueError(warning)
                warnings.append(warning)
                continue

        # Add to cleaned dict
        cleaned[field] = value

    # Normalize mvk.step_type to canonical string (e.g., "LLM")
    if "mvk.step_type" in cleaned:
        st = cleaned["mvk.step_type"]
        if isinstance(st, MVKStepType):
            cleaned["mvk.step_type"] = st.value
        elif isinstance(st, str) and st.startswith("MVKStepType."):
            cleaned["mvk.step_type"] = st.split(".")[-1]

    # Validate and clean tags
    if "mvk.tags" in cleaned:
        tags = cleaned["mvk.tags"]
        # Handle JSON string
        if isinstance(tags, str):
            import json

            try:
                tags = json.loads(tags)
            except json.JSONDecodeError:
                error = "Invalid JSON in mvk.tags field"
                if strict:
                    raise ValueError(error)
                warnings.append(error)
                tags = {}

        valid_tags, tag_errors = validate_tags(tags)
        if tag_errors:
            if strict:
                raise ValueError(f"Tag validation failed: {'; '.join(tag_errors)}")
            warnings.extend(tag_errors)

        cleaned["mvk.tags"] = valid_tags

    # v1.0: Validate metered_usage is present for LLM and EMBEDDING spans
    _mvk_step_type_enum = (
        mvk_step_type
        if isinstance(mvk_step_type, MVKStepType)
        else (MVKStepType(mvk_step_type) if mvk_step_type else None)
    )
    if _mvk_step_type_enum in [MVKStepType.LLM, MVKStepType.EMBEDDING]:
        if "mvk.metered_usage" not in cleaned:
            warning = f"Missing mvk.metered_usage for {mvk_step_type} span"
            if strict:
                raise ValueError(warning)
            warnings.append(warning)
        else:
            # Validate metered_usage structure
            metered_usage = cleaned.get("mvk.metered_usage")
            if isinstance(metered_usage, str):
                try:
                    import json

                    metered_usage = json.loads(metered_usage)
                except json.JSONDecodeError:
                    warning = "Invalid mvk.metered_usage JSON"
                    if strict:
                        raise ValueError(warning)
                    warnings.append(warning)
                    metered_usage = []

            if isinstance(metered_usage, list):
                validated_usage, usage_errors = validate_metered_usage(metered_usage)
                if usage_errors:
                    if strict:
                        raise ValueError(f"Invalid mvk.metered_usage: {'; '.join(usage_errors)}")
                    warnings.extend(usage_errors)
                cleaned["mvk.metered_usage"] = validated_usage

    # Calculate duration if not present (v1.1: using nanosecond timestamps)
    if (
        "start_time_unix_nano" in cleaned
        and "end_time_unix_nano" in cleaned
        and "mvk.duration_ms" not in cleaned
    ):
        # Convert nanoseconds to milliseconds
        start_ns = cleaned["start_time_unix_nano"]
        end_ns = cleaned["end_time_unix_nano"]
        if isinstance(start_ns, (int, float)) and isinstance(end_ns, (int, float)):
            cleaned["mvk.duration_ms"] = (end_ns - start_ns) / 1_000_000

    # Log warnings in non-strict mode
    if warnings and not strict:
        logger.debug(f"Schema validation warnings: {'; '.join(warnings[:3])}")

    return cleaned


def validate_span_for_export(span: Any) -> Dict[str, Any]:
    """Convert a Span object to validated dictionary for export.

    Args:
        span: Span object from tracer

    Returns:
        Validated span dictionary ready for export
    """
    # Extract span data
    span_dict = {
        "trace_id": span.context.trace_id,
        "span_id": span.context.span_id,
        "parent_span_id": span.context.parent_span_id,
        "start_time_unix_nano": span.start_time,  # Assuming already in nanoseconds
        "end_time_unix_nano": span.end_time or span.start_time,
        "name": span.name,
        "status_code": span._status.status_code.value,
    }

    if span._status.description:
        span_dict["status_message"] = span._status.description

    # Add attributes
    span_dict.update(span._attributes)

    # Add events if any
    if span._events:
        span_dict["events"] = span._events

    # Validate and return
    return validate(span_dict, strict=False)


def get_mvk_step_type_for_name(name: str) -> MVKStepType:
    """Infer MVK step type from span name.

    Args:
        name: Span name

    Returns:
        Inferred MVK step type
    """
    name_lower = name.lower()

    # LLM operations (check first as they're most specific)
    if any(x in name_lower for x in ["chat", "completion", "generate", "llm", "gpt", "claude"]):
        return MVKStepType.LLM

    # Embedding operations (check before retriever since "embed" is more specific than "vector")
    if any(x in name_lower for x in ["embed", "encoding", "encode"]):
        return MVKStepType.EMBEDDING

    # Retriever operations (check before general patterns)
    if any(x in name_lower for x in ["search", "retrieve", "query", "find", "lookup"]):
        return MVKStepType.RETRIEVER

    # Memory operations
    if any(x in name_lower for x in ["memory", "cache", "store", "load", "save"]):
        return MVKStepType.MEMORY

    # Check for "vector" last as it could be embedding or retriever
    if "vector" in name_lower:
        # If it has encoding/embed context, it's embedding
        if any(x in name_lower for x in ["encod", "embed"]):
            return MVKStepType.EMBEDDING
        # Otherwise assume retriever
        return MVKStepType.RETRIEVER

    # Tool operations
    if any(x in name_lower for x in ["tool", "function", "call", "execute", "api"]):
        return MVKStepType.TOOL

    # Default to AGENT_CALL for unknown
    return MVKStepType.AGENT_CALL


# Field mutability rules for v1.1
FIELD_MUTABILITY = {
    # Immutable - cannot be set by user
    "immutable": {
        "trace_id",
        "span_id",
        "parent_span_id",
        "start_time_unix_nano",
        "end_time_unix_nano",
        "mvk.duration_ms",
        "service.instance.id",
    },
    # Set only in mvk.instrument()
    "instrument_only": {"service.namespace", "mvk.agent_name"},
    # Set only in @mvk.signal or mvk.create_signal
    "span_only": {
        "mvk.step_type",
        "mvk.operation",
        "mvk.operation_subtype",
        "mvk.cloud_provider_code",
        "name",
    },
    # Can be set in @mvk.context or @mvk.signal
    "context_or_span": {"mvk.tags", "mvk.session_id"},
    # Auto-discovered, not user-settable
    "auto_only": {
        "mvk.model_provider",
        "mvk.sdk_version",
        "mvk.prompt_tokens",
        "mvk.completion_tokens",
        "mvk.total_tokens",
        "mvk.time_to_first_token_ms",
        "mvk.duration_ms",
        "mvk.stream_enabled",
        "mvk.vendor_name",
        "mvk.vendor_sdk",
        "mvk.embeddings_count",
        "mvk.embedding_dims",
        "mvk.bytes_read",
        "mvk.bytes_written",
        "mvk.e2e_latency_ms",
    },
}


def check_field_mutability(field: str, context: str) -> bool:
    """Check if a field can be set in the given context.

    Args:
        field: Field name
        context: Where the field is being set ("instrument", "context", "span", "auto")

    Returns:
        True if field can be set in this context
    """
    if field in FIELD_MUTABILITY["immutable"]:
        return False

    if context == "instrument":
        return field in FIELD_MUTABILITY["instrument_only"]
    elif context == "context":
        return field in FIELD_MUTABILITY["context_or_span"]
    elif context == "span":
        return field in (FIELD_MUTABILITY["span_only"] | FIELD_MUTABILITY["context_or_span"])
    elif context == "auto":
        return field in FIELD_MUTABILITY["auto_only"]

    # Unknown fields can be set anywhere (for extensibility)
    return True
