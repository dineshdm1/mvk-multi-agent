"""Metrics support for MVK SDK v1.1.

Provides the Metric class and add_metered_usage function.
"""

import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from .mvk_tracer import get_current_span
from .wrapper_logging import get_component_logger

logger = get_component_logger("core", "metrics")


@dataclass
class Metric:
    """Metric object for metered usage.

    Attributes:
        metric_kind: Type of metric (e.g., "token.prompt", "token.completion")
        quantity: Numeric value
        uom: Unit of measure (e.g., "token", "call", "image")

    Note:
        This class validates inputs and provides defaults to prevent exceptions
        from interrupting user code. Invalid values are logged but not raised.
        Unknown parameters are accepted and logged as warnings but do not raise exceptions.
    """

    metric_kind: str = "unknown"
    quantity: float = 0.0
    uom: str = "unit"

    def __init__(self, metric_kind: str = "unknown", quantity: float = 0.0, uom: str = "unit"):
        """Initialize Metric.

        Args:
            metric_kind: Type of metric
            quantity: Numeric value
            uom: Unit of measure
        """
        self.metric_kind = metric_kind
        self.quantity = quantity
        self.uom = uom

        # Call validation
        self.__post_init__()

    def __post_init__(self):
        """Validate and normalize metric fields without raising exceptions."""
        # Validate metric_kind
        if not isinstance(self.metric_kind, str):
            logger.warning(
                f"Metric metric_kind must be string, got {type(self.metric_kind).__name__}. "
                f"Using 'unknown'."
            )
            self.metric_kind = "unknown"
        elif not self.metric_kind or self.metric_kind.strip() == "":
            logger.warning("Metric metric_kind is empty. Using 'unknown'.")
            self.metric_kind = "unknown"

        # Validate quantity
        if not isinstance(self.quantity, (int, float)):
            logger.warning(
                f"Metric quantity must be numeric, got {type(self.quantity).__name__}. "
                f"Using 0.0."
            )
            self.quantity = 0.0
        else:
            # Ensure it's a float
            self.quantity = float(self.quantity)

        # Validate uom
        if not isinstance(self.uom, str):
            logger.warning(
                f"Metric uom must be string, got {type(self.uom).__name__}. " f"Using 'unit'."
            )
            self.uom = "unit"
        elif not self.uom or self.uom.strip() == "":
            logger.warning("Metric uom is empty. Using 'unit'.")
            self.uom = "unit"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "metric_kind": self.metric_kind,
            "quantity": self.quantity,
            "uom": self.uom,
        }

    # Common metric kinds as class constants
    # Token metrics (public constants keep historical 'tokens.*' for backward compatibility)
    PROMPT_TOKENS = "tokens.prompt"
    COMPLETION_TOKENS = "tokens.completion"
    EMBEDDING_TOKENS = "tokens.embedding"
    TOTAL_TOKENS = "tokens.total"

    # API metrics
    API_CALLS = "api.calls"

    # Image metrics
    IMAGES_GENERATED = "images.generated"
    IMAGES_PROCESSED = "images.processed"

    # Character metrics
    CHARACTERS_INPUT = "characters.input"
    CHARACTERS_OUTPUT = "characters.output"


def _normalize_metric_kind(kind: str) -> str:
    """Normalize legacy metric kinds to canonical forms.

    - tokens.prompt -> token.prompt
    - tokens.completion -> token.completion
    - tokens.total -> token.total
    - tokens.embedding -> embedding.tokens
    """
    try:
        k = str(kind)
        if k.startswith("tokens."):
            if k == "tokens.embedding":
                return "embedding.tokens"
            if k == "tokens.prompt":
                return "token.prompt"
            if k == "tokens.completion":
                return "token.completion"
            if k == "tokens.total":
                return "token.total"
            # Generic fallback: collapse plural to singular for token.* kinds
            if k.startswith("tokens."):
                return "token." + k.split(".", 1)[1]
        return k
    except Exception:
        return kind


def _infer_provider_from_model_name(model_name: str) -> Optional[str]:
    """Infer provider from a model name string using simple heuristics.

    This is a best-effort fallback when mvk.model_provider is not set.
    """
    name = model_name.lower()
    # OpenAI
    if name.startswith(("gpt-", "gpt4", "gpt_", "text-embedding-", "text-embedding-3", "o3", "o1")):
        return "openai"
    # Anthropic
    if name.startswith(("claude",)):
        return "anthropic"
    # Google Gemini
    if "gemini" in name:
        return "google"
    # AWS Bedrock (often vendor prefixes in ARN/context; fall back only when explicit)
    if any(prefix in name for prefix in ("bedrock", "amazon.", "cohere", "ai21")):
        return "aws-bedrock"
    return None


def _enrich_with_provider(metric_dicts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Attach model_provider to each metric's metadata if available on the current span.

    Does not override if already provided in a metric's metadata. Falls back to inferring
    the provider from model_name when mvk.model_provider is not present.
    """
    span = get_current_span()
    if not span or not hasattr(span, "attributes"):
        return metric_dicts

    provider = span.attributes.get("mvk.model_provider")
    if provider is None:
        # Backward compatibility alias
        provider = span.attributes.get("mvk.model_provider_code")

    # If still None, try to infer from model_name on span
    if provider is None:
        span_model_name = span.attributes.get("mvk.model_name")
        if isinstance(span_model_name, str):
            provider = _infer_provider_from_model_name(span_model_name)

    enriched: List[Dict[str, Any]] = []
    for m in metric_dicts:
        # Ensure metadata exists
        meta: Dict[str, Any] = {}
        if isinstance(m.get("metadata"), dict):
            meta = dict(m["metadata"])  # copy to avoid mutating input

        # If provider still missing, look into metric's metadata model_name
        if provider is None and isinstance(meta.get("model_name"), str):
            inferred = _infer_provider_from_model_name(str(meta["model_name"]))
            if inferred:
                provider = inferred

        # Only set if available and missing (use model_provider key)
        if provider is not None and "model_provider" not in meta:
            meta["model_provider"] = provider

        # Write back
        m_copy = dict(m)
        if meta:
            m_copy["metadata"] = meta
        enriched.append(m_copy)
    return enriched


def add_metered_usage(
    metrics: Optional[Union[List[Metric], str]] = None,
    value: Optional[float] = None,
    uom: Optional[str] = None,
    model_name: Optional[str] = None,
    metric: Optional[str] = None,  # Backward compatibility alias
    **metadata: Any,
) -> None:
    """Add metered usage metrics to the current span.

    Supports two calling styles:
    1. New v3.0 spec: Pass a list of Metric objects
    2. Legacy: Pass individual metric parameters

    Args:
        metrics: Either a list of Metric objects OR a metric kind string (for legacy)
        value: Numeric quantity (only for legacy style)
        uom: Unit of measure (only for legacy style, defaults based on metric kind)
        model_name: Model name to include in metadata (legacy only)
        **metadata: Additional metadata (legacy only)

    Examples:
        # v3.0 spec style - preferred
        add_metered_usage([
            Metric(metric_kind="token.prompt", quantity=150, uom="token"),
            Metric(metric_kind="token.completion", quantity=50, uom="token"),
            Metric(metric_kind="token.total", quantity=200, uom="token")
        ])

        # Legacy style - backward compatibility
        add_metered_usage("token.prompt", 150, uom="token", model_name="gpt-4")
    """
    span = get_current_span()
    if not span:
        logger.warning("No active span to add metered usage to")
        return

    # Handle backward compatibility - 'metric' parameter alias
    if metrics is None and metric is not None:
        metrics = metric

    # If still no metrics provided, error
    if metrics is None:
        logger.warning("No metrics provided to add_metered_usage")
        return

    # Convert inputs to list of metric dicts
    metric_dicts = []

    if isinstance(metrics, list):
        # v3.0 spec style - list of Metric objects
        for metric_obj in metrics:
            if isinstance(metric_obj, Metric):
                d = metric_obj.to_dict()
                d["metric_kind"] = _normalize_metric_kind(d["metric_kind"])  # normalize
                metric_dicts.append(d)
            elif isinstance(metric_obj, dict):
                # Also support dict format for flexibility
                d = dict(metric_obj)
                if "metric_kind" in d and isinstance(d["metric_kind"], str):
                    d["metric_kind"] = _normalize_metric_kind(d["metric_kind"])  # normalize
                metric_dicts.append(d)
            else:
                logger.warning(f"Invalid metric type: {type(metric_obj)}")
    else:
        # Legacy style - single metric with separate parameters
        metric_kind = str(metrics)  # First param is actually the metric kind string
        metric_kind = _normalize_metric_kind(metric_kind)  # normalize

        # Default UOM based on metric kind
        if uom is None:
            if "token" in metric_kind:
                uom = "token"
            elif "api.calls" in metric_kind:
                uom = "call"
            elif "images" in metric_kind:
                uom = "image"
            elif "character" in metric_kind:
                uom = "character"
            else:
                uom = "unit"

        # Build metric dict
        metric_dict: Dict[str, Any] = {
            "metric_kind": metric_kind,
            "uom": uom,
            "quantity": value,
        }

        # Add metadata if provided (legacy style)
        if model_name or metadata:
            meta: Dict[str, Any] = {}
            if model_name:
                meta["model_name"] = model_name
            meta.update(metadata)
            metric_dict["metadata"] = meta

        metric_dicts = [metric_dict]

    # Enrich with model_provider if available and not already set
    metric_dicts = _enrich_with_provider(metric_dicts)

    # Get existing metered_usage or create new list
    if hasattr(span, "attributes") and "mvk.metered_usage" in span.attributes:
        try:
            # Parse existing metrics
            existing = json.loads(span.attributes["mvk.metered_usage"])
            if isinstance(existing, list):
                existing.extend(metric_dicts)
            else:
                existing = metric_dicts
        except (json.JSONDecodeError, TypeError):
            existing = metric_dicts
    else:
        existing = metric_dicts

    # Ensure all entries (old and new) carry model_provider when available
    existing = _enrich_with_provider(existing)

    # Set updated metrics with mvk. prefix
    try:
        if hasattr(span, "set_attribute"):
            # Use set_attribute to ensure filtering logic is applied
            span.set_attribute("mvk.metered_usage", json.dumps(existing))
        elif hasattr(span, "attributes"):
            # Fallback for spans that don't have set_attribute method
            span.attributes["mvk.metered_usage"] = json.dumps(existing)
    except Exception as e:
        logger.error(f"Failed to set metered usage on span: {e}")

    logger.debug(f"Added {len(metric_dicts)} metered usage metrics")
