"""MVK SDK v1.1 HTTP Instrumentation Suppression Guard.

This module prevents double instrumentation of HTTP calls, especially
when the SDK itself makes HTTP calls to export telemetry or when
AI providers make internal HTTP calls. Enhanced with context-based
suppression for intelligent instrumentation control.
"""

import functools
import json
import logging
import os
import re
import threading
from contextlib import contextmanager
from typing import Any, Callable, Dict, List, Optional, Set, Union
from urllib.parse import urlparse

logger = logging.getLogger("mvk.core.http_suppression")

# Thread-local storage for suppression state and context
_thread_local = threading.local()

# Default exclusions for AI provider endpoints
DEFAULT_EXCLUSIONS = {
    # AI Providers
    "api.openai.com",
    "api.anthropic.com",
    "bedrock.amazonaws.com",
    "bedrock-runtime.amazonaws.com",
    "generativelanguage.googleapis.com",
    "aiplatform.googleapis.com",
    "openai.azure.com",
    # Vector Databases - Keep these excluded to prevent double instrumentation
    "api.pinecone.io",
    "weaviate.io",
    "qdrant.io",
    # Observability backends (to prevent loops)
    "api.mavvrik.ai",
    "otel-collector",
    "localhost:4317",
    "localhost:4318",
}

# Context-based suppression rules
CONTEXT_SUPPRESSION_RULES: Dict[str, Any] = {
    "span_operation": {
        "llm_call": True,  # Suppress HTTP calls within LLM operations
        "vectordb_query": True,  # Suppress HTTP calls within vector DB operations
        "http_call": False,  # Allow HTTP calls within HTTP operations
        "export": True,  # Suppress HTTP calls within export operations
    },
    "span_name_patterns": [
        r".*openai\.com.*",  # OpenAI API calls
        r".*anthropic\.com.*",  # Anthropic API calls
        r".*bedrock.*",  # AWS Bedrock calls
        r".*googleapis\.com.*",  # Google API calls
    ],
    "user_agent_patterns": [
        r".*mvk-sdk.*",  # MVK SDK user agents
        r".*otel.*",  # OpenTelemetry user agents
    ],
}

# Global exclusions set
_exclusions: Set[str] = set(DEFAULT_EXCLUSIONS)

# Context suppression state
_context_suppression_enabled = True


class SuppressionGuard:
    """Enhanced context manager for HTTP suppression with context awareness."""

    def __init__(self, reason: Optional[str] = None, context: Optional[Dict[str, Any]] = None):
        """Initialize suppression guard.

        Args:
            reason: Reason for suppression (e.g., "export", "llm_call")
            context: Additional context information
        """
        self._original_state = None
        self._original_context = None
        self.reason = reason
        self.context = context or {}

    def __enter__(self):
        """Enter suppression context."""
        self._original_state = getattr(_thread_local, "suppressed", False)
        self._original_context = getattr(_thread_local, "suppression_context", {})

        _thread_local.suppressed = True
        _thread_local.suppression_context = {
            "reason": self.reason,
            "context": self.context,
        }
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit suppression context."""
        _thread_local.suppressed = self._original_state
        _thread_local.suppression_context = self._original_context

    def is_suppressed(self) -> bool:
        """Check if currently suppressed.

        Returns:
            True if suppressed
        """
        return getattr(_thread_local, "suppressed", False)

    def get_suppression_context(self) -> Dict[str, Any]:
        """Get current suppression context.

        Returns:
            Current suppression context
        """
        return getattr(_thread_local, "suppression_context", {})


@contextmanager
def with_suppression(reason: Optional[str] = None, context: Optional[Dict[str, Any]] = None):
    """Enhanced context manager to suppress HTTP instrumentation with context awareness.

    Usage:
        with with_suppression("llm_call", {"provider": "openai"}):
            # HTTP calls here won't be instrumented
            requests.get("https://api.openai.com/v1/completions")
    """
    guard = SuppressionGuard(reason, context)
    with guard:
        yield


@contextmanager
def with_llm_suppression(provider: str = "unknown"):
    """Context manager specifically for LLM operation suppression.

    Args:
        provider: LLM provider name (e.g., "openai", "anthropic")
    """
    with with_suppression("llm_call", {"provider": provider}):
        yield


@contextmanager
def with_export_suppression(exporter_type: str = "unknown"):
    """Context manager specifically for export operation suppression.

    Args:
        exporter_type: Type of exporter (e.g., "otlp_http", "otlp_grpc")
    """
    with with_suppression("export", {"exporter_type": exporter_type}):
        yield


@contextmanager
def with_vectordb_suppression(db_type: str = "unknown"):
    """Context manager specifically for vector database operation suppression.

    Args:
        db_type: Vector DB type (e.g., "pinecone", "weaviate")
    """
    with with_suppression("vectordb_query", {"db_type": db_type}):
        yield


def suppress_http_instrumentation(func: Callable) -> Callable:
    """Decorator to suppress HTTP instrumentation.

    Args:
        func: Function to wrap

    Returns:
        Wrapped function
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with with_suppression():
            return func(*args, **kwargs)

    return wrapper


def is_suppressed() -> bool:
    """Check if HTTP instrumentation is currently suppressed.

    Returns:
        True if suppressed
    """
    return getattr(_thread_local, "suppressed", False)


def should_suppress_url(url: str, context: Optional[Dict[str, Any]] = None) -> bool:
    """Enhanced URL suppression check with context awareness.

    Args:
        url: The URL to check
        context: Additional context for intelligent suppression

    Returns:
        True if the URL should be suppressed
    """
    try:
        # First check basic exclusions
        if _should_suppress_url_basic(url):
            return True

        # Then check context-based suppression
        if _context_suppression_enabled and context:
            if _should_suppress_url_context(url, context):
                return True

        # Check current span context if available
        if _context_suppression_enabled:
            current_context = get_current_span_context()
            if current_context and _should_suppress_url_context(url, current_context):
                return True

        return False
    except Exception:  # pylint: disable=broad-except
        logger.exception(f"Error checking URL suppression: {url}")
        return False


def _should_suppress_url_basic(url: str) -> bool:
    """Basic URL suppression check based on exclusions list."""
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or parsed.netloc

        if not hostname:
            return False

        # Check if hostname matches any exclusion
        for exclusion in _exclusions:
            # Check for exact match or subdomain match
            if exclusion in hostname:
                return True
            # Check if it's a subdomain (e.g., bedrock.us-east-1.amazonaws.com matches bedrock.amazonaws.com)
            if "." in exclusion:
                base_domain = exclusion.split(".", 1)[0]
                if base_domain in hostname and "amazonaws.com" in hostname:
                    return True

        return False
    except Exception:  # pylint: disable=broad-except
        logger.exception(f"Error parsing URL: {url}")
        return False


def _should_suppress_url_context(url: str, context: Dict[str, Any]) -> bool:
    """Context-based URL suppression logic."""
    try:
        # Check span operation suppression
        operation = context.get("operation")
        span_operations = CONTEXT_SUPPRESSION_RULES.get("span_operation", {})
        if operation in span_operations:
            if span_operations[operation]:
                logger.debug(f"Suppressing URL due to operation context: {operation} -> {url}")
                return True

        # Check span name patterns
        span_name = context.get("span_name", "")
        span_name_patterns = CONTEXT_SUPPRESSION_RULES.get("span_name_patterns", [])
        for pattern in span_name_patterns:
            if re.search(pattern, span_name, re.IGNORECASE):
                logger.debug(f"Suppressing URL due to span name pattern: {pattern} -> {url}")
                return True

        # Check user agent patterns
        user_agent = context.get("user_agent", "")
        user_agent_patterns = CONTEXT_SUPPRESSION_RULES.get("user_agent_patterns", [])
        for pattern in user_agent_patterns:
            if re.search(pattern, user_agent, re.IGNORECASE):
                logger.debug(f"Suppressing URL due to user agent pattern: {pattern} -> {url}")
                return True

        return False
    except Exception:  # pylint: disable=broad-except
        logger.exception(f"Error in context-based URL suppression: {url}")
        return False


def get_current_span_context() -> Optional[Dict[str, Any]]:
    """Get current span context for suppression decisions."""
    # Prefer an injected trace object (used in tests) to avoid hard dependency
    trace_obj = globals().get("trace")
    if trace_obj is None:
        try:
            from opentelemetry import trace as ot_trace  # type: ignore

            trace_obj = ot_trace
        except Exception:  # pylint: disable=broad-except
            logger.debug(
                "OpenTelemetry not available and no injected trace object; skipping context"
            )
            return None

    try:
        current_span = trace_obj.get_current_span()
        is_recording = getattr(current_span, "is_recording", None)
        if current_span and callable(is_recording) and is_recording():
            return {
                "span_name": getattr(current_span, "name", ""),
                "operation": getattr(current_span, "operation", None),
                "attributes": dict(getattr(current_span, "attributes", {}) or {}),
            }
    except Exception:  # pylint: disable=broad-except
        logger.debug("Could not get current span context")

    return None


def add_exclusion(domain: str) -> None:
    """Add a domain to the exclusion list.

    Args:
        domain: Domain to exclude
    """
    _exclusions.add(domain)
    logger.debug(f"Added HTTP exclusion: {domain}")


def remove_exclusion(domain: str) -> None:
    """Remove a domain from the exclusion list.

    Args:
        domain: Domain to remove from exclusions
    """
    _exclusions.discard(domain)
    logger.debug(f"Removed HTTP exclusion: {domain}")


def load_exclusions_from_env() -> None:
    """Load custom exclusions from environment variable with enhanced parsing."""
    custom_exclusions = os.environ.get("MVK_HTTP_EXCLUSIONS", "")
    if custom_exclusions:
        try:
            # Try JSON array format first
            if custom_exclusions.startswith("[") and custom_exclusions.endswith("]"):
                exclusions_list = json.loads(custom_exclusions)
                for exclusion in exclusions_list:
                    if isinstance(exclusion, str) and exclusion.strip():
                        add_exclusion(exclusion.strip())
            else:
                # Fallback to comma-separated format
                for domain in custom_exclusions.split(","):
                    domain = domain.strip()
                    if domain:
                        add_exclusion(domain)
        except Exception as e:
            logger.warning(f"Failed to parse MVK_HTTP_EXCLUSIONS: {e}")
            # Fallback to simple comma-separated parsing
            for domain in custom_exclusions.split(","):
                domain = domain.strip()
                if domain:
                    add_exclusion(domain)


def add_context_suppression_rule(operation: str, should_suppress: bool) -> None:
    """Add or update a context suppression rule.

    Args:
        operation: Operation name (e.g., "llm_call", "vectordb_query")
        should_suppress: Whether to suppress HTTP calls for this operation
    """
    if "span_operation" not in CONTEXT_SUPPRESSION_RULES:
        CONTEXT_SUPPRESSION_RULES["span_operation"] = {}
    CONTEXT_SUPPRESSION_RULES["span_operation"][operation] = should_suppress
    logger.debug(f"Added context suppression rule: {operation} -> {should_suppress}")


def remove_context_suppression_rule(operation: str) -> None:
    """Remove a context suppression rule.

    Args:
        operation: Operation name to remove
    """
    span_operations = CONTEXT_SUPPRESSION_RULES.get("span_operation", {})
    if isinstance(span_operations, dict):
        span_operations.pop(operation, None)
    logger.debug(f"Removed context suppression rule: {operation}")


def add_span_name_pattern(pattern: str) -> None:
    """Add a span name pattern for suppression.

    Args:
        pattern: Regex pattern for span names to suppress
    """
    if "span_name_patterns" not in CONTEXT_SUPPRESSION_RULES:
        CONTEXT_SUPPRESSION_RULES["span_name_patterns"] = []
    patterns = CONTEXT_SUPPRESSION_RULES["span_name_patterns"]
    if isinstance(patterns, list) and pattern not in patterns:
        patterns.append(pattern)
        logger.debug(f"Added span name pattern: {pattern}")


def remove_span_name_pattern(pattern: str) -> None:
    """Remove a span name pattern.

    Args:
        pattern: Regex pattern to remove
    """
    patterns = CONTEXT_SUPPRESSION_RULES.get("span_name_patterns", [])
    if isinstance(patterns, list):
        CONTEXT_SUPPRESSION_RULES["span_name_patterns"] = [p for p in patterns if p != pattern]
    logger.debug(f"Removed span name pattern: {pattern}")


def enable_context_suppression(enabled: bool = True) -> None:
    """Enable or disable context-based suppression.

    Args:
        enabled: Whether to enable context suppression
    """
    global _context_suppression_enabled
    _context_suppression_enabled = enabled
    logger.debug(f"Context suppression {'enabled' if enabled else 'disabled'}")


def get_suppression_stats() -> Dict[str, Any]:
    """Get current suppression configuration statistics.

    Returns:
        Dictionary with suppression statistics
    """
    return {
        "total_exclusions": len(_exclusions),
        "context_suppression_enabled": _context_suppression_enabled,
        "context_rules": {
            "span_operations": len(CONTEXT_SUPPRESSION_RULES["span_operation"]),
            "span_name_patterns": len(CONTEXT_SUPPRESSION_RULES["span_name_patterns"]),
            "user_agent_patterns": len(CONTEXT_SUPPRESSION_RULES["user_agent_patterns"]),
        },
        "exclusions_sample": list(_exclusions)[:10],  # First 10 exclusions
    }


def wrap_http_client(client: Any) -> Any:
    """Enhanced HTTP client wrapper with context-aware suppression.

    Args:
        client: The HTTP client to wrap

    Returns:
        Wrapped client
    """
    original_request = client.request

    def wrapped_request(method, url, *args, **kwargs):
        # Get current suppression context
        suppression_context = getattr(_thread_local, "suppression_context", {})

        # Check if suppressed with context awareness
        if is_suppressed() or should_suppress_url(url, suppression_context):
            logger.debug(
                f"Suppressing HTTP instrumentation for {method} {url} (context: {suppression_context.get('reason', 'unknown')})"
            )
            # Call original without instrumentation
            return original_request(method, url, *args, **kwargs)

        # Create span for this request with context information
        span = create_http_span(method, url, suppression_context)
        try:
            response = original_request(method, url, *args, **kwargs)
            if span:
                span.set_status("OK")
            return response
        except Exception as e:
            if span:
                span.set_status("ERROR", str(e))
            raise
        finally:
            if span:
                span.end()

    client.request = wrapped_request
    return client


def create_http_span(
    method: str, url: str, context: Optional[Dict[str, Any]] = None
) -> Optional[Any]:
    """Create a span for an HTTP request with context information.

    Args:
        method: HTTP method
        url: Request URL
        context: Suppression context information

    Returns:
        Span object or None
    """
    # This is a placeholder - actual implementation would create a real span
    context_info = f" (context: {context.get('reason', 'none')})" if context else ""
    logger.debug(f"Creating HTTP span: {method} {url}{context_info}")
    return None


def make_http_call(url: str) -> Any:
    """Make an HTTP call (placeholder for testing).

    Args:
        url: URL to call

    Returns:
        Response
    """
    # This is a placeholder for testing
    return {"url": url, "suppressed": is_suppressed()}


def patch_requests() -> None:
    """Patch requests library to respect suppression."""
    try:
        import requests  # type: ignore[import-untyped]

        # Patch Session class
        original_session_init = requests.Session.__init__

        def patched_init(self, *args, **kwargs):
            original_session_init(self, *args, **kwargs)
            wrap_http_session(self)

        requests.Session.__init__ = patched_init  # type: ignore[assignment]
        logger.debug("Patched requests library for suppression")

    except ImportError:
        logger.debug("requests library not available")


def patch_httpx() -> None:
    """Patch HTTPX library to respect suppression."""
    try:
        import httpx  # type: ignore

        # Patch Client class
        original_client_init = httpx.Client.__init__

        def patched_init(self, *args, **kwargs):
            original_client_init(self, *args, **kwargs)
            wrap_http_client(self)

        httpx.Client.__init__ = patched_init  # type: ignore[assignment]
        logger.debug("Patched HTTPX library for suppression")

    except ImportError:
        logger.debug("HTTPX library not available")


def wrap_http_session(session: Any) -> Any:
    """Enhanced HTTP session wrapper with context-aware suppression.

    Args:
        session: The session to wrap

    Returns:
        Wrapped session
    """
    # Wrap common methods
    for method_name in ["get", "post", "put", "delete", "patch", "head", "options"]:
        if hasattr(session, method_name):
            original_method = getattr(session, method_name)

            def make_wrapped(original):
                def wrapped_method(url, *args, **kwargs):
                    # Get current suppression context
                    suppression_context = getattr(_thread_local, "suppression_context", {})

                    if is_suppressed() or should_suppress_url(url, suppression_context):
                        logger.debug(
                            f"Suppressing HTTP instrumentation for {method_name.upper()} {url} (context: {suppression_context.get('reason', 'unknown')})"
                        )
                        return original(url, *args, **kwargs)

                    span = create_http_span(method_name.upper(), url, suppression_context)
                    try:
                        response = original(url, *args, **kwargs)
                        if span:
                            span.set_status("OK")
                        return response
                    except Exception as e:
                        if span:
                            span.set_status("ERROR", str(e))
                        raise
                    finally:
                        if span:
                            span.end()

                return wrapped_method

            # Use setattr to assign wrapped method; ignore type checker since methods are descriptors
            setattr(session, method_name, make_wrapped(original_method))  # type: ignore[method-assign]

    return session


def wrap_exporter(exporter_func: Callable, exporter_type: str = "unknown") -> Callable:
    """Enhanced exporter wrapper with context-aware suppression.

    Args:
        exporter_func: The exporter function
        exporter_type: Type of exporter (e.g., "otlp_http", "otlp_grpc")

    Returns:
        Wrapped function
    """

    @functools.wraps(exporter_func)
    def wrapper(*args, **kwargs):
        with with_export_suppression(exporter_type):
            return exporter_func(*args, **kwargs)

    return wrapper


# Auto-configuration for exporters
def configure_exporter_suppression() -> None:
    """Configure enhanced HTTP suppression for all exporters."""
    try:
        from .exporters.otlp_grpc import OTLPGRPCExporter
        from .exporters.otlp_http import OTLPHTTPExporter

        # Wrap export methods with enhanced context-aware suppression
        if hasattr(OTLPHTTPExporter, "export"):
            setattr(OTLPHTTPExporter, "export", wrap_exporter(OTLPHTTPExporter.export, "otlp_http"))  # type: ignore[method-assign]

        if hasattr(OTLPGRPCExporter, "export"):
            setattr(OTLPGRPCExporter, "export", wrap_exporter(OTLPGRPCExporter.export, "otlp_grpc"))  # type: ignore[method-assign]

        logger.debug("Configured enhanced HTTP suppression for exporters")

    except ImportError:
        logger.debug("Exporters not available for suppression configuration")


# Initialize on module import
def initialize() -> None:
    """Initialize HTTP suppression."""
    # Load custom exclusions from environment
    load_exclusions_from_env()

    # Configure exporter suppression
    configure_exporter_suppression()

    # Patch HTTP libraries if available
    patch_requests()
    patch_httpx()

    logger.debug("HTTP suppression initialized")


# Auto-initialize on import
initialize()
