"""
MVK SDK Configuration Package

This package contains all configuration-related definitions and utilities.
It provides a centralized, versioned registry of environment variables,
configuration parameters, and wrapper definitions.

⚠️  IMPORTANT: This package is designed for internal SDK use only.
    Configuration definitions should not be modified without proper
    versioning consideration and backward compatibility assessment.

Package Structure:
- registry.py: Environment variable registry and configuration schema
- utils.py: Configuration utilities and helper functions (future)
- validators.py: Configuration validation functions (future)

Version: 1.0.0
Created: 02-OCT-2025
"""

# Re-export the configuration model
from .config_model import (
    BatchingConfig,
    ExporterConfig,
    FailedBatchDiskConfig,
    LoggingConfig,
    MvkSdkConfig,
    ServerlessConfig,
    WrappersConfig,
    create_config,
)

# Re-export the main registry components for convenience
from .registry import (
    ALLOWED_WRAPPERS,
    CONFIG_SCHEMA,
    REGISTRY_LAST_UPDATED,
    REGISTRY_VERSION,
    WRAPPER_DEFINITIONS,
    ConfigParameter,
    generate_documentation_table,
    generate_wrapper_documentation,
    get_all_env_vars,
    get_all_wrappers,
    get_registry_info,
    get_required_params_for_mode,
    get_wrapper_info,
    validate_wrapper,
)

__version__ = "1.0.0"
__all__ = [
    "CONFIG_SCHEMA",
    "ALLOWED_WRAPPERS",
    "WRAPPER_DEFINITIONS",
    "ConfigParameter",
    "generate_wrapper_documentation",
    "generate_documentation_table",
    "validate_wrapper",
    "get_wrapper_info",
    "get_all_wrappers",
    "get_registry_info",
    "get_all_env_vars",
    "get_required_params_for_mode",
    "REGISTRY_VERSION",
    "REGISTRY_LAST_UPDATED",
    # Configuration model exports
    "MvkSdkConfig",
    "BatchingConfig",
    "ExporterConfig",
    "FailedBatchDiskConfig",
    "LoggingConfig",
    "ServerlessConfig",
    "WrappersConfig",
    "create_config",
]
