"""
Environment Variable Registry for MVK SDK

⚠️  CRITICAL WARNING: DO NOT MODIFY THIS CONFIGURATION ⚠️

    This file contains the authoritative registry of all environment variables,
    configuration parameters, and wrapper definitions for the MVK SDK.

    Modifying this configuration can lead to:
    - Backward compatibility issues
    - Breaking changes for existing deployments
    - Inconsistent behavior across SDK versions
    - Configuration validation failures

    If you need to add new parameters or modify existing ones:
    1. Consider the impact on existing users
    2. Follow semantic versioning principles
    3. Provide migration guides for breaking changes
    4. Update all related documentation and examples

    This registry is imported by config_schema.py and other modules.
    Changes here will affect the entire SDK configuration system.

    Location: mvk_sdk.config.registry
    This package provides isolation for configuration definitions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IMPORTANT: How Environment Variable Prefixes Work
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The `env_var` field in CONFIG_SCHEMA does NOT include the "MVK_" prefix.
The prefix is AUTOMATICALLY ADDED by the loading code in config_schema.py.

Flow:
────────────────────────────────────────────────────────────────────────────

    CONFIG_SCHEMA              Load Configuration           User's Shell
    (Logical Name)             (Adds Prefix)                (Actual Variable)
    ─────────────────          ──────────────────           ─────────────────
    env_var="AGENT_ID"    ──►  os.getenv("MVK_AGENT_ID") ◄── export MVK_AGENT_ID=...
    env_var="API_KEY"     ──►  os.getenv("MVK_API_KEY")   ◄── export MVK_API_KEY=...
    env_var="EXPORTER_    ──►  os.getenv("MVK_EXPORTER_   ◄── export MVK_EXPORTER_
         TIMEOUT"                    TIMEOUT")                       TIMEOUT=...

Why This Design?
────────────────────────────────────────────────────────────────────────────

    ✅ Schema stays clean and readable (no repeated "MVK_" prefix)
    ✅ Single point of control (change prefix in one place)
    ✅ Impossible to forget prefix (automatically added)
    ✅ Separation of concerns (schema = logic, code = implementation)

Example:
────────────────────────────────────────────────────────────────────────────

    1. Schema Definition:
       "timeout": ConfigParameter(
           env_var="EXPORTER_TIMEOUT",  # ← NO "MVK_" prefix here!
           config_path="config.exporter.timeout",  # ← exporter is nested in config
           param_type=int,
           default=10,
       )

    2. Loading Code (in config_schema.py):
       env_value = os.getenv(f"MVK_{param_def.env_var}")
       #                      ^^^^  Automatically adds "MVK_" prefix!

    3. User Sets Variable:
       export MVK_EXPORTER_TIMEOUT=30  # ← MUST include "MVK_" prefix!

    4. Result (after load_configuration):
       merged_config = {
           "config": {
               "api_key": "...",
               "tenant_id": "...",
               "exporter": {"timeout": 30, "mode": "DIRECT", ...},  # ← nested in config
               "batching": {...},
               ...
           }
       }

Adding New Parameters:
────────────────────────────────────────────────────────────────────────────

    When adding a new parameter to CONFIG_SCHEMA:

    ✅ DO:   env_var="MY_NEW_PARAM"
    ❌ DON'T: env_var="MVK_MY_NEW_PARAM"

    Users will set:    export MVK_MY_NEW_PARAM=value
    Code will look up: os.getenv("MVK_MY_NEW_PARAM")

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Author: MVK SDK Team
Version: 1.0.0
Created At: 02-OCT-2025
Last Updated: 02-OCT-2025
"""

import os
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Union


@dataclass
class ConfigParameter:
    """Configuration parameter definition for environment variable mapping."""

    env_var: str
    config_path: str
    param_type: type
    default: Any = None
    required: bool = False
    required_in_modes: Optional[List[str]] = None
    validator: Optional[Callable] = None
    description: str = ""


# ============================================================================
# WRAPPER DEFINITIONS - DO NOT MODIFY WITHOUT VERSIONING CONSIDERATION
# ============================================================================

# Allowed wrappers for auto-instrumentation
ALLOWED_WRAPPERS = {
    "genai",  # General AI/LLM operations (OpenAI, Anthropic, etc.)
    "vectordb",  # Vector database operations (ChromaDB, Pinecone, etc.)
    "http",  # HTTP client libraries (requests, httpx, urllib)
    "httpx",  # Async HTTP client library
    "requests",  # Synchronous HTTP client library
    "anthropic",  # Anthropic Claude API calls
    "openai",  # OpenAI API calls (GPT, DALL-E, etc.)
    "azure_openai",  # Azure OpenAI Service API calls
    "gemini",  # Google Gemini API calls
    "vertexai",  # Google Vertex AI API calls
    "bedrock",  # AWS Bedrock API calls
    "chromadb",  # ChromaDB vector database operations
    "pinecone",  # Pinecone vector database operations
    "qdrant",  # Qdrant vector database operations
    "weaviate",  # Weaviate vector database operations
}

# Detailed wrapper definitions for documentation
WRAPPER_DEFINITIONS = {
    "genai": {
        "description": "General AI/LLM operations wrapper",
        "auto_instruments": [
            "OpenAI API calls (chat completions, embeddings, images)",
            "Anthropic Claude API calls",
            "Google Gemini API calls",
            "Azure OpenAI Service API calls",
            "AWS Bedrock API calls",
            "Vertex AI API calls",
        ],
        "span_types": ["LLM", "EMBEDDING"],
        "metrics": ["token_usage", "cost_estimation", "latency"],
    },
    "vectordb": {
        "description": "Vector database operations wrapper",
        "auto_instruments": [
            "ChromaDB operations (collection creation, document insertion, similarity search)",
            "Pinecone operations (index management, vector upserts, queries)",
            "Qdrant operations (collections, points, search)",
            "Weaviate operations (schema, objects, graph queries)",
        ],
        "span_types": ["RETRIEVER", "VECTORDB"],
        "metrics": ["vector_count", "search_latency", "similarity_scores"],
    },
    "http": {
        "description": "HTTP client libraries wrapper",
        "auto_instruments": [
            "requests library HTTP calls",
            "httpx library HTTP calls",
            "urllib HTTP calls",
            "aiohttp HTTP calls",
        ],
        "span_types": ["HTTP_CLIENT"],
        "metrics": ["response_time", "status_codes", "payload_size"],
    },
    "httpx": {
        "description": "Async HTTP client library wrapper",
        "auto_instruments": [
            "httpx.AsyncClient HTTP requests",
            "httpx.Client HTTP requests",
            "Streaming responses",
        ],
        "span_types": ["HTTP_CLIENT"],
        "metrics": ["async_response_time", "connection_pool_stats"],
    },
    "requests": {
        "description": "Synchronous HTTP client library wrapper",
        "auto_instruments": [
            "requests.get/post/put/delete calls",
            "requests.Session HTTP calls",
            "Response streaming",
        ],
        "span_types": ["HTTP_CLIENT"],
        "metrics": ["response_time", "redirects", "timeouts"],
    },
    "anthropic": {
        "description": "Anthropic Claude API wrapper",
        "auto_instruments": [
            "anthropic.Anthropic messages.create()",
            "Streaming completions",
            "Tool use and function calling",
        ],
        "span_types": ["LLM"],
        "metrics": ["input_tokens", "output_tokens", "claude_model_usage"],
    },
    "openai": {
        "description": "OpenAI API wrapper",
        "auto_instruments": [
            "openai.ChatCompletion.create()",
            "openai.Completion.create()",
            "openai.Embedding.create()",
            "openai.Image.create()",
            "openai.Audio.transcribe()",
        ],
        "span_types": ["LLM", "EMBEDDING", "IMAGE", "AUDIO"],
        "metrics": ["prompt_tokens", "completion_tokens", "total_cost"],
    },
    "azure_openai": {
        "description": "Azure OpenAI Service wrapper",
        "auto_instruments": [
            "Azure OpenAI chat completions",
            "Azure OpenAI embeddings",
            "Azure OpenAI DALL-E image generation",
        ],
        "span_types": ["LLM", "EMBEDDING", "IMAGE"],
        "metrics": ["azure_usage", "deployment_metrics", "regional_latency"],
    },
    "gemini": {
        "description": "Google Gemini API wrapper",
        "auto_instruments": [
            "google.generativeai.GenerativeModel.generate_content()",
            "Multimodal content generation",
            "Embedding generation",
        ],
        "span_types": ["LLM", "EMBEDDING"],
        "metrics": ["gemini_tokens", "multimodal_usage", "safety_ratings"],
    },
    "vertexai": {
        "description": "Google Vertex AI wrapper",
        "auto_instruments": [
            "vertexai.preview.language_models.ChatModel.predict()",
            "vertexai.preview.language_models.TextGenerationModel.predict()",
            "Vertex AI embeddings and multimodal models",
        ],
        "span_types": ["LLM", "EMBEDDING"],
        "metrics": ["vertex_tokens", "model_deployment", "regional_performance"],
    },
    "bedrock": {
        "description": "AWS Bedrock wrapper",
        "auto_instruments": [
            "boto3 bedrock-runtime invoke_model()",
            "Bedrock streaming responses",
            "Multiple foundation models (Claude, Titan, etc.)",
        ],
        "span_types": ["LLM", "EMBEDDING"],
        "metrics": ["aws_usage", "model_inference", "bedrock_metrics"],
    },
    "chromadb": {
        "description": "ChromaDB vector database wrapper",
        "auto_instruments": [
            "chromadb.Collection.add()",
            "chromadb.Collection.query()",
            "chromadb.Collection.get()",
            "Collection management operations",
        ],
        "span_types": ["VECTORDB", "RETRIEVER"],
        "metrics": ["collection_size", "query_latency", "embedding_dimensions"],
    },
    "pinecone": {
        "description": "Pinecone vector database wrapper",
        "auto_instruments": [
            "pinecone.Index.upsert()",
            "pinecone.Index.query()",
            "pinecone.Index.fetch()",
            "Index management operations",
        ],
        "span_types": ["VECTORDB", "RETRIEVER"],
        "metrics": ["vector_count", "index_stats", "query_performance"],
    },
    "qdrant": {
        "description": "Qdrant vector database wrapper",
        "auto_instruments": [
            "qdrant_client.QdrantClient.upsert()",
            "qdrant_client.QdrantClient.search()",
            "Collection and point operations",
        ],
        "span_types": ["VECTORDB", "RETRIEVER"],
        "metrics": ["points_count", "search_latency", "collection_metrics"],
    },
    "weaviate": {
        "description": "Weaviate vector database wrapper",
        "auto_instruments": [
            "weaviate_client.Client.data_object.create()",
            "weaviate_client.Client.query.get()",
            "GraphQL queries and mutations",
        ],
        "span_types": ["VECTORDB", "RETRIEVER"],
        "metrics": ["object_count", "graph_queries", "schema_operations"],
    },
}


# =====================================================================================
# CONFIGURATION SCHEMA - DO NOT MODIFY WITHOUT EXPLICIT INSTRUCTIONS & IMPACT ANALYSIS
# =====================================================================================
#
# ⚠️  IMPORTANT: Environment Variable Prefix Handling
# ────────────────────────────────────────────────────────────────────────────────────
#
# The `env_var` field below does NOT include the "MVK_" prefix.
# The prefix is AUTOMATICALLY ADDED by config_schema.py when loading environment variables.
#
# Example Flow:
# ─────────────────────────────────────────────────────────────────────────────────────
#
#   1. Schema Definition (below):
#      "agent_id": ConfigParameter(
#          env_var="AGENT_ID",  # ← NO "MVK_" prefix
#          ...
#      )
#
#   2. Loading Code (config_schema.py, line 420):
#      env_value = os.getenv(f"MVK_{param_def.env_var}")
#      #                      ^^^^  Automatically adds "MVK_" prefix
#      # Result: os.getenv("MVK_AGENT_ID")
#
#   3. User Sets Variable:
#      export MVK_AGENT_ID=my-agent  # ← MUST include "MVK_" prefix
#
#   4. Config Result:
#      config["agent_id"] = "my-agent"
#      config["api_key"] = "mvk_key123"
#      config["exporter"]["timeout"] = 30
#
# Quick Reference:
# ─────────────────────────────────────────────────────────────────────────────────────
#   Schema                    Loading Code                  User's Shell
#   ─────────────────────────────────────────────────────────────────────────────────
#   env_var="AGENT_ID"   →   os.getenv("MVK_AGENT_ID")  ←  export MVK_AGENT_ID=...
#   env_var="API_KEY"    →   os.getenv("MVK_API_KEY")   ←  export MVK_API_KEY=...
#   env_var="EXPORTER_   →   os.getenv("MVK_EXPORTER_   ←  export MVK_EXPORTER_
#        TIMEOUT"                  TIMEOUT")                      TIMEOUT=...
#
# When Adding New Parameters:
# ─────────────────────────────────────────────────────────────────────────────────────
#   ✅ DO:   env_var="MY_NEW_PARAM"
#   ❌ DON'T: env_var="MVK_MY_NEW_PARAM"
#
#   The MVK_ prefix will be added automatically by the loading code.
#
# =====================================================================================

CONFIG_SCHEMA: Dict[str, ConfigParameter] = {
    # ========== BASIC CONFIGURATION ==========
    "agent_id": ConfigParameter(  # Direct at root level
        env_var="AGENT_ID",  # ← Loaded from MVK_AGENT_ID (prefix added automatically)
        config_path="agent_id",
        param_type=str,
        default=None,
        required=True,
        description="Agent identifier",
    ),
    "api_key": ConfigParameter(  # Root level
        env_var="API_KEY",  # ← Loaded from MVK_API_KEY (prefix added automatically)
        config_path="api_key",
        param_type=str,
        default=None,
        required_in_modes=["DIRECT"],
        description="MVK API key for authentication",
    ),
    "agent_name": ConfigParameter(  # Root level
        env_var="AGENT_NAME",
        config_path="agent_name",
        param_type=str,
        default=None,
        description="Human-readable agent name",
    ),
    "tenant_id": ConfigParameter(  # Root level
        env_var="TENANT_ID",
        config_path="tenant_id",
        param_type=str,
        default=None,
        required_in_modes=["DIRECT"],
        description="Multi-tenant identifier (required in DIRECT mode, sent as X-Tenant-ID header)",
    ),
    "enabled": ConfigParameter(  # Root level
        env_var="ENABLED",
        config_path="enabled",
        param_type=bool,
        default=True,
        description="Enable/disable SDK (default: True)",
    ),
    # ========== DEPLOYMENT MODE ==========
    "mode": ConfigParameter(
        env_var="MODE",  # Fixed: was MVK_MODE
        config_path="exporter.mode",
        param_type=str,
        default="DIRECT",
        validator=lambda v: v.upper() in ("DIRECT", "COLLECTOR"),
        description="Deployment mode: DIRECT (to Mavvrik) or COLLECTOR (to your OTEL collector)",
    ),
    # ========== EXPORTER CONFIGURATION (Nested in config) ==========
    "type": ConfigParameter(
        env_var="EXPORTER_TYPE",
        config_path="exporter.type",
        param_type=str,
        default="otlp_http",
        validator=lambda v: v in ("otlp_http", "otlp_grpc", "console", "file"),
        description="Exporter type: otlp_http, otlp_grpc, console, or file (protocol derived from type)",
    ),
    "endpoint": ConfigParameter(
        env_var="ENDPOINT",
        config_path="exporter.endpoint",
        param_type=str,
        default=None,
        description="Endpoint URL or host:port (Mavvrik URL in DIRECT mode, collector address in COLLECTOR mode)",
    ),
    "headers": ConfigParameter(
        env_var="HEADERS",
        config_path="exporter.headers",
        param_type=str,  # JSON string or comma-separated key=value pairs
        default=None,
        description="Custom headers (JSON string or key1=val1,key2=val2 format) - works for both DIRECT and COLLECTOR modes",
    ),
    "insecure": ConfigParameter(
        env_var="EXPORTER_INSECURE",
        config_path="exporter.insecure",
        param_type=bool,
        default=False,
        description="Use HTTP instead of HTTPS (or no TLS for gRPC)",
    ),
    "compression": ConfigParameter(
        env_var="EXPORTER_COMPRESSION",
        config_path="exporter.compression",
        param_type=str,
        default="gzip",
        validator=lambda v: v in ("gzip", "none"),
        description="Compression method: gzip or none",
    ),
    "timeout": ConfigParameter(
        env_var="EXPORTER_TIMEOUT",
        config_path="exporter.timeout",
        param_type=int,
        default=10,
        validator=lambda v: 1 <= v <= 300,
        description="Request timeout in seconds",
    ),
    "max_retries": ConfigParameter(
        env_var="EXPORTER_MAX_RETRIES",
        config_path="exporter.max_retries",
        param_type=int,
        default=6,
        validator=lambda v: 0 <= v <= 20,
        description="Maximum retry attempts",
    ),
    "retry_timeout": ConfigParameter(
        env_var="EXPORTER_RETRY_TIMEOUT",
        config_path="exporter.retry_timeout",
        param_type=int,
        default=60,
        validator=lambda v: 1 <= v <= 600,
        description="Total retry timeout in seconds",
    ),
    "file_path": ConfigParameter(
        env_var="EXPORTER_FILE_PATH",
        config_path="exporter.file_path",
        param_type=str,
        default=None,
        description="File path for file exporter",
    ),
    "format": ConfigParameter(
        env_var="EXPORTER_FORMAT",
        config_path="exporter.format",
        param_type=str,
        default="simple",
        validator=lambda v: v in ("simple", "json"),
        description="Output format: simple or json (for console/file exporters)",
    ),
    # ========== BATCHING CONFIGURATION (Nested in config) ==========
    "batching_max_items": ConfigParameter(
        env_var="BATCH_MAX_ITEMS",
        config_path="batching.max_items",
        param_type=int,
        default=2000,
        validator=lambda v: 1 <= v <= 10000,
        description="Maximum spans per batch",
    ),
    "batching_max_bytes": ConfigParameter(
        env_var="BATCH_MAX_BYTES",
        config_path="batching.max_bytes",
        param_type=int,
        default=2097152,  # 2 MiB
        validator=lambda v: 1024 <= v <= 10485760,  # 1KB - 10MB
        description="Maximum batch size in bytes",
    ),
    "batching_max_interval_ms": ConfigParameter(
        env_var="BATCH_MAX_INTERVAL_MS",
        config_path="batching.max_interval_ms",
        param_type=int,
        default=3000,
        validator=lambda v: 100 <= v <= 60000,
        description="Maximum time between batches in milliseconds",
    ),
    # ========== FAILED BATCH DISK (Nested in config) ==========
    "failed_batch_disk_enabled": ConfigParameter(
        env_var="FAILED_BATCH_DISK_ENABLED",
        config_path="failed_batch_disk.enabled",
        param_type=bool,
        default=False,
        description="Enable failed batch disk storage",
    ),
    "failed_batch_disk_path": ConfigParameter(
        env_var="FAILED_BATCH_DISK_PATH",
        config_path="failed_batch_disk.path",
        param_type=str,
        default=None,
        description="Failed batch storage path",
    ),
    "failed_batch_disk_max_size_mb": ConfigParameter(
        env_var="FAILED_BATCH_DISK_MAX_SIZE_MB",
        config_path="failed_batch_disk.max_size_mb",
        param_type=int,
        default=1000,
        validator=lambda v: 10 <= v <= 100000,
        description="Maximum storage size in MB",
    ),
    "failed_batch_disk_retry_interval": ConfigParameter(
        env_var="FAILED_BATCH_DISK_RETRY_INTERVAL",
        config_path="failed_batch_disk.retry_interval",
        param_type=int,
        default=60,
        validator=lambda v: 1 <= v <= 3600,
        description="Retry interval in seconds",
    ),
    # ========== LOGGING ==========
    "log_level": ConfigParameter(  # Under logging
        env_var="LOG_LEVEL",
        config_path="logging.level",
        param_type=str,
        default="OFF",
        validator=lambda v: str(v).upper() in ("OFF", "INFO", "DEBUG", "WARNING", "ERROR"),
        description="Global log level",
    ),
    "log_prompts_responses": ConfigParameter(  # Under logging
        env_var="LOG_PROMPTS_RESPONSES",
        config_path="logging.prompts_responses",
        param_type=bool,
        default=False,
        description="Enable logging of prompts/responses",
    ),
    # ========== VALIDATION ==========
    "strict_validation": ConfigParameter(  # Root level
        env_var="STRICT_VALIDATION",
        config_path="strict_validation",
        param_type=bool,
        default=False,
        description="Enable strict schema validation",
    ),
    # ========== TAGS CONFIGURATION ==========
    "tags": ConfigParameter(  # At root level - populated from MVK_TAG_* env vars
        env_var="TAGS",  # Not used directly - populated from MVK_TAG_* variables
        config_path="tags",
        param_type=dict,
        default=None,
        description="Global tags configuration (populated from MVK_TAG_* environment variables)",
    ),
    "tag_limit": ConfigParameter(  # Maximum number of tags allowed per span
        env_var="TAG_LIMIT",
        config_path="tag_limit",
        param_type=int,
        default=10,
        validator=lambda v: 1 <= v <= 10,  # SDK enforces max 10, user can set lower
        description="Maximum number of tags allowed per span (1-10, SDK enforces max 10)",
    ),
    # ========== WRAPPERS CONFIGURATION ==========
    "wrappers": ConfigParameter(  # List of included wrappers - stored separately from wrapper configs
        env_var="WRAPPERS",
        config_path="wrappers.include",  # Changed to avoid conflict with wrappers.http.exclusions
        param_type=list,
        default=["genai", "vectordb"],
        description="Auto-instrumentation wrappers to include (validated against allowed list)",
    ),
    # ========== SERVERLESS CONFIGURATION ==========
    "serverless_force": ConfigParameter(  # Force serverless mode
        env_var="SERVERLESS",
        config_path="serverless.force",
        param_type=bool,
        default=False,
        description="Force serverless mode (set to 'true' to override auto-detection)",
    ),
    # ========== WRAPPER CONFIGURATION ==========
    "http_exclusions": ConfigParameter(  # HTTP wrapper exclusion list (language-agnostic)
        env_var="HTTP_EXCLUSIONS",
        config_path="wrappers.http.exclusions",  # At wrappers level, not config.wrappers
        param_type=str,  # JSON array or comma-separated string
        default=None,
        description="HTTP wrapper exclusion list - URLs to exclude from HTTP instrumentation when http wrapper is enabled (JSON array or comma-separated, e.g., '[\"api.openai.com\"]' or 'api.openai.com,api.anthropic.com')",
    ),
    # ========== WRAPPER LOGGING ==========
    "wrapper_log_level": ConfigParameter(  # Wrapper-specific log level (backward compat)
        env_var="WRAPPER_LOG_LEVEL",
        config_path="logging.wrapper_level",
        param_type=str,
        default=None,
        validator=lambda v: str(v).upper() in ("INFO", "DEBUG", "WARNING", "ERROR"),
        description="Wrapper-specific log level (backward compatibility)",
    ),
    # ========== EXPORTER HEADERS ==========
}


# ============================================================================
# UTILITY FUNCTIONS FOR DOCUMENTATION
# ============================================================================


def generate_wrapper_documentation() -> str:
    """Generate detailed documentation for all available wrappers."""
    lines = []
    lines.append("# Auto-Instrumentation Wrappers")
    lines.append("")
    lines.append("The MVK SDK provides comprehensive auto-instrumentation through wrappers.")
    lines.append("Each wrapper automatically instruments specific libraries and operations.")
    lines.append("")

    for wrapper_name, definition in WRAPPER_DEFINITIONS.items():
        lines.append(f"## {wrapper_name.upper()}")
        lines.append("")
        lines.append(f"**Description:** {definition['description']}")
        lines.append("")
        lines.append("**Auto-instruments:**")
        for item in definition["auto_instruments"]:
            lines.append(f"- {item}")
        lines.append("")
        lines.append("**Span Types:** " + ", ".join(definition["span_types"]))
        lines.append("")
        lines.append("**Metrics Collected:** " + ", ".join(definition["metrics"]))
        lines.append("")
        lines.append("---")
        lines.append("")

    return "\n".join(lines)


def generate_documentation_table() -> str:
    """
    Auto-generate the configuration reference table for documentation.

    Returns:
        Markdown table string
    """
    lines = []
    lines.append("| Parameter | Environment Variable | Default | Required | Description |")
    lines.append("|-----------|---------------------|---------|----------|-------------|")

    for key, param in CONFIG_SCHEMA.items():
        env_var = f"`{param.env_var}`"
        default_val = f"`{param.default}`" if param.default is not None else "None"
        required = "Yes" if param.required else ("DIRECT" if param.required_in_modes else "No")
        description = param.description.replace("|", "\\|")  # Escape pipes in description

        lines.append(f"| `{key}` | {env_var} | {default_val} | {required} | {description} |")

    return "\n".join(lines)


def get_all_env_vars() -> List[str]:
    """Get list of all environment variables used by the SDK."""
    return [param.env_var for param in CONFIG_SCHEMA.values()]


def get_required_params_for_mode(mode: str) -> List[str]:
    """Get list of required parameters for a specific deployment mode."""
    required = []
    for key, param in CONFIG_SCHEMA.items():
        if param.required or (param.required_in_modes and mode.upper() in param.required_in_modes):
            required.append(key)
    return required


# ============================================================================
# VALIDATION FUNCTIONS
# ============================================================================


def validate_wrapper(wrapper_name: str) -> bool:
    """Validate if a wrapper name is in the allowed list."""
    return wrapper_name in ALLOWED_WRAPPERS


def get_wrapper_info(wrapper_name: str) -> Optional[Dict[str, Any]]:
    """Get detailed information about a specific wrapper."""
    return WRAPPER_DEFINITIONS.get(wrapper_name)


def get_all_wrappers() -> List[str]:
    """Get list of all allowed wrapper names."""
    return sorted(list(ALLOWED_WRAPPERS))


# ============================================================================
# VERSION INFORMATION
# ============================================================================

REGISTRY_VERSION = "1.0.0"
REGISTRY_LAST_UPDATED = "2024"


def get_registry_info() -> Dict[str, str]:
    """Get registry version and metadata information."""
    return {
        "version": REGISTRY_VERSION,
        "last_updated": REGISTRY_LAST_UPDATED,
        "total_parameters": str(len(CONFIG_SCHEMA)),
        "total_wrappers": str(len(ALLOWED_WRAPPERS)),
        "description": "MVK SDK Environment Variable Registry",
    }
