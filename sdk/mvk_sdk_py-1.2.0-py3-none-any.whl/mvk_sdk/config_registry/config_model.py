"""
MVK SDK Configuration Model

This module provides a structured Pydantic model for MVK SDK configuration with
three-tier priority handling:

Priority (highest to lowest):
1. MVK_* environment variables (highest)
2. instrument() function parameters (medium)
3. Default values from CONFIG_SCHEMA (lowest)

The model provides:
- Type safety and validation
- Clear configuration structure
- Easy access to nested values
- Preservation of all existing validation logic
- Automatic environment variable loading with MVK_ prefix

Author: MVK SDK Team
Version: 1.0.0
"""

import json
import os
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from mvk_sdk.config_registry.registry import CONFIG_SCHEMA, ConfigParameter

# ============================================================================
# NESTED CONFIGURATION MODELS
# ============================================================================


class ExporterConfig(BaseModel):
    """Exporter configuration for telemetry data export."""

    mode: str = "DIRECT"
    type: str = "otlp_http"
    endpoint: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    insecure: bool = False
    compression: str = "gzip"
    timeout: int = 10
    max_retries: int = 6
    retry_timeout: int = 60
    file_path: Optional[str] = None
    format: str = "simple"
    otel_mode: bool = False  # Derived from mode

    @field_validator("mode")
    @classmethod
    def validate_mode(cls, v: str) -> str:
        """Validate deployment mode."""
        if v.upper() not in ("DIRECT", "COLLECTOR"):
            raise ValueError(f"Invalid mode: {v}. Must be DIRECT or COLLECTOR")
        return v.upper()

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        """Validate exporter type."""
        if v not in ("otlp_http", "otlp_grpc", "console", "file"):
            raise ValueError(
                f"Invalid exporter type: {v}. Must be one of: otlp_http, otlp_grpc, console, file"
            )
        return v

    @field_validator("compression")
    @classmethod
    def validate_compression(cls, v: str) -> str:
        """Validate compression method."""
        if v not in ("gzip", "none"):
            raise ValueError(f"Invalid compression: {v}. Must be gzip or none")
        return v

    @field_validator("timeout")
    @classmethod
    def validate_timeout(cls, v: int) -> int:
        """Validate timeout range."""
        if not 1 <= v <= 300:
            raise ValueError(f"Timeout must be between 1 and 300 seconds, got {v}")
        return v

    @field_validator("max_retries")
    @classmethod
    def validate_max_retries(cls, v: int) -> int:
        """Validate max retries range."""
        if not 0 <= v <= 20:
            raise ValueError(f"Max retries must be between 0 and 20, got {v}")
        return v

    @field_validator("retry_timeout")
    @classmethod
    def validate_retry_timeout(cls, v: int) -> int:
        """Validate retry timeout range."""
        if not 1 <= v <= 600:
            raise ValueError(f"Retry timeout must be between 1 and 600 seconds, got {v}")
        return v

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        """Validate output format."""
        if v not in ("simple", "json"):
            raise ValueError(f"Invalid format: {v}. Must be simple or json")
        return v


class BatchingConfig(BaseModel):
    """Batching configuration for span processing."""

    max_items: int = 2000
    max_bytes: int = 2097152  # 2 MiB
    max_interval_ms: int = 3000

    @field_validator("max_items")
    @classmethod
    def validate_max_items(cls, v: int) -> int:
        """Validate max items range."""
        if not 1 <= v <= 10000:
            raise ValueError(f"Max items must be between 1 and 10000, got {v}")
        return v

    @field_validator("max_bytes")
    @classmethod
    def validate_max_bytes(cls, v: int) -> int:
        """Validate max bytes range."""
        if not 1024 <= v <= 10485760:  # 1KB - 10MB
            raise ValueError(f"Max bytes must be between 1KB and 10MB, got {v}")
        return v

    @field_validator("max_interval_ms")
    @classmethod
    def validate_max_interval_ms(cls, v: int) -> int:
        """Validate max interval range."""
        if not 100 <= v <= 60000:
            raise ValueError(f"Max interval must be between 100 and 60000 ms, got {v}")
        return v


class FailedBatchDiskConfig(BaseModel):
    """Failed batch disk storage configuration."""

    enabled: bool = False
    path: Optional[str] = None
    max_size_mb: int = 1000
    retry_interval: int = 60

    @field_validator("max_size_mb")
    @classmethod
    def validate_max_size_mb(cls, v: int) -> int:
        """Validate max size range."""
        if not 10 <= v <= 100000:
            raise ValueError(f"Max size must be between 10 and 100000 MB, got {v}")
        return v

    @field_validator("retry_interval")
    @classmethod
    def validate_retry_interval(cls, v: int) -> int:
        """Validate retry interval range."""
        if not 1 <= v <= 3600:
            raise ValueError(f"Retry interval must be between 1 and 3600 seconds, got {v}")
        return v


class LoggingConfig(BaseModel):
    """Logging configuration."""

    level: str = "OFF"
    prompts_responses: bool = False
    wrapper_level: Optional[str] = None

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: str) -> str:
        """Validate log level."""
        if v.upper() not in ("OFF", "INFO", "DEBUG", "WARNING", "ERROR"):
            raise ValueError(
                f"Invalid log level: {v}. Must be one of: OFF, INFO, DEBUG, WARNING, ERROR"
            )
        return v.upper()

    @field_validator("wrapper_level")
    @classmethod
    def validate_wrapper_level(cls, v: Optional[str]) -> Optional[str]:
        """Validate wrapper log level."""
        if v is None:
            return v
        if v.upper() not in ("INFO", "DEBUG", "WARNING", "ERROR"):
            raise ValueError(
                f"Invalid wrapper log level: {v}. Must be one of: INFO, DEBUG, WARNING, ERROR"
            )
        return v.upper()


class ServerlessConfig(BaseModel):
    """Serverless mode configuration."""

    force: bool = False


class WrappersConfig(BaseModel):
    """Wrappers configuration."""

    include: List[str] = Field(default_factory=lambda: ["genai", "vectordb"])
    http: Optional[Dict[str, Any]] = Field(default_factory=dict)


# ============================================================================
# MAIN CONFIGURATION MODEL
# ============================================================================


class MvkSdkConfig(BaseModel):
    """
    Main MVK SDK Configuration Model.

    This model provides structured access to all SDK configuration with
    three-tier priority handling:
    1. Environment variables (MVK_* prefix) - highest priority
    2. Function parameters from instrument() - medium priority
    3. Default values from CONFIG_SCHEMA - lowest priority

    All validation logic from the registry is preserved.
    """

    # Core configuration
    agent_id: Optional[str] = None
    api_key: Optional[str] = None
    tenant_id: Optional[str] = None
    enabled: bool = True
    agent_name: Optional[str] = None
    strict_validation: bool = False

    # Nested configuration
    exporter: ExporterConfig = Field(default_factory=ExporterConfig)
    batching: BatchingConfig = Field(default_factory=BatchingConfig)
    failed_batch_disk: FailedBatchDiskConfig = Field(default_factory=FailedBatchDiskConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    serverless: ServerlessConfig = Field(default_factory=ServerlessConfig)
    wrappers: WrappersConfig = Field(default_factory=WrappersConfig)

    # Tags and limits
    tags: Optional[Dict[str, str]] = None
    tag_limit: int = 10

    @field_validator("tag_limit")
    @classmethod
    def validate_tag_limit(cls, v: int) -> int:
        """Validate and clamp tag limit range."""
        import logging

        logger = logging.getLogger(__name__)

        if v < 1:
            logger.warning(f"Tag limit {v} is below minimum (1), clamping to 1")
            return 1
        elif v > 10:
            logger.warning(f"Tag limit {v} exceeds maximum (10), clamping to 10")
            return 10
        return v

    @model_validator(mode="after")
    def validate_required_fields(self) -> "MvkSdkConfig":
        """Validate mode-specific required fields."""
        # Validate agent_id is present (can come from any source)
        if not self.agent_id:
            raise ValueError(
                "agent_id is required. Provide via MVK_AGENT_ID environment variable, "
                "function parameter, or config dictionary."
            )

        mode = self.exporter.mode

        if mode == "DIRECT":
            if not self.api_key:
                raise ValueError("api_key is required in DIRECT mode")
            if not self.tenant_id:
                raise ValueError("tenant_id is required in DIRECT mode")

        # Set otel_mode based on deployment mode
        self.exporter.otel_mode = mode == "COLLECTOR"

        return self

    @classmethod
    def from_defaults(cls, skip_validation: bool = False) -> "MvkSdkConfig":
        """
        Create configuration with only default values from CONFIG_SCHEMA.

        This represents the lowest priority tier.

        Args:
            skip_validation: If True, skip Pydantic validation (for internal use)

        Returns:
            MvkSdkConfig with default values
        """
        config_dict: Dict[str, Any] = {}

        # Load defaults from schema
        for param_name, param_def in CONFIG_SCHEMA.items():
            if param_def.default is not None:
                _set_nested_value(config_dict, param_def.config_path, param_def.default)

        # Add a placeholder agent_id to allow object creation
        # (will be overridden by actual values in from_function_params or from_env_vars)
        if "agent_id" not in config_dict:
            config_dict["agent_id"] = ""

        if skip_validation:
            # Convert nested dicts to Pydantic models to avoid serialization warnings
            if "exporter" in config_dict and isinstance(config_dict["exporter"], dict):
                config_dict["exporter"] = ExporterConfig(**config_dict["exporter"])
            if "batching" in config_dict and isinstance(config_dict["batching"], dict):
                config_dict["batching"] = BatchingConfig(**config_dict["batching"])
            if "failed_batch_disk" in config_dict and isinstance(
                config_dict["failed_batch_disk"], dict
            ):
                config_dict["failed_batch_disk"] = FailedBatchDiskConfig(
                    **config_dict["failed_batch_disk"]
                )
            if "logging" in config_dict and isinstance(config_dict["logging"], dict):
                config_dict["logging"] = LoggingConfig(**config_dict["logging"])
            if "serverless" in config_dict and isinstance(config_dict["serverless"], dict):
                config_dict["serverless"] = ServerlessConfig(**config_dict["serverless"])
            if "wrappers" in config_dict and isinstance(config_dict["wrappers"], dict):
                config_dict["wrappers"] = WrappersConfig(**config_dict["wrappers"])

            # Use model_construct to skip validation for internal use
            return cls.model_construct(**config_dict)
        else:
            return cls(**config_dict)

    @classmethod
    def from_function_params(
        cls,
        agent_id: Optional[str] = None,
        api_key: Optional[str] = None,
        tenant_id: Optional[str] = None,
        enabled: Optional[bool] = None,
        agent_name: Optional[str] = None,
        exporter: Optional[Dict[str, Any]] = None,
        batching: Optional[Dict[str, int]] = None,
        failed_batch_disk: Optional[Dict[str, Any]] = None,
        logging: Optional[Dict[str, Any]] = None,
        serverless: Optional[Dict[str, bool]] = None,
        strict_validation: Optional[bool] = None,
        tag_limit: Optional[int] = None,
        tags: Optional[Dict[str, str]] = None,
        wrappers: Optional[Dict[str, Any]] = None,
    ) -> "MvkSdkConfig":
        """
        Create configuration from instrument() function parameters.

        This represents the medium priority tier. It starts with defaults
        and applies function parameters on top.

        Args:
            agent_id: Agent identifier
            api_key: API key for authentication
            tenant_id: Tenant identifier
            enabled: Enable/disable SDK
            agent_name: Human-readable agent name
            exporter: Exporter configuration dict
            batching: Batching configuration dict
            failed_batch_disk: Failed batch disk configuration dict
            logging: Logging configuration dict
            serverless: Serverless configuration dict
            strict_validation: Enable strict validation
            tag_limit: Maximum tags per span
            tags: Global tags
            wrappers: Wrappers config dict with "include" and optional "http" keys

        Returns:
            MvkSdkConfig with defaults + function parameters applied
        """
        # Build a flat configuration dict from CONFIG_SCHEMA defaults
        config_dict: Dict[str, Any] = {}
        for param_name, param_def in CONFIG_SCHEMA.items():
            if param_def.default is not None:
                _set_nested_value(config_dict, param_def.config_path, param_def.default)

        # Apply function parameters (override defaults)
        if agent_id is not None:
            config_dict["agent_id"] = agent_id
        if api_key is not None:
            config_dict["api_key"] = api_key
        if tenant_id is not None:
            config_dict["tenant_id"] = tenant_id
        if enabled is not None:
            config_dict["enabled"] = enabled
        if agent_name is not None:
            config_dict["agent_name"] = agent_name
        if strict_validation is not None:
            config_dict["strict_validation"] = strict_validation
        if tag_limit is not None:
            config_dict["tag_limit"] = tag_limit
        if tags is not None:
            config_dict["tags"] = tags

        # Apply nested configurations - merge with existing defaults
        if exporter is not None:
            if "exporter" not in config_dict:
                config_dict["exporter"] = {}
            config_dict["exporter"].update(exporter)
        if batching is not None:
            if "batching" not in config_dict:
                config_dict["batching"] = {}
            config_dict["batching"].update(batching)
        if failed_batch_disk is not None:
            if "failed_batch_disk" not in config_dict:
                config_dict["failed_batch_disk"] = {}
            config_dict["failed_batch_disk"].update(failed_batch_disk)
        if logging is not None:
            if "logging" not in config_dict:
                config_dict["logging"] = {}
            config_dict["logging"].update(logging)
        if serverless is not None:
            if "serverless" not in config_dict:
                config_dict["serverless"] = {}
            config_dict["serverless"].update(serverless)
        if wrappers is not None:
            if "wrappers" not in config_dict:
                config_dict["wrappers"] = {}
            config_dict["wrappers"].update(wrappers)

        # Convert nested dicts to Pydantic models to avoid serialization warnings
        # Use model_construct for nested models to maintain performance
        if "exporter" in config_dict and isinstance(config_dict["exporter"], dict):
            config_dict["exporter"] = ExporterConfig(**config_dict["exporter"])
        if "batching" in config_dict and isinstance(config_dict["batching"], dict):
            config_dict["batching"] = BatchingConfig(**config_dict["batching"])
        if "failed_batch_disk" in config_dict and isinstance(
            config_dict["failed_batch_disk"], dict
        ):
            config_dict["failed_batch_disk"] = FailedBatchDiskConfig(
                **config_dict["failed_batch_disk"]
            )
        if "logging" in config_dict and isinstance(config_dict["logging"], dict):
            config_dict["logging"] = LoggingConfig(**config_dict["logging"])
        if "serverless" in config_dict and isinstance(config_dict["serverless"], dict):
            config_dict["serverless"] = ServerlessConfig(**config_dict["serverless"])
        if "wrappers" in config_dict and isinstance(config_dict["wrappers"], dict):
            config_dict["wrappers"] = WrappersConfig(**config_dict["wrappers"])

        # Return with validation disabled for intermediate step
        # (will be validated in from_env_vars or create_config)
        return cls.model_construct(**config_dict)

    @classmethod
    def from_env_vars(
        cls,
        base_config: Optional["MvkSdkConfig"] = None,
    ) -> "MvkSdkConfig":
        """
        Apply environment variables (MVK_* prefix) on top of base configuration.

        This represents the highest priority tier. Environment variables
        override both defaults and function parameters.

        Args:
            base_config: Base configuration to apply env vars on top of.
                        If None, starts with defaults only.

        Returns:
            MvkSdkConfig with env vars applied (highest priority)
        """
        # Start with base config or defaults
        if base_config is None:
            # Start with empty dict if no base config
            config_dict: Dict[str, Any] = {}
            # Load defaults from schema
            for param_name, param_def in CONFIG_SCHEMA.items():
                if param_def.default is not None:
                    _set_nested_value(config_dict, param_def.config_path, param_def.default)
        else:
            # Convert base config to dict (works with model_construct too)
            config_dict = (
                base_config.model_dump()
                if hasattr(base_config, "model_dump")
                else dict(base_config)
            )

        # Special handling for agent_id from environment
        mvk_agent_id = os.getenv("MVK_AGENT_ID")
        if mvk_agent_id:
            config_dict["agent_id"] = mvk_agent_id.strip()

        # Apply environment variables (highest priority)
        env_overrides_count = 0
        for param_name, param_def in CONFIG_SCHEMA.items():
            env_var_name = f"MVK_{param_def.env_var}"
            env_value = os.getenv(env_var_name)

            if env_value is not None:
                env_value = env_value.strip()
                if not env_value:
                    continue

                try:
                    # Type conversion
                    typed_value = _convert_type(env_value, param_def.param_type)

                    # Validation using registry validators
                    if param_def.validator and not param_def.validator(typed_value):
                        import logging

                        logger = logging.getLogger(__name__)
                        logger.warning(
                            f"Invalid value for {env_var_name}: {env_value}. " f"Validation failed."
                        )
                        continue

                    # Set the value
                    _set_nested_value(config_dict, param_def.config_path, typed_value)
                    env_overrides_count += 1

                except (ValueError, TypeError) as e:
                    import logging

                    logger = logging.getLogger(__name__)
                    logger.warning(
                        f"Failed to convert {env_var_name}={env_value} "
                        f"to {param_def.param_type.__name__}: {e}"
                    )
                    continue

        # Handle special MVK_TAG_* environment variables
        tag_dict = {}
        for key, value in os.environ.items():
            if key.startswith("MVK_TAG_"):
                tag_key = key[8:].lower()  # Remove MVK_TAG_ prefix and lowercase
                tag_dict[tag_key] = value

        if tag_dict:
            # Merge with existing tags (env vars take precedence)
            existing_tags = config_dict.get("tags") or {}
            existing_tags.update(tag_dict)
            config_dict["tags"] = existing_tags

        # Handle MVK_WRAPPERS environment variable (comma-separated list)
        mvk_wrappers = os.getenv("MVK_WRAPPERS")
        if mvk_wrappers:
            wrapper_list = [w.strip() for w in mvk_wrappers.split(",") if w.strip()]
            if wrapper_list:
                config_dict["wrappers"]["include"] = wrapper_list

        # Handle MVK_HTTP_EXCLUSIONS environment variable
        mvk_http_exclusions = os.getenv("MVK_HTTP_EXCLUSIONS")
        if mvk_http_exclusions:
            # Try to parse as JSON array first
            try:
                exclusions = json.loads(mvk_http_exclusions)
                if isinstance(exclusions, list):
                    if "http" not in config_dict["wrappers"]:
                        config_dict["wrappers"]["http"] = {}
                    config_dict["wrappers"]["http"]["exclusions"] = exclusions
            except json.JSONDecodeError:
                # Fall back to comma-separated
                exclusion_list = [e.strip() for e in mvk_http_exclusions.split(",") if e.strip()]
                if exclusion_list:
                    if "http" not in config_dict["wrappers"]:
                        config_dict["wrappers"]["http"] = {}
                    config_dict["wrappers"]["http"]["exclusions"] = exclusion_list

        # This is the final step, so enable full validation
        return cls(**config_dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary format compatible with existing code.

        Returns:
            Dictionary representation of configuration
        """
        return self.model_dump()

    def to_legacy_dict(self) -> Dict[str, Any]:
        """
        Convert to the legacy flat dictionary format used by instrument.py.

        This ensures backward compatibility with existing code that expects
        the old configuration structure.

        Returns:
            Dictionary in legacy format
        """
        # Use mode='python' to properly serialize nested models to dicts
        # This prevents Pydantic serialization warnings
        config = self.model_dump(mode="python")

        # The model already matches the expected structure, so just return it
        return config


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================


def _set_nested_value(d: Dict[str, Any], path: str, value: Any) -> None:
    """
    Set a value in a nested dictionary using dot notation.

    Args:
        d: Dictionary to modify
        path: Dot-separated path (e.g., "exporter.timeout")
        value: Value to set
    """
    keys = path.split(".")
    for key in keys[:-1]:
        if key not in d:
            d[key] = {}
        d = d[key]
    d[keys[-1]] = value


def _get_nested_value(d: Dict[str, Any], path: str) -> Any:
    """
    Get a value from a nested dictionary using dot notation.

    Args:
        d: Dictionary to read from
        path: Dot-separated path (e.g., "exporter.timeout")

    Returns:
        Value at the path, or None if not found
    """
    keys = path.split(".")
    current: Any = d
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key)
        else:
            return None
        if current is None:
            return None
    return current


def _convert_type(value: str, target_type: type) -> Any:
    """
    Convert a string value to the target type.

    Args:
        value: String value from environment variable
        target_type: Target Python type

    Returns:
        Converted value

    Raises:
        ValueError: If conversion fails
    """
    if target_type == bool:
        if value.lower() in ("true", "1", "yes", "on"):
            return True
        elif value.lower() in ("false", "0", "no", "off"):
            return False
        else:
            raise ValueError(f"Cannot convert '{value}' to bool")
    elif target_type == int:
        return int(value)
    elif target_type == float:
        return float(value)
    elif target_type == str:
        return value
    elif target_type == list:
        # For list types, split by comma
        return [item.strip() for item in value.split(",") if item.strip()]
    elif target_type == dict:
        # Try to parse as JSON
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            raise ValueError(f"Cannot parse '{value}' as JSON dict")
    else:
        return value


# ============================================================================
# FACTORY FUNCTION
# ============================================================================


def create_config(
    agent_id: Optional[str] = None,
    api_key: Optional[str] = None,
    tenant_id: Optional[str] = None,
    enabled: Optional[bool] = None,
    agent_name: Optional[str] = None,
    exporter: Optional[Dict[str, Any]] = None,
    batching: Optional[Dict[str, int]] = None,
    failed_batch_disk: Optional[Dict[str, Any]] = None,
    logging: Optional[Dict[str, Any]] = None,
    serverless: Optional[Dict[str, bool]] = None,
    strict_validation: Optional[bool] = None,
    tag_limit: Optional[int] = None,
    tags: Optional[Dict[str, str]] = None,
    wrappers: Optional[Dict[str, Any]] = None,
) -> MvkSdkConfig:
    """
    Create MVK SDK configuration with three-tier priority.

    Priority (highest to lowest):
    1. MVK_* environment variables
    2. Function parameters
    3. Default values

    This is the main entry point for creating configuration from instrument().

    Args:
        agent_id: Agent identifier
        api_key: API key
        tenant_id: Tenant ID
        enabled: Enable SDK
        agent_name: Agent name
        exporter: Exporter config
        batching: Batching config
        failed_batch_disk: Failed batch disk config
        logging: Logging config
        serverless: Serverless config
        strict_validation: Strict validation
        tag_limit: Tag limit
        tags: Global tags
        wrappers: Wrappers config dict

    Returns:
        Fully configured MvkSdkConfig with all priorities applied

    Raises:
        ValueError: If required fields are missing or validation fails
    """
    # Step 1: Load defaults
    # Step 2: Apply function parameters
    base_config = MvkSdkConfig.from_function_params(
        agent_id=agent_id,
        api_key=api_key,
        tenant_id=tenant_id,
        enabled=enabled,
        agent_name=agent_name,
        exporter=exporter,
        batching=batching,
        failed_batch_disk=failed_batch_disk,
        logging=logging,
        serverless=serverless,
        strict_validation=strict_validation,
        tag_limit=tag_limit,
        tags=tags,
        wrappers=wrappers,
    )

    # Step 3: Apply environment variables (highest priority)
    final_config = MvkSdkConfig.from_env_vars(base_config=base_config)

    return final_config
