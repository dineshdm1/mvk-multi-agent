"""MVK SDK v1.1 - Ultralight OpenTelemetry-compatible SDK for Mavvrik.

This is the micro SDK with minimal dependencies (~450KB).
Features clean architecture with separate processors and exporters.
Full OTEL support including OTLP export to OpenTelemetry Collector.
W3C TraceContext support for distributed tracing.

New in v1.1:
- OTEL-compliant error handling (vendor exceptions propagate)
- MVK-only configuration (no OTEL_* environment variables)
- Serverless auto-detection and optimization
- HTTP instrumentation suppression guard
- Graceful shutdown and fork safety
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as get_package_version


def _get_version() -> str:
    """Get version from installed package metadata."""
    try:
        return get_package_version("mvk-sdk-py")
    except PackageNotFoundError:
        # Fallback version for development environments
        return "1.2.0"


__version__ = _get_version()


def get_schema_version() -> str:
    """Derive schema version from SDK version (major.minor)."""
    parts = __version__.split(".")
    return f"{parts[0]}.{parts[1]}" if len(parts) >= 2 else "1.2"


from .decorators import context, signal

# Public API - everything is namespaced under mvk
from .instrument import (
    get_log_prompts_responses,
    get_service_instance_id,
    get_session_id,
    instrument,
    shutdown,
    uninstrument,
)
from .metrics import Metric, add_metered_usage
from .mvk_tracer import create_signal, get_current_span, get_tracer
from .schema import MVKStepType, validate_tags

# Auto-instrumentation is now built into instrument() - no separate module needed
AUTO_INSTRUMENT_AVAILABLE = True  # Always available since it's built into instrument()

# v1.1 features - optional imports with graceful fallback
try:
    from .error_handling import safe_async_wrapper, safe_operation, safe_wrapper
    from .http_suppression import suppress_http_instrumentation, with_suppression
    from .serverless import force_flush, is_serverless, lambda_handler

    V1_1_AVAILABLE = True
except ImportError:
    # v1.1 features not available in this environment
    V1_1_AVAILABLE = False

# Export public API
__all__ = [
    # Core functions
    "instrument",
    "uninstrument",
    "shutdown",
    "get_tracer",
    "get_session_id",
    "get_service_instance_id",
    "get_log_prompts_responses",
    # Signal creation
    "create_signal",
    "get_current_span",
    # Decorators
    "signal",
    "context",
    # Metrics
    "add_metered_usage",
    "Metric",
    "MVKStepType",
    # Helpers
    "validate_tags",
    # v1.1 status
    "V1_1_AVAILABLE",
    # Auto-instrumentation status
    "AUTO_INSTRUMENT_AVAILABLE",
]

# Auto-instrumentation now built into instrument() - no separate exports needed

# Add v1.1 exports if available
if V1_1_AVAILABLE:
    __all__.extend(
        [
            # Error handling
            "safe_wrapper",
            "safe_async_wrapper",
            "safe_operation",
            # Serverless
            "lambda_handler",
            "is_serverless",
            "force_flush",
            # HTTP suppression
            "with_suppression",
            "suppress_http_instrumentation",
        ]
    )
