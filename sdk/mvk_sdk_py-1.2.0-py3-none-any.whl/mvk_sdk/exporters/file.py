"""File exporter for local testing and debugging."""

import gzip
import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional

from .. import __version__
from ..json_utils import dumps as mvk_dumps
from ..wrapper_logging import get_component_logger
from .base import SpanExporter

logger = get_component_logger("exporters", "file")


class FileExporter(SpanExporter):
    """Export spans to JSON files in OTLP-compliant format.

    This exporter is intended for local testing and debugging only.
    Supports file rotation and compression for long-running tests.
    """

    def __init__(
        self,
        directory: str = "/tmp/mvk/spans",
        filename_prefix: str = "spans",
        max_file_size_mb: int = 100,
        max_files: int = 5,
        compress_rotated: bool = False,
        use_otlp_format: bool = True,
        service_name: str = "file-test",
        service_version: str = "dev",
    ):
        """Initialize file exporter.

        Args:
            directory: Directory to write span files
            filename_prefix: Prefix for span filenames
            max_file_size_mb: Maximum size per file before rotation
            max_files: Maximum number of files to keep
            compress_rotated: Compress rotated files with gzip
            use_otlp_format: Convert spans to OTLP format before writing
            service_name: Service name for OTLP resource
            service_version: Service version for OTLP resource
        """
        self.directory = Path(directory)
        self.filename_prefix = filename_prefix
        self.max_file_size = max_file_size_mb * 1024 * 1024  # Convert to bytes
        self.max_files = max_files
        self.compress_rotated = compress_rotated
        self.use_otlp_format = use_otlp_format
        self.service_name = service_name
        self.service_version = service_version

        # Create directory if it doesn't exist
        self.directory.mkdir(parents=True, exist_ok=True)

        # Current file tracking
        self.current_file: Optional[Any] = None
        self.current_file_size = 0
        self.file_counter = 0
        self.lock = Lock()

        # Spans are already in OTLP format from mvk_tracer

        # Initialize first file
        self._rotate_file()

    def export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Export spans to files.

        Args:
            spans: List of span dictionaries to export
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            True if export succeeded
        """
        try:
            if not spans:
                return True

            # Log export details
            logger.debug(f"File Export Request - Spans Count: {len(spans)}")
            if batch_metadata:
                logger.debug(f"File Export Request - Batch Metadata: {batch_metadata}")
            logger.debug(f"File Export Request - Use OTLP Format: {self.use_otlp_format}")
            logger.debug(
                f"File Export Request - Current File: {self.current_file.name if self.current_file else 'None'}"
            )

            with self.lock:
                # Choose export format
                if self.use_otlp_format:
                    data = self._create_export_request(
                        spans,
                        self.service_name,
                        self.service_version,
                        batch_metadata=batch_metadata,
                    )
                    logger.debug(
                        f"File Export Request - OTLP Data Size: {len(mvk_dumps(data, default=str))} chars"
                    )
                else:
                    # Raw JSON format - maintain backward compatibility
                    data = {"spans": spans, "timestamp": time.time()}
                    logger.debug(
                        f"File Export Request - Raw Data Size: {len(mvk_dumps(data, default=str))} chars"
                    )

                # Serialize to JSON
                json_data = mvk_dumps(data, default=str) + "\n"
                json_bytes = json_data.encode("utf-8")

                # Check if rotation needed
                if self.current_file_size + len(json_bytes) > self.max_file_size:
                    logger.debug(
                        f"File Export - Rotating file (current: {self.current_file_size}, new: {len(json_bytes)}, max: {self.max_file_size})"
                    )
                    self._rotate_file()

                # Write to file
                if self.current_file:
                    self.current_file.write(json_bytes)
                    self.current_file.flush()
                    self.current_file_size += len(json_bytes)
                    logger.debug(
                        f"File Export - Wrote {len(json_bytes)} bytes to {self.current_file.name}"
                    )

                logger.debug("File export completed successfully")
                return True

        except Exception as e:
            logger.error(f"File export failed: {e}")
            return False

    def _rotate_file(self) -> None:
        """Rotate to a new file."""
        # Close current file
        if self.current_file:
            self.current_file.close()

            # Compress if requested
            if self.compress_rotated and self.file_counter > 0:
                self._compress_file(self.current_file.name)

        # Generate new filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.file_counter += 1
        filename = f"{self.filename_prefix}_{timestamp}_{self.file_counter:03d}.json"
        filepath = self.directory / filename

        # Open new file
        self.current_file = open(filepath, "wb")
        self.current_file_size = 0

        # Cleanup old files
        self._cleanup_old_files()

        logger.debug(f"Rotated to new file: {filepath}")

    def _compress_file(self, filepath: str) -> None:
        """Compress a file with gzip."""
        try:
            compressed_path = f"{filepath}.gz"

            with open(filepath, "rb") as f_in:
                with gzip.open(compressed_path, "wb") as f_out:
                    f_out.writelines(f_in)

            # Remove original file
            os.remove(filepath)
            logger.debug(f"Compressed file: {filepath} -> {compressed_path}")

        except Exception as e:
            logger.warning(f"Failed to compress file {filepath}: {e}")

    def _cleanup_old_files(self) -> None:
        """Remove old files beyond max_files limit."""
        try:
            # List all span files
            pattern = f"{self.filename_prefix}_*.json*"
            files = sorted(self.directory.glob(pattern), key=lambda f: f.stat().st_mtime)

            # Remove oldest files if exceeded limit
            while len(files) > self.max_files:
                oldest = files.pop(0)
                oldest.unlink()
                logger.debug(f"Removed old file: {oldest}")

        except Exception as e:
            logger.warning(f"Failed to cleanup old files: {e}")

    def _create_export_request(
        self,
        otlp_spans: List[Dict[str, Any]],
        service_name: str,
        service_version: str,
        service_instance_id: Optional[str] = None,
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create OTLP export request structure.

        Args:
            otlp_spans: List of already OTLP-formatted spans
            service_name: Service name for resource
            service_version: Service version for resource
            service_instance_id: Optional service instance ID
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            OTLP export request dictionary
        """
        # Build resource attributes using standard semantic keys (omit service.name and service.version per MVK policy)
        resource_attrs = [
            {"key": "telemetry.sdk.name", "value": {"stringValue": "mvk-sdk-py"}},
            {"key": "telemetry.sdk.version", "value": {"stringValue": __version__}},
            {"key": "telemetry.sdk.language", "value": {"stringValue": "python"}},
        ]

        if service_instance_id:
            resource_attrs.append(
                {
                    "key": "service.instance.id",
                    "value": {"stringValue": service_instance_id},
                }
            )

        # Add batch metadata if provided
        if batch_metadata:
            if "batch.id" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.id",
                        "value": {"stringValue": str(batch_metadata["batch.id"])},
                    }
                )
            if "batch.received_at" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.received_at",
                        "value": {"stringValue": str(batch_metadata["batch.received_at"])},
                    }
                )

        # Add common MVK attributes to resource level
        # These were previously in individual spans but are common for all spans
        from ..mvk_tracer import get_tracer

        tracer = get_tracer()
        resource_attributes = tracer.get_resource_attributes()

        # Add common MVK attributes to resource level
        for key, value in resource_attributes.items():
            if key in [
                "mvk.agent_id",
                "mvk.agent_name",
                "mvk.service_name",
                "mvk.service_version",
                "mvk.service_instance",
            ]:
                resource_attrs.append({"key": key, "value": {"stringValue": str(value)}})

        # Build export request with already OTLP-formatted spans
        return {
            "resourceSpans": [
                {
                    "resource": {"attributes": resource_attrs},
                    "scopeSpans": [
                        {
                            "scope": {"name": "mvk-sdk-py", "version": __version__},
                            "spans": otlp_spans,
                        }
                    ],
                }
            ]
        }

    def shutdown(self) -> None:
        """Shutdown exporter and close files."""
        with self.lock:
            if self.current_file:
                try:
                    self.current_file.close()

                    # Final compression if needed
                    if self.compress_rotated:
                        self._compress_file(self.current_file.name)
                except Exception as e:  # pylint: disable=broad-except
                    # Ignore errors during final compression on shutdown
                    logger.debug(f"Failed to compress file during shutdown: {e}", exc_info=True)
                    pass
                finally:
                    self.current_file = None

    def get_written_files(self) -> List[Path]:
        """Get list of written span files.

        Returns:
            List of Path objects for span files
        """
        pattern = f"{self.filename_prefix}_*.json*"
        return sorted(self.directory.glob(pattern))

    def __repr__(self) -> str:
        """String representation."""
        return f"FileExporter(directory={self.directory}, prefix={self.filename_prefix})"
