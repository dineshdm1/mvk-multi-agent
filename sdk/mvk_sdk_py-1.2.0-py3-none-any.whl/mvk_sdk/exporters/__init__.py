"""MVK SDK exporters for v3.0."""

from typing import Any, List

from .base import SpanExporter
from .console import ConsoleExporter
from .file import FileExporter
from .otlp_grpc import OTLPGRPCExporter
from .otlp_http import OTLPHTTPExporter
from .retrying import RetryingExporter

__all__ = [
    "SpanExporter",
    "ConsoleExporter",
    "FileExporter",
    "OTLPHTTPExporter",
    "OTLPGRPCExporter",
    "RetryingExporter",
    "get_active_exporters",
]

# Track active exporters for shutdown
_active_exporters: List[Any] = []


def get_active_exporters():
    """Get all active exporters for shutdown.

    Returns:
        List of active exporters
    """
    return _active_exporters
