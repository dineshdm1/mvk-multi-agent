"""OTLP/HTTP Exporter for MVK SDK v1.0."""

import gzip
import json
import logging
import os
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from .. import __version__
from ..json_utils import dumps as mvk_dumps
from ..wrapper_logging import get_component_logger
from .retrying import RetryingExporter

logger = get_component_logger("exporters", "otlp_http")


class OTLPHTTPExporter(RetryingExporter):
    """Export spans to OTLP collector via HTTP.

    Supports JSON and Protobuf encoding with optional gzip compression.
    Implements retry logic with exponential backoff for transient failures.
    """

    def __init__(
        self,
        endpoint: str = "ingest.mavvrik.ai",
        encoding: str = "json",
        compression: str = "gzip",
        headers: Optional[Dict[str, str]] = None,
        timeout_secs: int = 10,
        insecure: bool = False,
        # Retry configuration (OTEL-compliant)
        max_retries: int = 6,
        retry_timeout_secs: float = 60.0,
        jitter_range: tuple[float, float] = (0.8, 1.2),
        # Legacy retry parameters (for backward compatibility)
        max_retry_hours: Optional[float] = None,
        initial_interval_secs: Optional[float] = None,
        max_interval_secs: Optional[int] = None,
        max_fast_retries: Optional[int] = None,
        # Service metadata
        service_name: str = "unknown",
        service_version: str = "unknown",
        service_instance_id: Optional[str] = None,
    ):
        """Initialize OTLP/HTTP exporter.

        Args:
            endpoint: Collector endpoint (host:port, no path)
            encoding: "json" or "protobuf"
            compression: "gzip" or "none"
            headers: Additional headers to send
            timeout_secs: Request timeout in seconds
            insecure: Use HTTP instead of HTTPS
            max_retries: Maximum number of retry attempts (OTEL default: 6)
            retry_timeout_secs: Maximum time for entire export operation (OTEL default: 60s)
            jitter_range: Multiplicative jitter range (OTEL default: (0.8, 1.2))
            max_retry_hours: Legacy parameter, use retry_timeout_secs
            initial_interval_secs: Legacy parameter
            max_interval_secs: Legacy parameter
            max_fast_retries: Legacy parameter, use max_retries
            service_name: Service name for resource
            service_version: Service version for resource
            service_instance_id: Optional service instance ID
        """
        # Initialize retry logic
        super().__init__(
            max_retries=max_retries,
            timeout_secs=retry_timeout_secs,
            jitter_range=jitter_range,
            # Legacy parameters for backward compatibility
            max_retry_hours=max_retry_hours,
            initial_interval_secs=initial_interval_secs,
            max_interval_secs=max_interval_secs,
            max_fast_retries=max_fast_retries,
        )

        self.endpoint = self._build_url(endpoint, insecure)
        self.encoding = encoding
        self.compression = compression
        self.headers = headers or {}
        self.timeout = timeout_secs
        # Spans are already in OTLP format from mvk_tracer

        # Service metadata
        self.service_name = service_name
        self.service_version = service_version
        self.service_instance_id = service_instance_id

        # Create session for connection pooling
        self._session = None

    def _get_session(self):
        """Get or create HTTP session."""
        if self._session is None:
            import urllib3  # type: ignore

            # Disable SSL warnings for insecure connections
            if self.endpoint.startswith("http://"):
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        return None  # Use urllib for simplicity

    def _do_export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[int]]:
        """Export a batch of spans.

        Args:
            spans: List of OTLP-formatted spans (already converted)
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            Tuple of (success, status_code)
        """
        try:
            # Spans are already in OTLP format from to_otlp_dict()
            # Just wrap them in the export request structure
            request_body = self._create_export_request(
                spans,
                self.service_name,
                self.service_version,
                self.service_instance_id,
                batch_metadata,
            )

            logger.debug(f"OTLP Export URL: {self.endpoint}")

            # Serialize based on encoding
            if self.encoding == "json":
                body = mvk_dumps(request_body).encode("utf-8")
                content_type = "application/json"
                logger.debug(f"OTLP Export Request JSON: {body.decode('utf-8')}")
            else:  # protobuf
                # For now, fallback to JSON if protobuf not available
                logger.warning("Protobuf encoding not yet implemented, using JSON")
                body = mvk_dumps(request_body).encode("utf-8")
                content_type = "application/json"

            # Prepare headers
            headers = {"Content-Type": content_type, **self.headers}

            # Log headers for debugging (mask sensitive values)
            headers_debug = {
                k: (v[:20] + "..." if k == "Authorization" and len(v) > 20 else v)
                for k, v in headers.items()
            }
            logger.debug(f"OTLP HTTP Export Request - Headers being sent: {headers_debug}")

            # Compress if enabled
            if self.compression == "gzip":
                body = gzip.compress(body)
                headers["Content-Encoding"] = "gzip"
                logger.info(f"OTLP HTTP Export Request - Compressed Body Size: {len(body)} bytes")

            # Send HTTP request
            import urllib.error
            import urllib.request

            req = urllib.request.Request(self.endpoint, data=body, headers=headers, method="POST")

            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    status_code = response.getcode()
                    response_body = response.read()

                    # Log response details
                    logger.debug(f"OTLP HTTP Export Response - Status: {status_code}")
                    logger.debug(
                        f"OTLP HTTP Export Response - Body Size: {len(response_body)} bytes"
                    )
                    if logger.isEnabledFor(logging.DEBUG):
                        try:
                            response_text = response_body.decode("utf-8")
                            logger.debug(f"OTLP HTTP Export Response - Body: {response_text}")
                        except UnicodeDecodeError:
                            logger.debug(
                                f"OTLP HTTP Export Response - Body: {response_body!r} (binary)"
                            )

                    if 200 <= status_code < 300:
                        logger.info(f"OTLP export succeeded with status {status_code}")
                        return True, status_code
                    else:
                        logger.warning(f"OTLP export failed with status {status_code}")
                        return False, status_code

            except urllib.error.HTTPError as e:
                status_code = e.code
                response_body = e.read() if hasattr(e, "read") else b""

                # Log error response details
                logger.error(f"OTLP HTTP Export Error - Status: {status_code}")
                logger.error(
                    f"OTLP HTTP Export Error - Headers: {dict(e.headers) if hasattr(e, 'headers') else {}}"
                )
                logger.error(f"OTLP HTTP Export Error - Body Size: {len(response_body)} bytes")
                if logger.isEnabledFor(logging.DEBUG):
                    try:
                        response_text = response_body.decode("utf-8")
                        logger.error(f"OTLP HTTP Export Error - Body: {response_text}")
                    except UnicodeDecodeError:
                        logger.error(f"OTLP HTTP Export Error - Body: {response_body!r} (binary)")

                # Check if error is retryable
                if status_code in [429, 502, 503, 504]:
                    logger.warning(f"Retryable HTTP error: {status_code}")
                    return False, status_code
                else:
                    logger.error(f"Non-retryable HTTP error: {status_code}")
                    # Return the status code so retry logic can decide
                    return False, status_code

            except urllib.error.URLError as e:
                logger.error(f"URL error: {self.endpoint}, {e.reason}")
                # Network errors are retryable
                return False, 500

        except Exception as e:
            logger.error(f"Export failed: {e}", exc_info=True)
            return False, None

    def _create_export_request(
        self,
        otlp_spans: List[Dict[str, Any]],
        service_name: str,
        service_version: str,
        service_instance_id: Optional[str] = None,
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create OTLP export request structure.

        Args:
            otlp_spans: List of already OTLP-formatted spans
            service_name: Service name for resource
            service_version: Service version for resource
            service_instance_id: Optional service instance ID
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            OTLP export request dictionary
        """
        # Build resource attributes using standard semantic keys (omit service.name and service.version per MVK policy)
        resource_attrs = [
            {"key": "telemetry.sdk.name", "value": {"stringValue": "mvk-sdk-py"}},
            {"key": "telemetry.sdk.version", "value": {"stringValue": __version__}},
            {"key": "telemetry.sdk.language", "value": {"stringValue": "python"}},
        ]

        if service_instance_id:
            resource_attrs.append(
                {
                    "key": "service.instance.id",
                    "value": {"stringValue": service_instance_id},
                }
            )

        # Add batch metadata if provided
        if batch_metadata:
            if "batch.id" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.id",
                        "value": {"stringValue": str(batch_metadata["batch.id"])},
                    }
                )
            if "batch.received_at" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.received_at",
                        "value": {"stringValue": str(batch_metadata["batch.received_at"])},
                    }
                )

        # Add common MVK attributes to resource level
        # These were previously in individual spans but are common for all spans
        from ..mvk_tracer import get_tracer

        tracer = get_tracer()
        resource_attributes = tracer.get_resource_attributes()

        # Add common MVK attributes to resource level
        for key, value in resource_attributes.items():
            if key in [
                "mvk.agent_id",
                "mvk.agent_name",
                "mvk.service_name",
                "mvk.service_version",
                "mvk.service_instance",
            ]:
                resource_attrs.append({"key": key, "value": {"stringValue": str(value)}})

        # Fallback: if mvk.service_version is not set by tracer, use the service_version parameter
        if not any(attr["key"] == "mvk.service_version" for attr in resource_attrs):
            resource_attrs.append(
                {"key": "mvk.service_version", "value": {"stringValue": service_version}}
            )

        # Build export request with already OTLP-formatted spans
        return {
            "resourceSpans": [
                {
                    "resource": {"attributes": resource_attrs},
                    "scopeSpans": [
                        {
                            "scope": {"name": "mvk-sdk-py", "version": __version__},
                            "spans": otlp_spans,
                        }
                    ],
                }
            ]
        }

    def _build_url(self, endpoint: str, insecure: bool) -> str:
        """Build full URL from endpoint.

        Args:
            endpoint: Host:port or full URL
            insecure: Use HTTP instead of HTTPS

        Returns:
            Full URL with path (only adds /v1/traces if not already present)
        """
        # Handle full URL
        if endpoint.startswith("http://") or endpoint.startswith("https://"):
            parsed = urlparse(endpoint)
            # Check if path is already included
            if parsed.path and parsed.path != "/":
                logger.debug(f"OTLP URL: Using provided endpoint as-is: {endpoint}")
                return endpoint
            else:
                # Add /v1/traces path
                base = f"{parsed.scheme}://{parsed.netloc}"
                url = f"{base}/v1/traces"
                logger.debug(f"OTLP URL: Added /v1/traces path: {url}")
                return url

        # Build from host:port
        protocol = "http" if insecure else "https"

        # Remove any trailing slashes
        endpoint = endpoint.rstrip("/")

        # Check if endpoint already ends with /v1/traces
        if endpoint.endswith("/v1/traces"):
            return f"{protocol}://{endpoint}"
        else:
            return f"{protocol}://{endpoint}/v1/traces"

    def shutdown(self):
        """Shutdown exporter and cleanup resources."""
        super().shutdown()
        if self._session:
            try:
                self._session.close()
            except Exception as e:  # pylint: disable=broad-except
                # Ignore errors when closing session on shutdown
                logger.debug(f"Failed to close HTTP session during shutdown: {e}", exc_info=True)
                pass

    def __repr__(self) -> str:
        """String representation of exporter."""
        return (
            f"OTLPHTTPExporter("
            f"endpoint={self.endpoint}, "
            f"encoding={self.encoding}, "
            f"compression={self.compression})"
        )
