"""Base exporter interface for MVK SDK v4.0."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class SpanExporter(ABC):
    """Common contract for sending spans outside your app.

    Exporters act like a delivery service for tracing data. Processors prepare
    batches of finished spans, and exporters deliver those batches to their
    destination (a file, your console, or a remote collector).

    Key expectations:
    - Must be safe to use from multiple threads at the same time.
    - Should handle temporary failures by retrying before giving up.
    - Called by the SDK; application code normally does not call these methods.
    """

    @abstractmethod
    def export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Send a ready-to-ship batch of spans.

        The SDK provides a batch of finished spans. The exporter is responsible
        for delivering that batch. If delivery fails due to temporary issues
        (for example, a brief network problem), it should retry a few times
        before reporting failure.

        Args:
            spans: Spans to deliver, already formatted for exporters.
            batch_metadata: Optional details about the batch (for example,
                an id or creation time) that can help with logging.

        Returns:
            True if delivery succeeds (including after retries), False if it cannot be delivered.
        """
        pass

    @abstractmethod
    def shutdown(self) -> None:
        """Cleanly release resources and make multiple calls safe.

        - Finish sending anything still in memory.
        - Close files, sockets, or network sessions.
        - Allow repeated calls without errors (idempotent).
        """
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Push out any buffered data immediately.

        Useful before shutdown or at important checkpoints so data is not left
        waiting for the normal schedule.

        Args:
            timeout_millis: Maximum time to wait for flushing to complete.

        Returns:
            True if flushing completed in time; otherwise False.
        """
        # Default implementation - subclasses can override
        return True
