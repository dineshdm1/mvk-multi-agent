"""OTLP/gRPC Exporter for MVK SDK v1.0."""

import base64
import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from .. import __version__
from ..json_utils import dumps as mvk_dumps
from ..wrapper_logging import get_component_logger
from .retrying import RetryingExporter

logger = get_component_logger("exporters", "otlp_grpc")

# gRPC is optional
try:
    import grpc  # type: ignore
    from google.protobuf.json_format import ParseDict  # type: ignore
    from opentelemetry.proto.collector.trace.v1 import (  # type: ignore
        trace_service_pb2,
        trace_service_pb2_grpc,
    )

    GRPC_AVAILABLE = True
except ImportError:
    GRPC_AVAILABLE = False
    logger.warning("gRPC dependencies not available, OTLP/gRPC exporter disabled")


class OTLPGRPCExporter(RetryingExporter):
    """Export spans to OTLP collector via gRPC.

    Uses Protobuf encoding with optional gzip compression.
    Implements retry logic with exponential backoff for transient failures.
    """

    def __init__(
        self,
        endpoint: str = "localhost:4317",
        insecure: bool = True,
        compression: str = "gzip",
        headers: Optional[Dict[str, str]] = None,
        timeout_secs: int = 10,
        # Retry configuration (OTEL-compliant)
        max_retries: int = 6,
        retry_timeout_secs: float = 60.0,
        jitter_range: tuple[float, float] = (0.8, 1.2),
        # Legacy retry parameters (for backward compatibility)
        max_retry_hours: Optional[float] = None,
        initial_interval_secs: Optional[float] = None,
        max_interval_secs: Optional[int] = None,
        max_fast_retries: Optional[int] = None,
        # Service metadata
        service_name: str = "unknown",
        service_version: str = "unknown",
        service_instance_id: Optional[str] = None,
        # Mode for validation
        mode: str = "DIRECT",
    ):
        """Initialize OTLP/gRPC exporter.

        Args:
            endpoint: Collector endpoint (host:port)
            insecure: Use insecure connection (no TLS)
            compression: "gzip" or "none"
            headers: Additional metadata headers
            timeout_secs: Request timeout in seconds
            max_retries: Maximum number of retry attempts (OTEL default: 6)
            retry_timeout_secs: Maximum time for entire export operation (OTEL default: 60s)
            jitter_range: Multiplicative jitter range (OTEL default: (0.8, 1.2))
            max_retry_hours: Legacy parameter, use retry_timeout_secs
            initial_interval_secs: Legacy parameter
            max_interval_secs: Legacy parameter
            max_fast_retries: Legacy parameter, use max_retries
            service_name: Service name for resource
            service_version: Service version for resource
            service_instance_id: Optional service instance ID
            mode: Deployment mode (DIRECT or COLLECTOR) for validation
        """
        if not GRPC_AVAILABLE:
            raise ImportError(
                "gRPC dependencies not installed. "
                "Install with: pip install grpcio opentelemetry-proto"
            )

        # Initialize retry logic
        super().__init__(
            max_retries=max_retries,
            timeout_secs=retry_timeout_secs,
            jitter_range=jitter_range,
            # Legacy parameters for backward compatibility
            max_retry_hours=max_retry_hours,
            initial_interval_secs=initial_interval_secs,
            max_interval_secs=max_interval_secs,
            max_fast_retries=max_fast_retries,
        )

        self.endpoint = endpoint
        self.insecure = insecure
        self.compression = compression
        self.headers = headers or {}
        self.timeout = timeout_secs
        self.mode = mode
        # Spans are already in OTLP format from mvk_tracer

        # Validate endpoint and insecure configuration (only for DIRECT mode)
        if self.mode == "DIRECT":
            self._validate_endpoint_config()

        # Service metadata
        self.service_name = service_name
        self.service_version = service_version
        self.service_instance_id = service_instance_id

        # Create gRPC channel and stub
        self.channel = self._create_channel()
        self.stub = trace_service_pb2_grpc.TraceServiceStub(self.channel)

    def _validate_endpoint_config(self):
        """Validate endpoint and TLS configuration to catch common misconfigurations."""
        # Extract port from endpoint
        port = None
        if ":" in self.endpoint:
            try:
                port = int(self.endpoint.split(":")[-1])
            except ValueError:
                pass  # Not a valid port number

        # Warn about common misconfigurations
        # Note: insecure=True uses grpc.insecure_channel() which skips TLS handshake entirely
        if port == 443 and self.insecure:
            logger.warning(
                f"⚠️  CONFIGURATION WARNING: Port 443 typically requires TLS, but 'insecure=True' "
                f"disables TLS handshake. Connection to {self.endpoint} may fail. "
                f"Set 'insecure=False' to enable TLS for HTTPS/gRPC over TLS."
            )
        elif port == 4317 and not self.insecure:
            logger.warning(
                f"⚠️  CONFIGURATION WARNING: Port 4317 typically uses plain gRPC (no TLS), "
                f"but 'insecure=False' enables TLS handshake. Connection to {self.endpoint} may fail. "
                f"Set 'insecure=True' for standard gRPC port 4317 (like OTel collector 'tls.insecure: true')."
            )

    def _create_channel(self):
        """Create gRPC channel with options."""
        options = [
            ("grpc.max_receive_message_length", 4 * 1024 * 1024),
            ("grpc.max_send_message_length", 4 * 1024 * 1024),
            ("grpc.keepalive_time_ms", 30000),
            ("grpc.keepalive_timeout_ms", 10000),
            ("grpc.keepalive_permit_without_calls", True),
            ("grpc.http2.max_pings_without_data", 0),
        ]

        # Add compression if enabled
        if self.compression == "gzip":
            options.append(("grpc.default_compression_algorithm", grpc.Compression.Gzip))
            options.append(("grpc.default_compression_level", "high"))

        # Create channel
        if self.insecure:
            channel = grpc.insecure_channel(self.endpoint, options=options)
        else:
            # Use secure channel with default credentials
            credentials = grpc.ssl_channel_credentials()
            channel = grpc.secure_channel(self.endpoint, credentials, options=options)

        return channel

    def _do_export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[int]]:
        """Export a batch of spans.

        Args:
            spans: List of OTLP-formatted spans (already converted)
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            Tuple of (success, status_code)
        """
        try:
            # Spans are already in OTLP format from to_otlp_dict()
            # Just wrap them in the export request structure
            request_dict = self._create_export_request(
                spans,
                self.service_name,
                self.service_version,
                self.service_instance_id,
                batch_metadata,
            )

            # Log request details
            logger.debug(f"OTLP gRPC Export Request - Endpoint: {self.endpoint}")
            logger.debug(f"OTLP gRPC Export Request - Headers: {self.headers}")
            logger.debug(f"OTLP gRPC Export Request - Spans Count: {len(spans)}")

            # No exporter-level normalization; handled earlier in tracer/schema
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(
                    f"OTLP gRPC Export Request - Request Dict: {mvk_dumps(request_dict, default=str)}"
                )

            # Ensure OTLP-compliant binary IDs for protobuf (bytes fields via base64 in JSON)
            request_dict = self._convert_ids_to_base64(request_dict)

            # Convert to protobuf
            request = ParseDict(request_dict, trace_service_pb2.ExportTraceServiceRequest())

            # Prepare metadata
            # gRPC requires all metadata keys to be lowercase
            metadata = []
            for key, value in self.headers.items():
                metadata.append((key.lower(), value))

            # Add compression metadata if enabled
            if self.compression == "gzip":
                metadata.append(("grpc-encoding", "gzip"))
                logger.debug("OTLP gRPC Export Request - Compression: gzip enabled")

            # Send request
            try:
                response = self.stub.Export(request, metadata=metadata, timeout=self.timeout)

                # Log response details
                logger.debug(f"OTLP gRPC Export Response - Success: True")
                logger.debug(
                    f"OTLP gRPC Export Response - Response Type: {type(response).__name__}"
                )
                if hasattr(response, "partial_success") and response.partial_success:
                    logger.debug(
                        f"OTLP gRPC Export Response - Partial Success: {response.partial_success}"
                    )
                if hasattr(response, "rejected_spans") and response.rejected_spans:
                    logger.warning(
                        f"OTLP gRPC Export Response - Rejected Spans: {response.rejected_spans}"
                    )

                logger.debug("OTLP/gRPC export succeeded")
                return True, None

            except grpc.RpcError as e:
                status_code = e.code()

                # Log error response details
                logger.error(
                    f"OTLP gRPC Export Error - Status: {status_code.name} ({status_code.value[0]})"
                )
                # Handle missing details() method gracefully
                try:
                    details = e.details()
                    logger.error(f"OTLP gRPC Export Error - Details: {details}")
                except AttributeError:
                    logger.error("OTLP gRPC Export Error - Details: Not available")

                if hasattr(e, "trailing_metadata"):
                    logger.error(
                        f"OTLP gRPC Export Error - Trailing Metadata: {e.trailing_metadata()}"
                    )

                # Check if error is retryable
                if status_code in [
                    grpc.StatusCode.UNAVAILABLE,
                    grpc.StatusCode.DEADLINE_EXCEEDED,
                    grpc.StatusCode.RESOURCE_EXHAUSTED,
                    grpc.StatusCode.ABORTED,
                ]:
                    logger.warning(f"Retryable gRPC error: {status_code.name}")
                    # Return numeric code for retry logic
                    return False, status_code.value[0]
                else:
                    logger.error(f"Non-retryable gRPC error: {status_code.name}")
                    # Map gRPC status to HTTP-like codes for retry logic
                    # INVALID_ARGUMENT, NOT_FOUND, ALREADY_EXISTS, PERMISSION_DENIED, etc. are 400-class errors
                    if status_code in [
                        grpc.StatusCode.INVALID_ARGUMENT,
                        grpc.StatusCode.NOT_FOUND,
                        grpc.StatusCode.ALREADY_EXISTS,
                        grpc.StatusCode.PERMISSION_DENIED,
                        grpc.StatusCode.FAILED_PRECONDITION,
                        grpc.StatusCode.OUT_OF_RANGE,
                        grpc.StatusCode.UNIMPLEMENTED,
                    ]:
                        return False, 400  # Client error equivalent
                    else:
                        return False, 500  # Server error equivalent

        except Exception as e:
            logger.error(f"Export failed: {e}", exc_info=True)
            return False, None

    def _create_export_request(
        self,
        otlp_spans: List[Dict[str, Any]],
        service_name: str,
        service_version: str,
        service_instance_id: Optional[str] = None,
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create OTLP export request structure.

        Args:
            otlp_spans: List of already OTLP-formatted spans
            service_name: Service name for resource
            service_version: Service version for resource
            service_instance_id: Optional service instance ID
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            OTLP export request dictionary
        """
        # Build resource attributes using standard semantic keys (omit service.name and service.version per MVK policy)
        resource_attrs = [
            {"key": "telemetry.sdk.name", "value": {"stringValue": "mvk-sdk-py"}},
            {"key": "telemetry.sdk.version", "value": {"stringValue": __version__}},
            {"key": "telemetry.sdk.language", "value": {"stringValue": "python"}},
        ]

        if service_instance_id:
            resource_attrs.append(
                {
                    "key": "service.instance.id",
                    "value": {"stringValue": service_instance_id},
                }
            )

        # Add batch metadata if provided
        if batch_metadata:
            if "batch.id" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.id",
                        "value": {"stringValue": str(batch_metadata["batch.id"])},
                    }
                )
            if "batch.received_at" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.received_at",
                        "value": {"stringValue": str(batch_metadata["batch.received_at"])},
                    }
                )

        # Add common MVK attributes to resource level
        # These were previously in individual spans but are common for all spans
        from ..mvk_tracer import get_tracer

        tracer = get_tracer()
        resource_attributes = tracer.get_resource_attributes()

        # Add common MVK attributes to resource level
        for key, value in resource_attributes.items():
            if key in [
                "mvk.agent_id",
                "mvk.agent_name",
                "mvk.service_name",
                "mvk.service_version",
                "mvk.service_instance",
            ]:
                resource_attrs.append({"key": key, "value": {"stringValue": str(value)}})

        # Fallback: if mvk.service_version is not set by tracer, use the service_version parameter
        if not any(attr["key"] == "mvk.service_version" for attr in resource_attrs):
            resource_attrs.append(
                {"key": "mvk.service_version", "value": {"stringValue": service_version}}
            )

        # Build export request with already OTLP-formatted spans
        return {
            "resourceSpans": [
                {
                    "resource": {"attributes": resource_attrs},
                    "scopeSpans": [
                        {
                            "scope": {"name": "mvk-sdk-py", "version": __version__},
                            "spans": otlp_spans,
                        }
                    ],
                }
            ]
        }

    @staticmethod
    def _convert_ids_to_base64(request_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Convert hex trace/span IDs in request_dict to base64 for protobuf JSON parsing."""
        for rs in request_dict.get("resourceSpans", []):
            for ss in rs.get("scopeSpans", []):
                for sp in ss.get("spans", []):
                    for key, hex_len in (("traceId", 32), ("spanId", 16), ("parentSpanId", 16)):
                        val = sp.get(key)
                        if isinstance(val, str) and len(val) == hex_len:
                            try:
                                sp[key] = base64.b64encode(bytes.fromhex(val)).decode("ascii")
                            except ValueError as e:
                                logger.debug(
                                    f"Failed to encode hex value as base64 for {key}: {e}",
                                    exc_info=True,
                                )
                                pass
        return request_dict

    def shutdown(self):
        """Shutdown exporter and cleanup resources."""
        super().shutdown()
        if self.channel:
            try:
                self.channel.close()
            except Exception as e:  # pylint: disable=broad-except
                # Ignore errors when closing channel on shutdown
                logger.debug(f"Failed to close gRPC channel during shutdown: {e}", exc_info=True)
                pass

    def __repr__(self) -> str:
        """String representation of exporter."""
        return (
            f"OTLPGRPCExporter("
            f"endpoint={self.endpoint}, "
            f"insecure={self.insecure}, "
            f"compression={self.compression})"
        )
