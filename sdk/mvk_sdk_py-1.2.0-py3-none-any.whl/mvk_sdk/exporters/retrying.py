"""Base retrying exporter with exponential backoff for v3.0."""

import logging
import random
import time
from abc import abstractmethod
from typing import Any, Dict, List, Optional

from .base import SpanExporter

logger = logging.getLogger(__name__)


class RetryingExporter(SpanExporter):
    """Base exporter with built-in retry logic.

    This class provides exponential backoff retry logic that
    HTTP and OTLP exporters can use. Subclasses only need to
    implement _do_export() for the actual export logic.
    """

    def __init__(
        self,
        # OTEL-compliant defaults
        max_retries: int = 6,  # OTEL default: 6 attempts
        timeout_secs: float = 60.0,  # OTEL default: 60s request deadline
        jitter_range: tuple[float, float] = (0.8, 1.2),  # OTEL: ±20% multiplicative
        # Legacy parameters (kept for backward compatibility)
        max_retry_hours: Optional[float] = None,
        initial_interval_secs: Optional[float] = None,
        max_interval_secs: Optional[int] = None,
        max_fast_retries: Optional[int] = None,
        backoff_multiplier: Optional[float] = None,
        jitter_percent: Optional[float] = None,
        # Backward compatibility aliases
        initial_retry_interval_secs: Optional[float] = None,
        max_retry_interval_secs: Optional[int] = None,
    ):
        """Initialize retrying exporter with OTEL-compliant configuration.

        Args:
            max_retries: Maximum number of retry attempts (OTEL default: 6)
            timeout_secs: Maximum time for entire export operation (OTEL default: 60s)
            jitter_range: Multiplicative jitter range (OTEL default: (0.8, 1.2) for ±20%)

            Legacy parameters (for backward compatibility):
            max_retry_hours: Deprecated, use timeout_secs
            initial_interval_secs: Deprecated, OTEL uses 2^attempt backoff
            max_interval_secs: Deprecated, OTEL uses unbounded exponential
            max_fast_retries: Deprecated, use max_retries
            backoff_multiplier: Deprecated, OTEL uses base-2 exponential
            jitter_percent: Deprecated, use jitter_range
            initial_retry_interval_secs: Deprecated
            max_retry_interval_secs: Deprecated
        """
        # Use OTEL defaults or provided values
        self.max_retries = max_retries
        self.timeout_secs = timeout_secs
        self.jitter_range = jitter_range

        # Handle backward compatibility - convert legacy params to new model
        if max_retry_hours is not None:
            self.timeout_secs = max_retry_hours * 3600
        if max_fast_retries is not None:
            self.max_retries = max_fast_retries

        # Legacy parameters (not used in OTEL mode but kept for compatibility)
        self.initial_retry_interval = initial_interval_secs or initial_retry_interval_secs or 1.0
        self.max_retry_interval = max_interval_secs or max_retry_interval_secs or 300
        self.backoff_multiplier = backoff_multiplier or 2.0
        self.jitter_percent = jitter_percent or 0.1

        # Statistics
        self.stats: Dict[str, Any] = {
            "batches_sent": 0,
            "spans_sent": 0,
            "batches_failed": 0,
            "spans_failed": 0,
            "retries": 0,
            "total_retry_time_ms": 0,
        }

    @abstractmethod
    def _do_export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> tuple[bool, Optional[int]]:
        """Perform the actual export.

        Subclasses must implement this method to perform the actual
        export operation without retry logic.

        Args:
            spans: List of span dictionaries to export
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            Tuple of (success, http_status_code)
            - success: True if export succeeded, False otherwise
            - http_status_code: Optional HTTP status code for debugging
        """
        pass

    def export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Export spans with retry logic.

        Args:
            spans: List of span dictionaries to export
            batch_metadata: Optional metadata about the batch (e.g., batch.id, batch.received_at)

        Returns:
            True if export succeeded (after retries if needed),
            False if all retries exhausted
        """
        if not spans:
            return True

        start_time = time.time()
        retry_count = 0

        while retry_count <= self.max_retries:
            # Check timeout
            elapsed = time.time() - start_time
            if elapsed > self.timeout_secs:
                logger.error(
                    f"Exceeded timeout of {self.timeout_secs}s, "
                    f"dropping {len(spans)} spans after {retry_count} retries"
                )
                self.stats["batches_failed"] += 1
                self.stats["spans_failed"] += len(spans)
                return False

            # Try to export
            try:
                success, status_code = self._do_export(spans, batch_metadata)

                if success:
                    # Export succeeded
                    self.stats["batches_sent"] += 1
                    self.stats["spans_sent"] += len(spans)
                    if retry_count > 0:
                        logger.info(f"Export succeeded after {retry_count} retries")
                    return True

                # Check if we should retry based on status code
                if status_code is not None:
                    if status_code >= 400 and status_code < 500 and status_code != 429:
                        # Client error (except rate limiting) - don't retry
                        logger.error(f"Permanent export failure with status {status_code}")
                        self.stats["batches_failed"] += 1
                        self.stats["spans_failed"] += len(spans)
                        return False

            except Exception as e:
                logger.error(f"Export exception: {e}", exc_info=True)

            # Check if we've exhausted retries
            if retry_count >= self.max_retries:
                logger.error(
                    f"Exhausted {self.max_retries} retry attempts, " f"dropping {len(spans)} spans"
                )
                self.stats["batches_failed"] += 1
                self.stats["spans_failed"] += len(spans)
                return False

            # Export failed, calculate backoff
            retry_count += 1
            self.stats["retries"] += 1

            # OTEL-compliant exponential backoff: 2^attempt seconds
            base_delay = 2**retry_count

            # Apply multiplicative jitter (OTEL: uniform 0.8-1.2 per attempt)
            jitter_multiplier = random.uniform(self.jitter_range[0], self.jitter_range[1])
            delay = base_delay * jitter_multiplier

            # Check if we have time for another retry
            if elapsed + delay > self.timeout_secs:
                logger.error(
                    f"Not enough time for retry {retry_count}, "
                    f"would exceed {self.timeout_secs}s timeout, "
                    f"dropping {len(spans)} spans"
                )
                self.stats["batches_failed"] += 1
                self.stats["spans_failed"] += len(spans)
                return False

            logger.warning(
                f"Export failed (attempt {retry_count}/{self.max_retries}), "
                f"retrying in {delay:.1f}s (base: {base_delay}s, jitter: {jitter_multiplier:.2f}x). "
                f"Elapsed: {elapsed:.1f}s of {self.timeout_secs}s timeout"
            )

            self.stats["total_retry_time_ms"] += int(delay * 1000)
            time.sleep(delay)

        # If we exit the loop without returning, we've exhausted retries
        logger.error(f"Failed to export {len(spans)} spans after {retry_count} retries")
        self.stats["batches_failed"] += 1
        self.stats["spans_failed"] += len(spans)
        return False

    def get_stats(self) -> Dict[str, Any]:
        """Get exporter statistics."""
        return self.stats.copy()

    def shutdown(self) -> None:
        """Log final statistics on shutdown."""
        logger.info(
            f"Exporter stats - "
            f"batches sent: {self.stats['batches_sent']}, "
            f"spans sent: {self.stats['spans_sent']}, "
            f"batches failed: {self.stats['batches_failed']}, "
            f"spans failed: {self.stats['spans_failed']}, "
            f"retries: {self.stats['retries']}, "
            f"total retry time: {self.stats['total_retry_time_ms']}ms"
        )
