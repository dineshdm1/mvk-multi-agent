"""Console exporter for local testing and debugging."""

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .. import __version__
from ..wrapper_logging import get_component_logger
from .base import SpanExporter

logger = get_component_logger("exporters", "console")


class ConsoleExporter(SpanExporter):
    """Print spans to the terminal for easy inspection.

    This exporter shows spans without leaving the development environment. It
    can print as JSON, as short readable lines, or wrapped in an OTLP-style
    envelope to preview what a collector would receive.

    Intended for local development and debugging, not production use.
    """

    def __init__(
        self,
        output: str = "stdout",
        format: str = "json",
        pretty: bool = False,
        use_otlp_format: bool = True,
        service_name: str = "console-test",
        service_version: str = "dev",
    ):
        """Choose where and how to print spans.

        Args:
            output: Where to print (the normal screen or the error stream).
            format: How to show the data: as raw JSON, a short readable line,
                or wrapped as an OTLP export payload.
            pretty: If True, JSON is spaced out and easier to read.
            use_otlp_format: If True, surrounds spans with resource details so
                the output looks like a real export request.
            service_name: Name to include in the resource info.
            service_version: Version to include in the resource info.
        """
        self.output = sys.stdout if output == "stdout" else sys.stderr
        self.format = format
        self.pretty = pretty
        self.use_otlp_format = use_otlp_format
        self.service_name = service_name
        self.service_version = service_version

        # Spans are already in OTLP format from mvk_tracer

    def export(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Print a group of spans to the terminal.

        Args:
            spans: The spans to print.
            batch_metadata: Optional notes about the group (like an id or time).

        Returns:
            True if everything printed without errors.
        """
        try:
            if not spans:
                return True

            # Log export details
            logger.debug(f"Console Export Request - Spans Count: {len(spans)}")
            if batch_metadata:
                logger.debug(f"Console Export Request - Batch Metadata: {batch_metadata}")
            logger.debug(f"Console Export Request - Format: {self.format}")
            logger.debug(f"Console Export Request - Use OTLP Format: {self.use_otlp_format}")

            # Choose export format
            if self.use_otlp_format:
                self._export_otlp(spans, batch_metadata)
            elif self.format == "simple":
                self._export_simple(spans)
            else:  # raw_json
                self._export_raw_json(spans)

            # Flush output
            self.output.flush()

            logger.debug("Console export completed successfully")
            return True

        except Exception as e:
            logger.error(f"Console export failed: {e}")
            return False

    def _create_export_request(
        self,
        otlp_spans: List[Dict[str, Any]],
        service_name: str,
        service_version: str,
        service_instance_id: Optional[str] = None,
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Wrap spans with the resource info collectors expect.

        This builds the same kind of envelope that would be sent to an OTLP
        collector, including the service name/version and SDK identity, so
        you can preview exactly what an exporter would ship.

        Args:
            otlp_spans: Spans already in OTLP shape.
            service_name: Name to include at the resource level.
            service_version: Version to include at the resource level.
            service_instance_id: Optional unique instance id.
            batch_metadata: Optional details about this group of spans.

        Returns:
            A dictionary shaped like an OTLP export request.
        """
        # Build resource attributes using standard semantic keys (omit service.name and service.version per MVK policy)
        resource_attrs = [
            {"key": "telemetry.sdk.name", "value": {"stringValue": "mvk-sdk-py"}},
            {"key": "telemetry.sdk.version", "value": {"stringValue": __version__}},
            {"key": "telemetry.sdk.language", "value": {"stringValue": "python"}},
        ]

        if service_instance_id:
            resource_attrs.append(
                {
                    "key": "service.instance.id",
                    "value": {"stringValue": service_instance_id},
                }
            )

        # Add batch metadata if provided
        if batch_metadata:
            if "batch.id" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.id",
                        "value": {"stringValue": str(batch_metadata["batch.id"])},
                    }
                )
            if "batch.received_at" in batch_metadata:
                resource_attrs.append(
                    {
                        "key": "batch.received_at",
                        "value": {"stringValue": str(batch_metadata["batch.received_at"])},
                    }
                )

        # Add common MVK attributes to resource level
        # These were previously in individual spans but are common for all spans
        from ..mvk_tracer import get_tracer

        tracer = get_tracer()
        resource_attributes = tracer.get_resource_attributes()

        # Add common MVK attributes to resource level
        for key, value in resource_attributes.items():
            if key in [
                "mvk.agent_id",
                "mvk.agent_name",
                "mvk.service_name",
                "mvk.service_version",
                "mvk.service_instance",
            ]:
                resource_attrs.append({"key": key, "value": {"stringValue": str(value)}})

        # Build export request with already OTLP-formatted spans
        return {
            "resourceSpans": [
                {
                    "resource": {"attributes": resource_attrs},
                    "scopeSpans": [
                        {
                            "scope": {"name": "mvk-sdk-py", "version": __version__},
                            "spans": otlp_spans,
                        }
                    ],
                }
            ]
        }

    def _export_otlp(
        self,
        spans: List[Dict[str, Any]],
        batch_metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Print spans wrapped as an OTLP payload (what collectors see)."""
        # Spans are already in OTLP format, just wrap in export request structure
        request = self._create_export_request(
            spans,
            self.service_name,
            self.service_version,
            batch_metadata=batch_metadata,
        )

        # Output as JSON
        if self.pretty:
            json.dump(request, self.output, indent=2, default=str)
        else:
            json.dump(request, self.output, default=str)
        self.output.write("\n")

    def _export_simple(self, spans: List[Dict[str, Any]]) -> None:
        """Print a short, readable line for each span.

        This focuses on when it happened, how long it took, and a few key
        fields like the operation name, model, and token count if present.
        """
        for span in spans:
            # Format timestamp (use UTC)
            start_time = datetime.fromtimestamp(span.get("start_time", 0), timezone.utc)
            duration_ms = span.get("mvk.duration_ms", 0)

            # Build output line
            self.output.write(f"[{start_time.strftime('%Y-%m-%d %H:%M:%S')}] ")
            self.output.write(f"{span.get('name', 'unnamed')} ")
            self.output.write(f"({duration_ms:.2f}ms) ")

            # Add key attributes
            if "mvk.operation" in span:
                self.output.write(f"op={span['mvk.operation']} ")
            if "mvk.model_name" in span:
                self.output.write(f"model={span['mvk.model_name']} ")
            if "mvk.total_tokens" in span:
                self.output.write(f"tokens={span['mvk.total_tokens']} ")

            # Add status if error
            status = span.get("status_code")
            if status and status != "STATUS_CODE_OK":
                self.output.write(f"ERROR: {span.get('status_message', 'Unknown error')} ")

            self.output.write("\n")

    def _export_raw_json(self, spans: List[Dict[str, Any]]) -> None:
        """Print the raw span dictionaries as JSON for copy/paste or diffing."""
        for span in spans:
            if self.pretty:
                json.dump(span, self.output, indent=2, default=str)
            else:
                json.dump(span, self.output, default=str)
            self.output.write("\n")

    def shutdown(self) -> None:
        """Nothing to close here, but we flush the stream just in case."""
        try:
            self.output.flush()
        except Exception as e:  # pylint: disable=broad-except
            # Ignore flush errors on shutdown
            logger.debug(f"Failed to flush console output during shutdown: {e}", exc_info=True)
            pass

    def __repr__(self) -> str:
        """String representation."""
        return f"ConsoleExporter(output={self.output.name}, format={self.format})"
