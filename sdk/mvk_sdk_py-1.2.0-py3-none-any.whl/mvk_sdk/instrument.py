"""Instrumentation module for MVK SDK v1.1.

Provides the main instrument() function to initialize the SDK with required agent_id.
Uses centralized schema-driven configuration system (v1.2) for easier maintenance.
"""

import json
import logging
import threading
import uuid
from typing import Any, Dict, List, Optional

from .context import set_global_context
from .mvk_tracer import get_tracer
from .processors.factory import ProcessorFactory
from .wrapper_logging import configure_logger_levels

logger = logging.getLogger(__name__)

_initialized = False
_init_lock = threading.Lock()
_strict_validation: bool = False
_log_prompts_responses: bool = False
_service_instance_id: str = str(uuid.uuid4())
_effective_config: Dict[str, Any] = {}
_active_instrumentors: Dict[str, Any] = {}


def _make_instrumentor_key(lib_name: str, instrumentor_class: str) -> str:
    """Create a stable key for tracking instrumentor instances."""
    return f"{lib_name}:{instrumentor_class}"


def instrument(
    agent_id: Optional[str] = None,
    api_key: Optional[str] = None,
    tenant_id: Optional[str] = None,
    enabled: Optional[bool] = None,
    agent_name: Optional[str] = None,
    exporter: Optional[Dict[str, Any]] = None,
    batching: Optional[Dict[str, int]] = None,
    failed_batch_disk: Optional[Dict[str, Any]] = None,
    logging: Optional[Dict[str, Any]] = None,
    serverless: Optional[Dict[str, bool]] = None,
    strict_validation: Optional[bool] = None,
    tag_limit: Optional[int] = None,
    tags: Optional[Dict[str, str]] = None,
    wrappers: Optional[Dict[str, Any]] = None,
) -> None:
    """Initialize MVK SDK instrumentation with simplified configuration.

    This is the main entry point for SDK initialization. Must be called
    once per process before using any SDK features.

    Configuration precedence (high → low):
    1. MVK_* environment variables (highest priority)
    2. Function parameters
    3. Default values from schema

    Args:
        agent_id: Required agent ID (can be provided via MVK_AGENT_ID env var)
        api_key: MVK API key (required for DIRECT mode, or use MVK_API_KEY env var)
        tenant_id: Tenant identifier (required for DIRECT mode)
        enabled: SDK on/off switch (default: true)
        agent_name: Human-readable agent name (defaults to agent_id)

        exporter: Exporter/transport configuration dict with keys:
            - mode: Deployment mode - "DIRECT" or "COLLECTOR" (default: "DIRECT")
            - type: Exporter type - "otlp_http", "otlp_grpc", "console", "file" (default: "otlp_http")
            - endpoint: Where to send traces (URL or host:port) - same for all modes
            - headers: Custom headers (dict or string) - same for all modes
            - timeout: Request timeout in seconds (default: 10, range: 1-300)
            - compression: Compression type - "gzip" or "none" (default: "gzip")
            - insecure: Use HTTP instead of HTTPS (default: false)
            - max_retries: Max retry attempts (default: 6, range: 0-20)
            - retry_timeout: Total retry timeout in seconds (default: 60, range: 1-600)
            - file_path: File exporter directory path (for file exporter only)
            - format: Output format - "simple" or "json" (default: "simple", for console/file)

        batching: Batching configuration dict with keys:
            - max_items: Max spans per batch (default: 2000)
            - max_bytes: Max batch size in bytes (default: 2097152)
            - max_interval_ms: Max time between batches (default: 3000)

        failed_batch_disk: Failed batch disk recovery configuration dict with keys:
            - enabled: Enable failed batch disk (default: false)
            - path: Failed batch directory (required if enabled)
            - max_size_mb: Max disk space in MB (default: 1000)
            - retry_interval: Retry interval in seconds (default: 60)

        logging: Logging configuration dict with keys:
            - level: SDK log level - "OFF", "INFO", "DEBUG" (default: "OFF")
            - prompts_responses: Log prompts/responses (default: false) ⚠️ SECURITY

        serverless: Serverless configuration dict with keys:
            - force: Force serverless mode (default: auto-detect)

        strict_validation: Enable strict schema validation (default: false)
        tag_limit: Maximum number of tags (default: 10)
        tags: Optional global tags (max 10, dots allowed in keys)

        wrappers: Controls auto-instrumentation. Must be a dict with structure:
                 {
                     "include": ["genai", "vectordb", "http"],  # list of wrapper categories to include
                     "http": {  # optional, only needed for HTTP wrapper configuration
                         "exclusions": ["api.openai.com", "api.anthropic.com"]
                     }
                 }
                 Default: None (defaults to {"include": ["genai", "vectordb"]})
                 To disable all: {"include": []}
                 To include only AI: {"include": ["genai"]}
                 To include everything: {"include": ["genai", "vectordb", "http"]}

                 Environment variables (alternative):
                 - MVK_WRAPPERS=genai,vectordb,http
                 - MVK_HTTP_EXCLUSIONS=["api.openai.com","api.anthropic.com"]

    Raises:
        ValueError: If agent_id not provided in function parameter or MVK_AGENT_ID env var
        RuntimeError: If already instrumented

    Example:
        mvk.instrument(
            agent_id="my-agent-123",
            api_key="mvk_...",
            tenant_id="tenant-456",
            agent_name="my-agent-name",
            wrappers={
                "include": ["genai", "vectordb"],
                "http": {
                    "exclusions": ["api.custom.com"]
                }
            }
        )
    """
    global _initialized, _strict_validation, _log_prompts_responses, _service_instance_id

    with _init_lock:
        if _initialized:
            logger.warning("MVK SDK already initialized, ignoring duplicate call")
            return

        # Build simplified config dictionary from parameters
        config_dict: Dict[str, Any] = {}

        # Root level parameters
        if api_key is not None:
            config_dict["api_key"] = api_key
        if tenant_id is not None:
            config_dict["tenant_id"] = tenant_id
        if enabled is not None:
            config_dict["enabled"] = enabled
        if agent_name is not None:
            config_dict["agent_name"] = agent_name
        if strict_validation is not None:
            config_dict["strict_validation"] = strict_validation
        if tag_limit is not None:
            config_dict["tag_limit"] = tag_limit

        # Add configuration groups directly
        if exporter is not None:
            config_dict["exporter"] = exporter
        if batching is not None:
            config_dict["batching"] = batching
        if failed_batch_disk is not None:
            config_dict["failed_batch_disk"] = failed_batch_disk
        if logging is not None:
            config_dict["logging"] = logging
        if serverless is not None:
            config_dict["serverless"] = serverless

        # Handle wrappers configuration - only dict format supported
        if wrappers is not None:
            if not isinstance(wrappers, dict):
                raise ValueError(
                    "wrappers parameter must be a dict with structure: "
                    '{"include": ["genai", "vectordb"], "http": {"exclusions": [...]}}'
                )

        # Load configuration using the new config model with three-tier priority
        from mvk_sdk.config_registry import create_config

        try:
            sdk_config = create_config(
                agent_id=agent_id,
                api_key=api_key,
                tenant_id=tenant_id,
                enabled=enabled,
                agent_name=agent_name,
                exporter=exporter,
                batching=batching,
                failed_batch_disk=failed_batch_disk,
                logging=logging,
                serverless=serverless,
                strict_validation=strict_validation,
                tag_limit=tag_limit,
                tags=tags,
                wrappers=wrappers,
            )
        except ValueError as e:
            raise ValueError(f"Configuration error: {e}")

        # Convert to legacy dict format for backward compatibility
        merged_config = sdk_config.to_legacy_dict()
        final_agent_id = sdk_config.agent_id
        merged_tags = sdk_config.tags or {}
        final_wrappers = sdk_config.wrappers.include

        # Check if SDK is enabled
        if sdk_config.enabled is False:  # Explicitly check for False to distinguish from None
            logger.info("MVK SDK is disabled via configuration")
            _initialized = True  # Mark as initialized to prevent re-entry
            return

        # Validate credentials (already done in model validation, but keep for clarity)
        if not sdk_config.api_key and sdk_config.exporter.mode != "COLLECTOR":
            raise ValueError(
                "api_key is required in DIRECT mode. Provide via MVK_API_KEY environment variable or config parameter."
            )

        _strict_validation = sdk_config.strict_validation

        # Handle log_prompts_responses setting
        _log_prompts_responses = bool(sdk_config.logging.prompts_responses)

        if _log_prompts_responses:
            logger.warning(
                "SECURITY WARNING: Prompt and response logging is enabled. "
                "This may expose sensitive data. Use with caution in production."
            )

        # Determine agent_name (defaults to agent_id)
        agent_name = sdk_config.agent_name or final_agent_id

        global_tracer = get_tracer()
        api_key = sdk_config.api_key or ""
        global_tracer.configure(api_key, agent_name or "", bool(_strict_validation))

        configure_logger_levels(merged_config)

        global_tracer.set_resource_attribute("mvk.agent_id", final_agent_id or "")
        global_tracer.set_resource_attribute("mvk.agent_name", agent_name or "")
        global_tracer.set_resource_attribute("mvk.service_instance", _service_instance_id)

        global_context: Dict[str, Any] = {
            "mvk.agent_id": final_agent_id,
            "mvk.agent_name": agent_name,
            "service.instance.id": _service_instance_id,
        }

        if merged_tags:
            if len(merged_tags) > 10:
                logger.warning(f"Too many tags ({len(merged_tags)}), limiting to 10")
                merged_tags = dict(list(merged_tags.items())[:10])

            import re

            key_pattern = re.compile(r"^[a-z0-9_.-]{1,32}$")
            value_pattern = re.compile(r"^[a-z0-9_.-]{1,32}$", re.IGNORECASE)
            validated_tags = {}
            for key, value in merged_tags.items():
                str_value = str(value)
                if key_pattern.match(key) and value_pattern.match(str_value):
                    validated_tags[key] = str_value
                else:
                    logger.warning(f"Invalid tag format: {key}={value}, skipping")

            if validated_tags:
                global_context["tags"] = validated_tags

        set_global_context(global_context)

        try:
            # Use the new convenience method that accepts MvkSdkConfig directly
            processor = ProcessorFactory.create_from_sdk_config(sdk_config)
        except Exception as e:
            logger.error(f"Failed to create processor: {e}")
            processor = ProcessorFactory.create_default()

        global_tracer.add_span_processor(processor)

        _apply_wrappers(final_wrappers or [])

        try:
            import copy as _copy

            globals()["_effective_config"] = _copy.deepcopy(merged_config)
            _effective_config["agent_id"] = final_agent_id
        except Exception:
            globals()["_effective_config"] = dict(merged_config)
            _effective_config["agent_id"] = final_agent_id

        _initialized = True

        exporter_type = merged_config.get("exporter", {}).get("type", "otlp_http")
        exporter_mode = merged_config.get("exporter", {}).get("mode", "DIRECT")

        init_info = {
            "event": "mvk_sdk_initialized",
            "version": "1.1",
            "agent_id": final_agent_id,
            "agent_name": agent_name,
            "exporter": exporter_type,
            "mode": exporter_mode,
            "instance_id": _service_instance_id,
            "wrappers": sorted(final_wrappers) if final_wrappers else [],
        }
        logger.info(json.dumps(init_info, indent=2))


def _apply_wrappers(wrappers: List[str]) -> None:
    """Apply auto-instrumentation following OpenTelemetry Python SDK patterns.

    Strategy (like OTEL):
    1. If library already imported → Immediate instrumentation
    2. If library not imported → Lazy hook (wrapt.when_imported)

    This is simpler than doing both and matches OTEL behavior.

    Args:
        wrappers: List of wrapper categories to enable
                 Options: "genai", "vectordb", "http", "bedrock"
    """
    import sys

    include_wrappers = set(wrappers)

    if not include_wrappers:
        logger.info("Auto-instrumentation explicitly disabled")
        return
    else:
        wrapper_list = ", ".join(sorted(include_wrappers))
        logger.info(f"Auto-instrumentation enabled for: {wrapper_list}")

    try:
        import wrapt  # type: ignore
    except ImportError:
        logger.warning("wrapt not available - only immediate instrumentation will work")
        wrapt = None

    if "genai" in include_wrappers:
        _setup_genai_instrumentation(sys.modules, wrapt)

    if "vectordb" in include_wrappers:
        _setup_vectordb_instrumentation(sys.modules, wrapt)

    if "bedrock" in include_wrappers:
        _setup_bedrock_instrumentation(sys.modules, wrapt)

    if "http" in include_wrappers:
        _setup_http_instrumentation(sys.modules, wrapt)
        logger.info("HTTP wrappers enabled (normally disabled by default)")
    else:
        logger.debug("HTTP wrappers disabled (default)")


def _setup_genai_instrumentation(sys_modules, wrapt):
    """Set up GenAI instrumentation using OTEL strategy: immediate if imported, lazy if not."""
    instrumentors = [
        ("openai", "OpenAIInstrumentor", ".instrumentation.openai_instrumentor"),
        ("anthropic", "AnthropicInstrumentor", ".instrumentation.anthropic_instrumentor"),
        # Google Gemini SDKs - separate entries for clarity and maintainability
        (
            "google.generativeai",
            "GeminiInstrumentor",
            ".instrumentation.gemini_instrumentor",
        ),  # Gemini SDK v1 (stable)
        (
            "google.genai",
            "GoogleGenAIInstrumentor",
            ".instrumentation.google_genai_instrumentor",
        ),  # GenAI SDK v2 (unified)
        (
            "google.ai.generativelanguage_v1beta",
            "GenerativeLanguageInstrumentor",
            ".instrumentation.generativelanguage_instrumentor",
        ),  # Low-level protobuf API (used by LangChain)
        (
            "boto3",
            "BedrockInstrumentor",
            ".instrumentation.bedrock_instrumentor",
        ),
        (
            "openai",
            "AzureOpenAIInstrumentor",
            ".instrumentation.azure_openai_instrumentor",
        ),
        ("vertexai", "VertexAIInstrumentor", ".instrumentation.vertexai_instrumentor"),
        ("litellm", "LiteLLMInstrumentor", ".instrumentation.litellm_instrumentor"),
    ]

    for lib_name, instrumentor_class, module_path in instrumentors:
        _setup_instrumentor(lib_name, instrumentor_class, module_path, sys_modules, wrapt)


def _setup_vectordb_instrumentation(sys_modules, wrapt):
    """Set up Vector DB instrumentation using OTEL strategy."""
    instrumentors = [
        ("chromadb", "ChromaDBInstrumentor", ".instrumentation.chromadb_instrumentor"),
        ("pinecone", "PineconeInstrumentor", ".instrumentation.pinecone_instrumentor"),
        ("weaviate", "WeaviateInstrumentor", ".instrumentation.weaviate_instrumentor"),
        ("qdrant_client", "QdrantInstrumentor", ".instrumentation.qdrant_instrumentor"),
    ]

    logger.debug(f"Setting up vectordb instrumentation for {len(instrumentors)} libraries")
    for lib_name, instrumentor_class, module_path in instrumentors:
        _setup_instrumentor(lib_name, instrumentor_class, module_path, sys_modules, wrapt)


def _setup_http_instrumentation(sys_modules, wrapt):
    """Set up HTTP instrumentation using OTEL strategy."""
    instrumentors = [
        ("httpx", "HTTPXInstrumentor", ".instrumentation.httpx_instrumentor"),
    ]

    for lib_name, instrumentor_class, module_path in instrumentors:
        _setup_instrumentor(lib_name, instrumentor_class, module_path, sys_modules, wrapt)


def _setup_bedrock_instrumentation(sys_modules, wrapt):
    """Set up Bedrock instrumentation using OTEL strategy."""
    instrumentors = [
        ("boto3", "BedrockInstrumentor", ".instrumentation.bedrock_instrumentor"),
    ]

    logger.debug(f"Setting up bedrock instrumentation for {len(instrumentors)} libraries")
    for lib_name, instrumentor_class, module_path in instrumentors:
        _setup_instrumentor(lib_name, instrumentor_class, module_path, sys_modules, wrapt)


def _setup_instrumentor(lib_name, instrumentor_class, module_path, sys_modules, wrapt):
    """Set up a single instrumentor following OTEL Python SDK strategy.

    OTEL Strategy:
    - If library already imported → Immediate instrumentation
    - If library not imported → Lazy hook via wrapt.when_imported
    """
    instrumentor_key = _make_instrumentor_key(lib_name, instrumentor_class)
    if instrumentor_key in _active_instrumentors:
        logger.debug(f"{instrumentor_class} already instrumented for {lib_name}")
        return

    if lib_name in sys_modules:
        logger.info(f"{lib_name} already imported, attempting immediate instrumentation")
        _try_immediate_instrumentation(lib_name, instrumentor_class, module_path)
    else:
        logger.info(f"{lib_name} not yet imported, setting up lazy hook")
        _setup_lazy_hook(lib_name, instrumentor_class, module_path, wrapt)


def _try_immediate_instrumentation(lib_name, instrumentor_class, module_path):
    """Try immediate instrumentation for an already-imported library."""
    try:
        logger.debug(f"Attempting immediate instrumentation for {lib_name}")
        module = __import__(f"mvk_sdk{module_path}", fromlist=[instrumentor_class])

        instrumentor_cls = getattr(module, instrumentor_class)
        instrumentor_key = _make_instrumentor_key(lib_name, instrumentor_class)

        try:
            instrumentor = instrumentor_cls()
        except Exception as e:
            logger.warning(f"Failed to instantiate {instrumentor_cls}: {e}")
            return

        if instrumentor_key in _active_instrumentors:
            logger.debug(f"{instrumentor_class} already active for {lib_name}, skipping")
            return

        # Handle factory pattern for Gemini SDKs
        if hasattr(instrumentor, "create_instrumentors"):
            # This is a factory - create and instrument all available SDKs
            logger.info(f"Factory detected for {lib_name}, creating instrumentors")

            # Check if Gemini instrumentors are already active to prevent double instrumentation
            if any(
                key.startswith("google.generativeai") or key.startswith("google.genai")
                for key in _active_instrumentors.keys()
            ):
                logger.info("Gemini instrumentors already active, skipping factory instrumentation")
                return

            created_instrumentors = instrumentor.create_instrumentors()
            if created_instrumentors:
                for created_instrumentor in created_instrumentors:
                    created_instrumentor.instrument(config=_effective_config)
                    _active_instrumentors[f"{lib_name}.{created_instrumentor.name}"] = (
                        created_instrumentor
                    )
                logger.info(f"{lib_name} factory instrumented {len(created_instrumentors)} SDKs")
            else:
                logger.info(f"{lib_name} factory found no SDKs to instrument")
        else:
            # Regular instrumentor
            # Use _effective_config if available, otherwise use empty dict
            config = _effective_config if _effective_config else {}
            try:
                instrumentor.instrument(config=config)
                _active_instrumentors[instrumentor_key] = instrumentor
                logger.info(f"{lib_name} instrumented immediately")
            except Exception as e:
                logger.warning(f"Failed to instrument {lib_name}: {e}")

    except ImportError as e:
        logger.warning(f"{lib_name} instrumentor not available: {e}")
    except Exception as e:
        logger.warning(f"Failed to instrument {lib_name}: {e}", exc_info=True)


def _setup_lazy_hook(lib_name, instrumentor_class, module_path, wrapt):
    """Set up lazy hook for when library gets imported."""
    if not wrapt:
        logger.debug(f"Cannot set up lazy hook for {lib_name} (wrapt not available)")
        return

    def on_import(module):
        """Called when the library is imported."""
        logger.debug(f"{lib_name} imported, attempting instrumentation")
        instrumentor_key = _make_instrumentor_key(lib_name, instrumentor_class)
        if instrumentor_key not in _active_instrumentors:
            _try_immediate_instrumentation(lib_name, instrumentor_class, module_path)
        else:
            logger.debug(f"{instrumentor_class} already active for {lib_name}, skipping")

    try:
        wrapt.when_imported(lib_name)(on_import)
        logger.info(f"Lazy hook registered for {lib_name}")
    except Exception as e:
        logger.warning(f"Failed to register lazy hook for {lib_name}: {e}")


def uninstrument() -> None:
    """Remove all instrumentation from wrapped libraries.

    This function removes all patches and restores original library behavior.
    It should be called before shutdown() if you want to completely disable
    MVK SDK instrumentation.

    Note: This does NOT flush pending spans. Call shutdown() for that.
    """
    global _active_instrumentors

    with _init_lock:
        for lib_name, instrumentor in _active_instrumentors.items():
            try:
                instrumentor.uninstrument()
                logger.debug(f"Uninstrumented {lib_name}")
            except Exception as e:
                logger.warning(f"Failed to uninstrument {lib_name}: {e}")

        _active_instrumentors.clear()

        logger.info("All instrumentation removed")


def shutdown() -> None:
    """Shutdown the SDK and flush all pending spans."""
    global _initialized, _strict_validation, _log_prompts_responses
    global _service_instance_id, _effective_config, _active_instrumentors

    with _init_lock:
        was_initialized = _initialized

        if _initialized:
            try:
                global_tracer = get_tracer()
                global_tracer.shutdown()
            except Exception as e:
                logger.debug(f"Error shutting down tracer: {e}")

        # Clear global context for test isolation (always, not just when initialized)
        from .context import _global_context

        _global_context.clear()

        # Reset all module-level variables for test isolation (always)
        _initialized = False
        _strict_validation = False
        _log_prompts_responses = False
        _effective_config.clear()
        _active_instrumentors.clear()

        if was_initialized:
            logger.info("MVK SDK shutdown complete")


def get_session_id() -> Optional[str]:
    """Get the current session ID.

    Returns:
        Session ID if set in global context, None otherwise
    """
    from .context import get_global_context

    ctx = get_global_context()
    return ctx.get("mvk.session_id")


def configure_otlp_compliance(strict: bool = True) -> None:
    """Configure SDK for strict OTLP compliance.

    When enabled, enforces:
    - Proper ID formats (32 hex for trace_id, 16 hex for span_id)
    - Nanosecond timestamps
    - All custom fields in attributes map
    - OTLP SpanKind and StatusCode enums

    Args:
        strict: If True, raise errors on OTLP violations.
                If False, attempt to fix violations.
    """
    global _strict_validation
    _strict_validation = strict
    logger.info(f"OTLP compliance mode: {'strict' if strict else 'lenient'}")


def get_service_instance_id() -> str:
    """Get the service instance ID (unique per process).

    Returns:
        Service instance ID (UUID v4)
    """
    return _service_instance_id


def get_log_prompts_responses() -> bool:
    """Check if prompt and response logging is enabled.

    Returns:
        True if prompt/response logging is enabled, False otherwise (default)
    """
    return _log_prompts_responses


def should_log_prompts_responses() -> bool:
    """Helper function for wrappers to check if they should log prompts/responses.

    Returns:
        True if logging is enabled, False otherwise (default for security)
    """
    return _log_prompts_responses


def is_strict_validation() -> bool:
    """Check if strict validation is enabled.

    Returns:
        True if strict validation is enabled
    """
    return _strict_validation
