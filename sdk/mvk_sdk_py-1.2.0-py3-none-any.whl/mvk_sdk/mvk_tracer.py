"""OTLP-compliant tracer for MVK SDK without OTEL dependencies."""

import json
import logging
import time
import uuid
from contextvars import ContextVar
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from .context import get_current_context, get_global_context, get_merged_context
from .schema import MVKStepType, get_mvk_step_type_for_name, validate
from .wrapper_logging import get_component_logger

logger = get_component_logger("core", "mvk_tracer")

# Context variable for current span
_current_span: ContextVar[Optional["Span"]] = ContextVar("current_span", default=None)


# OTLP SpanKind enum - using proper OTEL numeric values
class OTLPSpanKind(int, Enum):
    UNSPECIFIED = 0  # SPAN_KIND_UNSPECIFIED
    INTERNAL = 1  # SPAN_KIND_INTERNAL
    SERVER = 2  # SPAN_KIND_SERVER
    CLIENT = 3  # SPAN_KIND_CLIENT
    PRODUCER = 4  # SPAN_KIND_PRODUCER
    CONSUMER = 5  # SPAN_KIND_CONSUMER

    @property
    def string_value(self) -> str:
        """Get the string representation for logging/serialization."""
        return {
            0: "UNSPECIFIED",
            1: "INTERNAL",
            2: "SERVER",
            3: "CLIENT",
            4: "PRODUCER",
            5: "CONSUMER",
        }.get(self.value, "SPAN_KIND_UNSPECIFIED")


# OTLP Status Code enum - using proper OTEL numeric values
class OTLPStatusCode(int, Enum):
    UNSET = 0  # STATUS_CODE_UNSET
    OK = 1  # STATUS_CODE_OK
    ERROR = 2  # STATUS_CODE_ERROR

    @property
    def string_value(self) -> str:
        """Get the string representation for logging/serialization."""
        return {0: "STATUS_CODE_UNSET", 1: "STATUS_CODE_OK", 2: "STATUS_CODE_ERROR"}.get(
            self.value, "STATUS_CODE_UNSET"
        )


def generate_trace_id() -> str:
    """Generate OTLP-compliant 32-char hex trace ID."""
    return uuid.uuid4().hex


def generate_span_id() -> str:
    """Generate OTLP-compliant 16-char hex span ID."""
    return uuid.uuid4().hex[:16]


def to_nanoseconds(timestamp: float) -> int:
    """Convert float seconds timestamp to int nanoseconds."""
    return int(timestamp * 1_000_000_000)


class Span:
    """Lightweight span implementation."""

    def __init__(self, name: str, kind: str, attributes: Dict[str, Any]):
        # Generate OTLP-compliant IDs
        self.span_id = generate_span_id()
        self.trace_id = attributes.get("trace_id")
        if not self.trace_id:
            self.trace_id = generate_trace_id()
        elif "-" in self.trace_id:
            # Convert UUID format to hex if needed
            self.trace_id = self.trace_id.replace("-", "")

        self.parent_id = attributes.get("parent_id")
        self.parent_span_id = self.parent_id  # Alias for compatibility
        self.name = name

        # Determine MVK step type from attributes or kind parameter
        mvk_step_type = attributes.get("mvk.step_type") or attributes.get("step_type")

        if mvk_step_type:
            # Use step_type from attributes (set by wrappers)
            # Keep enum or string as-is internally; converted at export boundaries
            self.mvk_kind = mvk_step_type
            try:
                logger.info(
                    "MVK DIAG | Span.__init__ | name=%s raw mvk.step_type=%s",
                    name,
                    mvk_step_type,
                )
            except Exception:
                # Diagnostic logging failed - cannot log the failure itself to avoid recursion
                pass
        else:
            # Use kind parameter as fallback, but only if it's a valid MVK step type
            valid_mvk_kinds = [k.value for k in MVKStepType]
            if kind in valid_mvk_kinds:
                self.mvk_kind = kind
            else:
                # If kind is an OTLP SpanKind, infer MVK step type from name
                self.mvk_kind = get_mvk_step_type_for_name(name)

        # Ensure mvk.step_type is set in attributes; keep enum/string as-is
        if self.mvk_kind:
            attributes["mvk.step_type"] = self.mvk_kind
            try:
                logger.info(
                    "MVK DIAG | Span.__init__ | set attributes['mvk.step_type']=%s",
                    attributes["mvk.step_type"],
                )
            except Exception:
                # Diagnostic logging failed - cannot log the failure itself to avoid recursion
                pass

        # Map MVK step type to OTLP SpanKind
        self.otlp_kind = self._map_to_otlp_kind(
            self.mvk_kind.value if isinstance(self.mvk_kind, Enum) else self.mvk_kind
        )
        self.start_time = time.time()
        self.end_time = None
        self.duration_ms = None
        self.attributes = self._format_attributes(attributes)
        self.events: List[Dict[str, Any]] = []
        self.status_code = OTLPStatusCode.UNSET
        self.status_message = ""
        self.error: Optional[Dict[str, str]] = None
        self.error_type: Optional[str] = None
        self.error_message: Optional[str] = None
        self.metrics: List[Dict[str, Any]] = []

    def end(self):
        """End the span and send to processor.

        Never fails - silently drops span if processing fails.
        """
        try:
            if self.end_time is not None:
                return

            self.end_time = time.time()
            self.duration_ms = (self.end_time - self.start_time) * 1000

            # Set status to OK if not already set
            if self.status_code == OTLPStatusCode.UNSET:
                self.status_code = OTLPStatusCode.OK

            # Convert to OTLP-compliant dict
            otlp_span = self.to_otlp_dict()

            # Send to processor (non-blocking)
            tracer = get_tracer()
            if tracer._processor:
                tracer._processor.on_end(otlp_span)
        except Exception as e:
            # Never let span processing affect customer code
            logger.debug(f"Failed to end span {self.name}: {e}")

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        """Add an event to the span."""
        event = {"name": name, "timestamp": time.time(), "attributes": attributes or {}}
        self.events.append(event)

    def set_error(self, error: Exception):
        """Set error on span."""
        self.status_code = OTLPStatusCode.ERROR
        self.status_message = str(error)
        self.error_type = type(error).__name__
        self.error_message = str(error)
        self.error = {"type": self.error_type, "message": self.error_message}
        self.add_event(
            "exception",
            {"exception.type": type(error).__name__, "exception.message": str(error)},
        )

    def __enter__(self):
        """Enter span context."""
        self._token = _current_span.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit span context."""
        if exc_val:
            self.set_error(exc_val)
        self.end()
        _current_span.reset(self._token)
        return False

    async def __aenter__(self):
        """Enter async span context."""
        self._token = _current_span.set(self)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async span context."""
        if exc_val:
            self.set_error(exc_val)
        self.end()
        _current_span.reset(self._token)
        return False

    def set_attribute(self, key: str, value: Any):
        """Set an attribute on the span safely.

        Never fails - logs warning if attribute can't be set.
        """
        try:
            # Import here to avoid circular imports
            from .decorators import _is_parent_span_context, _is_token_attribute

            # Filter token attributes for business operations
            # Check if this is an AI provider operation based on span name or attributes
            is_ai_provider_operation = False

            # Check if span name indicates AI provider operation
            ai_provider_prefixes = [
                "openai.",
                "anthropic.",
                "gemini.",
                "bedrock.",
                "azure.openai.",
                "vertexai.",
                "cohere.",
                "mistral.",
                "huggingface.",
            ]
            span_name = getattr(self, "name", "")
            if any(span_name.startswith(prefix) for prefix in ai_provider_prefixes):
                is_ai_provider_operation = True

            # Check if span has AI provider step_type
            if not is_ai_provider_operation:
                step_type = self.attributes.get("mvk.step_type")
                if step_type in ["LLM", "EMBEDDING", "VECTORDB", "TOOL"]:
                    is_ai_provider_operation = True

            # Filter token attributes for business operations
            if not is_ai_provider_operation and _is_token_attribute(key):
                logger.debug(
                    f"Skipping token attribute {key} for business operation - should only be set on AI provider operations"
                )
                return

            # Apply same formatting logic as _format_attributes
            formatted_key = self._format_attribute_key(key)

            # Store value with proper formatting
            if isinstance(value, (str, int, float, bool, type(None))):
                self.attributes[formatted_key] = value
            elif isinstance(value, (list, tuple)):
                # Lists and tuples are usually fine
                self.attributes[formatted_key] = value
            elif isinstance(value, dict):
                # JSON-encode complex objects
                self.attributes[formatted_key] = json.dumps(value)
            else:
                # For other types (objects, functions, etc.), convert to string
                self.attributes[formatted_key] = str(value)
        except Exception as e:
            # If even string conversion fails, skip this attribute
            logger.debug(f"Failed to set attribute {key}: {e}")

    def _format_attribute_key(self, key: str) -> str:
        """Format attribute key with proper prefix.

        Args:
            key: Original attribute key

        Returns:
            Formatted key with appropriate prefix
        """
        # Skip internal fields that shouldn't be in attributes
        if key in ["trace_id", "span_id", "parent_id", "parent_span_id"]:
            return key

        # Add proper prefixes based on key patterns
        if key.startswith("mvk."):
            # Already has mvk prefix
            return key
        elif key.startswith(("service.", "http.", "db.", "rpc.", "cloud.", "tags.")):
            # Standard OTEL semantic conventions or already prefixed tags
            return key
        elif key in [
            "agent_name",
            "agent_id",
            "session_id",
            "user_id",
            "client_id",
            "operation",
            "model_name",
            "model_provider",
            "model_provider_code",  # Legacy - maps to model_provider
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
            "duration_ms",
            "time_to_first_token_ms",
            "cloud_provider",
        ]:
            # MVK-specific fields that need prefix
            # Standardize model_provider_code to model_provider
            if key == "model_provider_code":
                return "mvk.model_provider"
            return f"mvk.{key}"
        else:
            # Other custom fields get mvk prefix
            return f"mvk.{key}"

    def to_otlp_dict(self) -> Dict[str, Any]:
        """Convert span to OTLP-compliant dictionary format.

        Returns:
            OTLP-compliant span dictionary with proper ID formats,
            nanosecond timestamps, and all custom fields in attributes.

        Never fails - returns minimal span if conversion fails.
        """
        try:
            # Format events for OTLP with camelCase
            otlp_events = []
            for event in self.events:
                otlp_event = {
                    "timeUnixNano": str(
                        to_nanoseconds(event["timestamp"])
                    ),  # String for 64-bit int
                    "name": event["name"],
                    "attributes": [],
                }
                # Convert event attributes to typed format
                event_attrs = event.get("attributes", {})
                for key, value in event_attrs.items():
                    if value is not None:
                        typed_attr = {"key": key}
                        if isinstance(value, bool):
                            typed_attr["value"] = {"boolValue": value}
                        elif isinstance(value, int):
                            typed_attr["value"] = {"intValue": str(value)}
                        elif isinstance(value, float):
                            typed_attr["value"] = {"doubleValue": value}
                        else:
                            typed_attr["value"] = {"stringValue": str(value)}
                        otlp_event["attributes"].append(typed_attr)
                otlp_events.append(otlp_event)

            # Build OTLP span with proper camelCase
            otlp_span: Dict[str, Any] = {
                "traceId": self.trace_id,
                "spanId": self.span_id,
                "name": self.name,
                "kind": self.otlp_kind.value,
                "startTimeUnixNano": str(to_nanoseconds(self.start_time)),  # String for 64-bit int
                "endTimeUnixNano": str(
                    to_nanoseconds(self.end_time)
                    if self.end_time
                    else to_nanoseconds(self.start_time)
                ),
                "status": {"code": self.status_code.string_value},
                "attributes": self._format_attributes_for_otlp(),  # Convert to typed format
                "events": otlp_events,
                "links": [],
            }

            # Only add parentSpanId if it exists (omit for root spans)
            if self.parent_id:
                otlp_span["parentSpanId"] = self.parent_id

            # Only add status message if present
            if self.status_message:
                otlp_span["status"]["message"] = self.status_message

            # Only add dropped counts if non-zero
            if hasattr(self, "dropped_attributes_count") and self.dropped_attributes_count > 0:
                otlp_span["droppedAttributesCount"] = self.dropped_attributes_count
            if hasattr(self, "dropped_events_count") and self.dropped_events_count > 0:
                otlp_span["droppedEventsCount"] = self.dropped_events_count
            if hasattr(self, "dropped_links_count") and self.dropped_links_count > 0:
                otlp_span["droppedLinksCount"] = self.dropped_links_count

            return otlp_span
        except Exception as e:
            # If conversion fails, return minimal valid span
            logger.debug(f"Failed to convert span to OTLP format: {e}")
            # Return absolute minimum OTLP span
            return {
                "traceId": self.trace_id or "00000000000000000000000000000000",
                "spanId": self.span_id or "0000000000000000",
                "name": self.name or "unknown",
                "kind": OTLPSpanKind.INTERNAL.value,
                "startTimeUnixNano": str(to_nanoseconds(self.start_time or time.time())),
                "endTimeUnixNano": str(to_nanoseconds(self.end_time or time.time())),
                "status": {"code": "STATUS_CODE_OK"},
                "attributes": [],
                "events": [],
                "links": [],
            }

    def _map_to_otlp_kind(self, mvk_kind: str) -> OTLPSpanKind:
        """Map MVK semantic kind to OTLP SpanKind.

        Args:
            mvk_kind: MVK semantic kind (LLM, TOOL, etc.)

        Returns:
            OTLP SpanKind enum value
        """
        # Convert enum to string value if needed
        if hasattr(mvk_kind, "value"):
            mvk_kind = mvk_kind.value

        # Map MVK kinds to OTLP kinds
        mapping = {
            "LLM": OTLPSpanKind.CLIENT,  # LLM calls are client operations
            "EMBEDDING": OTLPSpanKind.CLIENT,  # Embedding calls are client operations
            "RETRIEVER": OTLPSpanKind.CLIENT,  # Retriever calls are client operations
            "TOOL": OTLPSpanKind.INTERNAL,  # Tools are internal operations
            "MEMORY": OTLPSpanKind.INTERNAL,  # Memory ops are internal
            "AGENT_CALL": OTLPSpanKind.INTERNAL,  # Agent calls are internal orchestration
            "HTTP": OTLPSpanKind.CLIENT,  # HTTP calls are client operations
            "DATABASE": OTLPSpanKind.CLIENT,  # DB calls are client operations
        }

        return mapping.get(mvk_kind, OTLPSpanKind.INTERNAL)

    def _format_attributes_for_otlp(self) -> List[Dict[str, Any]]:
        """Format attributes as typed key-value pairs for OTLP.

        Returns:
            List of typed attribute objects

        Never fails - skips problematic attributes.
        """
        typed_attrs = []

        for key, value in self.attributes.items():
            try:
                if value is None:
                    continue

                # Skip empty strings - don't add them to OTLP spans
                if isinstance(value, str) and value == "":
                    continue

                typed_attr: Dict[str, Any] = {"key": key}

                # Determine type and set value
                if isinstance(value, bool):
                    typed_attr["value"] = {"boolValue": value}
                elif isinstance(value, int):
                    # Use string for 64-bit ints in JSON
                    typed_attr["value"] = {"intValue": str(value)}
                elif isinstance(value, float):
                    typed_attr["value"] = {"doubleValue": value}
                elif isinstance(value, str):
                    typed_attr["value"] = {"stringValue": value}
                elif isinstance(value, (list, tuple)):
                    # Array value
                    typed_attr["value"] = {
                        "arrayValue": {"values": [self._create_typed_value(v) for v in value]}
                    }
                elif isinstance(value, dict):
                    # Convert dict to string for now
                    typed_attr["value"] = {"stringValue": json.dumps(value)}
                else:
                    # Default to string representation, but handle enums and enum-like strings
                    if isinstance(value, Enum):
                        typed_attr["value"] = {"stringValue": value.value}
                    elif isinstance(value, str) and value.startswith("MVKStepType."):
                        typed_attr["value"] = {"stringValue": value.split(".")[-1]}
                    else:
                        typed_attr["value"] = {"stringValue": str(value)}

                typed_attrs.append(typed_attr)
            except Exception as e:
                # Skip attributes that can't be formatted
                logger.debug(f"Failed to format attribute {key}: {e}")

        return typed_attrs

    def _create_typed_value(self, value: Any) -> Dict[str, Any]:
        """Create a typed value for array elements."""
        if isinstance(value, bool):
            return {"boolValue": value}
        elif isinstance(value, int):
            return {"intValue": str(value)}
        elif isinstance(value, float):
            return {"doubleValue": value}
        else:
            # Handle enums properly and enum-like strings
            if isinstance(value, Enum):
                return {"stringValue": value.value}
            if isinstance(value, str) and value.startswith("MVKStepType."):
                return {"stringValue": value.split(".")[-1]}
            return {"stringValue": str(value)}

    def _format_attributes(self, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """Format attributes with proper OTLP namespacing.

        Args:
            attributes: Raw attributes dictionary

        Returns:
            Formatted attributes with proper prefixes and flattened tags
        """
        formatted = {}

        # Extract tags for flattening
        tags = attributes.pop("tags", {})

        # Process each attribute
        for key, value in attributes.items():
            # Skip internal fields that shouldn't be in attributes
            if key in ["trace_id", "span_id", "parent_id", "parent_span_id"]:
                continue

            # Skip service.* attributes - these belong in Resource only
            if key.startswith("service."):
                continue

            # Add proper prefixes based on key patterns
            if key.startswith("mvk."):
                # Skip mvk.mvk_step_type as it's a duplicate that should not be exported
                if key == "mvk.mvk_step_type":
                    continue
                # Already has mvk prefix
                # Special handling for mvk.step_type to ensure it's a normalized string value
                if key == "mvk.step_type":
                    if isinstance(value, Enum):
                        formatted[key] = value.value
                    elif isinstance(value, str):
                        # Normalize strings like "MVKStepType.LLM" -> "LLM"
                        formatted[key] = (
                            value.split(".")[-1] if value.startswith("MVKStepType.") else value
                        )
                    else:
                        formatted[key] = str(value)
                else:
                    formatted[key] = value
            elif key.startswith(("http.", "db.", "rpc.", "cloud.")):
                # Standard OTEL semantic conventions
                formatted[key] = value
            elif key.startswith("mvk.tags."):
                # Already properly prefixed tags
                formatted[key] = value
            elif key in [
                "agent_name",
                "agent_id",
                "session_id",
                "user_id",
                "client_id",
                "operation",
                "model_name",
                "model_provider",
                "model_provider_code",  # Legacy - maps to model_provider
                "prompt_tokens",
                "completion_tokens",
                "total_tokens",
                "duration_ms",
                "time_to_first_token_ms",
                "cloud_provider",
            ]:
                # MVK-specific fields that need prefix
                # Standardize model_provider_code to model_provider
                if key == "model_provider_code":
                    formatted["mvk.model_provider"] = value
                else:
                    formatted[f"mvk.{key}"] = value
            else:
                # Other custom fields get mvk prefix
                formatted[f"mvk.{key}"] = value

        # Add MVK span kind if present (only if not already set)
        if "mvk.step_type" not in formatted and self.mvk_kind:
            # Only add if mvk_kind is a valid MVK step type, not an OTLP SpanKind
            valid_mvk_kinds = [k.value for k in MVKStepType]
            mk = self.mvk_kind.value if isinstance(self.mvk_kind, Enum) else self.mvk_kind
            if mk in valid_mvk_kinds:
                formatted["mvk.step_type"] = mk

        # Flatten tags with mvk.tags.* prefix
        for tag_key, tag_value in tags.items():
            formatted[f"mvk.tags.{tag_key}"] = tag_value

        # Ensure values are JSON-serializable and filter out empty strings
        keys_to_remove = []
        for key, value in formatted.items():
            if key == "mvk.metered_usage" and isinstance(value, str):
                # mvk.metered_usage is already JSON-encoded, keep as-is
                pass
            elif isinstance(value, (dict, list)):
                # JSON-encode complex objects
                formatted[key] = json.dumps(value)
            elif isinstance(value, bool):
                # Keep booleans as-is (OTLP supports them)
                pass
            elif isinstance(value, (int, float)):
                # Keep numbers as-is
                pass
            else:
                # Convert everything else to string
                if value is not None:
                    str_value = str(value)
                    # Skip empty strings - don't add them to spans
                    if str_value == "":
                        keys_to_remove.append(key)
                    else:
                        formatted[key] = str_value
                else:
                    # Skip None values - don't add them to spans
                    keys_to_remove.append(key)

        # Remove all keys that had empty or None values
        for key in keys_to_remove:
            del formatted[key]

        # DIAG: after full formatting, log mvk.step_type
        try:
            if "mvk.step_type" in formatted:
                logger.info(
                    "MVK DIAG | _format_attributes | final mvk.step_type=%s",
                    formatted.get("mvk.step_type"),
                )
        except Exception:
            # Diagnostic logging failed - cannot log the failure itself to avoid recursion
            pass

        return formatted

    def _flatten_attributes(self, attributes: Dict[str, Any]) -> Dict[str, Any]:
        """Flatten attributes for OTLP events.

        Args:
            attributes: Event attributes

        Returns:
            Flattened attributes dictionary
        """
        flattened = {}
        for key, value in attributes.items():
            if isinstance(value, (dict, list)):
                flattened[key] = json.dumps(value)
            else:
                flattened[key] = value
        return flattened


class UltralightTracer:
    """Global tracer singleton for MVK SDK v1.1."""

    def __init__(self) -> None:
        self._processor: Optional[Any] = None
        self._api_key: Optional[str] = None
        self._agent_name: Optional[str] = None
        self._strict_validation: bool = False
        # Common resource attributes that should not be in individual spans
        self._resource_attributes: Dict[str, str] = {}

    def configure(self, api_key: str, agent_name: str, strict_validation: bool = False) -> None:
        """Configure the tracer with API key and agent name.

        Args:
            api_key: MVK API key
            agent_name: Name of the agent
            strict_validation: Whether to enforce strict validation
        """
        self._api_key = api_key
        self._agent_name = agent_name
        self._strict_validation = strict_validation

        # Set common resource attributes
        self._resource_attributes = {
            "mvk.agent_name": agent_name,
        }

    def set_resource_attribute(self, key: str, value: str) -> None:
        """Set a resource-level attribute that will be common to all spans.

        Args:
            key: Attribute key (should start with mvk.)
            value: Attribute value
        """
        if key.startswith("mvk."):
            self._resource_attributes[key] = value
        else:
            self._resource_attributes[f"mvk.{key}"] = value

    def get_resource_attributes(self) -> Dict[str, str]:
        """Get the current resource attributes.

        Returns:
            Dictionary of resource attributes
        """
        return self._resource_attributes.copy()

    def add_span_processor(self, processor: Any) -> None:
        """Add a span processor to handle finished spans.

        Args:
            processor: Span processor instance
        """
        self._processor = processor

    def start_span(
        self,
        name: str,
        kind: Optional[Union[MVKStepType, str]] = None,
        inherit_context: bool = True,
        **kwargs,
    ) -> Span:
        """Start a new span.

        Args:
            name: Span name
            kind: Span kind (will be inferred if not provided)
            inherit_context: Whether to inherit current context (default True)
            **kwargs: Additional attributes

        Returns:
            Span instance
        """
        # Get current context attributes only if inheriting
        if inherit_context:
            context = get_current_context()
            # Start with kwargs, then apply context with proper namespacing
            attributes = kwargs.copy()

            # Apply proper namespacing for context attributes (same logic as @mvk.signal)
            for key, value in context.items():
                if key == "tags" and isinstance(value, dict):
                    # Flatten tags with mvk.tags.* prefix
                    for tag_key, tag_value in value.items():
                        attributes[f"mvk.tags.{tag_key}"] = tag_value
                elif key.startswith(("service.", "mvk.tags.", "http.", "rpc.")):
                    # Already properly namespaced - keep as is
                    attributes[key] = value
                elif key.startswith("mvk."):
                    # Already has mvk prefix - keep as is
                    attributes[key] = value
                else:
                    # Add mvk prefix to custom fields (session_id, user_id, client_id, etc.)
                    prefixed_key = f"mvk.{key}"
                    # Don't override if already set in kwargs
                    if prefixed_key not in kwargs:
                        attributes[prefixed_key] = value
        else:
            attributes = kwargs.copy()

        # Handle mvk_step_type and mvk_operation parameters specifically
        if "mvk_step_type" in attributes:
            mvk_step_type = attributes.pop("mvk_step_type")
            # Keep enum or string as-is; conversion happens at export formatting
            attributes["mvk.step_type"] = mvk_step_type

        if "mvk_operation" in attributes:
            mvk_operation = attributes.pop("mvk_operation")
            attributes["mvk.operation"] = mvk_operation

        # Also handle mvk.mvk_step_type if it exists
        if "mvk.mvk_step_type" in attributes:
            mvk_step_type = attributes.pop("mvk.mvk_step_type")
            # Keep enum or string as-is; conversion happens at export formatting
            attributes["mvk.step_type"] = mvk_step_type

        # Strip agent identity from span attributes if present (resource-level only)
        for attr in [
            "mvk.agent_id",
            "mvk.agent_name",
            "mvk.service_instance",
        ]:
            if attr in attributes:
                attributes.pop(attr, None)

        # Check if step_type is already provided in attributes (from wrappers)
        mvk_step_type = attributes.get("mvk.step_type") or attributes.get("step_type")

        # Special case: if operation is "chat_session", always set step_type to "LLM"
        operation = attributes.get("mvk.operation") or attributes.get("operation")
        if operation == "chat_session" and not mvk_step_type:
            mvk_step_type = "LLM"
            attributes["mvk.step_type"] = "LLM"

        # Infer kind if not provided and step_type not already set
        if not kind and not mvk_step_type:
            kind = get_mvk_step_type_for_name(name)

        # Validate kind if strict validation is enabled
        if kind and hasattr(self, "_strict_validation") and self._strict_validation:
            valid_kinds = [k.value for k in MVKStepType]
            if kind not in valid_kinds:
                raise ValueError(
                    f"Invalid span kind '{kind}'. Valid kinds: {', '.join(valid_kinds)}"
                )

        # Add kind to attributes for v3.0 (only if step_type not already provided)
        if not mvk_step_type and kind:
            # Only use kind if it's a valid MVK step type, not an OTLP SpanKind
            valid_mvk_kinds = [k.value for k in MVKStepType]
            # Normalize enum to its value if needed
            kind_value = kind.value if hasattr(kind, "value") else kind
            if kind_value in valid_mvk_kinds:
                attributes["mvk.step_type"] = str(kind_value)
            else:
                # If kind is an OTLP SpanKind, infer MVK step type from name
                inferred_kind = get_mvk_step_type_for_name(name)
                attributes["mvk.step_type"] = inferred_kind

        # Final check: if we still don't have a step_type, infer from name
        if not attributes.get("mvk.step_type"):
            inferred_step_type = get_mvk_step_type_for_name(name)
            attributes["mvk.step_type"] = inferred_step_type

        # Get parent span if any
        parent = _current_span.get()
        if parent:
            attributes["trace_id"] = parent.trace_id
            attributes["parent_id"] = parent.span_id

            # Only inherit specific fields from parent span if we're inheriting context
            # (create_signal sets inherit_context=False and should not inherit)
            if inherit_context and hasattr(parent, "attributes"):
                parent_attrs = parent.attributes
                # Inherit session_id, user_id, client_id if not already set
                for field in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]:
                    if field in parent_attrs and field not in attributes:
                        attributes[field] = parent_attrs[field]
        else:
            # No parent span - check if there's a trace_id in the context
            # This allows trace_id reuse within mvk.context() or across @mvk.signal() calls
            # Always check context trace_id (even if inherit_context=False) because trace_id
            # should be shared across all operations in a trace, regardless of context inheritance settings
            from .context import get_trace_id

            context_trace_id = get_trace_id()
            if context_trace_id:
                attributes["trace_id"] = context_trace_id
                logger.debug(f"Reusing trace_id from context: {context_trace_id}")

        # Create span (ensure kind is a string for type safety)
        if isinstance(kind, Enum):
            kind_str = str(kind.value)
        else:
            kind_str = str(kind) if kind is not None else ""
        span_kind = attributes.get("mvk.step_type") or kind_str
        span = Span(name, str(span_kind), attributes)

        return span

    def force_flush(self, timeout_ms: int = 30000) -> bool:
        """Force flush all pending spans for serverless environments.

        Args:
            timeout_ms: Maximum time to wait for flush in milliseconds

        Returns:
            True if successful, False otherwise
        """
        import time

        deadline = time.time() + (timeout_ms / 1000.0)

        try:
            # Flush processor if available
            if self._processor and hasattr(self._processor, "force_flush"):
                remaining = max(0, deadline - time.time())
                if remaining > 0:
                    if not self._processor.force_flush(int(remaining * 1000)):
                        logger.warning("Processor force flush failed")
                        return False
                else:
                    logger.warning("Timeout before processor flush")
                    return False

            # Flush exporter if available
            if (
                hasattr(self, "_exporter")
                and getattr(self, "_exporter", None) is not None
                and hasattr(self._exporter, "force_flush")
            ):
                remaining = max(0, deadline - time.time())
                if remaining > 0:
                    if not self._exporter.force_flush(int(remaining * 1000)):
                        logger.warning("Exporter force flush failed")
                        return False
                else:
                    logger.warning("Timeout before exporter flush")
                    return False

            return True

        except Exception:  # pylint: disable=broad-except
            logger.exception("Error during force flush")
            return False

    def shutdown(self) -> None:
        """Shutdown the tracer and its processor."""
        if self._processor:
            self._processor.shutdown()


# Global tracer instance
_global_tracer: Optional[UltralightTracer] = None


def get_tracer() -> UltralightTracer:
    """Get the global tracer instance.

    Returns:
        UltralightTracer: The global tracer singleton
    """
    global _global_tracer
    if _global_tracer is None:
        _global_tracer = UltralightTracer()
    return _global_tracer


def get_current_span() -> Optional[Span]:
    """Get the currently active span."""
    return _current_span.get()


def force_flush(timeout_ms: int = 30000) -> bool:
    """Force flush all pending spans for serverless environments.

    This is a global function that can be called to flush all spans
    before a serverless function exits.

    Args:
        timeout_ms: Maximum time to wait for flush in milliseconds

    Returns:
        True if successful, False otherwise

    Example:
        # In AWS Lambda handler
        def handler(event, context):
            result = process(event)
            mvk.force_flush(timeout_ms=1000)  # Flush before exit
            return result
    """
    tracer = get_tracer()
    if tracer:
        return tracer.force_flush(timeout_ms)
    return True  # No tracer means nothing to flush


def create_signal(
    name: str,
    step_type: Optional[str] = None,
    operation: Optional[str] = None,
    operation_subtype: Optional[str] = None,
    kind: Optional[Union[MVKStepType, str]] = None,  # Deprecated, use step_type
    tags: Optional[Dict[str, str]] = None,
) -> Span:
    """Create a new signal without auto-instrumentation.

    This is the public API for manual signal creation. It creates a signal
    with only the specified parameters. Use span.set_attribute() to add
    additional attributes after creation.

    Context Parameter Inheritance (v1.1+):
        By default, create_signal() inherits context parameters from:
        1. Parent signal (if within another signal) - session_id, user_id, client_id, agent_name
        2. Global context (instrument level) - all context parameters
        3. @mvk.context decorators/context managers - all context parameters
        4. Explicit parameters - highest priority

        Inherited parameters include:
        - session_id (mvk.session_id)
        - user_id (mvk.user_id)
        - client_id (mvk.client_id)
        - tenant_id (mvk.tenant_id)
        - request_id (mvk.request_id)
        - region (mvk.region)
        - cloud_provider_code (mvk.cloud_provider_code)
        - use_case_id (mvk.use_case_id)
        - tags (mvk.tags.*)

        Tag Inheritance:
        By default, create_signal() inherits tags from:
        1. Global context (instrument level) - ALWAYS inherited
        2. @mvk.context decorators - inherited by default
        3. Parent signal - inherited if within another signal
        4. Explicit tags parameter - highest priority

        To opt-out of context tag inheritance, pass tags=[] explicitly.
        This will only inherit global and parent signal tags.

    Args:
        name: Signal name
        step_type: Step type (LLM, TOOL, RETRIEVER, etc.)
        operation: Operation type
        operation_subtype: Operation subtype
        kind: Deprecated - use step_type instead
        tags: Custom tags for signal attribution (will be flattened as mvk.tags.*)
              Pass tags={} to skip @mvk.context tag inheritance
              Pass tags=None (default) to inherit all context tags

    Returns:
        Signal instance to be used as context manager

    Example:
        # Inherits all context parameters from @mvk.context
        with mvk_context(session_id="s-123", user_id="u-456"):
            with mvk_create_signal("custom_operation", step_type="TOOL") as signal:
                # Signal inherits session_id="s-123" and user_id="u-456"
                signal.set_attribute("mvk.custom_field", "value")

        # Add custom tags (merges with inherited tags)
        with mvk_create_signal("custom_op", step_type="TOOL", tags={"env": "prod"}) as signal:
            pass

        # Opt-out of context tag inheritance
        with mvk_create_signal("custom_op", step_type="TOOL", tags={}) as signal:
            pass  # Only inherits global + parent signal tags
    """
    tracer = get_tracer()

    # Handle step_type (with backward compatibility for kind)
    actual_step_type = step_type or kind

    # Build attributes
    attrs = {}
    if actual_step_type:
        # Convert enum to string value if it's an enum
        if isinstance(actual_step_type, Enum):
            attrs["mvk.step_type"] = actual_step_type.value
        else:
            attrs["mvk.step_type"] = str(actual_step_type)
    if operation:
        attrs["mvk.operation"] = operation
    if operation_subtype:
        attrs["mvk.operation_subtype"] = operation_subtype

    # Handle tags with proper merging and limit enforcement
    # ALWAYS process tags from global context, even if not explicitly passed
    # Inherit from:
    # 1. Global context (instrument level) - ALWAYS inherit
    # 2. Context stack (@mvk.context decorators) - inherit UNLESS tags=[] explicitly passed
    # 3. Parent span tags (if in a span context) - inherit
    # 4. Explicit tags parameter - of course

    global_ctx = get_global_context()

    # Extract tags from different sources
    global_tags = {}
    context_tags = {}
    parent_span_tags = {}
    span_tags = tags if tags is not None else None

    # Check if user explicitly passed tags=[] to opt-out of inheritance
    explicit_empty_tags = tags is not None and isinstance(tags, dict) and len(tags) == 0

    # Extract global tags (from instrument) - ALWAYS inherit these
    if "tags" in global_ctx and isinstance(global_ctx["tags"], dict):
        global_tags = global_ctx["tags"]

    # Extract context tags from @mvk.context decorators - inherit UNLESS tags=[] explicitly
    if not explicit_empty_tags:
        merged_ctx = get_merged_context()
        if "tags" in merged_ctx and isinstance(merged_ctx["tags"], dict):
            context_tags = merged_ctx["tags"]

    # Extract parent span tags (from current active span) - inherit these too
    current_span = get_current_span()
    if current_span and hasattr(current_span, "attributes"):
        for key, value in current_span.attributes.items():
            if key.startswith("mvk.tags."):
                tag_key = key[9:]  # Remove "mvk.tags." prefix
                parent_span_tags[tag_key] = value

    # Merge tags with proper priority and limit enforcement
    # Priority: global < context < parent_span < create_signal
    # If user passes tags=[], only global tags are used (context tags are skipped)
    from .schema import merge_tags_with_limit

    merged_tags = merge_tags_with_limit(
        global_tags,
        context_tags,
        parent_span_tags,
        span_tags or {},
        source_names=["instrument()", "@mvk.context()", "parent_span", "create_signal()"],
    )

    # Add merged tags to span attributes with proper namespacing
    for tag_key, tag_value in merged_tags.items():
        attrs[f"mvk.tags.{tag_key}"] = tag_value

    # v1.1: create_signal NOW inherits context parameters by default
    # Check for selective inheritance from parent span (similar to @track decorator)
    parent_span = get_current_span()
    if parent_span:
        # Only inherit specific fields from parent span
        if hasattr(parent_span, "attributes"):
            parent_attrs = parent_span.attributes
            # Selective inheritance: session_id, user_id, client_id, and mvk.agent_name
            # Empty string "" disables inheritance, None allows it
            if "mvk.session_id" in parent_attrs and "mvk.session_id" not in attrs:
                attrs["mvk.session_id"] = parent_attrs["mvk.session_id"]
            if "mvk.user_id" in parent_attrs and "mvk.user_id" not in attrs:
                attrs["mvk.user_id"] = parent_attrs["mvk.user_id"]
            if "mvk.client_id" in parent_attrs and "mvk.client_id" not in attrs:
                attrs["mvk.client_id"] = parent_attrs["mvk.client_id"]
            if "mvk.agent_name" in parent_attrs and "mvk.agent_name" not in attrs:
                attrs["mvk.agent_name"] = parent_attrs["mvk.agent_name"]

    # Get context attributes from global and @mvk_context (similar to @track decorator)
    context_attrs = get_merged_context()

    # Apply context attributes with proper namespacing (same logic as @track)
    for key, value in context_attrs.items():
        # Skip token-related attributes for business operations
        # These should only be set on AI provider operations
        from .decorators import _is_ai_provider_operation, _is_token_attribute

        if (
            _is_token_attribute(key) or _is_token_attribute(key.replace("mvk.", ""))
        ) and not _is_ai_provider_operation(actual_step_type):
            logger.debug(
                f"Skipping token attribute {key} from context for business operation - should only be set on AI provider operations"
            )
            continue

        # Apply OTLP namespacing if needed
        if key == "tags" and isinstance(value, dict):
            # Tags are already handled above, skip here
            continue
        elif key.startswith("tags."):
            # Individual tag attributes - already handled above
            continue
        elif key.startswith(("service.", "mvk.tags.", "http.", "rpc.")):
            # Already properly namespaced - keep as is
            # Don't override if already set
            if key not in attrs:
                attrs[key] = value
        elif key.startswith("mvk."):
            # Already has mvk prefix
            # Don't override inherited session_id/user_id/client_id with context
            if key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]:
                if key not in attrs:
                    attrs[key] = value
            else:
                # Other mvk.* attributes - don't override if already set
                # Skip agent identity attributes (they're resource-level, not span-level)
                if key not in [
                    "mvk.agent_id",
                    "mvk.agent_name",
                    "mvk.service_instance",
                ]:
                    if key not in attrs:
                        attrs[key] = value
        else:
            # Add mvk prefix to custom fields (session_id, user_id, client_id, etc.)
            prefixed_key = f"mvk.{key}"
            # Don't override inherited fields with context
            if (
                prefixed_key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]
                and prefixed_key in attrs
            ):
                continue  # Keep inherited value
            # Don't override if already set
            if prefixed_key not in attrs:
                attrs[prefixed_key] = value
                logger.debug(
                    f"Added context attribute {prefixed_key}={value} to span from context key={key}"
                )

    # v1.1: create_signal NOW inherits context parameters by default (handled manually above)
    # User can opt-out of context tag inheritance by passing tags=[]
    # Note: We use inherit_context=False because we manually handle context above
    return tracer.start_span(name, actual_step_type, inherit_context=False, **attrs)
