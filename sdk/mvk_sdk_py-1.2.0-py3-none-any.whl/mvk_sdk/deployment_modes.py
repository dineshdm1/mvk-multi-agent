"""Deployment Mode Management for MVK SDK v1.1.

This module provides clear separation between DIRECT and COLLECTOR deployment modes
as specified in the v1.1 architecture specification.

DIRECT Mode:
- Sends traces directly to Mavvrik platform
- Requires MVK API key and tenant ID
- Uses Mavvrik-specific headers and authentication
- Optimized for Mavvrik platform features

COLLECTOR Mode:
- Sends traces to customer-managed OTEL collector
- No API key required
- Uses standard OTEL headers and protocols
- Compatible with any OTEL-compliant collector
"""

import logging
from enum import Enum
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("mvk.deployment_modes")


class DeploymentMode(str, Enum):
    """Deployment modes supported by MVK SDK v1.1."""

    DIRECT = "DIRECT"  # Send directly to Mavvrik platform
    COLLECTOR = "COLLECTOR"  # Send to customer OTEL collector


class DeploymentModeManager:
    """Manages deployment mode configuration and validation.

    Ensures proper separation between DIRECT and COLLECTOR modes
    with appropriate validation and configuration for each mode.
    """

    def __init__(self, mode: DeploymentMode, config: Dict[str, Any]):
        """Initialize deployment mode manager.

        Args:
            mode: Deployment mode (DIRECT or COLLECTOR)
            config: Configuration dictionary
        """
        self.mode = mode
        self.config = config
        self._validate_mode_configuration()

    def _validate_mode_configuration(self) -> None:
        """Validate configuration based on deployment mode."""
        if self.mode == DeploymentMode.DIRECT:
            self._validate_direct_mode()
        elif self.mode == DeploymentMode.COLLECTOR:
            self._validate_collector_mode()
        else:
            raise ValueError(f"Invalid deployment mode: {self.mode}")

    def _validate_direct_mode(self) -> None:
        """Validate DIRECT mode configuration."""
        # DIRECT mode requires API key
        api_key = self.config.get("api_key")
        if not api_key:
            raise ValueError(
                "api_key is required in DIRECT mode. "
                "Provide via MVK_API_KEY environment variable or config parameter."
            )

        # DIRECT mode requires tenant_id (v1.1 requirement)
        tenant_id = self.config.get("tenant_id")
        if not tenant_id:
            raise ValueError(
                "tenant_id is required in DIRECT mode. "
                "Provide via MVK_TENANT_ID environment variable or config parameter."
            )

        # DIRECT mode requires Mavvrik endpoint
        endpoint = self.config.get("exporter", {}).get("endpoint")
        if not endpoint:
            # Use default Mavvrik endpoint
            self.config.setdefault("exporter", {})["endpoint"] = "https://api.mavvrik.ai/v1/traces"
            logger.info("Using default Mavvrik endpoint for DIRECT mode")

        # Validate endpoint is Mavvrik-compatible
        endpoint = self.config.get("exporter", {}).get("endpoint")
        if not self._is_mavvrik_endpoint(endpoint):
            logger.warning(
                f"Endpoint {endpoint} may not be Mavvrik-compatible in DIRECT mode. "
                "Consider using COLLECTOR mode for custom endpoints."
            )

    def _validate_collector_mode(self) -> None:
        """Validate COLLECTOR mode configuration."""
        # COLLECTOR mode requires collector endpoint
        endpoint = self.config.get("exporter", {}).get("endpoint")
        if not endpoint:
            raise ValueError(
                "exporter.endpoint is required in COLLECTOR mode. "
                "Provide your OTEL collector endpoint."
            )

        # API key not required in COLLECTOR mode
        api_key = self.config.get("api_key")
        if api_key:
            logger.info("API key provided in COLLECTOR mode (will be ignored)")

    def _is_mavvrik_endpoint(self, endpoint: str) -> bool:
        """Check if endpoint is Mavvrik-compatible."""
        if not endpoint:
            return False

        mavvrik_domains = [
            "api.mavvrik.ai",
            "ingest.mavvrik.ai",
            "mavvrik.ai",
        ]

        return any(domain in endpoint for domain in mavvrik_domains)

    def get_exporter_config(self) -> Dict[str, Any]:
        """Get exporter configuration based on deployment mode.

        Returns:
            Exporter configuration optimized for the deployment mode
        """
        if self.mode == DeploymentMode.DIRECT:
            return self._get_direct_exporter_config()
        else:
            return self._get_collector_exporter_config()

    def _get_direct_exporter_config(self) -> Dict[str, Any]:
        """Get exporter configuration for DIRECT mode."""
        exporter_config: Dict[str, Any] = dict(self.config.get("exporter", {}))

        # Set DIRECT mode defaults
        exporter_config.setdefault("type", "otlp_http")
        exporter_config.setdefault("endpoint", "https://api.mavvrik.ai/v1/traces")
        exporter_config.setdefault("timeout", 30)
        exporter_config.setdefault("max_retries", 3)
        exporter_config.setdefault("compression", "gzip")
        exporter_config.setdefault("insecure", False)

        # Add Mavvrik-specific headers
        headers = exporter_config.get("headers", {})
        if not isinstance(headers, dict):
            headers = {}

        # Add authentication headers
        headers["Authorization"] = f"Bearer {self.config['api_key']}"
        headers["X-Tenant-ID"] = self.config.get("tenant_id", "")

        # Add Mavvrik-specific headers
        headers["X-MVK-SDK-Version"] = "1.1.0"
        headers["X-MVK-Agent-ID"] = self.config.get("agent_id", "")

        exporter_config["headers"] = headers

        return exporter_config

    def _get_collector_exporter_config(self) -> Dict[str, Any]:
        """Get exporter configuration for COLLECTOR mode."""
        exporter_config: Dict[str, Any] = dict(self.config.get("exporter", {}))

        # Set COLLECTOR mode defaults
        exporter_config.setdefault("type", "otlp_grpc")
        exporter_config.setdefault("timeout", 30)
        exporter_config.setdefault("max_retries", 3)
        exporter_config.setdefault("compression", "gzip")
        exporter_config.setdefault("insecure", True)  # Default to insecure for local collectors

        # Preserve user-provided headers (don't add Mavvrik-specific ones)
        headers = exporter_config.get("headers", {})
        if headers:
            exporter_config["headers"] = headers

        return exporter_config

    def get_mode_specific_optimizations(self) -> Dict[str, Any]:
        """Get optimizations specific to the deployment mode.

        Returns:
            Configuration optimizations for the deployment mode
        """
        if self.mode == DeploymentMode.DIRECT:
            return self._get_direct_optimizations()
        else:
            return self._get_collector_optimizations()

    def _get_direct_optimizations(self) -> Dict[str, Any]:
        """Get optimizations for DIRECT mode."""
        return {
            "batching": {
                "max_items": 2000,
                "max_bytes": 2097152,  # 2 MiB
                "max_interval_ms": 3000,
            },
            "exporter": {
                "timeout": 30,
                "max_retries": 3,
                "compression": "gzip",
            },
            "failed_batch_disk": {
                "enabled": True,  # Enable for better reliability
            },
        }

    def _get_collector_optimizations(self) -> Dict[str, Any]:
        """Get optimizations for COLLECTOR mode."""
        return {
            "batching": {
                "max_items": 1000,  # Smaller batches for collector
                "max_bytes": 1048576,  # 1 MiB
                "max_interval_ms": 5000,  # Longer intervals
            },
            "exporter": {
                "timeout": 60,  # Longer timeout for collector
                "max_retries": 5,  # More retries for collector
                "compression": "gzip",
            },
            "failed_batch_disk": {
                "enabled": True,  # Enable for better reliability
            },
        }

    def get_validation_rules(self) -> Dict[str, Any]:
        """Get validation rules specific to the deployment mode.

        Returns:
            Validation rules for the deployment mode
        """
        if self.mode == DeploymentMode.DIRECT:
            return {
                "required_fields": ["api_key", "tenant_id"],
                "optional_fields": ["exporter.endpoint"],
                "forbidden_fields": [],
            }
        else:
            return {
                "required_fields": ["exporter.endpoint"],
                "optional_fields": ["exporter.type", "exporter.headers"],
                "forbidden_fields": ["api_key"],  # API key not used in COLLECTOR mode
            }

    def is_mode_compatible(self, feature: str) -> bool:
        """Check if a feature is compatible with the current deployment mode.

        Args:
            feature: Feature name to check

        Returns:
            True if feature is compatible with current mode
        """
        if self.mode == DeploymentMode.DIRECT:
            return feature in [
                "mavvrik_analytics",
                "mavvrik_dashboards",
                "mavvrik_alerts",
                "agent_insights",
                "cost_tracking",
            ]
        else:
            return feature in [
                "standard_otel",
                "custom_collector",
                "grafana_integration",
                "prometheus_integration",
                "jaeger_integration",
            ]

    def get_mode_info(self) -> Dict[str, Any]:
        """Get information about the current deployment mode.

        Returns:
            Mode information dictionary
        """
        return {
            "mode": self.mode.value,
            "description": self._get_mode_description(),
            "features": self._get_mode_features(),
            "requirements": self._get_mode_requirements(),
            "limitations": self._get_mode_limitations(),
        }

    def _get_mode_description(self) -> str:
        """Get description of the current mode."""
        if self.mode == DeploymentMode.DIRECT:
            return "Sends traces directly to Mavvrik platform for analytics and insights"
        else:
            return "Sends traces to customer-managed OTEL collector for custom processing"

    def _get_mode_features(self) -> list[str]:
        """Get features available in the current mode."""
        if self.mode == DeploymentMode.DIRECT:
            return [
                "Real-time analytics",
                "Cost tracking",
                "Agent insights",
                "Performance monitoring",
                "Alert management",
                "Dashboard visualization",
            ]
        else:
            return [
                "Standard OTEL compliance",
                "Custom collector integration",
                "Flexible data processing",
                "Multi-vendor compatibility",
                "Custom alerting",
                "Custom dashboards",
            ]

    def _get_mode_requirements(self) -> list[str]:
        """Get requirements for the current mode."""
        if self.mode == DeploymentMode.DIRECT:
            return [
                "MVK API key",
                "Tenant ID",
                "Internet connectivity to Mavvrik",
                "Valid Mavvrik account",
            ]
        else:
            return [
                "OTEL collector endpoint",
                "Network access to collector",
                "OTEL-compatible collector",
            ]

    def _get_mode_limitations(self) -> list[str]:
        """Get limitations of the current mode."""
        if self.mode == DeploymentMode.DIRECT:
            return [
                "Requires Mavvrik platform",
                "Data processed by Mavvrik",
                "Limited customization",
            ]
        else:
            return [
                "No Mavvrik analytics",
                "No built-in dashboards",
                "Requires custom setup",
            ]


def create_deployment_mode_manager(config: Dict[str, Any]) -> DeploymentModeManager:
    """Create deployment mode manager from configuration.

    Args:
        config: Configuration dictionary

    Returns:
        DeploymentModeManager instance

    Raises:
        ValueError: If deployment mode is invalid or configuration is incomplete
    """
    # Determine deployment mode - check both top-level and exporter.mode
    mode_str = config.get("mode") or config.get("exporter", {}).get("mode", "DIRECT")

    try:
        mode = DeploymentMode(mode_str.upper())
    except ValueError:
        raise ValueError(f"Invalid deployment mode: {mode_str}. Must be DIRECT or COLLECTOR")

    return DeploymentModeManager(mode, config)


def validate_deployment_mode_config(config: Dict[str, Any]) -> Tuple[bool, list[str]]:
    """Validate deployment mode configuration.

    Args:
        config: Configuration dictionary

    Returns:
        Tuple of (is_valid, list_of_issues)
    """
    try:
        manager = create_deployment_mode_manager(config)
        return True, []
    except ValueError as e:
        return False, [str(e)]
    except Exception as e:
        return False, [f"Unexpected error: {str(e)}"]


def get_deployment_mode_info(mode: DeploymentMode) -> Dict[str, Any]:
    """Get information about a deployment mode.

    Args:
        mode: Deployment mode

    Returns:
        Mode information dictionary
    """
    # Create a minimal config for the mode
    config = {"exporter": {"mode": mode.value}}
    manager = DeploymentModeManager(mode, config)
    return manager.get_mode_info()
