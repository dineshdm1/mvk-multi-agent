"""Common logging utilities for MVK SDK wrappers.

Provides standardized logging functions for all wrapper implementations.
"""

import json
import time
from typing import Any, Dict, Optional

from .wrapper_logging import get_wrapper_logger


def _format_context(context: Dict[str, Any]) -> str:
    """Format context dictionary as key=value pairs."""
    return " ".join(f"{k}={v}" for k, v in context.items())


def log_request_start(
    wrapper_name: str,
    operation: str,
    model: Optional[str] = None,
    request_id: Optional[str] = None,
    **kwargs,
) -> None:
    """Log the start of a request operation.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        model: Model being used (optional)
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {"operation": operation, "timestamp": time.time()}

    if model:
        context["model"] = model
    if request_id:
        context["request_id"] = request_id

    # Add any additional context
    context.update(kwargs)

    logger.info(f"Request started | {_format_context(context)}")


def log_request_end(
    wrapper_name: str,
    operation: str,
    duration_ms: float,
    success: bool = True,
    model: Optional[str] = None,
    request_id: Optional[str] = None,
    **kwargs,
) -> None:
    """Log the end of a request operation.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        duration_ms: Request duration in milliseconds
        success: Whether the request was successful
        model: Model being used (optional)
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {
        "operation": operation,
        "duration_ms": duration_ms,
        "success": success,
        "timestamp": time.time(),
    }

    if model:
        context["model"] = model
    if request_id:
        context["request_id"] = request_id

    # Add any additional context
    context.update(kwargs)

    status = "completed" if success else "failed"
    logger.info(f"Request {status} | {_format_context(context)}")


def log_request_body(
    wrapper_name: str, operation: str, request_data: Any, request_id: Optional[str] = None, **kwargs
) -> None:
    """Log request body for debugging.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        request_data: Request data to log
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {"operation": operation, "timestamp": time.time()}

    if request_id:
        context["request_id"] = request_id

    # Add any additional context
    context.update(kwargs)

    # Safely serialize request data
    try:
        if hasattr(request_data, "model_dump"):
            # Pydantic model
            serialized_data = request_data.model_dump()
        elif hasattr(request_data, "dict"):
            # Pydantic v1 model
            serialized_data = request_data.dict()
        elif isinstance(request_data, dict):
            serialized_data = request_data
        else:
            serialized_data = str(request_data)

        # Truncate very large payloads
        data_str = json.dumps(serialized_data, default=str)
        if len(data_str) > 1000:
            data_str = data_str[:1000] + "... [truncated]"

        context["request_body"] = data_str

    except Exception as e:
        context["request_body"] = f"[Error serializing request: {e}]"

    logger.debug(f"Request body | {_format_context(context)}")


def log_response_body(
    wrapper_name: str,
    operation: str,
    response_data: Any,
    request_id: Optional[str] = None,
    **kwargs,
) -> None:
    """Log response body for debugging.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        response_data: Response data to log
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {"operation": operation, "timestamp": time.time()}

    if request_id:
        context["request_id"] = request_id

    # Add any additional context
    context.update(kwargs)

    # Safely serialize response data
    try:
        if hasattr(response_data, "model_dump"):
            # Pydantic model
            serialized_data = response_data.model_dump()
        elif hasattr(response_data, "dict"):
            # Pydantic v1 model
            serialized_data = response_data.dict()
        elif isinstance(response_data, dict):
            serialized_data = response_data
        else:
            serialized_data = str(response_data)

        # Truncate very large payloads
        data_str = json.dumps(serialized_data, default=str)
        if len(data_str) > 1000:
            data_str = data_str[:1000] + "... [truncated]"

        context["response_body"] = data_str

    except Exception as e:
        context["response_body"] = f"[Error serializing response: {e}]"

    logger.debug(f"Response body | {_format_context(context)}")


def log_error(
    wrapper_name: str, operation: str, error: Exception, request_id: Optional[str] = None, **kwargs
) -> None:
    """Log an error that occurred during request processing.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        error: Exception that occurred
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {
        "operation": operation,
        "error_type": type(error).__name__,
        "error_message": str(error),
        "timestamp": time.time(),
    }

    if request_id:
        context["request_id"] = request_id

    # Add any additional context
    context.update(kwargs)

    logger.info(f"Request failed | {_format_context(context)}")


def log_metrics(
    wrapper_name: str,
    operation: str,
    metrics: Dict[str, Any],
    request_id: Optional[str] = None,
    **kwargs,
) -> None:
    """Log metrics for a request.

    Args:
        wrapper_name: Name of the wrapper (e.g., 'openai', 'anthropic')
        operation: Operation being performed (e.g., 'chat_completion', 'embedding')
        metrics: Dictionary of metrics to log
        request_id: Unique request identifier (optional)
        **kwargs: Additional context to log
    """
    logger = get_wrapper_logger(wrapper_name)

    context = {"operation": operation, "timestamp": time.time()}

    if request_id:
        context["request_id"] = request_id

    # Add metrics to context
    context.update(metrics)

    # Add any additional context
    context.update(kwargs)

    logger.info(f"Request metrics | {_format_context(context)}")
