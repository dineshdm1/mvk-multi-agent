"""Logger level configuration for MVK SDK v1.1.

Provides configurable logging for SDK components with component-specific levels.
Logging is disabled by default and can be enabled via configuration or environment variables.
"""

import logging
import os
from typing import Any, Dict, Optional, Set


class LoggerLevelConfig:
    """Configuration manager for component-specific logging levels."""

    def __init__(self) -> None:
        self._enabled_levels: Dict[str, Set[str]] = {}
        self._configured: bool = False
        # When true, all MVK logs must be fully suppressed
        self._off: bool = False

    def configure(self, config: Optional[Dict] = None) -> None:
        """Configure logger levels from config and environment variables.

        Args:
            config: Optional configuration dict from mvk.instrument()
        """
        enabled_levels: Dict[str, Any] = {}
        log_level = None

        # Check config first (takes precedence)
        # Support new flattened structure: logging.level (from function parameters)
        if config and "logging" in config and isinstance(config["logging"], dict):
            log_level = config["logging"].get("level")
        elif config and ("log_level" in config or "logger_level" in config):
            # Support both new log_level and old logger_level for backward compatibility
            log_level = config.get("log_level") or config.get("logger_level")

        # Fallback: Check environment variable if not in config
        # This is needed because configure_logger_levels() can be called independently
        # of instrument(), so we need this fallback for backward compatibility
        if not log_level:
            log_level = os.getenv("MVK_LOG_LEVEL")

        # Apply global log level to all components
        if log_level:
            level_upper = str(log_level).upper()
            if level_upper in {"OFF", "NONE", "DISABLE", "DISABLED", "0"}:
                # Explicitly disable all MVK logs
                enabled_levels = {}
                self._off = True
                # Hard-disable our logger trees to avoid leaking via root handlers
                try:
                    mvk_logger = logging.getLogger("mvk")
                    mvk_logger.setLevel(logging.CRITICAL)
                    mvk_logger.propagate = False
                    mvk_logger.disabled = True
                    if not mvk_logger.handlers:
                        mvk_logger.addHandler(logging.NullHandler())
                except Exception as e:
                    # Cannot use logger here as it might be the logger we're trying to configure
                    import sys

                    print(f"WARNING: Failed to disable mvk logger: {e}", file=sys.stderr)
                    pass
                try:
                    sdk_logger = logging.getLogger("mvk_sdk")
                    sdk_logger.setLevel(logging.CRITICAL)
                    sdk_logger.propagate = False
                    sdk_logger.disabled = True
                    if not sdk_logger.handlers:
                        sdk_logger.addHandler(logging.NullHandler())
                except Exception as e:
                    # Cannot use logger here as it might be the logger we're trying to configure
                    import sys

                    print(f"WARNING: Failed to disable mvk_sdk logger: {e}", file=sys.stderr)
                    pass
            elif level_upper == "DEBUG":
                # DEBUG level automatically enables INFO level
                enabled_levels = {
                    "wrappers": {"DEBUG", "INFO"},
                    "exporters": {"DEBUG", "INFO"},
                    "processors": {"DEBUG", "INFO"},
                    "core": {"DEBUG", "INFO"},
                    "instrumentation": {"DEBUG", "INFO"},
                }
                self._off = False
                # Re-enable parent loggers if previously disabled
                try:
                    for parent_name in ("mvk", "mvk_sdk"):
                        parent_logger = logging.getLogger(parent_name)
                        parent_logger.disabled = False
                        parent_logger.propagate = True
                except Exception as e:
                    # Cannot use logger here as it might be the logger we're trying to configure
                    import sys

                    print(
                        f"WARNING: Failed to re-enable parent loggers for DEBUG: {e}",
                        file=sys.stderr,
                    )
                    pass
            elif level_upper == "INFO":
                enabled_levels = {
                    "wrappers": {"INFO"},
                    "exporters": {"INFO"},
                    "processors": {"INFO"},
                    "core": {"INFO"},
                    "instrumentation": {"INFO"},
                }
                self._off = False
                # Re-enable parent loggers if previously disabled
                try:
                    for parent_name in ("mvk", "mvk_sdk"):
                        parent_logger = logging.getLogger(parent_name)
                        parent_logger.disabled = False
                        parent_logger.propagate = True
                except Exception as e:
                    # Cannot use logger here as it might be the logger we're trying to configure
                    import sys

                    print(
                        f"WARNING: Failed to re-enable parent loggers for INFO: {e}",
                        file=sys.stderr,
                    )
                    pass
        else:
            # No log level provided means logging remains at defaults
            self._off = False

        self._enabled_levels = enabled_levels
        self._configured = True

        # Auto-configure Python logging if any logging is enabled
        if enabled_levels:
            self._auto_configure_python_logging()

    def get_enabled_levels(self, component: str) -> Set[str]:
        """Get currently enabled log levels for a specific component.

        Args:
            component: Component name (e.g., 'wrappers', 'exporters')

        Returns:
            Set of enabled log levels for the component
        """
        return self._enabled_levels.get(component, set()).copy()

    def is_enabled(self, component: str, level: str) -> bool:
        """Check if a specific log level is enabled for a component.

        Args:
            component: Component name (e.g., 'wrappers', 'exporters')
            level: Log level to check ('INFO', 'DEBUG')

        Returns:
            True if level is enabled for the component
        """
        return level in self._enabled_levels.get(component, set())

    def is_configured(self) -> bool:
        """Check if logging has been configured.

        Returns:
            True if configured
        """
        return self._configured

    def _auto_configure_python_logging(self) -> None:
        """Auto-configure Python logging for component logs.

        This method sets up Python logging to display component logs without
        requiring clients to manually configure logging.
        """
        # Check if logging is already configured
        root_logger = logging.getLogger()
        if root_logger.handlers:
            # Logging is already configured, just set the component logger levels
            for component, levels in self._enabled_levels.items():
                component_logger = logging.getLogger(f"mvk.{component}")
                if "DEBUG" in levels:
                    component_logger.setLevel(logging.DEBUG)
                elif "INFO" in levels:
                    component_logger.setLevel(logging.INFO)
            return

        # Auto-configure basic logging for component logs
        # Determine the most verbose level across all components
        max_level = logging.WARNING  # Default
        for levels in self._enabled_levels.values():
            if "DEBUG" in levels:
                max_level = logging.DEBUG
                break
            elif "INFO" in levels:
                max_level = logging.INFO

        if max_level == logging.WARNING:
            return

        # Configure basic logging
        logging.basicConfig(
            level=max_level,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            force=True,  # Override existing configuration
        )

        # Set component logger levels specifically
        for component, levels in self._enabled_levels.items():
            component_logger = logging.getLogger(f"mvk.{component}")
            if "DEBUG" in levels:
                component_logger.setLevel(logging.DEBUG)
            elif "INFO" in levels:
                component_logger.setLevel(logging.INFO)


# Global configuration instance
_logger_level_config = LoggerLevelConfig()


def _update_existing_loggers() -> None:
    """Update existing logger levels based on current configuration."""
    # Get all existing loggers that match our pattern
    for logger_name in list(logging.Logger.manager.loggerDict.keys()):
        if logger_name.startswith("mvk."):
            # Extract component from logger name (mvk.component.name)
            parts = logger_name.split(".")
            if len(parts) >= 3:  # mvk.component.name
                component = parts[1]
                logger = logging.getLogger(logger_name)

                # Set logger level based on configuration
                if getattr(_logger_level_config, "_off", False):
                    logger.setLevel(logging.CRITICAL)
                    logger.propagate = False
                    logger.disabled = True
                    if not logger.handlers:
                        logger.addHandler(logging.NullHandler())
                else:
                    enabled_levels = _logger_level_config.get_enabled_levels(component)
                    if "DEBUG" in enabled_levels:
                        logger.setLevel(logging.DEBUG)
                    elif "INFO" in enabled_levels:
                        logger.setLevel(logging.INFO)
                    else:
                        logger.setLevel(logging.WARNING)
                    # Ensure logger is active after being previously disabled
                    logger.disabled = False
                    logger.propagate = True


def configure_logger_levels(config: Optional[Dict] = None) -> None:
    """Configure logger levels globally.

    Args:
        config: Optional configuration dict from mvk.instrument()
    """
    _logger_level_config.configure(config)

    # Update existing loggers with new configuration
    _update_existing_loggers()


def get_component_logger(component: str, name: str) -> logging.Logger:
    """Get a configured logger for a specific component.

    Args:
        component: Component name (e.g., 'wrappers', 'exporters')
        name: Logger name (typically __name__ from the component)

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(f"mvk.{component}.{name}")

    # Set logger level based on configuration
    if getattr(_logger_level_config, "_off", False):
        logger.setLevel(logging.CRITICAL)
        logger.propagate = False
        logger.disabled = True
        if not logger.handlers:
            logger.addHandler(logging.NullHandler())
    else:
        enabled_levels = _logger_level_config.get_enabled_levels(component)
        if "DEBUG" in enabled_levels:
            logger.setLevel(logging.DEBUG)
        elif "INFO" in enabled_levels:
            logger.setLevel(logging.INFO)
        else:
            logger.setLevel(logging.WARNING)
        # Ensure logger is not globally disabled from previous OFF state
        logger.disabled = False
        logger.propagate = True

    return logger


def is_logger_level_enabled(component: str, level: str) -> bool:
    """Check if logger level is enabled for a specific component.

    Args:
        component: Component name (e.g., 'wrappers', 'exporters')
        level: Log level to check ('INFO', 'DEBUG')

    Returns:
        True if level is enabled for the component
    """
    return _logger_level_config.is_enabled(component, level)


# Backward compatibility functions
def configure_wrapper_logging(config: Optional[Dict] = None) -> None:
    """Configure wrapper logging (backward compatibility).

    Args:
        config: Optional configuration dict from mvk.instrument()
    """
    # Handle new nested logging structure
    if config and "logging" in config and isinstance(config["logging"], dict):
        configure_logger_levels(config)
        return

    # Convert old wrapper_logging config to new log_level format
    if config and "wrapper_logging" in config:
        wrapper_config = config["wrapper_logging"]
        log_level = wrapper_config.get("log_level", "").upper()

        if log_level in ["INFO", "DEBUG"]:
            # Convert to new format
            new_config = {"logging": {"level": log_level, "log_response": ""}}
            configure_logger_levels(new_config)
            return

    # Check for wrapper_log_level in config (from MVK_WRAPPER_LOG_LEVEL via registry)
    if config and "logging" in config and isinstance(config["logging"], dict):
        wrapper_level = config["logging"].get("wrapper_level", "").upper()
        if wrapper_level in ["INFO", "DEBUG"]:
            new_config = {"logging": {"level": wrapper_level, "log_response": ""}}
            configure_logger_levels(new_config)
            return

    # Fallback: Check environment variable for backward compatibility
    # This is needed because configure_wrapper_logging() can be called independently
    log_level_env = os.getenv("MVK_WRAPPER_LOG_LEVEL", "").upper()
    if log_level_env in ["INFO", "DEBUG"]:
        new_config = {"logging": {"level": log_level_env, "log_response": ""}}
        configure_logger_levels(new_config)


def get_wrapper_logger(name: str) -> logging.Logger:
    """Get a wrapper logger (backward compatibility).

    Args:
        name: Logger name (typically __name__ from wrapper)

    Returns:
        Configured logger instance
    """
    return get_component_logger("wrappers", name)


def is_wrapper_logging_enabled(level: str) -> bool:
    """Check if wrapper logging is enabled for a specific level (backward compatibility).

    Args:
        level: Log level to check ('INFO', 'DEBUG')

    Returns:
        True if level is enabled
    """
    return is_logger_level_enabled("wrappers", level)
