"""Context management for MVK SDK v1.1.

Implements the 4-level context precedence:
1. Global (from instrument)
2. Decorator (@mvk_context)
3. Context manager (with mvk_context)
4. Headers (x-mvk-*)

v3.0 Inheritance Rules:
- Tags inherit from @mvk_context, NOT from @mvk_signal
- Session ID and mvk_agent_name inherit between nested @mvk_signal
- Other fields do NOT inherit between @mvk_signal spans
"""

import logging
from contextvars import ContextVar
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Context variables for different levels
_global_context: Dict[str, Any] = {}
_context_stack: ContextVar[list] = ContextVar("mvk_context_stack", default=[])
_header_context: ContextVar[Optional[Dict[str, Any]]] = ContextVar(
    "mvk_header_context", default=None
)
# Separate context var for trace_id (internal, not exposed to users)
_trace_id_context: ContextVar[Optional[str]] = ContextVar("mvk_trace_id", default=None)


def set_global_context(context: Dict[str, Any]) -> None:
    """Set global context from instrument() call.

    Args:
        context: Global context attributes
    """
    global _global_context
    _global_context.clear()
    _global_context.update(context)


def push_context(attributes: Dict[str, Any]) -> None:
    """Push context attributes onto the stack.

    Used by both @mvk_context decorator and with mvk_context manager.

    Args:
        attributes: Context attributes to push
    """
    stack = _context_stack.get()
    new_stack = stack + [attributes]
    _context_stack.set(new_stack)


def pop_context() -> None:
    """Pop the most recent context from the stack."""
    stack = _context_stack.get()
    if stack:
        new_stack = stack[:-1]
        _context_stack.set(new_stack)
    else:
        logger.warning("Attempted to pop from empty context stack")


def set_header_context(headers: Dict[str, str]) -> None:
    """Set context from HTTP headers (x-mvk-* pattern).

    Args:
        headers: HTTP headers dict
    """
    mvk_headers = {}
    for key, value in headers.items():
        if key.lower().startswith("x-mvk-"):
            # Extract attribute name from header
            attr_name = key[6:].lower().replace("-", "_")
            mvk_headers[attr_name] = value

    if mvk_headers:
        _header_context.set(mvk_headers)


def clear_header_context() -> None:
    """Clear header context after request."""
    _header_context.set(None)


def get_merged_context() -> Dict[str, Any]:
    """Get merged context following precedence rules.

    Precedence (latest wins):
    1. Global (lowest)
    2. Decorator/Context manager stack
    3. Headers (highest)

    Returns:
        Merged context dictionary
    """
    # Start with global context
    merged = _global_context.copy()

    # Apply context stack (decorator and context manager)
    # Special handling for tags: merge tag dicts instead of replacing
    # Exception: empty dict {} clears all inherited tags
    stack = _context_stack.get()
    for context in stack:
        for key, value in context.items():
            if key == "tags" and isinstance(value, dict):
                if len(value) == 0:
                    # Empty dict clears all inherited tags
                    merged["tags"] = {}
                else:
                    # Merge tags dict instead of replacing
                    if "tags" not in merged:
                        merged["tags"] = {}
                    if isinstance(merged["tags"], dict):
                        merged["tags"].update(value)
                    else:
                        merged["tags"] = value
            else:
                merged[key] = value

    # Apply header context (highest precedence)
    # Special handling for tags here too
    # Exception: empty dict {} clears all inherited tags
    header_ctx = _header_context.get()
    if header_ctx:
        for key, value in header_ctx.items():
            if key == "tags" and isinstance(value, dict):
                if len(value) == 0:
                    # Empty dict clears all inherited tags
                    merged["tags"] = {}
                else:
                    # Merge tags dict instead of replacing
                    if "tags" not in merged:
                        merged["tags"] = {}
                    if isinstance(merged["tags"], dict):
                        merged["tags"].update(value)
                    else:
                        merged["tags"] = value
            else:
                merged[key] = value

    return merged


def get_context_at_level(level: str) -> Dict[str, Any]:
    """Get context at a specific level for debugging.

    Args:
        level: One of 'global', 'stack', 'headers'

    Returns:
        Context at that level
    """
    if level == "global":
        return _global_context.copy()
    elif level == "stack":
        stack = _context_stack.get()
        merged: Dict[str, Any] = {}
        for context in stack:
            for key, value in context.items():
                if key == "tags" and isinstance(value, dict):
                    if len(value) == 0:
                        # Empty dict clears all inherited tags
                        merged["tags"] = {}
                    else:
                        # Merge tags dict instead of replacing
                        if "tags" not in merged:
                            merged["tags"] = {}
                        if isinstance(merged["tags"], dict):
                            merged["tags"].update(value)
                        else:
                            merged["tags"] = value
                else:
                    merged[key] = value
        return merged
    elif level == "headers":
        return _header_context.get() or {}
    else:
        raise ValueError(f"Unknown context level: {level}")


def get_current_context() -> Dict[str, Any]:
    """Get the current merged context (alias for get_merged_context).

    Returns:
        Merged context dictionary
    """
    return get_merged_context()


def get_global_context() -> Dict[str, Any]:
    """Get the global context.

    Returns:
        Global context dictionary
    """
    return _global_context.copy()


def clear_context_stack() -> None:
    """Clear the context stack (for testing)."""
    _context_stack.set([])


def set_trace_id(trace_id: str) -> None:
    """Set the current trace ID for this context.

    This is used internally to track trace IDs across operations
    without polluting the user-visible context.

    Args:
        trace_id: The trace ID to set
    """
    _trace_id_context.set(trace_id)


def get_trace_id() -> Optional[str]:
    """Get the current trace ID from context.

    Returns:
        The current trace ID if set, None otherwise
    """
    return _trace_id_context.get()


def clear_trace_id() -> None:
    """Clear the trace ID from context."""
    _trace_id_context.set(None)
