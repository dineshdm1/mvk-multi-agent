"""Single Writer Thread Architecture for MVK SDK v1.0.

This module implements a deadlock-proof single writer thread that handles
all span processing with fixed batching thresholds.
"""

import json
import logging
import queue
import random
import threading
import time
from typing import Any, Dict, List, Optional

from ..exporters.base import SpanExporter
from ..wrapper_logging import get_component_logger
from .base import SpanProcessor

logger = get_component_logger("processors", "writer")


class Writer(SpanProcessor):
    """Single writer thread with configurable batching for v3.0.

    Features:
    - Memory-bounded queue to prevent OOM (default 10MB)
    - Configurable batching: defaults to 2000 items / 2MiB / 3 seconds
    - Exponential backoff retry for failed batches
    - Optional FailedBatchDisk for persistent retry
    - Graceful shutdown with drain
    """

    # Default batching thresholds (configurable in v3.0)
    DEFAULT_MAX_ITEMS = 2000
    DEFAULT_MAX_BYTES = 2_097_152  # 2 MiB
    DEFAULT_MAX_INTERVAL_MS = 3000  # 3 seconds

    # Memory protection: ~10MB default (10,000 spans * ~1KB per span)
    DEFAULT_MAX_QUEUE_SIZE = 10_000

    # Retry configuration
    MAX_RETRY_ATTEMPTS = 10
    INITIAL_BACKOFF = 1.0  # 1 second
    MAX_BACKOFF = 300  # 5 minutes

    def __init__(
        self,
        exporter: SpanExporter,
        failed_batch_disk: Optional[Any] = None,  # Will be FailedBatchDisk
        max_queue_size: int = DEFAULT_MAX_QUEUE_SIZE,
        shutdown_timeout: float = 5.0,
        max_items: int = DEFAULT_MAX_ITEMS,
        max_bytes: int = DEFAULT_MAX_BYTES,
        max_interval_ms: int = DEFAULT_MAX_INTERVAL_MS,
    ):
        """Initialize the single writer.

        Args:
            exporter: The exporter to send batches to
            failed_batch_disk: Optional FailedBatchDisk for persistent retry
            max_queue_size: Maximum queue size to prevent OOM (default 10,000 spans)
            shutdown_timeout: Maximum time to wait for shutdown
            max_items: Maximum items per batch (default 2000)
            max_bytes: Maximum bytes per batch (default 2 MiB)
            max_interval_ms: Maximum interval between batches in ms (default 3000ms)
        """
        super().__init__()
        self.exporter = exporter
        self.failed_batch_disk = failed_batch_disk
        self.max_queue_size = max_queue_size
        self.shutdown_timeout = shutdown_timeout

        # Store batching thresholds as instance variables
        self.max_items = max_items
        self.max_bytes = max_bytes
        self.max_interval_ms = max_interval_ms

        # Use bounded Queue to prevent OOM
        self.queue: queue.Queue = queue.Queue(maxsize=max_queue_size)

        # Thread control
        self.running = False
        self.thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()

        # Batch state
        self.current_batch: List[Dict[str, Any]] = []
        self.current_batch_size = 0
        self.last_flush_time = time.monotonic()

        # Stats
        self.spans_processed = 0
        self.batches_sent = 0
        self.spans_dropped = 0
        self.spans_dropped_queue_full = 0  # Track queue full drops specifically
        self.queue_high_water_mark = 0  # Track max queue size seen
        self.drop_on_full = True  # Always drop when queue full (non-blocking)
        self._warned_at_80_percent = False  # Track if we've already warned at 80%

    def start(self) -> None:
        """Start the writer thread."""
        if self.running:
            logger.warning("Writer already running")
            return

        self.running = True
        self._shutdown_event.clear()
        self.thread = threading.Thread(target=self._run, name="mvk-writer")
        self.thread.daemon = False  # Don't be a daemon to allow graceful shutdown
        self.thread.start()
        logger.info("Writer thread started")

    def stop(self) -> None:
        """Stop the writer thread gracefully."""
        if not self.running:
            return

        logger.info("Stopping writer thread...")
        self.running = False
        self._shutdown_event.set()

        # Send sentinel to wake up thread if blocked on queue.get()
        self.queue.put(None)

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=self.shutdown_timeout)
            if self.thread.is_alive():
                logger.warning(f"Writer thread did not stop within {self.shutdown_timeout}s")

        # Final flush of any remaining spans
        if self.current_batch:
            self._flush_batch()

        logger.info(
            f"Writer stopped. Processed {self.spans_processed} spans in {self.batches_sent} batches"
        )

    def process(self, span: Dict[str, Any]) -> None:
        """Process a span by adding to queue (lock-free).

        Memory-First Mode Design:
        - Memory queue handles all spans
        - Writer thread retries with exponential backoff
        - Failed batches saved to FailedBatchDisk (if available)
        - No producer blocking

        Args:
            span: The span to process
        """
        if not self.running:
            logger.debug("Writer not running, dropping span")
            self.spans_dropped += 1
            return

        # Always add to memory queue for batching
        # Memory-first approach for optimal performance
        try:
            # Try non-blocking put to avoid producer blocking
            self.queue.put_nowait(span)
            # Track high water mark
            current_size = self.queue.qsize()
            if current_size > self.queue_high_water_mark:
                self.queue_high_water_mark = current_size

            # Warn when queue reaches 80% capacity (only once)
            if current_size >= int(self.max_queue_size * 0.8) and not self._warned_at_80_percent:
                logger.warning(
                    f"Queue at {current_size}/{self.max_queue_size} spans ({(current_size/self.max_queue_size)*100:.1f}% full)"
                )
                self._warned_at_80_percent = True
            elif current_size < int(self.max_queue_size * 0.8):
                # Reset warning flag when queue drops below 80%
                self._warned_at_80_percent = False
        except queue.Full:
            # Queue is full - drop span
            logger.warning(f"Queue full ({self.max_queue_size} spans), dropping span")
            self.spans_dropped += 1
            self.spans_dropped_queue_full += 1
        except Exception as e:
            logger.error(f"Failed to enqueue span: {e}")
            self.spans_dropped += 1

    # SpanProcessor interface methods
    def on_start(self, span: Any) -> None:
        """Called when a span starts. No-op for Writer."""
        pass

    def on_end(self, span_dict: Dict[str, Any]) -> None:
        """Called when a span ends. Queues the span for export."""
        self.process(span_dict)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force export of all pending spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds

        Returns:
            True if all spans were exported within timeout
        """
        if not self.running:
            return True

        start_time = time.time()
        timeout_sec = timeout_millis / 1000.0

        # Wait for queue to empty
        while not self.queue.empty():
            if time.time() - start_time > timeout_sec:
                return False
            time.sleep(0.01)

        # Force flush current batch
        if self.current_batch:
            self._flush_batch()

        return True

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor and export remaining spans.

        Args:
            timeout_millis: Maximum time to wait in milliseconds
        """
        self.shutdown_timeout = timeout_millis / 1000.0
        self.stop()

    def _run(self) -> None:
        """Main writer thread loop."""
        logger.debug("Writer thread running")

        while self.running or not self.queue.empty():
            try:
                # Calculate timeout based on last flush
                elapsed_ms = (time.monotonic() - self.last_flush_time) * 1000
                remaining_ms = max(0, self.max_interval_ms - elapsed_ms)
                timeout = remaining_ms / 1000.0 if remaining_ms > 0 else 0

                # Try to get span with timeout
                try:
                    span = self.queue.get(timeout=timeout if timeout > 0 else 0.001)
                except queue.Empty:
                    # Timeout reached, check if we need to flush
                    if self.current_batch and self._should_flush_time():
                        self._flush_batch()
                    continue

                # Check for shutdown sentinel
                if span is None:
                    logger.debug("Received shutdown sentinel")
                    break

                # Add span to batch
                self._add_to_batch(span)

                # Check if batch should be flushed
                if self._should_flush():
                    self._flush_batch()

                else:
                    # If queue is near capacity, flush early to avoid draining producer headroom.
                    # This helps maintain backpressure and ensures drops occur under sustained overload.
                    try:
                        if self.queue.qsize() >= int(self.max_queue_size * 0.8):
                            self._flush_batch()
                    except Exception as e:  # pylint: disable=broad-except
                        # Best effort flush on timeout - don't propagate errors
                        logger.debug(f"Best-effort flush failed on timeout: {e}", exc_info=True)
                        pass

            except Exception as e:
                logger.error(f"Error in writer thread: {e}", exc_info=True)

        # Final flush on exit
        if self.current_batch:
            self._flush_batch()

        logger.debug("Writer thread exiting")

    def _add_to_batch(self, span: Dict[str, Any]) -> None:
        """Add span to current batch with size tracking.

        Args:
            span: The span to add
        """
        # Estimate size (simplified - actual implementation would use proper serialization)
        span_size = len(str(span))

        # If single span exceeds max size, send it alone
        if span_size > self.max_bytes:
            logger.warning(f"Single span exceeds max batch size ({span_size} bytes)")
            if self.current_batch:
                self._flush_batch()
            self._send_batch([span])
            return

        # If adding would exceed limits, flush first
        if self.current_batch and (
            len(self.current_batch) >= self.max_items
            or self.current_batch_size + span_size > self.max_bytes
        ):
            self._flush_batch()

        # Add to batch
        self.current_batch.append(span)
        self.current_batch_size += span_size
        self.spans_processed += 1

    def _should_flush(self) -> bool:
        """Check if batch should be flushed based on fixed thresholds.

        Returns:
            True if batch should be flushed
        """
        if not self.current_batch:
            return False

        # Check item count
        if len(self.current_batch) >= self.max_items:
            return True

        # Check size
        if self.current_batch_size >= self.max_bytes:
            return True

        # Check time
        if self._should_flush_time():
            return True

        return False

    def _should_flush_time(self) -> bool:
        """Check if batch should be flushed based on time.

        Returns:
            True if max_interval_ms has elapsed
        """
        elapsed_ms = (time.monotonic() - self.last_flush_time) * 1000
        return elapsed_ms >= self.max_interval_ms

    def _flush_batch(self) -> None:
        """Flush current batch to exporter."""
        if not self.current_batch:
            return

        batch = self.current_batch
        self.current_batch = []
        self.current_batch_size = 0
        self.last_flush_time = time.monotonic()

        self._send_batch(batch)

    def _send_batch(self, batch: List[Dict[str, Any]]) -> None:
        """Send batch to exporter with exponential backoff retry.

        Args:
            batch: The batch to send
        """
        last_error = None

        # Generate batch metadata for OTEL compliance
        import datetime
        import uuid

        batch_metadata = {
            "batch.id": str(uuid.uuid4()),
            "batch.received_at": datetime.datetime.now(datetime.timezone.utc).isoformat() + "Z",
        }

        for attempt in range(self.MAX_RETRY_ATTEMPTS):
            try:
                # Try to export the batch with batch metadata
                self.exporter.export(batch, batch_metadata)
                self.batches_sent += 1
                if attempt > 0:
                    logger.info(f"Batch exported successfully on attempt {attempt + 1}")
                else:
                    logger.debug(
                        f"Sent batch of {len(batch)} spans with batch ID: {batch_metadata['batch.id']}"
                    )
                return  # Success!

            except Exception as e:
                last_error = e
                if attempt < self.MAX_RETRY_ATTEMPTS - 1:
                    # Calculate backoff with jitter
                    wait_time = min(self.INITIAL_BACKOFF * (2**attempt), self.MAX_BACKOFF)
                    # Add jitter to prevent thundering herd
                    wait_time *= 0.5 + random.random()

                    logger.warning(
                        f"Export failed (attempt {attempt + 1}/{self.MAX_RETRY_ATTEMPTS}), "
                        f"retrying in {wait_time:.1f}s: {e}"
                    )

                    # Interruptible sleep
                    sleep_until = time.time() + wait_time
                    while time.time() < sleep_until and self.running:
                        time.sleep(0.1)

                    if not self.running:
                        break

        # All retries exhausted
        logger.error(
            f"Failed to export batch after {self.MAX_RETRY_ATTEMPTS} attempts: {last_error}"
        )

        # Save to failed batch disk if available
        if self.failed_batch_disk:
            try:
                self.failed_batch_disk.save_batch(batch)
                logger.info(f"Saved failed batch ({len(batch)} spans) to disk for later retry")
            except Exception as disk_error:
                logger.error(f"Failed to save batch to disk: {disk_error}")
                self.spans_dropped += len(batch)
        else:
            # No failed batch disk, spans are lost
            self.spans_dropped += len(batch)

    def get_stats(self) -> Dict[str, Any]:
        """Get writer statistics.

        Returns:
            Dictionary of statistics
        """
        queue_size = self.queue.qsize() if hasattr(self.queue, "qsize") else 0
        queue_capacity = self.max_queue_size
        utilization_pct = (queue_size / queue_capacity * 100) if queue_capacity > 0 else 0

        return {
            "spans_processed": self.spans_processed,
            "batches_sent": self.batches_sent,
            "spans_dropped": self.spans_dropped,
            "spans_dropped_queue_full": self.spans_dropped_queue_full,
            "queue_size": queue_size,
            "queue_capacity": queue_capacity,
            "queue_utilization": f"{utilization_pct:.1f}%",
            "queue_high_water_mark": self.queue_high_water_mark,
            "current_batch_size": len(self.current_batch),
        }
