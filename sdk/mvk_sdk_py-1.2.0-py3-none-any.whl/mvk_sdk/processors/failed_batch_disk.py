"""FailedBatchDisk - Persistent storage for failed batches.

This component stores only batches that have failed all retry attempts,
providing a recovery mechanism for transient failures.
"""

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, List

from ..exporters.base import SpanExporter

logger = logging.getLogger(__name__)


class FailedBatchDisk:
    """Handles failed batches for recovery.

    This is NOT a WAL - it only stores batches that failed after exponential
    backoff retry in the Writer thread. A separate retry thread periodically
    attempts to export these failed batches.
    """

    def __init__(
        self,
        path: str,
        exporter: SpanExporter,
        max_size_mb: int = 1000,
        retry_interval_secs: int = 60,
        max_age_hours: int = 24,
    ):
        """Initialize FailedBatchDisk.

        Args:
            path: Directory to store failed batches
            exporter: The exporter to retry with
            max_size_mb: Maximum disk usage in MB (default 1GB)
            retry_interval_secs: How often to retry failed batches (default 60s)
            max_age_hours: Maximum age before dropping batches (default 24h)
        """
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self.exporter = exporter
        self.max_size_bytes = max_size_mb * 1024 * 1024
        # Ensure retry_interval is never None
        self.retry_interval = retry_interval_secs if retry_interval_secs is not None else 60
        self.max_age_seconds = max_age_hours * 3600 if max_age_hours is not None else 86400

        # Thread safety
        self._lock = threading.Lock()
        self._running = True

        # Statistics
        self.batches_saved = 0
        self.batches_recovered = 0
        self.batches_expired = 0
        self.batches_failed = 0

        # Start retry thread
        self._retry_thread = threading.Thread(
            target=self._retry_loop, name="FailedBatchRetry", daemon=True
        )
        self._retry_thread.start()
        logger.info(f"FailedBatchDisk initialized at {self.path}")

    def save_batch(self, batch: List[Dict[str, Any]]) -> None:
        """Save a failed batch to disk.

        Args:
            batch: The batch that failed all retry attempts
        """
        with self._lock:
            try:
                # Check disk space
                if self._get_total_size() > self.max_size_bytes:
                    logger.warning("FailedBatchDisk full, cleaning up old batches")
                    self._cleanup_old_batches()

                # Generate unique filename with timestamp
                timestamp = int(time.time() * 1000000)  # Microseconds for uniqueness
                filename = f"failed_batch_{timestamp}.json"
                filepath = self.path / filename

                # Write batch with metadata
                data = {
                    "timestamp": time.time(),
                    "batch": batch,
                    "retry_count": 0,
                    "size": len(batch),
                }

                with open(filepath, "w") as f:
                    json.dump(data, f)

                self.batches_saved += 1
                logger.debug(f"Saved failed batch to {filename} ({len(batch)} spans)")

            except Exception as e:
                logger.error(f"Failed to save batch to disk: {e}")
                raise

    def _retry_loop(self) -> None:
        """Background thread that retries failed batches."""
        logger.info("FailedBatchRetry thread started")

        while self._running:
            try:
                # Wait for retry interval (ensure retry_interval is valid)
                wait_iterations = int(max(1, self.retry_interval or 60) * 10)
                for _ in range(wait_iterations):
                    if not self._running:
                        break
                    time.sleep(0.1)

                if not self._running:
                    break

                # Process failed batches
                self._process_failed_batches()

            except Exception as e:
                logger.error(f"Error in retry loop: {e}", exc_info=True)

        logger.info("FailedBatchRetry thread stopped")

    def _process_failed_batches(self) -> None:
        """Process all failed batch files."""
        try:
            # Find all batch files
            batch_files = sorted(self.path.glob("failed_batch_*.json"))

            if batch_files:
                logger.info(f"Processing {len(batch_files)} failed batches")

            for batch_file in batch_files:
                if not self._running:
                    break

                try:
                    # Read batch file
                    with open(batch_file, "r") as f:
                        data = json.load(f)

                    # Check age
                    age = time.time() - data["timestamp"]
                    if age > self.max_age_seconds:
                        # Too old, remove it
                        batch_file.unlink()
                        self.batches_expired += 1
                        logger.info(f"Removed expired batch: {batch_file.name} (age: {age:.0f}s)")
                        continue

                    # Try to export the batch
                    batch = data["batch"]
                    try:
                        # Generate batch metadata for OTEL compliance
                        import datetime
                        import uuid

                        batch_metadata = {
                            "batch.id": str(uuid.uuid4()),
                            "batch.received_at": datetime.datetime.now(
                                datetime.timezone.utc
                            ).isoformat()
                            + "Z",
                        }

                        self.exporter.export(batch, batch_metadata)
                        # Success! Remove the file
                        batch_file.unlink()
                        self.batches_recovered += 1
                        logger.info(
                            f"Successfully exported failed batch: {batch_file.name} ({len(batch)} spans)"
                        )

                    except Exception as e:
                        # Still failing - update retry count
                        data["retry_count"] += 1

                        # If too many retries, give up
                        if data["retry_count"] > 100:  # Max 100 retry cycles
                            batch_file.unlink()
                            self.batches_failed += 1
                            logger.error(
                                f"Giving up on batch {batch_file.name} after {data['retry_count']} retries"
                            )
                        else:
                            # Update the file with new retry count
                            with open(batch_file, "w") as f:
                                json.dump(data, f)
                            logger.debug(
                                f"Batch {batch_file.name} still failing (retry {data['retry_count']}): {e}"
                            )

                except Exception as e:
                    logger.error(f"Error processing batch file {batch_file}: {e}")

        except Exception as e:
            logger.error(f"Error in _process_failed_batches: {e}")

    def _get_total_size(self) -> int:
        """Get total size of all batch files."""
        total = 0
        try:
            for batch_file in self.path.glob("failed_batch_*.json"):
                total += batch_file.stat().st_size
        except Exception as e:
            logger.error(f"Error calculating total size: {e}")
        return total

    def _cleanup_old_batches(self) -> None:
        """Remove oldest batch files to make space."""
        try:
            # Get all batch files sorted by modification time
            batch_files = sorted(
                self.path.glob("failed_batch_*.json"), key=lambda p: p.stat().st_mtime
            )

            # Remove oldest 10% of files
            to_remove = max(1, len(batch_files) // 10)
            for batch_file in batch_files[:to_remove]:
                batch_file.unlink()
                logger.info(f"Removed old batch file: {batch_file.name}")

        except Exception as e:
            logger.error(f"Error cleaning up old batches: {e}")

    def shutdown(self) -> None:
        """Shutdown the retry thread."""
        logger.info("Shutting down FailedBatchDisk")
        self._running = False

        # Wait for retry thread to stop
        if self._retry_thread and self._retry_thread.is_alive():
            self._retry_thread.join(timeout=2.0)

        # Log final statistics
        logger.info(
            f"FailedBatchDisk stats - Saved: {self.batches_saved}, "
            f"Recovered: {self.batches_recovered}, Expired: {self.batches_expired}, "
            f"Failed: {self.batches_failed}"
        )

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about failed batch handling.

        Returns:
            Dictionary of statistics
        """
        batch_count = len(list(self.path.glob("failed_batch_*.json")))
        total_size = self._get_total_size()

        return {
            "batches_on_disk": batch_count,
            "disk_usage_mb": total_size / (1024 * 1024),
            "batches_saved": self.batches_saved,
            "batches_recovered": self.batches_recovered,
            "batches_expired": self.batches_expired,
            "batches_failed": self.batches_failed,
        }
