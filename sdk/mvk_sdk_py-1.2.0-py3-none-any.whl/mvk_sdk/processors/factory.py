"""Factory for creating processors and exporters from configuration for v3.0."""

import logging
import os
import warnings
from typing import Any, Dict, List, Optional

from ..exporters.base import SpanExporter
from ..exporters.console import ConsoleExporter
from ..exporters.file import FileExporter
from ..exporters.otlp_grpc import OTLPGRPCExporter
from ..exporters.otlp_http import OTLPHTTPExporter
from .base import SpanProcessor
from .failed_batch_disk import FailedBatchDisk
from .writer import Writer

logger = logging.getLogger(__name__)

# Track active processors for shutdown
_active_processors: List[SpanProcessor] = []


def get_active_processors():
    """Get all active processors for shutdown.

    Returns:
        List of active processors
    """
    return _active_processors


class ProcessorFactory:
    """Factory for creating processors and exporters from configuration."""

    @staticmethod
    def create_from_sdk_config(sdk_config) -> SpanProcessor:
        """Create a processor from MvkSdkConfig model (v3.0).

        This is a convenience method that accepts the structured MvkSdkConfig
        model and converts it to the dictionary format expected by create_from_config.

        Args:
            sdk_config: MvkSdkConfig instance with validated configuration

        Returns:
            Configured SpanProcessor instance (Writer)

        Raises:
            ValueError: If configuration is invalid
        """
        # Import here to avoid circular dependency
        from mvk_sdk.config_registry import MvkSdkConfig

        if not isinstance(sdk_config, MvkSdkConfig):
            raise TypeError(f"Expected MvkSdkConfig, got {type(sdk_config)}")

        # Convert to legacy dict format
        config_dict = sdk_config.to_legacy_dict()
        agent_id = sdk_config.agent_id

        if not agent_id:
            raise ValueError("agent_id is required in MvkSdkConfig")

        return ProcessorFactory.create_from_config(config_dict, agent_id)

    @staticmethod
    def create_from_config(config: Dict[str, Any], agent_id: str) -> SpanProcessor:
        """Create a processor from configuration (v3.0 - two-mode architecture).

        Args:
            config: Configuration dictionary with exporter and optional FailedBatchDisk settings
            agent_id: Required agent ID (passed separately from config)

        Returns:
            Configured SpanProcessor instance (Writer)

        Raises:
            ValueError: If configuration is invalid
        """
        # Validate required agent_id parameter
        if not agent_id:
            raise ValueError("agent_id is required as separate parameter for v3.0")

        # After load_configuration(), all major sections are at root level:
        # {"exporter": {...}, "batching": {...}, "failed_batch_disk": {...}}
        exporter_config = config.get("exporter", {})

        exporter = ProcessorFactory.create_exporter(
            exporter_config, full_config=config, agent_id=agent_id
        )
        # Memory Mode with optional FailedBatchDisk
        logger.info("Creating memory-first writer with exponential backoff")

        # Create optional FailedBatchDisk
        failed_batch_disk = None
        fbd_config = config.get("failed_batch_disk", {})

        # Default to enabled unless explicitly disabled
        if fbd_config.get("enabled", True):
            failed_batch_disk = FailedBatchDisk(
                path=fbd_config.get("path", "/tmp/mvk/failed_batches"),
                exporter=exporter,
                max_size_mb=fbd_config.get("max_size_mb", 1000),
                retry_interval_secs=fbd_config.get("retry_interval_secs", 60),
                max_age_hours=fbd_config.get("max_age_hours", 24),
            )

        # Get batching configuration
        batching_config = config.get("batching", {})

        # Return regular Writer with exponential backoff
        writer = Writer(
            exporter=exporter,
            failed_batch_disk=failed_batch_disk,
            max_queue_size=config.get("max_queue_size", Writer.DEFAULT_MAX_QUEUE_SIZE),
            shutdown_timeout=config.get("shutdown_timeout", 5.0),
            max_items=batching_config.get("max_items", Writer.DEFAULT_MAX_ITEMS),
            max_bytes=batching_config.get("max_bytes", Writer.DEFAULT_MAX_BYTES),
            max_interval_ms=batching_config.get("max_interval_ms", Writer.DEFAULT_MAX_INTERVAL_MS),
        )
        writer.start()  # Start the writer thread
        _active_processors.append(writer)
        return writer

    @staticmethod
    def create_exporter(
        config: Dict[str, Any], full_config: Dict[str, Any], agent_id: str
    ) -> SpanExporter:
        """Create an OTLP exporter from configuration (v3.0 - OTLP only).

        Args:
            config: Exporter configuration with protocol specification
            full_config: Full configuration dictionary for service attribute detection
            agent_id: Required agent ID (passed separately from config)

        Returns:
            Configured OTLP SpanExporter instance (HTTP or gRPC)

        Raises:
            ValueError: If configuration is invalid
        """
        # Check for local testing exporters first (console/file)
        # Exporter is at root level after load_configuration()
        temp_exporter_cfg = full_config.get("exporter", {})

        exporter_type = config.get("type") or temp_exporter_cfg.get("type")
        if exporter_type in ["console", "file"]:
            logger.info(f"Using {exporter_type} exporter for local testing")

            if exporter_type == "console":
                return ConsoleExporter(
                    output=temp_exporter_cfg.get("output", "stdout"),
                    format=temp_exporter_cfg.get("format", "json"),
                    pretty=temp_exporter_cfg.get("pretty", False),
                    use_otlp_format=temp_exporter_cfg.get("use_otlp_format", True),
                    service_name=ProcessorFactory._detect_service_name(full_config, agent_id),
                    service_version=ProcessorFactory._detect_service_version(full_config),
                )
            elif exporter_type == "file":
                return FileExporter(
                    directory=temp_exporter_cfg.get("file_path")
                    or temp_exporter_cfg.get("directory", "/tmp/mvk/spans"),
                    filename_prefix=temp_exporter_cfg.get("filename_prefix", "spans"),
                    max_file_size_mb=temp_exporter_cfg.get("max_file_size_mb", 100),
                    max_files=temp_exporter_cfg.get("max_files", 5),
                    compress_rotated=temp_exporter_cfg.get("compress_rotated", False),
                    use_otlp_format=temp_exporter_cfg.get("use_otlp_format", True),
                    service_name=ProcessorFactory._detect_service_name(full_config, agent_id),
                    service_version=ProcessorFactory._detect_service_version(full_config),
                )

        # ========== STEP 1: Determine Mode, Type, Protocol, Endpoint, Headers (SIMPLIFIED) ==========
        # After load_configuration(), exporter is at root level: merged_config["exporter"]
        exporter_cfg = full_config.get("exporter", {})

        # Mode determines interpretation (DIRECT = Mavvrik, COLLECTOR = your collector)
        mode = exporter_cfg.get("mode", "DIRECT").upper()
        logger.debug(f"Resolved mode: {mode}")

        # Type: otlp_http, otlp_grpc, console, or file
        exporter_type = exporter_cfg.get("type", "otlp_http")
        logger.debug(f"Exporter type: {exporter_type}")

        # Derive protocol from type (internal - not exposed to user)
        if exporter_type == "otlp_http":
            protocol = "http"
        elif exporter_type == "otlp_grpc":
            protocol = "grpc"
        elif exporter_type in ["console", "file"]:
            protocol = None  # Not applicable for local exporters
        else:
            logger.warning(f"Unknown exporter type '{exporter_type}', defaulting to otlp_http")
            exporter_type = "otlp_http"
            protocol = "http"
        logger.debug(f"Derived protocol: {protocol}")

        # Endpoint: where to send (same parameter for both modes)
        endpoint = exporter_cfg.get("endpoint")
        if not endpoint:
            # Default endpoints based on mode and protocol
            if mode == "COLLECTOR":
                endpoint = "localhost:4317" if protocol == "grpc" else "localhost:4318"
            else:  # DIRECT mode
                endpoint = "ingest.mavvrik.ai:443" if protocol == "grpc" else "ingest.mavvrik.ai"

        if ":" not in endpoint and mode == "DIRECT":
            endpoint = f"{endpoint}:443"
            logger.info(f"No port specified in endpoint, defaulting to {endpoint}")

        logger.debug(f"Endpoint: {endpoint}")

        # Headers: custom headers (same parameter for both modes)
        headers_input = exporter_cfg.get("headers")
        headers = {}

        # Parse headers (supports dict or string format)
        if isinstance(headers_input, dict):
            headers = dict(headers_input)
        elif isinstance(headers_input, str) and headers_input:
            # Parse string format: "key1=val1,key2=val2" or JSON
            if headers_input.startswith("{"):
                # JSON format
                import json

                try:
                    headers = json.loads(headers_input)
                except json.JSONDecodeError:
                    logger.warning(f"Failed to parse headers as JSON: {headers_input}")
            else:
                # Comma-separated format
                for header in headers_input.split(","):
                    if "=" in header:
                        key, value = header.split("=", 1)
                        headers[key.strip()] = value.strip()

        # Add MVK authentication headers in DIRECT mode
        if mode == "DIRECT":
            api_key = full_config.get("api_key")
            tenant_id = full_config.get("tenant_id")

            if api_key:
                headers["Authorization"] = f"Bearer {api_key.strip()}"
            if tenant_id:
                headers["X-Tenant-ID"] = tenant_id.strip()
            if agent_id:
                headers["X-Agent-ID"] = agent_id.strip()

        logger.info(
            f"{mode} mode: protocol={protocol}, endpoint={endpoint}, headers={len(headers)}"
        )
        logger.debug(f"Headers: {list(headers.keys())}")

        # ========== STEP 2: Extract Common Configuration ==========
        # Read from exporter_cfg (where registry stores all exporter.* values)
        service_name = ProcessorFactory._detect_service_name(full_config, agent_id)
        service_version = ProcessorFactory._detect_service_version(full_config)
        service_instance_id = full_config.get("service_instance_id")

        # Common exporter parameters (all from exporter_cfg now)
        exporter_params = {
            "endpoint": endpoint,
            "headers": headers,
            "timeout_secs": exporter_cfg.get("timeout", 10),
            "max_retry_hours": exporter_cfg.get("max_retry_hours", 4.0),
            "initial_interval_secs": exporter_cfg.get("initial_interval_secs", 1.0),
            "max_interval_secs": exporter_cfg.get("max_interval_secs", 300),
            "max_fast_retries": exporter_cfg.get("max_fast_retries", 10),
            "service_name": service_name,
            "service_version": service_version,
            "service_instance_id": service_instance_id,
        }

        logger.debug(f"Exporter parameters: {exporter_params}")

        # ========== STEP 3: Create Exporter Based on Protocol ==========
        if protocol == "grpc":
            logger.debug(f"Creating OTLPGRPCExporter with protocol: {protocol}")
            return OTLPGRPCExporter(
                insecure=exporter_cfg.get("insecure", True),
                compression=exporter_cfg.get("compression", "gzip"),
                **exporter_params,
            )
        elif protocol == "http":
            logger.debug(f"Creating OTLPHTTPExporter with protocol: {protocol}")
            return OTLPHTTPExporter(
                encoding=exporter_cfg.get("encoding", "json"),
                compression=exporter_cfg.get("compression", "gzip"),
                insecure=exporter_cfg.get("insecure", False),
                **exporter_params,
            )
        else:
            raise ValueError(f"Invalid protocol: {protocol}. Must be 'http' or 'grpc'")

    @staticmethod
    def _detect_service_name(config: Dict[str, Any], agent_id: str) -> str:
        """Auto-detect service name from multiple sources with fallback priority.

        Priority order:
        1. config["agent_name"] (agent name)
        2. agent_id (required agent ID passed separately)
        3. Environment variables
        4. System detection (package.json, setup.py, etc.)
        5. Default fallback
        """
        # Check agent name
        if "agent_name" in config:
            return str(config["agent_name"])

        # Check agent_id (required, passed separately)
        if agent_id:
            return str(agent_id)

        # Check package.json or setup.py for Python package name
        package_name = ProcessorFactory._detect_package_name()
        if package_name:
            return package_name

        # Check if running in container (Docker, Kubernetes)
        container_name = ProcessorFactory._detect_container_name()
        if container_name:
            return container_name

        # Check hostname as last resort
        hostname = ProcessorFactory._get_hostname()
        if hostname and hostname != "localhost":
            return f"service-{hostname}"

        return "unknown"

    @staticmethod
    def _detect_service_version(config: Dict[str, Any]) -> str:
        """Auto-detect service version from multiple sources with fallback priority.

        Priority order:
        1. Environment variables
        2. Package version detection
        3. Git commit hash
        4. Default fallback
        """
        # Check git commit hash first (prioritize git over package version)
        git_commit = ProcessorFactory._detect_git_commit()
        if git_commit:
            return git_commit  # Use full git version instead of just short hash

        # Check package version
        package_version = ProcessorFactory._detect_package_version()
        if package_version:
            return package_version

        return "unknown"

    @staticmethod
    def _detect_package_name() -> Optional[str]:
        """Detect Python package name from various sources."""
        try:
            # Try to get from current working directory
            cwd = os.getcwd()

            # Check for setup.py
            setup_py = os.path.join(cwd, "setup.py")
            if os.path.exists(setup_py):
                with open(setup_py, "r") as f:
                    content = f.read()
                    # Simple regex to extract name
                    import re

                    match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        return match.group(1)

            # Check for pyproject.toml
            pyproject_toml = os.path.join(cwd, "pyproject.toml")
            if os.path.exists(pyproject_toml):
                with open(pyproject_toml, "r") as f:
                    content = f.read()
                    import re

                    match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        return match.group(1)

            # Check for package.json (Node.js projects)
            package_json = os.path.join(cwd, "package.json")
            if os.path.exists(package_json):
                import json

                with open(package_json, "r") as f:
                    data = json.load(f)
                    name = data.get("name")
                    return str(name) if name is not None else None

            # Check for go.mod (Go projects)
            go_mod = os.path.join(cwd, "go.mod")
            if os.path.exists(go_mod):
                with open(go_mod, "r") as f:
                    content = f.read()
                    import re

                    match = re.search(r"module\s+([^\s]+)", content)
                    if match:
                        return match.group(1).split("/")[-1]  # Last part of module path

        except Exception:  # pylint: disable=broad-except
            # Ignore errors in service name detection
            pass

        return None

    @staticmethod
    def _detect_package_version() -> Optional[str]:
        """Detect package version from various sources."""
        try:
            # Try to get from current working directory
            cwd = os.getcwd()

            # Check for setup.py
            setup_py = os.path.join(cwd, "setup.py")
            if os.path.exists(setup_py):
                with open(setup_py, "r") as f:
                    content = f.read()
                    import re

                    match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        return match.group(1)

            # Check for pyproject.toml
            pyproject_toml = os.path.join(cwd, "pyproject.toml")
            if os.path.exists(pyproject_toml):
                with open(pyproject_toml, "r") as f:
                    content = f.read()
                    import re

                    match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                    if match:
                        return match.group(1)

            # Check for package.json
            package_json = os.path.join(cwd, "package.json")
            if os.path.exists(package_json):
                import json

                with open(package_json, "r") as f:
                    data = json.load(f)
                    ver = data.get("version")
                    return str(ver) if ver is not None else None

            # Check for go.mod
            go_mod = os.path.join(cwd, "go.mod")
            if os.path.exists(go_mod):
                with open(go_mod, "r") as f:
                    content = f.read()
                    import re

                    match = re.search(r"go\s+([^\s]+)", content)
                    if match:
                        return match.group(1)

        except Exception:  # pylint: disable=broad-except
            # Ignore errors in version detection
            pass

        return None

    @staticmethod
    def _detect_git_commit() -> Optional[str]:
        """Detect git commit hash or version."""
        try:
            import subprocess

            # Try multiple git commands for better version detection
            git_commands = [
                ["git", "describe", "--tags", "--always"],  # Most descriptive
                ["git", "describe", "--always"],  # Just commit hash if no tags
                ["git", "rev-parse", "--short", "HEAD"],  # Short commit hash
                ["git", "rev-parse", "HEAD"],  # Full commit hash
            ]

            for cmd in git_commands:
                try:
                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        cwd=os.getcwd(),
                        timeout=5,
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except Exception:  # pylint: disable=broad-except
                    # Continue to next command attempt
                    continue
        except Exception:  # pylint: disable=broad-except
            # Ignore errors in git detection
            pass
        return None

    @staticmethod
    def _detect_container_name() -> Optional[str]:
        """Detect container name from environment."""
        # Docker
        container_name = os.getenv("HOSTNAME")
        if container_name and container_name != os.getenv("HOSTNAME", ""):
            return container_name

        # Kubernetes
        pod_name = os.getenv("POD_NAME")
        if pod_name:
            return pod_name

        # Check if running in container
        if os.path.exists("/.dockerenv"):
            return "docker-container"

        return None

    @staticmethod
    def _get_hostname() -> str:
        """Get system hostname."""
        try:
            import socket

            return socket.gethostname()
        except Exception:  # pylint: disable=broad-except
            # Fall back to 'unknown' on any error
            return "unknown"

    @staticmethod
    def create_default() -> SpanProcessor:
        """Create a default processor for development (v3.0 - Console with OTLP format).

        Returns:
            A Writer with ConsoleExporter (memory-bounded, safe default)
        """
        # Create minimal config for default processor
        default_config = {
            "service": {"name": "development", "version": "dev"},
        }

        # Default to console exporter with OTLP format for local development
        exporter = ConsoleExporter(
            output="stdout",
            format="simple",
            pretty=True,
            use_otlp_format=True,
            service_name=ProcessorFactory._detect_service_name(default_config, "development"),
            service_version=ProcessorFactory._detect_service_version(default_config),
        )
        # Default: memory mode without FailedBatchDisk for simplicity
        writer = Writer(exporter=exporter, failed_batch_disk=None)
        writer.start()  # Start the writer thread
        return writer
