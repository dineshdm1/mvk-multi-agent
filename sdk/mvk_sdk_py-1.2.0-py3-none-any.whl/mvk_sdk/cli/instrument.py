#!/usr/bin/env python
"""mvk-instrument command-line tool for auto-instrumentation.

This tool follows OpenTelemetry patterns, allowing users to run Python
programs with automatic instrumentation enabled.

Usage:
    mvk-instrument [options] python script.py
    mvk-instrument [options] python -m module
    MVK_AUTO_INSTRUMENT=1 mvk-instrument python script.py
"""

import argparse
import os
import subprocess
import sys
from typing import List, Optional

from ..wrapper_logging import get_component_logger

logger = get_component_logger("cli", "instrument")


def parse_args(args: Optional[List[str]] = None) -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="mvk-instrument",
        description="Run Python with MVK SDK auto-instrumentation enabled",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage with required configuration
  mvk-instrument --api-key YOUR_KEY --agent-id YOUR_AGENT python app.py
  
  # Using environment variables
  export MVK_API_KEY=YOUR_KEY
  export MVK_AGENT_ID=YOUR_AGENT
  mvk-instrument python app.py
  
  # Exclude specific libraries
  mvk-instrument --exclude httpx,requests python app.py
  
  # Only instrument specific libraries
  mvk-instrument --include openai,anthropic python app.py
  
  # Run a module
  mvk-instrument python -m mymodule
  
  # Pass arguments to your script
  mvk-instrument python script.py --arg1 value1 --arg2 value2
""",
    )

    # MVK SDK configuration
    parser.add_argument(
        "--api-key",
        help="MVK API key (or use MVK_API_KEY env var)",
        default=os.environ.get("MVK_API_KEY"),
    )

    parser.add_argument(
        "--agent-id",
        help="MVK Agent ID (or use MVK_AGENT_ID env var)",
        default=os.environ.get("MVK_AGENT_ID"),
    )

    parser.add_argument(
        "--endpoint",
        help="MVK collector endpoint (or use MVK_ENDPOINT env var)",
        default=os.environ.get("MVK_ENDPOINT"),
    )

    # Instrumentation control
    parser.add_argument(
        "--exclude",
        help="Comma-separated list of libraries to exclude from instrumentation",
        default=os.environ.get("MVK_EXCLUDED_LIBRARIES", ""),
    )

    parser.add_argument(
        "--include",
        help="Comma-separated list of libraries to include (if set, only these are instrumented)",
        default=os.environ.get("MVK_INCLUDED_LIBRARIES", ""),
    )

    parser.add_argument(
        "--log-level",
        help="Logging level (DEBUG, INFO, WARNING, ERROR)",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
    )

    parser.add_argument(
        "--dry-run", action="store_true", help="Show what would be executed without running it"
    )

    parser.add_argument("--version", action="version", version="%(prog)s 1.1.0")

    # Python command and script
    parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="Python command to execute (e.g., 'python script.py')",
    )

    return parser.parse_args(args)


def validate_args(args: argparse.Namespace) -> bool:
    """Validate command-line arguments.

    Returns:
        True if valid, False otherwise
    """
    # Check for required configuration
    if not args.api_key:
        print("Error: MVK API key is required. Use --api-key or set MVK_API_KEY", file=sys.stderr)
        return False

    if not args.agent_id:
        print(
            "Error: MVK Agent ID is required. Use --agent-id or set MVK_AGENT_ID", file=sys.stderr
        )
        return False

    # Check that a command was provided
    if not args.command:
        print("Error: No command provided. Usage: mvk-instrument python script.py", file=sys.stderr)
        return False

    # Check that the command starts with python
    if not args.command[0].startswith("python"):
        print(f"Warning: Command does not start with 'python': {args.command[0]}", file=sys.stderr)

    return True


def build_environment(args: argparse.Namespace) -> dict:
    """Build environment variables for the subprocess.

    Args:
        args: Parsed command-line arguments

    Returns:
        Dictionary of environment variables
    """
    env = os.environ.copy()

    # Enable auto-instrumentation
    env["MVK_AUTO_INSTRUMENT"] = "1"

    # Set MVK configuration
    if args.api_key:
        env["MVK_API_KEY"] = args.api_key

    if args.agent_id:
        env["MVK_AGENT_ID"] = args.agent_id

    if args.endpoint:
        env["MVK_ENDPOINT"] = args.endpoint

    # Set instrumentation control
    if args.exclude:
        env["MVK_EXCLUDED_LIBRARIES"] = args.exclude

    if args.include:
        env["MVK_INCLUDED_LIBRARIES"] = args.include

    # Set logging level
    env["MVK_LOG_LEVEL"] = args.log_level

    # Ensure our sitecustomize can be imported
    # Add the MVK SDK directory to PYTHONPATH
    mvk_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    python_path = env.get("PYTHONPATH", "")
    if python_path:
        env["PYTHONPATH"] = f"{mvk_dir}{os.pathsep}{python_path}"
    else:
        env["PYTHONPATH"] = mvk_dir

    # Enable sitecustomize import
    env["PYTHONSTARTUP"] = os.path.join(mvk_dir, "sitecustomize.py")

    return env


def main(args: Optional[List[str]] = None) -> int:
    """Main entry point for mvk-instrument.

    Args:
        args: Command-line arguments (for testing)

    Returns:
        Exit code
    """
    # Parse arguments
    parsed_args = parse_args(args)

    # Validate arguments
    if not validate_args(parsed_args):
        return 1

    # Build environment
    env = build_environment(parsed_args)

    # Show dry-run information if requested
    if parsed_args.dry_run:
        print("=== Dry Run Mode ===")
        print(f"Command: {' '.join(parsed_args.command)}")
        print("\nEnvironment variables:")
        for key, value in sorted(env.items()):
            if key.startswith("MVK_") or key == "PYTHONPATH" or key == "PYTHONSTARTUP":
                # Mask sensitive values
                if "KEY" in key or "TOKEN" in key:
                    value = value[:4] + "..." if len(value) > 4 else "***"
                print(f"  {key}={value}")
        return 0

    # Execute the command with instrumentation
    try:
        # Log what we're doing
        logger.info(f"Running with auto-instrumentation: {' '.join(parsed_args.command)}")
        logger.debug(f"Excluded libraries: {parsed_args.exclude or 'none'}")
        logger.debug(f"Included libraries: {parsed_args.include or 'all supported'}")

        # Run the command
        result = subprocess.run(parsed_args.command, env=env, stdout=sys.stdout, stderr=sys.stderr)

        return result.returncode

    except FileNotFoundError:
        print(f"Error: Command not found: {parsed_args.command[0]}", file=sys.stderr)
        return 127
    except KeyboardInterrupt:
        print("\nInterrupted by user", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error running command: {e}", file=sys.stderr)
        logger.exception("Failed to run instrumented command")
        return 1


def console_script():
    """Entry point for console script."""
    sys.exit(main())


if __name__ == "__main__":
    console_script()
