"""
SpanBuilder - A common class for creating schema-compliant spans.

This module provides a standardized way to create spans that are fully compliant
with the MVK SDK v1.1 schema and OpenTelemetry specifications.
"""

import json
import time
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from . import get_schema_version
from .context import get_global_context
from .error_handling import never_break_client_code, safe_span_operation
from .metered_usage import MeteredUsageBuilder
from .mvk_tracer import OTLPSpanKind, get_tracer
from .schema import MVKStepType


class ModelProvider(str, Enum):
    """Enum for model providers as per schema."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    AZURE_OPENAI = "azure-openai"
    GOOGLE_VERTEXAI = "google-vertexai"
    AWS_BEDROCK = "aws-bedrock"
    COHERE = "cohere"
    MISTRAL = "mistral"
    HUGGINGFACE = "huggingface"
    CUSTOM = "custom"


class ModelType(str, Enum):
    """Enum for model types as per schema."""

    CHAT = "chat"
    EMBEDDING = "embedding"
    COMPLETION = "completion"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    MULTIMODAL = "multimodal"


class Operation(str, Enum):
    """Enum for operations as per schema."""

    COMPLETION = "completion"
    GENERATE_EMBEDDINGS = "generate_embeddings"
    TOOL_CALL = "tool_call"
    RETRIEVAL = "retrieval"
    RERANK = "rerank"
    SEARCH = "search"
    CUSTOM = "custom"


class OperationSubtype(str, Enum):
    """Enum for operation subtypes."""

    STREAM = "stream"
    BATCH = "batch"
    ASYNC = "async"
    SYNC = "sync"


class SpanBuilder:
    """
    Builder class for creating schema-compliant spans.

    This class ensures:
    1. All mandatory OTLP fields are set
    2. All mandatory MVK attributes are set
    3. Proper OpenTelemetry SpanKind is used
    4. MVKStepType is set as an attribute
    5. Metered usage is properly formatted
    6. All field names match the schema exactly
    """

    def __init__(self, name: str):
        """Initialize the span builder.

        Args:
            name: The name of the span (e.g., "openai.chat.completion")
        """
        self.name = name
        self.tracer = get_tracer()
        self.attributes: Dict[str, Any] = {}
        self.kind = OTLPSpanKind.CLIENT  # Default for external API calls
        self.step_type: Optional[MVKStepType] = None
        self.metered_usage_builder = MeteredUsageBuilder()
        self.start_time: Optional[float] = None
        self.span: Optional[Any] = None

        # Initialize with global context attributes
        self._init_global_attributes()

    def _init_global_attributes(self):
        """Initialize attributes from global context."""
        global_ctx = get_global_context()

        # Mandatory MVK attributes from context
        self.attributes["agent_id"] = global_ctx.get("mvk.agent_id", "unknown")
        self.attributes["agent_name"] = global_ctx.get("mvk.agent_name", "unknown")
        self.attributes["schema_version"] = get_schema_version()

        # Optional context attributes
        if "mvk.session_id" in global_ctx:
            self.attributes["session_id"] = global_ctx["mvk.session_id"]
        if "mvk.user_id" in global_ctx:
            self.attributes["user_id"] = global_ctx["mvk.user_id"]
        if "mvk.environment" in global_ctx:
            self.attributes["environment"] = global_ctx["mvk.environment"]

    def with_llm_operation(
        self,
        model_provider: Union[ModelProvider, str],
        model_name: str,
        operation: Union[Operation, str] = Operation.COMPLETION,
        model_type: Union[ModelType, str] = ModelType.CHAT,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Configure span for LLM operations.

        Args:
            model_provider: The model provider (e.g., "openai", "anthropic")
            model_name: The specific model name (e.g., "gpt-4", "claude-3")
            operation: The operation type (default: "completion")
            model_type: The model type (default: "chat")
            **kwargs: Additional attributes (max_tokens, etc.)

        Returns:
            Self for method chaining
        """
        self.step_type = MVKStepType.LLM
        self.attributes.update(
            {
                "step_type": MVKStepType.LLM,
                "model_provider": (
                    model_provider.value
                    if isinstance(model_provider, Enum)
                    else str(model_provider)
                ),
                "model_name": model_name,
                "operation": (operation.value if isinstance(operation, Enum) else str(operation)),
                "model_type": (
                    model_type.value if isinstance(model_type, Enum) else str(model_type)
                ),
            }
        )

        # Add optional LLM attributes
        if "max_tokens" in kwargs:
            self.attributes["max_tokens"] = kwargs["max_tokens"]
        if "top_p" in kwargs:
            self.attributes["top_p"] = kwargs["top_p"]
        if "stream_enabled" in kwargs:
            self.attributes["stream_enabled"] = kwargs["stream_enabled"]
            if kwargs["stream_enabled"]:
                self.attributes["operation_subtype"] = OperationSubtype.STREAM.value

        return self

    def with_embedding_operation(
        self,
        model_provider: Union[ModelProvider, str],
        model_name: str,
        embeddings_count: int = 1,
        embedding_dims: Optional[int] = None,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Configure span for embedding operations.

        Args:
            model_provider: The model provider
            model_name: The specific model name
            embeddings_count: Number of embeddings generated
            embedding_dims: Dimension of embeddings
            **kwargs: Additional attributes

        Returns:
            Self for method chaining
        """
        self.step_type = MVKStepType.EMBEDDING
        self.attributes.update(
            {
                "step_type": MVKStepType.EMBEDDING,
                "model_provider": (
                    model_provider.value
                    if isinstance(model_provider, Enum)
                    else str(model_provider)
                ),
                "model_name": model_name,
                "operation": Operation.GENERATE_EMBEDDINGS.value,
                "model_type": ModelType.EMBEDDING.value,
                "operation_subtype": OperationSubtype.BATCH.value,
                "embeddings_count": embeddings_count,
            }
        )

        if embedding_dims:
            self.attributes["embedding_dims"] = embedding_dims

        return self

    def with_tool_operation(
        self, tool_name: str, operation: str, db_system: Optional[str] = None, **kwargs
    ) -> "SpanBuilder":
        """
        Configure span for tool operations.

        Args:
            tool_name: Name of the tool
            operation: The operation being performed
            db_system: Database system if applicable
            **kwargs: Additional attributes

        Returns:
            Self for method chaining
        """
        self.step_type = MVKStepType.TOOL
        self.attributes.update(
            {
                "step_type": MVKStepType.TOOL,
                "tool_name": tool_name,
                "operation": operation,
            }
        )

        if db_system:
            self.attributes["db_system"] = db_system

        # Add any additional tool-specific attributes
        self.attributes.update(kwargs)

        return self

    def with_retriever_operation(
        self,
        retriever_provider: str,
        operation: str,
        collection_name: Optional[str] = None,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Configure span for retriever operations.

        Args:
            retriever_provider: The retriever provider (e.g., "pinecone", "weaviate")
            operation: The operation (e.g., "query", "upsert")
            collection_name: The collection/index name
            **kwargs: Additional attributes

        Returns:
            Self for method chaining
        """
        self.step_type = MVKStepType.RETRIEVER
        self.attributes.update(
            {
                "step_type": MVKStepType.RETRIEVER,
                "retriever_provider": retriever_provider,
                "operation": operation,
            }
        )

        if collection_name:
            self.attributes["collection_name"] = collection_name
            self.attributes["vectordb_index"] = collection_name  # Alias for compatibility

        # Add retriever-specific attributes
        if "top_k" in kwargs:
            self.attributes["top_k"] = kwargs["top_k"]
        if "similarity_threshold" in kwargs:
            self.attributes["similarity_threshold"] = kwargs["similarity_threshold"]

        self.attributes.update(kwargs)

        return self

    def with_vendor_info(
        self, vendor_name: str, vendor_sdk: str, sdk_version: str = "unknown"
    ) -> "SpanBuilder":
        """
        Set vendor information.

        Args:
            vendor_name: Vendor identifier
            vendor_sdk: SDK being wrapped
            sdk_version: Version of the SDK

        Returns:
            Self for method chaining
        """
        self.attributes.update(
            {
                "vendor_name": vendor_name,
                "vendor_sdk": vendor_sdk,
                "sdk_version": sdk_version,
            }
        )
        return self

    def with_token_usage(
        self,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        total_tokens: Optional[int] = None,
        cached_read: int = 0,
        cached_write: int = 0,
    ) -> "SpanBuilder":
        """
        Set token usage metrics.

        Args:
            prompt_tokens: Number of prompt/input tokens
            completion_tokens: Number of completion/output tokens
            total_tokens: Total tokens (auto-calculated if not provided)
            cached_read: Cached tokens read (for providers that support caching)
            cached_write: Cached tokens written

        Returns:
            Self for method chaining
        """
        if total_tokens is None:
            total_tokens = prompt_tokens + completion_tokens

        # Set individual attributes for backward compatibility
        if prompt_tokens > 0:
            self.attributes["prompt_tokens"] = prompt_tokens
        if completion_tokens > 0:
            self.attributes["completion_tokens"] = completion_tokens
        if total_tokens > 0:
            self.attributes["total_tokens"] = total_tokens
        if cached_read > 0:
            self.attributes["cached_tokens_read"] = cached_read
        if cached_write > 0:
            self.attributes["cached_tokens_write"] = cached_write

        # Add to metered usage
        self.metered_usage_builder.add_token_metrics(
            prompt=prompt_tokens,
            completion=completion_tokens,
            total=total_tokens,
            cached_read=cached_read,
            cached_write=cached_write,
        )

        return self

    def with_custom_metered_usage(
        self, metric_kind: str, quantity: float, uom: str = "unit"
    ) -> "SpanBuilder":
        """
        Add custom metered usage.

        Args:
            metric_kind: Type of metric (e.g., "api.calls", "compute.time")
            quantity: The quantity value
            uom: Unit of measure

        Returns:
            Self for method chaining
        """
        self.metered_usage_builder.add_metric(metric_kind=metric_kind, quantity=quantity, uom=uom)
        return self

    def with_attributes(self, **kwargs) -> "SpanBuilder":
        """
        Add custom attributes to the span.

        Args:
            **kwargs: Key-value pairs of attributes

        Returns:
            Self for method chaining
        """
        self.attributes.update(kwargs)
        return self

    def with_span_kind(self, kind: OTLPSpanKind) -> "SpanBuilder":
        """
        Override the default span kind.

        Args:
            kind: The OpenTelemetry SpanKind

        Returns:
            Self for method chaining
        """
        self.kind = kind
        return self

    def with_prompt_response(
        self,
        prompt: Optional[str] = None,
        response: Optional[str] = None,
        messages: Optional[List[Dict]] = None,
    ) -> "SpanBuilder":
        """
        Add prompt and response if logging is enabled.

        Args:
            prompt: The prompt text
            response: The response text
            messages: Chat messages (for chat completions)

        Returns:
            Self for method chaining
        """
        from .instrument import should_log_prompts_responses

        if should_log_prompts_responses():
            if prompt:
                self.attributes["prompt"] = prompt[:1000]  # Limit to 1000 chars
            if response:
                self.attributes["response"] = response[:1000]
            if messages:
                self.attributes["messages"] = str(messages)[:1000]

        return self

    def _validate_mandatory_fields(self):
        """Validate that all mandatory fields are present."""
        # Check mandatory MVK attributes
        mandatory_attrs = [
            "agent_id",
            "agent_name",
            "schema_version",
            "step_type",
            "operation",
        ]

        for attr in mandatory_attrs:
            if attr not in self.attributes:
                raise ValueError(f"Mandatory attribute '{attr}' is missing")

        # Validate step_type
        if not isinstance(self.attributes["step_type"], MVKStepType):
            raise ValueError(
                f"step_type must be an MVKStepType enum, got {type(self.attributes['step_type'])}"
            )

        # Validate model operations have required fields
        if self.attributes["step_type"] in [MVKStepType.LLM, MVKStepType.EMBEDDING]:
            required_model_attrs = ["model_provider", "model_name", "model_type"]
            for attr in required_model_attrs:
                if attr not in self.attributes:
                    raise ValueError(f"Model operation requires '{attr}' attribute")

    def start(self) -> "SpanBuilder":
        """
        Start the span with all configured attributes.

        Returns:
            Self for method chaining

        Raises:
            ValueError: If mandatory fields are missing
        """
        self._validate_mandatory_fields()

        self.start_time = time.time()

        # Start the span with OpenTelemetry SpanKind and all attributes
        self.span = self.tracer.start_span(self.name, kind=str(self.kind), **self.attributes)

        return self

    @safe_span_operation("end")
    def end(self, error: Optional[Exception] = None):
        """
        End the span, setting final attributes and metered usage.

        Args:
            error: Optional exception to record
        """
        if not self.span:
            raise RuntimeError("Span not started. Call start() first.")

        # Calculate duration
        if self.start_time:
            duration_ms = int((time.time() - self.start_time) * 1000)
            self.span.set_attribute("mvk.duration_ms", duration_ms)

        # Set metered usage
        metered_usage = self.metered_usage_builder.build()
        if metered_usage:
            # Ensure it's properly JSON encoded for OTLP compliance
            self.span.set_attribute("mvk.metered_usage", json.dumps(metered_usage))

        # Handle error if provided
        if error:
            self.span.set_error(error)

        # End the span
        self.span.end()

    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        if exc_val:
            self.end(error=exc_val)
        else:
            self.end()
        # Don't suppress exceptions
        return False

    @classmethod
    def create_llm_span(
        cls,
        name: str,
        model_provider: str,
        model_name: str,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Convenience method to create an LLM span.

        Args:
            name: Span name
            model_provider: Model provider
            model_name: Model name
            prompt_tokens: Prompt tokens used
            completion_tokens: Completion tokens generated
            **kwargs: Additional attributes

        Returns:
            Configured SpanBuilder
        """
        builder = cls(name)
        builder.with_llm_operation(model_provider=model_provider, model_name=model_name, **kwargs)
        if prompt_tokens or completion_tokens:
            builder.with_token_usage(
                prompt_tokens=prompt_tokens, completion_tokens=completion_tokens
            )
        return builder

    @classmethod
    def create_embedding_span(
        cls,
        name: str,
        model_provider: str,
        model_name: str,
        embeddings_count: int = 1,
        embedding_dims: Optional[int] = None,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Convenience method to create an embedding span.

        Args:
            name: Span name
            model_provider: Model provider
            model_name: Model name
            embeddings_count: Number of embeddings
            embedding_dims: Embedding dimensions
            **kwargs: Additional attributes

        Returns:
            Configured SpanBuilder
        """
        builder = cls(name)
        builder.with_embedding_operation(
            model_provider=model_provider,
            model_name=model_name,
            embeddings_count=embeddings_count,
            embedding_dims=embedding_dims,
            **kwargs,
        )
        return builder

    @classmethod
    def create_tool_span(cls, name: str, tool_name: str, operation: str, **kwargs) -> "SpanBuilder":
        """
        Convenience method to create a tool span.

        Args:
            name: Span name
            tool_name: Tool name
            operation: Operation being performed
            **kwargs: Additional attributes

        Returns:
            Configured SpanBuilder
        """
        builder = cls(name)
        builder.with_tool_operation(tool_name=tool_name, operation=operation, **kwargs)
        return builder

    @classmethod
    def create_retriever_span(
        cls,
        name: str,
        retriever_provider: str,
        operation: str,
        collection_name: Optional[str] = None,
        **kwargs,
    ) -> "SpanBuilder":
        """
        Convenience method to create a retriever span.

        Args:
            name: Span name
            retriever_provider: Retriever provider
            operation: Operation being performed
            collection_name: Collection/index name
            **kwargs: Additional attributes

        Returns:
            Configured SpanBuilder
        """
        builder = cls(name)
        builder.with_retriever_operation(
            retriever_provider=retriever_provider,
            operation=operation,
            collection_name=collection_name,
            **kwargs,
        )
        return builder
