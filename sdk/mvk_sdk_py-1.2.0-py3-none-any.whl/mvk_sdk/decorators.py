"""MVK SDK v1.1 decorators.

Provides @mvk_signal and mvk_context for manual instrumentation.
Supports W3C TraceContext and selective field inheritance.
"""

import functools
import inspect
import logging
from typing import Any, Callable, Dict, Optional, TypeVar, Union

from .context import get_merged_context, pop_context, push_context
from .mvk_tracer import get_current_span, get_tracer
from .schema import MVKStepType, merge_tags_with_limit

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def _is_token_attribute(key: str) -> bool:
    """Check if an attribute key represents token/usage information that should only be on child spans."""
    token_attributes = {
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "metered_usage",
        "cached_tokens_read",
        "cached_tokens_write",
        "reasoning_tokens",
        "audio_input_seconds",
        "audio_output_seconds",
        "video_input_seconds",
        "video_output_seconds",
        "image_input_count",
        "image_input_pixels",
        # Also filter model-related attributes that should only be on AI provider spans
        "model_name",
        "model_provider",
        "model_type",
        "model_family",
        "input_type",
        "output_type",
        "operation_subtype",
        "vendor_name",
        "vendor_sdk",
        "sdk_version",
        "schema_version",
        "step_type",  # step_type="LLM" should only be on AI provider spans
    }
    return key in token_attributes


def _is_ai_provider_operation(step_type: Optional[Union[str, MVKStepType]]) -> bool:
    """Check if this is an AI provider operation based on step_type parameter.

    Returns True if this is an AI provider operation (should allow token attributes).
    Returns False if this is a business operation (should filter token attributes).
    """
    if step_type:
        # If step_type is explicitly set to AI provider types, it's an AI provider operation
        ai_provider_types = {"LLM", "EMBEDDING", "VECTORDB", "TOOL"}
        if str(step_type) in ai_provider_types:
            return True

    # Otherwise, check current span context
    return not _is_parent_span_context()


def _is_parent_span_context() -> bool:
    """Check if we're in a business operation context vs AI provider call context.

    Returns True for business operations (should filter token attributes).
    Returns False for AI provider calls (should allow token attributes).
    """
    current_span = get_current_span()
    if not current_span:
        return True  # Assume business operation if no current span

    # Check if this is an AI provider span
    span_name = getattr(current_span, "name", "")
    ai_provider_prefixes = [
        "openai.",
        "anthropic.",
        "gemini.",
        "bedrock.",
        "azure.openai.",
        "vertexai.",
        "cohere.",
        "mistral.",
        "huggingface.",
    ]

    # If this is an AI provider span, it's NOT a business operation context
    # (regardless of whether it's a parent or child LLM call)
    is_ai_provider_call = any(span_name.startswith(prefix) for prefix in ai_provider_prefixes)

    if is_ai_provider_call:
        return False  # AI provider calls should have token attributes

    # For non-AI provider spans, check if they have step_type="LLM"
    # If they do, they're business operations that should not have token attributes
    step_type = getattr(current_span, "attributes", {}).get("mvk.step_type", "")
    if step_type == "LLM":
        return True  # Business operation with LLM step_type should filter tokens

    # Default: assume business operation context
    return True


def signal(
    name: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    client_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    request_id: Optional[str] = None,
    region: Optional[str] = None,
    cloud_provider_code: Optional[str] = None,
    tags: Optional[Dict[str, str]] = None,
    **kwargs: Any,
) -> Callable[[F], F]:
    """Decorator to signal a function as a signal.

    This decorator:
    - ALWAYS creates a new signal (never reuses)
    - Supports selective field inheritance from parent @mvk_signal
    - Extracts traceparent from HTTP requests if applicable
    - Allows user-provided cloud_provider_code
    - step_type, operation, operation_subtype, and model are auto-instrumented by wrappers

    Args:
        name: Signal name (defaults to function name)
        session_id: Session identifier (inherits from parent @mvk_signal)
        user_id: User identifier (inherits from parent @mvk_signal)
        client_id: Client/caller identifier (inherits from parent @mvk_signal)
        tenant_id: Multi-tenant organization identifier (inherits from parent @mvk_signal)
        request_id: External request correlation ID (inherits from parent @mvk_signal)
        region: Geographic region identifier (inherits from parent @mvk_signal)
        cloud_provider_code: Optional user-provided cloud provider
        tags: Custom tags for signal attribution (will be flattened as mvk.tags.*)

    Returns:
        Decorated function

    Example:
        @mvk_signal(user_id="user-123", session_id="session-456",
                    cloud_provider_code="aws")
        def call_custom_llm(prompt: str) -> str:
            return my_custom_openai_call(prompt)
    """

    # Log warnings for unknown parameters
    if kwargs:
        logger.warning(
            f"Unknown parameters passed to @track decorator: {list(kwargs.keys())}. "
            "These parameters will be ignored. "
            f"Valid parameters are: name, session_id, user_id, client_id, tenant_id, "
            f"request_id, region, cloud_provider_code, tags"
        )

    def decorator(func: F) -> F:
        # Get function name for span name
        func_name = name or func.__name__

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            tracer = get_tracer()

            # Build span attributes with OTLP namespacing
            span_attrs = {}

            # v1.0: Check for selective inheritance from parent @mvk_signal
            parent_span = get_current_span()
            if parent_span:
                # Only inherit specific fields from parent @mvk_signal
                if hasattr(parent_span, "attributes"):
                    parent_attrs = parent_span.attributes
                    # Selective inheritance: session_id, user_id, client_id, and mvk.agent_name
                    # Empty string "" disables inheritance, None allows it
                    if "mvk.session_id" in parent_attrs and session_id is None:
                        span_attrs["mvk.session_id"] = parent_attrs["mvk.session_id"]
                    if "mvk.user_id" in parent_attrs and user_id is None:
                        span_attrs["mvk.user_id"] = parent_attrs["mvk.user_id"]
                    if "mvk.client_id" in parent_attrs and client_id is None:
                        span_attrs["mvk.client_id"] = parent_attrs["mvk.client_id"]
                    if "mvk.agent_name" in parent_attrs:
                        span_attrs["mvk.agent_name"] = parent_attrs["mvk.agent_name"]

            # Get context attributes FIRST (from global and @mvk_context)
            context_attrs = get_merged_context()

            # Check if tags inheritance is disabled by empty dict/list
            tags_disabled = False
            if tags is not None:
                if isinstance(tags, (dict, list)):
                    if (isinstance(tags, dict) and len(tags) == 0) or (
                        isinstance(tags, list) and len(tags) == 0
                    ):
                        tags_disabled = True
                        logger.debug("Empty tags dict/list detected - disabling tag inheritance")

            # ALSO check if context has empty tags dict (from @mvk_context(tags={}))
            if not tags_disabled and "tags" in context_attrs:
                context_tags = context_attrs.get("tags")
                if isinstance(context_tags, dict) and len(context_tags) == 0:
                    tags_disabled = True
                    logger.debug("Empty tags dict in context - disabling tag inheritance")

            # v1.0: Include global context with proper namespacing
            for key, value in context_attrs.items():
                # Skip token-related attributes for business operations
                # These should only be set on AI provider operations
                if (
                    _is_token_attribute(key) or _is_token_attribute(key.replace("mvk.", ""))
                ) and not _is_ai_provider_operation(None):
                    logger.debug(
                        f"Skipping token attribute {key} from context for business operation - should only be set on AI provider operations"
                    )
                    continue

                # Apply OTLP namespacing if needed
                if key == "tags" and isinstance(value, dict):
                    # Skip tag inheritance if tags explicitly set to empty dict/list
                    if tags_disabled:
                        logger.debug("Skipping tag inheritance due to empty tags parameter")
                        continue
                    # Flatten tags with mvk.tags.* prefix
                    for tag_key, tag_value in value.items():
                        span_attrs[f"mvk.tags.{tag_key}"] = tag_value
                elif key.startswith("tags."):
                    # Skip individual tag attributes if tags inheritance disabled
                    if tags_disabled:
                        logger.debug(
                            f"Skipping tag '{key}' inheritance due to empty tags parameter"
                        )
                        continue
                    # Add mvk prefix to tag attributes
                    span_attrs[f"mvk.{key}"] = value
                elif key.startswith(("service.", "mvk.tags.", "http.", "rpc.")):
                    # Already properly namespaced - keep as is
                    # Skip mvk.tags.* if tags inheritance disabled
                    if key.startswith("mvk.tags.") and tags_disabled:
                        logger.debug(
                            f"Skipping tag '{key}' inheritance due to empty tags parameter"
                        )
                        continue
                    span_attrs[key] = value
                elif key.startswith("mvk."):
                    # Already has mvk prefix
                    # Don't override inherited session_id with global context
                    if key == "mvk.session_id" and "mvk.session_id" in span_attrs:
                        continue  # Keep inherited value
                    span_attrs[key] = value
                else:
                    # Add mvk prefix to custom fields
                    # Don't override inherited fields with context
                    prefixed_key = f"mvk.{key}"
                    if (
                        prefixed_key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]
                        and prefixed_key in span_attrs
                    ):
                        continue  # Keep inherited value
                    span_attrs[prefixed_key] = value

            # Track if session_id was explicitly set to empty
            session_explicitly_empty = False

            span_attrs["mvk.signal"] = func_name
            # Add span-specific fields AFTER context (to allow override)
            # Note: step_type, operation, operation_subtype, and model are auto-instrumented by wrappers

            # Empty string "" clears the value, None allows inheritance
            if session_id is not None:
                if session_id == "":
                    # Empty string explicitly clears the field and MUST prevent auto-generation
                    span_attrs["mvk.session_id"] = ""
                    session_explicitly_empty = True
                    logger.debug("Set session_explicitly_empty=True for empty string")
                else:
                    span_attrs["mvk.session_id"] = session_id
            if user_id is not None:
                if user_id == "":
                    # Empty string explicitly clears the field
                    span_attrs["mvk.user_id"] = ""
                else:
                    span_attrs["mvk.user_id"] = user_id
            if client_id is not None:
                if client_id == "":
                    # Empty string explicitly clears the field
                    span_attrs["mvk.client_id"] = ""
                else:
                    span_attrs["mvk.client_id"] = client_id
            if tenant_id is not None:
                if tenant_id == "":
                    # Empty string explicitly clears the field
                    span_attrs["mvk.tenant_id"] = ""
                else:
                    span_attrs["mvk.tenant_id"] = tenant_id
            if request_id is not None:
                if request_id == "":
                    # Empty string explicitly clears the field
                    span_attrs["mvk.request_id"] = ""
                else:
                    span_attrs["mvk.request_id"] = request_id
            if region is not None:
                if region == "":
                    # Empty string explicitly clears the field
                    span_attrs["mvk.region"] = ""
                else:
                    span_attrs["mvk.region"] = region
            if cloud_provider_code:
                # v1.0: User-provided cloud provider only (no auto-detection)
                span_attrs["mvk.cloud_provider_code"] = cloud_provider_code

            # Handle tags with proper merging and limit enforcement
            # Extract tags from each level separately to ensure proper merging
            from .context import get_context_at_level

            global_tags = {}
            context_tags = {}
            span_tags = tags or {} if tags is not None else {}

            # Extract global tags (from instrument) - get from global level only
            global_ctx = get_context_at_level("global")
            if "tags" in global_ctx and isinstance(global_ctx["tags"], dict):
                global_tags = global_ctx["tags"].copy()

            # Extract context tags (from @context decorator) - get from stack level only
            stack_ctx = get_context_at_level("stack")
            if "tags" in stack_ctx and isinstance(stack_ctx["tags"], dict):
                context_tags = stack_ctx["tags"].copy()

            # Remove any mvk.tags.* that were added from merged context
            # We'll re-add them after proper merging with limit enforcement
            removed_tags = []
            for key in list(span_attrs.keys()):
                if key.startswith("mvk.tags."):
                    removed_tags.append(key)
                    del span_attrs[key]
            logger.debug(
                f"Tag sources - global: {list(global_tags.keys())}, context: {list(context_tags.keys())}, span: {list(span_tags.keys())}, removed from attrs: {removed_tags}"
            )

            # Handle empty tags (disable inheritance)
            if tags_disabled:
                # Skip tag merging if tags explicitly set to empty
                logger.debug("Empty tags dict/list detected - skipping tag merging")
            else:
                # Merge tags with proper priority and limit enforcement
                merged_tags = merge_tags_with_limit(
                    global_tags,
                    context_tags,
                    span_tags,
                    source_names=["instrument()", "context()", "signal()"],
                )

                # Add merged tags to span attributes with proper namespacing
                for tag_key, tag_value in merged_tags.items():
                    span_attrs[f"mvk.tags.{tag_key}"] = tag_value
            # Note: step_type is now auto-instrumented by wrappers, not set by @track

            # v1.0: Auto-generate session_id if not present at root span
            # If this is a root span (no parent) and no session_id, generate one
            # BUT NOT if user explicitly set it to empty string
            logger.debug(
                f"Session auto-gen check: parent_span={parent_span}, session_id_in_attrs={'mvk.session_id' in span_attrs}, session_explicitly_empty={session_explicitly_empty}"
            )
            if (
                not parent_span
                and "mvk.session_id" not in span_attrs
                and not session_explicitly_empty
            ):
                import uuid

                span_attrs["mvk.session_id"] = str(uuid.uuid4())
                logger.debug(f"Auto-generated session_id: {span_attrs['mvk.session_id']}")
            else:
                logger.debug(
                    f"Skipped auto-generation: parent_span={parent_span}, session_id_in_attrs={'mvk.session_id' in span_attrs}, session_explicitly_empty={session_explicitly_empty}"
                )

            # v1.0: ALWAYS create new span (never reuse)
            # Don't inherit context again - we already merged it above
            span = None
            try:
                span = tracer.start_span(
                    func_name,
                    kind=None,  # kind is auto-instrumented by wrappers
                    inherit_context=False,
                    **span_attrs,
                )
            except Exception:  # pylint: disable=broad-except
                # SDK initialization failed - call original without instrumentation
                logger.debug(f"Failed to instrument {func_name}, calling original")
                return func(*args, **kwargs)

            # Execute user function with span
            try:
                # Use context manager for proper span lifecycle
                with span:
                    result = func(*args, **kwargs)
                    return result
            except Exception as e:
                # Record user exception but let it propagate
                if span:
                    span.set_error(e)
                raise  # User exceptions always propagate

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = get_tracer()

            # Build span attributes (same as sync)
            span_attrs = {}

            # v1.0: Check for selective inheritance from parent @mvk_signal
            parent_span = get_current_span()
            if parent_span:
                # Only inherit specific fields from parent @mvk_signal
                if hasattr(parent_span, "attributes"):
                    parent_attrs = parent_span.attributes
                    # Selective inheritance: session_id, user_id, client_id, and mvk.agent_name
                    # Empty string "" disables inheritance, None allows it
                    if "mvk.session_id" in parent_attrs and session_id is None:
                        span_attrs["mvk.session_id"] = parent_attrs["mvk.session_id"]
                    if "mvk.user_id" in parent_attrs and user_id is None:
                        span_attrs["mvk.user_id"] = parent_attrs["mvk.user_id"]
                    if "mvk.client_id" in parent_attrs and client_id is None:
                        span_attrs["mvk.client_id"] = parent_attrs["mvk.client_id"]
                    if "mvk.agent_name" in parent_attrs:
                        span_attrs["mvk.agent_name"] = parent_attrs["mvk.agent_name"]

            # Get context attributes FIRST (from global and @mvk_context)
            context_attrs = get_merged_context()

            # Check if tags inheritance is disabled by empty dict/list
            tags_disabled = False
            if tags is not None:
                if isinstance(tags, (dict, list)):
                    if (isinstance(tags, dict) and len(tags) == 0) or (
                        isinstance(tags, list) and len(tags) == 0
                    ):
                        tags_disabled = True
                        logger.debug("Empty tags dict/list detected - disabling tag inheritance")

            # ALSO check if context has empty tags dict (from @mvk_context(tags={}))
            if not tags_disabled and "tags" in context_attrs:
                context_tags = context_attrs.get("tags")
                if isinstance(context_tags, dict) and len(context_tags) == 0:
                    tags_disabled = True
                    logger.debug("Empty tags dict in context - disabling tag inheritance")

            # v1.0: Include global context with proper namespacing
            for key, value in context_attrs.items():
                # Skip token-related attributes for business operations
                # These should only be set on AI provider operations
                if (
                    _is_token_attribute(key) or _is_token_attribute(key.replace("mvk.", ""))
                ) and not _is_ai_provider_operation(None):
                    logger.debug(
                        f"Skipping token attribute {key} from context for business operation - should only be set on AI provider operations"
                    )
                    continue

                # Apply OTLP namespacing if needed
                if key == "tags" and isinstance(value, dict):
                    # Skip tag inheritance if tags explicitly set to empty dict/list
                    if tags_disabled:
                        logger.debug("Skipping tag inheritance due to empty tags parameter")
                        continue
                    # Flatten tags with mvk.tags.* prefix
                    for tag_key, tag_value in value.items():
                        span_attrs[f"mvk.tags.{tag_key}"] = tag_value
                elif key.startswith("tags."):
                    # Skip individual tag attributes if tags inheritance disabled
                    if tags_disabled:
                        logger.debug(
                            f"Skipping tag '{key}' inheritance due to empty tags parameter"
                        )
                        continue
                    # Add mvk prefix to tag attributes
                    span_attrs[f"mvk.{key}"] = value
                elif key.startswith(("service.", "mvk.tags.", "http.", "rpc.")):
                    # Already properly namespaced - keep as is
                    # Skip mvk.tags.* if tags inheritance disabled
                    if key.startswith("mvk.tags.") and tags_disabled:
                        logger.debug(
                            f"Skipping tag '{key}' inheritance due to empty tags parameter"
                        )
                        continue
                    span_attrs[key] = value
                elif key.startswith("mvk."):
                    # Already has mvk prefix
                    # Don't override inherited session_id with global context
                    if key == "mvk.session_id" and "mvk.session_id" in span_attrs:
                        continue  # Keep inherited value
                    span_attrs[key] = value
                else:
                    # Add mvk prefix to custom fields
                    # Don't override inherited fields with context
                    prefixed_key = f"mvk.{key}"
                    if (
                        prefixed_key in ["mvk.session_id", "mvk.user_id", "mvk.client_id"]
                        and prefixed_key in span_attrs
                    ):
                        continue  # Keep inherited value
                    span_attrs[prefixed_key] = value

            # Track if session_id was explicitly set to empty
            session_explicitly_empty = False

            # Add span-specific fields AFTER context (to allow override)            # Empty string "" clears the value, None allows inheritance
            if session_id is not None:
                if session_id == "":
                    # Empty string removes the field
                    span_attrs.pop("mvk.session_id", None)
                    session_explicitly_empty = True
                    logger.debug("Set session_explicitly_empty=True for empty string")
                else:
                    span_attrs["mvk.session_id"] = session_id
            if user_id is not None:
                if user_id == "":
                    # Empty string removes the field
                    span_attrs.pop("mvk.user_id", None)
                else:
                    span_attrs["mvk.user_id"] = user_id
            if client_id is not None:
                if client_id == "":
                    # Empty string removes the field
                    span_attrs.pop("mvk.client_id", None)
                else:
                    span_attrs["mvk.client_id"] = client_id
            if cloud_provider_code:
                # v1.0: User-provided cloud provider only (no auto-detection)
                span_attrs["mvk.cloud_provider_code"] = cloud_provider_code

            # Handle tags with proper merging and limit enforcement
            # Extract tags from each level separately to ensure proper merging
            from .context import get_context_at_level

            global_tags = {}
            context_tags = {}
            span_tags = tags or {} if tags is not None else {}

            # Extract global tags (from instrument) - get from global level only
            global_ctx = get_context_at_level("global")
            if "tags" in global_ctx and isinstance(global_ctx["tags"], dict):
                global_tags = global_ctx["tags"].copy()

            # Extract context tags (from @context decorator) - get from stack level only
            stack_ctx = get_context_at_level("stack")
            if "tags" in stack_ctx and isinstance(stack_ctx["tags"], dict):
                context_tags = stack_ctx["tags"].copy()

            # Remove any mvk.tags.* that were added from merged context
            # We'll re-add them after proper merging with limit enforcement
            removed_tags = []
            for key in list(span_attrs.keys()):
                if key.startswith("mvk.tags."):
                    removed_tags.append(key)
                    del span_attrs[key]
            logger.debug(
                f"Tag sources - global: {list(global_tags.keys())}, context: {list(context_tags.keys())}, span: {list(span_tags.keys())}, removed from attrs: {removed_tags}"
            )

            # Handle empty tags (disable inheritance)
            if tags_disabled:
                # Skip tag merging if tags explicitly set to empty
                logger.debug("Empty tags dict/list detected - skipping tag merging")
            else:
                # Merge tags with proper priority and limit enforcement
                merged_tags = merge_tags_with_limit(
                    global_tags,
                    context_tags,
                    span_tags,
                    source_names=["instrument()", "context()", "signal()"],
                )

                # Add merged tags to span attributes with proper namespacing
                for tag_key, tag_value in merged_tags.items():
                    span_attrs[f"mvk.tags.{tag_key}"] = tag_value
            # Note: step_type is now auto-instrumented by wrappers, not set by @track

            # v1.0: Auto-generate session_id if not present at root span
            # If this is a root span (no parent) and no session_id, generate one
            # BUT NOT if user explicitly set it to empty string
            logger.debug(
                f"Session auto-gen check: parent_span={parent_span}, session_id_in_attrs={'mvk.session_id' in span_attrs}, session_explicitly_empty={session_explicitly_empty}"
            )
            if (
                not parent_span
                and "mvk.session_id" not in span_attrs
                and not session_explicitly_empty
            ):
                import uuid

                span_attrs["mvk.session_id"] = str(uuid.uuid4())
                logger.debug(f"Auto-generated session_id: {span_attrs['mvk.session_id']}")
            else:
                logger.debug(
                    f"Skipped auto-generation: parent_span={parent_span}, session_id_in_attrs={'mvk.session_id' in span_attrs}, session_explicitly_empty={session_explicitly_empty}"
                )

            # v1.0: ALWAYS create new span (never reuse)
            # Don't inherit context again - we already merged it above
            span = None
            try:
                span = tracer.start_span(
                    func_name,
                    kind=None,  # kind is auto-instrumented by wrappers
                    inherit_context=False,
                    **span_attrs,
                )
            except Exception:  # pylint: disable=broad-except
                # SDK initialization failed - call original without instrumentation
                logger.debug(f"Failed to instrument async {func_name}, calling original")
                return await func(*args, **kwargs)

            # Execute async user function with span
            try:
                # Use async context manager for proper span lifecycle
                async with span:
                    result = await func(*args, **kwargs)
                    return result
            except Exception as e:
                # Record user exception but let it propagate
                if span:
                    span.set_error(e)
                raise  # User exceptions always propagate

        # Return appropriate wrapper
        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        else:
            return sync_wrapper  # type: ignore

    return decorator


class context:
    """Context manager and decorator for setting context attributes.

    This unified interface replaces both @mvk_signal decorator and
    with mvk_signal_context() from v2.1.

    Can be used as both decorator and context manager:

    As decorator:
        @mvk_context(user_id="u-123", session_id="s-456", region="us-east-1")
        def process_request():
            pass

    As context manager:
        with mvk_context(user_id="u-123", session_id="s-456", region="us-east-1"):
            process_request()
    """

    def __init__(
        self,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        client_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        request_id: Optional[str] = None,
        region: Optional[str] = None,
        cloud_provider_code: Optional[str] = None,
        use_case_id: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ):
        """Initialize with context attributes.

        Args:
            name: Context name for identification (will be prefixed as mvk.name in spans)
            user_id: End-user identity for correlation (will be prefixed as mvk.user_id in spans)
            session_id: Session identifier for workflow correlation (will be prefixed as mvk.session_id in spans)
            client_id: Calling application/client identity (will be prefixed as mvk.client_id in spans)
            tenant_id: Multi-tenant organization identifier (will be prefixed as mvk.tenant_id in spans)
            request_id: External request correlation ID (will be prefixed as mvk.request_id in spans)
            region: Geographic region identifier (will be prefixed as mvk.region in spans)
            cloud_provider_code: Cloud provider code (will be prefixed as mvk.cloud_provider_code in spans)
            use_case_id: Use case identifier for business logic correlation (will be prefixed as mvk.use_case_id in spans)
            tags: Custom tags for span attribution (will be flattened as mvk.tags.*)
        """
        self.attributes: Dict[str, Any] = {}

        # Log warnings for unknown parameters
        if kwargs:
            logger.warning(
                f"Unknown parameters passed to context: {list(kwargs.keys())}. "
                "These parameters will be ignored. "
                f"Valid parameters are: name, user_id, session_id, client_id, tenant_id, "
                f"request_id, region, cloud_provider_code, use_case_id, tags"
            )

        # Handle all explicit parameters
        if name is not None:
            self.attributes["name"] = name
        if user_id is not None:
            self.attributes["user_id"] = user_id
        if session_id is not None:
            self.attributes["session_id"] = session_id
        if client_id is not None:
            self.attributes["client_id"] = client_id
        if tenant_id is not None:
            self.attributes["tenant_id"] = tenant_id
        if request_id is not None:
            self.attributes["request_id"] = request_id
        if region is not None:
            self.attributes["region"] = region
        if cloud_provider_code is not None:
            self.attributes["cloud_provider_code"] = cloud_provider_code
        if use_case_id is not None:
            self.attributes["use_case_id"] = use_case_id
        if tags is not None:
            self.attributes["tags"] = tags

    def __enter__(self):
        """Enter context manager - push attributes to context stack."""
        # Generate trace_id for this context if not already set
        # This allows all @mvk.signal() calls within this context to share the same trace
        # Store in separate context var to avoid polluting user-visible context
        from .context import get_trace_id, set_trace_id
        from .mvk_tracer import generate_trace_id

        current_trace_id = get_trace_id()
        if not current_trace_id:
            # No existing trace_id in context - generate a new one
            new_trace_id = generate_trace_id()
            set_trace_id(new_trace_id)
            logger.debug(f"Generated new trace_id for context: {new_trace_id}")

        push_context(self.attributes)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager - pop attributes from context stack."""
        from .context import clear_trace_id

        pop_context()
        # Clear trace_id when exiting context to avoid leaking to next context
        clear_trace_id()
        return False

    def __call__(self, func: F) -> F:
        """Decorator mode - wrap function with context."""

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            with self:
                return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            with self:
                return await func(*args, **kwargs)

        # Return appropriate wrapper
        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        else:
            return sync_wrapper  # type: ignore
